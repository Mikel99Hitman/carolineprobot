const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('iot-smart-home')
        .setDescription('IoT & Smart Home Integration System')
        .addSubcommand(subcommand =>
            subcommand
                .setName('device-control')
                .setDescription('Control smart home devices')
                .addStringOption(option =>
                    option.setName('device_type')
                        .setDescription('Type of smart device')
                        .addChoices(
                            { name: 'Smart Lights', value: 'lights' },
                            { name: 'Thermostat', value: 'thermostat' },
                            { name: 'Security Cameras', value: 'cameras' },
                            { name: 'Smart Locks', value: 'locks' },
                            { name: 'Voice Assistant', value: 'assistant' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('automation-rules')
                .setDescription('Create smart home automation rules')
                .addStringOption(option =>
                    option.setName('rule_type')
                        .setDescription('Type of automation rule')
                        .addChoices(
                            { name: 'Time-based', value: 'time' },
                            { name: 'Sensor-triggered', value: 'sensor' },
                            { name: 'Location-based', value: 'location' },
                            { name: 'Weather-based', value: 'weather' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('energy-monitoring')
                .setDescription('Monitor and optimize energy consumption')
                .addStringOption(option =>
                    option.setName('monitoring_scope')
                        .setDescription('Monitoring scope')
                        .addChoices(
                            { name: 'Whole House', value: 'house' },
                            { name: 'Individual Devices', value: 'devices' },
                            { name: 'Room by Room', value: 'rooms' },
                            { name: 'Solar System', value: 'solar' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('security-system')
                .setDescription('Advanced home security management')
                .addStringOption(option =>
                    option.setName('security_feature')
                        .setDescription('Security feature to manage')
                        .addChoices(
                            { name: 'Intrusion Detection', value: 'intrusion' },
                            { name: 'Fire Safety', value: 'fire' },
                            { name: 'Water Leak Detection', value: 'water' },
                            { name: 'Air Quality Monitoring', value: 'air' }
                        ))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        switch (subcommand) {
            case 'device-control':
                await this.deviceControl(interaction);
                break;
            case 'automation-rules':
                await this.automationRules(interaction);
                break;
            case 'energy-monitoring':
                await this.energyMonitoring(interaction);
                break;
            case 'security-system':
                await this.securitySystem(interaction);
                break;
        }
    },

    async deviceControl(interaction) {
        await interaction.deferReply();

        const deviceType = interaction.options.getString('device_type') || 'lights';
        const deviceData = this.generateDeviceData(deviceType);

        const embed = new EmbedBuilder()
            .setTitle('🏠 Smart Home Device Control')
            .setDescription('Advanced IoT device management and control')
            .addFields(
                { name: '📱 Device Type', value: deviceData.deviceName, inline: true },
                { name: '🔌 Status', value: deviceData.status, inline: true },
                { name: '📊 Connected Devices', value: deviceData.connectedDevices, inline: true },
                { name: '⚡ Power Consumption', value: deviceData.powerConsumption, inline: true },
                { name: '📡 Network Status', value: deviceData.networkStatus, inline: true },
                { name: '🔋 Battery Level', value: deviceData.batteryLevel, inline: true },
                { name: '🎛️ Available Controls', value: deviceData.controls.join('\n'), inline: false },
                { name: '📊 Device Analytics', value: deviceData.analytics.join('\n'), inline: false },
                { name: '🔧 Maintenance Status', value: deviceData.maintenance.join('\n'), inline: false }
            )
            .setColor('#00bcd4')
            .setTimestamp()
            .setFooter({ text: 'Smart Home • IoT Integration' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('device_settings')
                    .setLabel('⚙️ Device Settings')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('create_scene')
                    .setLabel('🎭 Create Scene')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('device_diagnostics')
                    .setLabel('🔍 Diagnostics')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async automationRules(interaction) {
        await interaction.deferReply();

        const ruleType = interaction.options.getString('rule_type') || 'time';
        const automationData = this.generateAutomationData(ruleType);

        const embed = new EmbedBuilder()
            .setTitle('🤖 Smart Home Automation Rules')
            .setDescription('Intelligent automation for enhanced living experience')
            .addFields(
                { name: '🎯 Rule Type', value: automationData.ruleName, inline: true },
                { name: '⚡ Active Rules', value: automationData.activeRules, inline: true },
                { name: '📊 Success Rate', value: automationData.successRate, inline: true },
                { name: '🔄 Executions Today', value: automationData.executionsToday, inline: true },
                { name: '💡 Energy Saved', value: automationData.energySaved, inline: true },
                { name: '🎯 Efficiency Score', value: automationData.efficiencyScore, inline: true },
                { name: '🎛️ Suggested Rules', value: automationData.suggestedRules.join('\n'), inline: false },
                { name: '📈 Optimization Tips', value: automationData.optimizationTips.join('\n'), inline: false },
                { name: '🔮 AI Predictions', value: automationData.aiPredictions.join('\n'), inline: false }
            )
            .setColor('#4caf50')
            .setTimestamp()
            .setFooter({ text: 'Home Automation • AI-Powered Rules' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('create_rule')
                    .setLabel('➕ Create Rule')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('rule_templates')
                    .setLabel('📋 Templates')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('ai_suggestions')
                    .setLabel('🧠 AI Suggestions')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async energyMonitoring(interaction) {
        await interaction.deferReply();

        const scope = interaction.options.getString('monitoring_scope') || 'house';
        const energyData = this.generateEnergyData(scope);

        const embed = new EmbedBuilder()
            .setTitle('⚡ Smart Energy Monitoring')
            .setDescription('Advanced energy consumption analysis and optimization')
            .addFields(
                { name: '🏠 Monitoring Scope', value: energyData.scopeName, inline: true },
                { name: '⚡ Current Usage', value: energyData.currentUsage, inline: true },
                { name: '💰 Monthly Cost', value: energyData.monthlyCost, inline: true },
                { name: '📊 Peak Demand', value: energyData.peakDemand, inline: true },
                { name: '🌱 Carbon Footprint', value: energyData.carbonFootprint, inline: true },
                { name: '💡 Efficiency Rating', value: energyData.efficiencyRating, inline: true },
                { name: '📈 Usage Breakdown', value: energyData.usageBreakdown.join('\n'), inline: false },
                { name: '💰 Cost Optimization', value: energyData.costOptimization.join('\n'), inline: false },
                { name: '🌿 Sustainability Tips', value: energyData.sustainabilityTips.join('\n'), inline: false }
            )
            .setColor('#ff9800')
            .setTimestamp()
            .setFooter({ text: 'Energy Monitoring • Smart Optimization' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('energy_report')
                    .setLabel('📊 Detailed Report')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('set_budget')
                    .setLabel('💰 Set Budget')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('solar_calculator')
                    .setLabel('☀️ Solar Calculator')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async securitySystem(interaction) {
        await interaction.deferReply();

        const feature = interaction.options.getString('security_feature') || 'intrusion';
        const securityData = this.generateSecurityData(feature);

        const embed = new EmbedBuilder()
            .setTitle('🛡️ Advanced Home Security System')
            .setDescription('Comprehensive security monitoring and protection')
            .addFields(
                { name: '🔒 Security Feature', value: securityData.featureName, inline: true },
                { name: '🚨 System Status', value: securityData.systemStatus, inline: true },
                { name: '📊 Threat Level', value: securityData.threatLevel, inline: true },
                { name: '📱 Active Sensors', value: securityData.activeSensors, inline: true },
                { name: '🔔 Alerts Today', value: securityData.alertsToday, inline: true },
                { name: '🎯 Response Time', value: securityData.responseTime, inline: true },
                { name: '🛡️ Protection Features', value: securityData.protectionFeatures.join('\n'), inline: false },
                { name: '📊 Security Analytics', value: securityData.analytics.join('\n'), inline: false },
                { name: '🚨 Emergency Protocols', value: securityData.emergencyProtocols.join('\n'), inline: false }
            )
            .setColor('#f44336')
            .setTimestamp()
            .setFooter({ text: 'Home Security • 24/7 Protection' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('arm_system')
                    .setLabel('🔒 Arm System')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('security_cameras')
                    .setLabel('📹 View Cameras')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('emergency_contacts')
                    .setLabel('📞 Emergency Contacts')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    generateDeviceData(deviceType) {
        const devices = {
            lights: {
                deviceName: 'Smart LED Lighting System',
                status: '🟢 Online (12/15 devices)',
                connectedDevices: '15 bulbs',
                powerConsumption: '127W total',
                networkStatus: '🟢 Strong WiFi',
                batteryLevel: 'N/A (Wired)',
                controls: [
                    '💡 Brightness: 0-100%',
                    '🌈 Color: 16M colors',
                    '⏰ Scheduling: Custom timers',
                    '🎭 Scenes: 12 presets available'
                ],
                analytics: [
                    '📊 Daily usage: 8.5 hours average',
                    '💰 Monthly cost: $12.40',
                    '🌱 Energy efficiency: 89%',
                    '🔄 Most used: Living room (34%)'
                ],
                maintenance: [
                    '✅ All devices functioning normally',
                    '🔄 Last update: 2 days ago',
                    '⚠️ 1 bulb needs replacement soon',
                    '📅 Next maintenance: In 3 months'
                ]
            },
            thermostat: {
                deviceName: 'Smart Climate Control',
                status: '🟢 Active (Heating mode)',
                connectedDevices: '3 zones',
                powerConsumption: '2.4kW',
                networkStatus: '🟢 Connected',
                batteryLevel: '87%',
                controls: [
                    '🌡️ Temperature: 18-28°C',
                    '💨 Fan speed: Auto/Manual',
                    '⏰ Schedule: 7-day program',
                    '🏠 Zones: Individual control'
                ]
            }
        };

        return devices[deviceType] || devices.lights;
    },

    generateAutomationData(ruleType) {
        return {
            ruleName: ruleType.charAt(0).toUpperCase() + ruleType.slice(1) + '-based Automation',
            activeRules: '23 rules',
            successRate: '98.7%',
            executionsToday: '47 times',
            energySaved: '12.4 kWh',
            efficiencyScore: '9.2/10',
            suggestedRules: [
                '🌅 Morning routine: Gradual light increase',
                '🌙 Bedtime: Auto-lock doors and dim lights',
                '🏃 Away mode: Energy-saving settings',
                '🎬 Movie night: Ambient lighting scene'
            ],
            optimizationTips: [
                '⏰ Adjust schedules based on usage patterns',
                '📊 Use occupancy sensors for efficiency',
                '🌡️ Optimize temperature settings',
                '💡 Group similar devices for better control'
            ],
            aiPredictions: [
                '🔮 Predicted 15% energy savings next month',
                '📈 Usage pattern suggests new rule opportunities',
                '🎯 Optimal automation timing identified',
                '🌱 Carbon footprint reduction: 8.3%'
            ]
        };
    },

    generateEnergyData(scope) {
        return {
            scopeName: scope.charAt(0).toUpperCase() + scope.slice(1) + ' Energy Monitoring',
            currentUsage: '3.2 kW',
            monthlyCost: '$187.45',
            peakDemand: '5.8 kW',
            carbonFootprint: '1.2 tons CO₂/month',
            efficiencyRating: 'A+ (92%)',
            usageBreakdown: [
                '🏠 HVAC System: 45% (2.1 kW)',
                '💡 Lighting: 18% (0.8 kW)',
                '📺 Electronics: 22% (1.0 kW)',
                '🔌 Appliances: 15% (0.7 kW)'
            ],
            costOptimization: [
                '💰 Switch to off-peak hours: Save $23/month',
                '🌡️ Adjust thermostat 2°C: Save $31/month',
                '💡 LED upgrade remaining bulbs: Save $8/month',
                '⚡ Smart power strips: Save $12/month'
            ],
            sustainabilityTips: [
                '☀️ Consider solar panels (ROI: 7 years)',
                '🔋 Battery storage for peak shaving',
                '🌱 Energy-efficient appliance upgrades',
                '📊 Real-time monitoring for awareness'
            ]
        };
    },

    generateSecurityData(feature) {
        const features = {
            intrusion: {
                featureName: 'Intrusion Detection System',
                systemStatus: '🟢 Armed & Active',
                threatLevel: '🟢 Low Risk',
                activeSensors: '18/20 sensors',
                alertsToday: '0 alerts',
                responseTime: '<30 seconds',
                protectionFeatures: [
                    '🚪 Door/Window sensors: 12 active',
                    '👁️ Motion detectors: 6 zones covered',
                    '📹 Security cameras: 8 HD cameras',
                    '🔊 Glass break sensors: 4 installed'
                ],
                analytics: [
                    '📊 System uptime: 99.8%',
                    '🎯 False alarm rate: 0.2%',
                    '⚡ Average response: 18 seconds',
                    '📈 Security score: 9.4/10'
                ],
                emergencyProtocols: [
                    '🚨 Immediate alert to security company',
                    '📞 Auto-call to emergency contacts',
                    '📹 Automatic video recording',
                    '🔊 Siren activation (110dB)'
                ]
            }
        };

        return features[feature] || features.intrusion;
    }
};