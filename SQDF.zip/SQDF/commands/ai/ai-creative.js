const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ai-creative')
        .setDescription('AI Creative Assistant (Arabic/English)')
        .addSubcommand(subcommand =>
            subcommand
                .setName('story-writer')
                .setDescription('Generate creative stories')
                .addStringOption(option =>
                    option.setName('genre')
                        .setDescription('Story genre')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Adventure', value: 'adventure' },
                            { name: 'Mystery', value: 'mystery' },
                            { name: 'Romance', value: 'romance' },
                            { name: 'Sci-Fi', value: 'scifi' },
                            { name: 'Fantasy', value: 'fantasy' }
                        ))
                .addStringOption(option =>
                    option.setName('theme')
                        .setDescription('Story theme or prompt')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('language')
                        .setDescription('Story language')
                        .addChoices(
                            { name: 'English', value: 'en' },
                            { name: 'العربية', value: 'ar' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('poem-generator')
                .setDescription('Create beautiful poems')
                .addStringOption(option =>
                    option.setName('style')
                        .setDescription('Poetry style')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Classical', value: 'classical' },
                            { name: 'Modern Free Verse', value: 'modern' },
                            { name: 'Haiku', value: 'haiku' },
                            { name: 'Arabic Traditional', value: 'arabic_traditional' }
                        ))
                .addStringOption(option =>
                    option.setName('topic')
                        .setDescription('Poem topic')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('script-writer')
                .setDescription('Generate scripts and dialogues')
                .addStringOption(option =>
                    option.setName('type')
                        .setDescription('Script type')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Short Film', value: 'short_film' },
                            { name: 'Theater Play', value: 'theater' },
                            { name: 'Podcast', value: 'podcast' },
                            { name: 'YouTube Video', value: 'youtube' }
                        ))
                .addStringOption(option =>
                    option.setName('concept')
                        .setDescription('Script concept')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('creative-brainstorm')
                .setDescription('AI brainstorming for creative projects')
                .addStringOption(option =>
                    option.setName('project_type')
                        .setDescription('Type of creative project')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Book/Novel', value: 'book' },
                            { name: 'Game Concept', value: 'game' },
                            { name: 'Art Project', value: 'art' },
                            { name: 'Business Idea', value: 'business' },
                            { name: 'Social Campaign', value: 'campaign' }
                        ))
                .addStringOption(option =>
                    option.setName('brief')
                        .setDescription('Project brief or initial idea')
                        .setRequired(true))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        switch (subcommand) {
            case 'story-writer':
                await this.generateStory(interaction);
                break;
            case 'poem-generator':
                await this.generatePoem(interaction);
                break;
            case 'script-writer':
                await this.generateScript(interaction);
                break;
            case 'creative-brainstorm':
                await this.creativeBrainstorm(interaction);
                break;
        }
    },

    async generateStory(interaction) {
        await interaction.deferReply();

        const genre = interaction.options.getString('genre');
        const theme = interaction.options.getString('theme');
        const language = interaction.options.getString('language') || this.detectLanguage(theme);

        const story = this.createStory(genre, theme, language);

        const embed = new EmbedBuilder()
            .setTitle(language === 'ar' ? '📖 كاتب القصص الذكي' : '📖 AI Story Writer')
            .setDescription(language === 'ar' ? 'قصة إبداعية مُولدة بالذكاء الاصطناعي' : 'Creative story generated by AI')
            .addFields(
                { name: language === 'ar' ? '🎭 النوع' : '🎭 Genre', value: genre.charAt(0).toUpperCase() + genre.slice(1), inline: true },
                { name: language === 'ar' ? '🎯 الموضوع' : '🎯 Theme', value: theme, inline: true },
                { name: language === 'ar' ? '🌐 اللغة' : '🌐 Language', value: language === 'ar' ? 'العربية' : 'English', inline: true },
                { name: language === 'ar' ? '📊 طول القصة' : '📊 Story Length', value: `${story.wordCount} ${language === 'ar' ? 'كلمة' : 'words'}`, inline: true },
                { name: language === 'ar' ? '⏱️ وقت القراءة' : '⏱️ Reading Time', value: `${Math.ceil(story.wordCount / 200)} ${language === 'ar' ? 'دقائق' : 'minutes'}`, inline: true },
                { name: language === 'ar' ? '🎨 الأسلوب' : '🎨 Style', value: story.style, inline: true }
            )
            .setColor('#e67e22')
            .setTimestamp();

        // Add story content
        embed.addFields({
            name: language === 'ar' ? '📚 القصة' : '📚 Story',
            value: `\`\`\`\n${story.content.substring(0, 1000)}${story.content.length > 1000 ? '...' : ''}\n\`\`\``,
            inline: false
        });

        // Add story analysis
        embed.addFields({
            name: language === 'ar' ? '🔍 تحليل القصة' : '🔍 Story Analysis',
            value: story.analysis.join('\n'),
            inline: false
        });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('continue_story')
                    .setLabel(language === 'ar' ? '➡️ متابعة القصة' : '➡️ Continue Story')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('rewrite_story')
                    .setLabel(language === 'ar' ? '🔄 إعادة كتابة' : '🔄 Rewrite')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('story_variations')
                    .setLabel(language === 'ar' ? '🎭 نسخ مختلفة' : '🎭 Variations')
                    .setStyle(ButtonStyle.Success)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async generatePoem(interaction) {
        await interaction.deferReply();

        const style = interaction.options.getString('style');
        const topic = interaction.options.getString('topic');
        const language = this.detectLanguage(topic);

        const poem = this.createPoem(style, topic, language);

        const embed = new EmbedBuilder()
            .setTitle(language === 'ar' ? '🌹 مولد الشعر الذكي' : '🌹 AI Poetry Generator')
            .setDescription(language === 'ar' ? 'قصيدة إبداعية مُولدة بالذكاء الاصطناعي' : 'Creative poem generated by AI')
            .addFields(
                { name: language === 'ar' ? '🎨 الأسلوب' : '🎨 Style', value: style.replace('_', ' ').charAt(0).toUpperCase() + style.replace('_', ' ').slice(1), inline: true },
                { name: language === 'ar' ? '🎯 الموضوع' : '🎯 Topic', value: topic, inline: true },
                { name: language === 'ar' ? '📊 عدد الأبيات' : '📊 Verses', value: `${poem.verses}`, inline: true },
                { name: language === 'ar' ? '🎵 البحر الشعري' : '🎵 Meter', value: poem.meter, inline: true },
                { name: language === 'ar' ? '💫 المزاج' : '💫 Mood', value: poem.mood, inline: true },
                { name: language === 'ar' ? '🌟 التقييم' : '🌟 Rating', value: poem.rating, inline: true }
            )
            .setColor('#9b59b6')
            .setTimestamp();

        // Add poem content
        embed.addFields({
            name: language === 'ar' ? '📜 القصيدة' : '📜 Poem',
            value: `\`\`\`\n${poem.content}\n\`\`\``,
            inline: false
        });

        // Add literary analysis
        embed.addFields({
            name: language === 'ar' ? '🔍 التحليل الأدبي' : '🔍 Literary Analysis',
            value: poem.analysis.join('\n'),
            inline: false
        });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('extend_poem')
                    .setLabel(language === 'ar' ? '➕ إضافة أبيات' : '➕ Add Verses')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('change_style')
                    .setLabel(language === 'ar' ? '🎨 تغيير الأسلوب' : '🎨 Change Style')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('poem_music')
                    .setLabel(language === 'ar' ? '🎵 إضافة لحن' : '🎵 Add Melody')
                    .setStyle(ButtonStyle.Success)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async generateScript(interaction) {
        await interaction.deferReply();

        const type = interaction.options.getString('type');
        const concept = interaction.options.getString('concept');
        const language = this.detectLanguage(concept);

        const script = this.createScript(type, concept, language);

        const embed = new EmbedBuilder()
            .setTitle(language === 'ar' ? '🎬 كاتب السيناريو الذكي' : '🎬 AI Script Writer')
            .setDescription(language === 'ar' ? 'سيناريو احترافي مُولد بالذكاء الاصطناعي' : 'Professional script generated by AI')
            .addFields(
                { name: language === 'ar' ? '🎭 النوع' : '🎭 Type', value: type.replace('_', ' ').charAt(0).toUpperCase() + type.replace('_', ' ').slice(1), inline: true },
                { name: language === 'ar' ? '💡 المفهوم' : '💡 Concept', value: concept, inline: true },
                { name: language === 'ar' ? '⏱️ المدة المقدرة' : '⏱️ Estimated Duration', value: script.duration, inline: true },
                { name: language === 'ar' ? '👥 عدد الشخصيات' : '👥 Characters', value: `${script.characters.length}`, inline: true },
                { name: language === 'ar' ? '🎯 الجمهور المستهدف' : '🎯 Target Audience', value: script.audience, inline: true },
                { name: language === 'ar' ? '📊 مستوى الصعوبة' : '📊 Complexity', value: script.complexity, inline: true }
            )
            .setColor('#e74c3c')
            .setTimestamp();

        // Add characters
        embed.addFields({
            name: language === 'ar' ? '👥 الشخصيات' : '👥 Characters',
            value: script.characters.join('\n'),
            inline: false
        });

        // Add script excerpt
        embed.addFields({
            name: language === 'ar' ? '🎬 مقطع من السيناريو' : '🎬 Script Excerpt',
            value: `\`\`\`\n${script.excerpt}\n\`\`\``,
            inline: false
        });

        // Add production notes
        embed.addFields({
            name: language === 'ar' ? '📝 ملاحظات الإنتاج' : '📝 Production Notes',
            value: script.notes.join('\n'),
            inline: false
        });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('full_script')
                    .setLabel(language === 'ar' ? '📄 السيناريو كاملاً' : '📄 Full Script')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('character_development')
                    .setLabel(language === 'ar' ? '👤 تطوير الشخصيات' : '👤 Character Development')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('storyboard')
                    .setLabel(language === 'ar' ? '🎨 لوحة القصة' : '🎨 Storyboard')
                    .setStyle(ButtonStyle.Success)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async creativeBrainstorm(interaction) {
        await interaction.deferReply();

        const projectType = interaction.options.getString('project_type');
        const brief = interaction.options.getString('brief');
        const language = this.detectLanguage(brief);

        const brainstorm = this.generateBrainstorm(projectType, brief, language);

        const embed = new EmbedBuilder()
            .setTitle(language === 'ar' ? '🧠 العصف الذهني الإبداعي' : '🧠 Creative Brainstorming')
            .setDescription(language === 'ar' ? 'أفكار إبداعية مُولدة بالذكاء الاصطناعي' : 'Creative ideas generated by AI')
            .addFields(
                { name: language === 'ar' ? '🎯 نوع المشروع' : '🎯 Project Type', value: projectType.replace('_', ' ').charAt(0).toUpperCase() + projectType.replace('_', ' ').slice(1), inline: true },
                { name: language === 'ar' ? '💡 الفكرة الأولية' : '💡 Initial Brief', value: brief, inline: false },
                { name: language === 'ar' ? '🎨 مستوى الإبداع' : '🎨 Creativity Level', value: brainstorm.creativityLevel, inline: true },
                { name: language === 'ar' ? '📊 إمكانية التنفيذ' : '📊 Feasibility', value: brainstorm.feasibility, inline: true },
                { name: language === 'ar' ? '💰 التكلفة المقدرة' : '💰 Estimated Cost', value: brainstorm.cost, inline: true }
            )
            .setColor('#f39c12')
            .setTimestamp();

        // Add main concepts
        embed.addFields({
            name: language === 'ar' ? '💡 المفاهيم الرئيسية' : '💡 Main Concepts',
            value: brainstorm.concepts.join('\n'),
            inline: false
        });

        // Add creative variations
        embed.addFields({
            name: language === 'ar' ? '🎨 التنويعات الإبداعية' : '🎨 Creative Variations',
            value: brainstorm.variations.join('\n'),
            inline: false
        });

        // Add implementation steps
        embed.addFields({
            name: language === 'ar' ? '📋 خطوات التنفيذ' : '📋 Implementation Steps',
            value: brainstorm.steps.join('\n'),
            inline: false
        });

        // Add potential challenges
        embed.addFields({
            name: language === 'ar' ? '⚠️ التحديات المحتملة' : '⚠️ Potential Challenges',
            value: brainstorm.challenges.join('\n'),
            inline: false
        });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('expand_ideas')
                    .setLabel(language === 'ar' ? '🔍 توسيع الأفكار' : '🔍 Expand Ideas')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('market_analysis')
                    .setLabel(language === 'ar' ? '📊 تحليل السوق' : '📊 Market Analysis')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('create_proposal')
                    .setLabel(language === 'ar' ? '📄 إنشاء مقترح' : '📄 Create Proposal')
                    .setStyle(ButtonStyle.Success)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    detectLanguage(text) {
        const arabicPattern = /[\u0600-\u06FF]/;
        return arabicPattern.test(text) ? 'ar' : 'en';
    },

    createStory(genre, theme, language) {
        const isArabic = language === 'ar';
        
        const stories = {
            adventure: {
                en: `The ancient map crackled in Sarah's hands as she studied the mysterious symbols. According to legend, it led to the lost city of Atlantara, hidden deep within the Amazon rainforest. With her team of explorers, she embarked on a journey that would test their courage and determination. Through treacherous rivers and dense jungle, they discovered that the real treasure wasn't gold or jewels, but the bonds of friendship forged in adversity.`,
                ar: `تشققت الخريطة القديمة بين يدي سارة وهي تدرس الرموز الغامضة. وفقاً للأسطورة، كانت تقود إلى مدينة أتلانتارا المفقودة، المخبأة في أعماق غابات الأمازون المطيرة. مع فريقها من المستكشفين، انطلقت في رحلة ستختبر شجاعتهم وعزيمتهم. عبر الأنهار الخطيرة والأدغال الكثيفة، اكتشفوا أن الكنز الحقيقي لم يكن ذهباً أو جواهر، بل روابط الصداقة المتكونة في المحن.`
            },
            mystery: {
                en: `Detective Morgan stared at the locked room, puzzled by the impossible crime. The victim was found inside with no way in or out, yet the evidence suggested murder. As she examined each clue meticulously, a pattern began to emerge. The solution lay not in what was present, but in what was conspicuously absent.`,
                ar: `حدقت المحققة مورغان في الغرفة المقفلة، محتارة من الجريمة المستحيلة. تم العثور على الضحية بالداخل دون وجود طريق للدخول أو الخروج، ومع ذلك تشير الأدلة إلى جريمة قتل. بينما فحصت كل دليل بدقة، بدأ نمط في الظهور. كان الحل لا يكمن فيما كان موجوداً، بل فيما كان غائباً بشكل واضح.`
            }
        };

        const content = stories[genre]?.[language] || stories.adventure[language];
        
        return {
            content,
            wordCount: content.split(' ').length,
            style: isArabic ? 'أدبي كلاسيكي' : 'Literary Classic',
            analysis: isArabic ? [
                '• بناء قوي للشخصيات',
                '• تطور مثير للأحداث',
                '• استخدام فعال للوصف',
                '• رسالة عميقة ومؤثرة'
            ] : [
                '• Strong character development',
                '• Engaging plot progression',
                '• Effective use of description',
                '• Deep and meaningful message'
            ]
        };
    },

    createPoem(style, topic, language) {
        const isArabic = language === 'ar';
        
        const poems = {
            classical: {
                en: `In gardens where the roses bloom so bright,\nAnd morning dew reflects the golden light,\nI find within this beauty pure and true,\nA mirror of the love I have for you.`,
                ar: `في بستان الورد يزهو جميلاً\nوندى الصبح يلمع تحت الضياء\nأجد في هذا الجمال الأصيل\nمرآة للحب الذي في فؤادي`
            },
            modern: {
                en: `Whispers of tomorrow\ncarried on today's wind\nspeak of dreams\nyet to unfold`,
                ar: `همسات الغد\nتحملها رياح اليوم\nتتحدث عن أحلام\nلم تتفتح بعد`
            }
        };

        const content = poems[style]?.[language] || poems.classical[language];
        
        return {
            content,
            verses: content.split('\n').length / 2,
            meter: isArabic ? 'البحر الكامل' : 'Iambic Pentameter',
            mood: isArabic ? 'رومانسي' : 'Romantic',
            rating: '⭐⭐⭐⭐⭐',
            analysis: isArabic ? [
                '• إيقاع موسيقي متناغم',
                '• صور شعرية جميلة',
                '• عمق في المعنى',
                '• تدفق طبيعي للكلمات'
            ] : [
                '• Harmonious musical rhythm',
                '• Beautiful poetic imagery',
                '• Depth of meaning',
                '• Natural flow of words'
            ]
        };
    },

    createScript(type, concept, language) {
        const isArabic = language === 'ar';
        
        return {
            duration: isArabic ? '15-20 دقيقة' : '15-20 minutes',
            audience: isArabic ? 'جمهور عام' : 'General Audience',
            complexity: isArabic ? 'متوسط' : 'Medium',
            characters: isArabic ? [
                '👤 أحمد - الشخصية الرئيسية',
                '👥 فاطمة - الصديقة المقربة',
                '🎭 الراوي - صوت خارجي'
            ] : [
                '👤 Alex - Main Character',
                '👥 Sarah - Close Friend',
                '🎭 Narrator - Voice Over'
            ],
            excerpt: isArabic ? 
                `المشهد الأول: في المقهى\n\nأحمد: (ينظر من النافذة) أتساءل أحياناً عما لو اتخذت قراراً مختلفاً.\n\nفاطمة: (تبتسم) الحياة مليئة بالاحتمالات، لكن المهم هو ما نفعله الآن.\n\nالراوي: وفي تلك اللحظة، أدرك أحمد أن المستقبل يبدأ من هنا.` :
                `Scene 1: At the Café\n\nAlex: (looking out the window) I sometimes wonder what if I had made a different choice.\n\nSarah: (smiling) Life is full of possibilities, but what matters is what we do now.\n\nNarrator: In that moment, Alex realized that the future starts here.`,
            notes: isArabic ? [
                '🎬 استخدام إضاءة طبيعية',
                '🎵 موسيقى هادئة في الخلفية',
                '📱 تصوير بزوايا متنوعة',
                '🎭 التركيز على تعابير الوجه'
            ] : [
                '🎬 Use natural lighting',
                '🎵 Soft background music',
                '📱 Varied camera angles',
                '🎭 Focus on facial expressions'
            ]
        };
    },

    generateBrainstorm(projectType, brief, language) {
        const isArabic = language === 'ar';
        
        return {
            creativityLevel: isArabic ? 'عالي جداً' : 'Very High',
            feasibility: isArabic ? 'قابل للتنفيذ' : 'Feasible',
            cost: isArabic ? 'متوسط' : 'Medium',
            concepts: isArabic ? [
                '💡 مفهوم أساسي مبتكر',
                '🎯 تطبيق عملي للفكرة',
                '🌟 عنصر تفاعلي جذاب',
                '📱 دمج التكنولوجيا الحديثة'
            ] : [
                '💡 Innovative core concept',
                '🎯 Practical application',
                '🌟 Engaging interactive element',
                '📱 Modern technology integration'
            ],
            variations: isArabic ? [
                '🎨 نسخة مبسطة للمبتدئين',
                '🚀 نسخة متقدمة للخبراء',
                '👥 نسخة تعاونية جماعية',
                '🌐 نسخة رقمية عبر الإنترنت'
            ] : [
                '🎨 Simplified version for beginners',
                '🚀 Advanced version for experts',
                '👥 Collaborative group version',
                '🌐 Digital online version'
            ],
            steps: isArabic ? [
                '1️⃣ البحث وجمع المعلومات',
                '2️⃣ تطوير النموذج الأولي',
                '3️⃣ اختبار الفكرة مع المستخدمين',
                '4️⃣ التحسين والتطوير',
                '5️⃣ الإطلاق والتسويق'
            ] : [
                '1️⃣ Research and information gathering',
                '2️⃣ Develop prototype',
                '3️⃣ User testing',
                '4️⃣ Refinement and development',
                '5️⃣ Launch and marketing'
            ],
            challenges: isArabic ? [
                '⚠️ قيود الميزانية',
                '⏰ ضيق الوقت',
                '👥 إيجاد الفريق المناسب',
                '📊 قياس النجاح'
            ] : [
                '⚠️ Budget constraints',
                '⏰ Time limitations',
                '👥 Finding the right team',
                '📊 Measuring success'
            ]
        };
    }
};