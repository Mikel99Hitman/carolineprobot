const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ai-education')
        .setDescription('AI-powered education system (Arabic/English)')
        .addSubcommand(subcommand =>
            subcommand
                .setName('smart-quiz')
                .setDescription('Generate intelligent quizzes (Arabic/English)')
                .addStringOption(option =>
                    option.setName('subject')
                        .setDescription('Quiz subject')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('difficulty')
                        .setDescription('Difficulty level')
                        .addChoices(
                            { name: 'Easy', value: 'easy' },
                            { name: 'Medium', value: 'medium' },
                            { name: 'Hard', value: 'hard' },
                            { name: 'Expert', value: 'expert' }
                        ))
                .addStringOption(option =>
                    option.setName('language')
                        .setDescription('Quiz language')
                        .addChoices(
                            { name: 'English', value: 'en' },
                            { name: 'العربية', value: 'ar' },
                            { name: 'Bilingual', value: 'both' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('study-plan')
                .setDescription('Create personalized study plans')
                .addStringOption(option =>
                    option.setName('goal')
                        .setDescription('Learning goal')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('timeframe')
                        .setDescription('Study timeframe')
                        .addChoices(
                            { name: '1 Week', value: '1w' },
                            { name: '1 Month', value: '1m' },
                            { name: '3 Months', value: '3m' },
                            { name: '6 Months', value: '6m' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('explain-concept')
                .setDescription('AI explains complex concepts simply')
                .addStringOption(option =>
                    option.setName('concept')
                        .setDescription('Concept to explain')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('level')
                        .setDescription('Explanation level')
                        .addChoices(
                            { name: 'Child (5-10)', value: 'child' },
                            { name: 'Teenager (11-17)', value: 'teen' },
                            { name: 'Adult (18+)', value: 'adult' },
                            { name: 'Expert', value: 'expert' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('homework-helper')
                .setDescription('AI homework assistance (Arabic/English)')
                .addStringOption(option =>
                    option.setName('subject')
                        .setDescription('Subject area')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Mathematics', value: 'math' },
                            { name: 'Science', value: 'science' },
                            { name: 'History', value: 'history' },
                            { name: 'Literature', value: 'literature' },
                            { name: 'Programming', value: 'programming' }
                        ))
                .addStringOption(option =>
                    option.setName('question')
                        .setDescription('Your homework question')
                        .setRequired(true))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        switch (subcommand) {
            case 'smart-quiz':
                await this.generateSmartQuiz(interaction);
                break;
            case 'study-plan':
                await this.createStudyPlan(interaction);
                break;
            case 'explain-concept':
                await this.explainConcept(interaction);
                break;
            case 'homework-helper':
                await this.homeworkHelper(interaction);
                break;
        }
    },

    async generateSmartQuiz(interaction) {
        await interaction.deferReply();

        const subject = interaction.options.getString('subject');
        const difficulty = interaction.options.getString('difficulty') || 'medium';
        const language = interaction.options.getString('language') || 'en';

        const quiz = this.createQuiz(subject, difficulty, language);

        const embed = new EmbedBuilder()
            .setTitle(language === 'ar' ? '🧠 اختبار ذكي' : language === 'both' ? '🧠 Smart Quiz | اختبار ذكي' : '🧠 Smart Quiz')
            .setDescription(language === 'ar' ? 'اختبار مُولد بالذكاء الاصطناعي' : language === 'both' ? 'AI-Generated Quiz | اختبار مُولد بالذكاء الاصطناعي' : 'AI-Generated Quiz')
            .addFields(
                { name: language === 'ar' ? '📚 الموضوع' : '📚 Subject', value: subject, inline: true },
                { name: language === 'ar' ? '📊 المستوى' : '📊 Difficulty', value: difficulty.charAt(0).toUpperCase() + difficulty.slice(1), inline: true },
                { name: language === 'ar' ? '🌐 اللغة' : '🌐 Language', value: language === 'ar' ? 'العربية' : language === 'both' ? 'ثنائية اللغة' : 'English', inline: true },
                { name: language === 'ar' ? '❓ عدد الأسئلة' : '❓ Questions', value: `${quiz.questions.length}`, inline: true },
                { name: language === 'ar' ? '⏱️ الوقت المقدر' : '⏱️ Estimated Time', value: `${quiz.questions.length * 2} minutes`, inline: true },
                { name: language === 'ar' ? '🎯 النقاط' : '🎯 Points', value: `${quiz.questions.length * 10}`, inline: true }
            )
            .setColor('#3498db')
            .setTimestamp()
            .setFooter({ text: language === 'ar' ? 'اختبار ذكي • تعلم تفاعلي' : 'Smart Quiz • Interactive Learning' });

        // Add first question
        if (quiz.questions.length > 0) {
            const firstQ = quiz.questions[0];
            embed.addFields({
                name: `${language === 'ar' ? 'السؤال' : 'Question'} 1/${quiz.questions.length}`,
                value: firstQ.question,
                inline: false
            });
        }

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('start_quiz')
                    .setLabel(language === 'ar' ? '🚀 بدء الاختبار' : '🚀 Start Quiz')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('preview_questions')
                    .setLabel(language === 'ar' ? '👀 معاينة الأسئلة' : '👀 Preview Questions')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('customize_quiz')
                    .setLabel(language === 'ar' ? '⚙️ تخصيص' : '⚙️ Customize')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async createStudyPlan(interaction) {
        await interaction.deferReply();

        const goal = interaction.options.getString('goal');
        const timeframe = interaction.options.getString('timeframe') || '1m';
        const language = this.detectLanguage(goal);

        const plan = this.generateStudyPlan(goal, timeframe, language);

        const embed = new EmbedBuilder()
            .setTitle(language === 'ar' ? '📅 خطة دراسية شخصية' : '📅 Personalized Study Plan')
            .setDescription(language === 'ar' ? 'خطة مُصممة خصيصاً لأهدافك التعليمية' : 'Tailored plan for your learning objectives')
            .addFields(
                { name: language === 'ar' ? '🎯 الهدف التعليمي' : '🎯 Learning Goal', value: goal, inline: false },
                { name: language === 'ar' ? '⏰ الإطار الزمني' : '⏰ Timeframe', value: this.formatTimeframe(timeframe, language), inline: true },
                { name: language === 'ar' ? '📊 مستوى الصعوبة' : '📊 Difficulty Level', value: language === 'ar' ? 'متوسط' : 'Intermediate', inline: true },
                { name: language === 'ar' ? '🎓 نوع التعلم' : '🎓 Learning Type', value: language === 'ar' ? 'تفاعلي' : 'Interactive', inline: true }
            )
            .setColor('#e67e22')
            .setTimestamp();

        // Add weekly breakdown
        plan.weeks.forEach((week, index) => {
            embed.addFields({
                name: `${language === 'ar' ? 'الأسبوع' : 'Week'} ${index + 1}`,
                value: week.activities.join('\n'),
                inline: false
            });
        });

        embed.addFields({
            name: language === 'ar' ? '💡 نصائح للنجاح' : '💡 Success Tips',
            value: plan.tips.join('\n'),
            inline: false
        });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('start_plan')
                    .setLabel(language === 'ar' ? '🚀 بدء الخطة' : '🚀 Start Plan')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('modify_plan')
                    .setLabel(language === 'ar' ? '✏️ تعديل الخطة' : '✏️ Modify Plan')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('track_progress')
                    .setLabel(language === 'ar' ? '📊 تتبع التقدم' : '📊 Track Progress')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async explainConcept(interaction) {
        await interaction.deferReply();

        const concept = interaction.options.getString('concept');
        const level = interaction.options.getString('level') || 'adult';
        const language = this.detectLanguage(concept);

        const explanation = this.generateExplanation(concept, level, language);

        const embed = new EmbedBuilder()
            .setTitle(language === 'ar' ? '🧠 شرح المفهوم' : '🧠 Concept Explanation')
            .setDescription(language === 'ar' ? 'شرح مبسط ومفهوم للمفاهيم المعقدة' : 'Simple and clear explanation of complex concepts')
            .addFields(
                { name: language === 'ar' ? '📖 المفهوم' : '📖 Concept', value: concept, inline: true },
                { name: language === 'ar' ? '👥 مستوى الشرح' : '👥 Explanation Level', value: level.charAt(0).toUpperCase() + level.slice(1), inline: true },
                { name: language === 'ar' ? '🎯 مستوى الصعوبة' : '🎯 Complexity', value: explanation.complexity, inline: true },
                { name: language === 'ar' ? '📝 الشرح المبسط' : '📝 Simple Explanation', value: explanation.simple, inline: false },
                { name: language === 'ar' ? '🔍 التفاصيل' : '🔍 Details', value: explanation.detailed, inline: false },
                { name: language === 'ar' ? '💡 أمثلة عملية' : '💡 Practical Examples', value: explanation.examples.join('\n'), inline: false },
                { name: language === 'ar' ? '🔗 مفاهيم ذات صلة' : '🔗 Related Concepts', value: explanation.related.join(', '), inline: false }
            )
            .setColor('#9b59b6')
            .setTimestamp()
            .setFooter({ text: language === 'ar' ? 'شرح ذكي • تعلم مبسط' : 'Smart Explanation • Simplified Learning' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('deeper_explanation')
                    .setLabel(language === 'ar' ? '🔬 شرح أعمق' : '🔬 Deeper Explanation')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('visual_diagram')
                    .setLabel(language === 'ar' ? '📊 رسم بياني' : '📊 Visual Diagram')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('practice_quiz')
                    .setLabel(language === 'ar' ? '🧠 اختبار تطبيقي' : '🧠 Practice Quiz')
                    .setStyle(ButtonStyle.Success)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async homeworkHelper(interaction) {
        await interaction.deferReply();

        const subject = interaction.options.getString('subject');
        const question = interaction.options.getString('question');
        const language = this.detectLanguage(question);

        const help = this.generateHomeworkHelp(subject, question, language);

        const embed = new EmbedBuilder()
            .setTitle(language === 'ar' ? '📚 مساعد الواجبات المنزلية' : '📚 Homework Helper')
            .setDescription(language === 'ar' ? 'مساعدة ذكية لحل الواجبات والمهام الدراسية' : 'Smart assistance for homework and academic tasks')
            .addFields(
                { name: language === 'ar' ? '📖 المادة' : '📖 Subject', value: subject.charAt(0).toUpperCase() + subject.slice(1), inline: true },
                { name: language === 'ar' ? '🎯 نوع المساعدة' : '🎯 Help Type', value: help.type, inline: true },
                { name: language === 'ar' ? '⏱️ الوقت المقدر' : '⏱️ Estimated Time', value: help.estimatedTime, inline: true },
                { name: language === 'ar' ? '❓ سؤالك' : '❓ Your Question', value: `\`\`\`\n${question}\n\`\`\``, inline: false },
                { name: language === 'ar' ? '💡 التوجيه' : '💡 Guidance', value: help.guidance, inline: false },
                { name: language === 'ar' ? '📝 خطوات الحل' : '📝 Solution Steps', value: help.steps.join('\n'), inline: false },
                { name: language === 'ar' ? '🔍 مصادر إضافية' : '🔍 Additional Resources', value: help.resources.join('\n'), inline: false }
            )
            .setColor('#2ecc71')
            .setTimestamp()
            .setFooter({ text: language === 'ar' ? 'مساعد الواجبات • تعلم ذاتي' : 'Homework Helper • Self-Learning' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('step_by_step')
                    .setLabel(language === 'ar' ? '👣 خطوة بخطوة' : '👣 Step by Step')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('similar_problems')
                    .setLabel(language === 'ar' ? '🔄 مسائل مشابهة' : '🔄 Similar Problems')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('check_answer')
                    .setLabel(language === 'ar' ? '✅ تحقق من الإجابة' : '✅ Check Answer')
                    .setStyle(ButtonStyle.Success)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    detectLanguage(text) {
        const arabicPattern = /[\u0600-\u06FF]/;
        return arabicPattern.test(text) ? 'ar' : 'en';
    },

    createQuiz(subject, difficulty, language) {
        const questions = {
            en: [
                { question: `What is the fundamental concept of ${subject}?`, type: 'multiple', points: 10 },
                { question: `Explain the importance of ${subject} in modern applications.`, type: 'essay', points: 15 },
                { question: `Which of the following best describes ${subject}?`, type: 'multiple', points: 10 }
            ],
            ar: [
                { question: `ما هو المفهوم الأساسي لـ ${subject}؟`, type: 'multiple', points: 10 },
                { question: `اشرح أهمية ${subject} في التطبيقات الحديثة.`, type: 'essay', points: 15 },
                { question: `أي مما يلي يصف ${subject} بشكل أفضل؟`, type: 'multiple', points: 10 }
            ]
        };

        return {
            questions: questions[language === 'ar' ? 'ar' : 'en'],
            totalPoints: 35,
            timeLimit: 30
        };
    },

    generateStudyPlan(goal, timeframe, language) {
        const weeks = [];
        const weekCount = timeframe === '1w' ? 1 : timeframe === '1m' ? 4 : timeframe === '3m' ? 12 : 24;

        for (let i = 0; i < Math.min(weekCount, 4); i++) {
            weeks.push({
                activities: language === 'ar' ? [
                    `• دراسة المفاهيم الأساسية لـ ${goal}`,
                    `• حل التمارين العملية`,
                    `• مراجعة ومناقشة المواد`,
                    `• اختبار تقييمي أسبوعي`
                ] : [
                    `• Study fundamental concepts of ${goal}`,
                    `• Practice exercises and problems`,
                    `• Review and discuss materials`,
                    `• Weekly assessment quiz`
                ]
            });
        }

        return {
            weeks,
            tips: language === 'ar' ? [
                '📅 التزم بجدول دراسي منتظم',
                '🎯 ركز على فهم المفاهيم وليس الحفظ',
                '💬 ناقش المواد مع الآخرين',
                '📊 تتبع تقدمك بانتظام'
            ] : [
                '📅 Stick to a regular study schedule',
                '🎯 Focus on understanding, not memorization',
                '💬 Discuss materials with others',
                '📊 Track your progress regularly'
            ]
        };
    },

    generateExplanation(concept, level, language) {
        const isArabic = language === 'ar';
        
        return {
            complexity: isArabic ? 'متوسط' : 'Medium',
            simple: isArabic ? 
                `${concept} هو مفهوم مهم يساعدنا في فهم كيفية عمل الأشياء في العالم من حولنا.` :
                `${concept} is an important idea that helps us understand how things work in the world around us.`,
            detailed: isArabic ?
                `يمكن تطبيق مفهوم ${concept} في العديد من المجالات العملية، ويعتبر أساساً لفهم المواضيع المتقدمة.` :
                `The concept of ${concept} can be applied in many practical fields and serves as a foundation for understanding advanced topics.`,
            examples: isArabic ? [
                `• مثال عملي من الحياة اليومية`,
                `• تطبيق في مجال التكنولوجيا`,
                `• استخدام في العلوم الطبيعية`
            ] : [
                `• Real-life everyday example`,
                `• Application in technology`,
                `• Use in natural sciences`
            ],
            related: isArabic ? [
                'مفهوم مرتبط أول',
                'مفهوم مرتبط ثاني',
                'مفهوم مرتبط ثالث'
            ] : [
                'Related concept one',
                'Related concept two', 
                'Related concept three'
            ]
        };
    },

    generateHomeworkHelp(subject, question, language) {
        const isArabic = language === 'ar';
        
        return {
            type: isArabic ? 'توجيه وإرشاد' : 'Guidance & Direction',
            estimatedTime: isArabic ? '15-30 دقيقة' : '15-30 minutes',
            guidance: isArabic ?
                'سأساعدك في فهم المسألة وإيجاد الطريقة الصحيحة للحل دون إعطائك الإجابة مباشرة.' :
                'I will help you understand the problem and find the right approach without giving you the direct answer.',
            steps: isArabic ? [
                '1️⃣ اقرأ السؤال بعناية وحدد المطلوب',
                '2️⃣ اجمع المعلومات والبيانات المتاحة',
                '3️⃣ حدد الطريقة أو القانون المناسب',
                '4️⃣ طبق الخطوات بالترتيب',
                '5️⃣ راجع الإجابة وتأكد من منطقيتها'
            ] : [
                '1️⃣ Read the question carefully and identify what is required',
                '2️⃣ Gather available information and data',
                '3️⃣ Determine the appropriate method or formula',
                '4️⃣ Apply the steps in order',
                '5️⃣ Review the answer and check its logic'
            ],
            resources: isArabic ? [
                '📚 مراجع إضافية في المكتبة',
                '🌐 مواقع تعليمية موثوقة',
                '👥 مجموعات دراسية',
                '🎓 ساعات مكتبية مع المعلم'
            ] : [
                '📚 Additional library references',
                '🌐 Reliable educational websites',
                '👥 Study groups',
                '🎓 Office hours with teacher'
            ]
        };
    },

    formatTimeframe(timeframe, language) {
        const formats = {
            '1w': { en: '1 Week', ar: 'أسبوع واحد' },
            '1m': { en: '1 Month', ar: 'شهر واحد' },
            '3m': { en: '3 Months', ar: '3 أشهر' },
            '6m': { en: '6 Months', ar: '6 أشهر' }
        };
        
        return formats[timeframe]?.[language] || formats[timeframe]?.en || timeframe;
    }
};