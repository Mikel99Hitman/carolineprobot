const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const User = require('../../models/User');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('userinfo')
        .setDescription('عرض معلومات المستخدم')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('المستخدم المراد عرض معلوماته')
                .setRequired(false)),

    async execute(interaction) {
        const targetUser = interaction.options.getUser('user') || interaction.user;
        const member = interaction.guild.members.cache.get(targetUser.id);

        if (!member) {
            return interaction.reply({ content: '❌ المستخدم غير موجود في السيرفر!', ephemeral: true });
        }

        const userData = await User.findOne({ 
            userId: targetUser.id, 
            guildId: interaction.guild.id 
        });

        const userEmbed = new EmbedBuilder()
            .setColor(member.displayHexColor || '#0099ff')
            .setTitle(`📋 معلومات ${member.displayName}`)
            .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 256 }))
            .addFields(
                { name: '👤 الاسم', value: targetUser.username, inline: true },
                { name: '🏷️ العلامة', value: `#${targetUser.discriminator}`, inline: true },
                { name: '🆔 المعرف', value: targetUser.id, inline: true },
                { name: '📅 تاريخ الإنشاء', value: `<t:${Math.floor(targetUser.createdTimestamp / 1000)}:F>`, inline: true },
                { name: '📥 تاريخ الانضمام', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:F>`, inline: true },
                { name: '🎭 الأدوار', value: member.roles.cache.filter(role => role.id !== interaction.guild.id).map(role => role.toString()).join(', ') || 'لا توجد أدوار', inline: false }
            )
            .setTimestamp();

        if (userData) {
            userEmbed.addFields(
                { name: '📊 المستوى', value: userData.level.toString(), inline: true },
                { name: '⭐ النقاط', value: userData.xp.toString(), inline: true },
                { name: '💬 الرسائل', value: userData.messages.toString(), inline: true },
                { name: '⚠️ التحذيرات', value: userData.warnings.toString(), inline: true },
                { name: '🔗 الدعوات', value: userData.invites.toString(), inline: true }
            );
        }

        // إضافة معلومات الحالة
        const status = {
            'online': '🟢 متصل',
            'idle': '🟡 خامل',
            'dnd': '🔴 مشغول',
            'offline': '⚫ غير متصل'
        };

        userEmbed.addFields({
            name: '📱 الحالة',
            value: status[member.presence?.status] || '⚫ غير متصل',
            inline: true
        });

        // إضافة النشاط الحالي
        if (member.presence?.activities?.length > 0) {
            const activity = member.presence.activities[0];
            userEmbed.addFields({
                name: '🎮 النشاط',
                value: `${activity.name}`,
                inline: true
            });
        }

        await interaction.reply({ embeds: [userEmbed] });
    }
};