const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const Canvas = require('canvas');

const activityData = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('activity')
        .setDescription('Advanced server activity tracking')
        .addSubcommand(subcommand =>
            subcommand
                .setName('overview')
                .setDescription('Server activity overview'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('user')
                .setDescription('User activity stats')
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('User to check')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('channel')
                .setDescription('Channel activity stats')
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('Channel to check')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('heatmap')
                .setDescription('Activity heatmap')),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        await interaction.deferReply();

        if (subcommand === 'overview') {
            const guild = interaction.guild;
            
            // Mock activity data
            const todayMessages = Math.floor(Math.random() * 1000) + 500;
            const activeUsers = Math.floor(Math.random() * 100) + 50;
            const peakHour = Math.floor(Math.random() * 24);
            
            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('📊 Server Activity Overview')
                .setThumbnail(guild.iconURL())
                .addFields(
                    { name: '💬 Messages Today', value: todayMessages.toLocaleString(), inline: true },
                    { name: '👥 Active Users', value: activeUsers.toString(), inline: true },
                    { name: '⏰ Peak Hour', value: `${peakHour}:00`, inline: true },
                    { name: '📈 Growth Rate', value: '+12.5%', inline: true },
                    { name: '🔥 Most Active Channel', value: '#general', inline: true },
                    { name: '⭐ Top User', value: interaction.user.toString(), inline: true }
                )
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

        } else if (subcommand === 'heatmap') {
            // Create activity heatmap
            const canvas = Canvas.createCanvas(800, 400);
            const ctx = canvas.getContext('2d');

            // Background
            ctx.fillStyle = '#2f3136';
            ctx.fillRect(0, 0, 800, 400);

            // Title
            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 20px Arial';
            ctx.textAlign = 'center';
            ctx.fillText('Server Activity Heatmap (24 Hours)', 400, 30);

            // Draw heatmap grid
            const cellWidth = 30;
            const cellHeight = 20;
            const startX = 50;
            const startY = 60;

            // Hours (0-23)
            for (let hour = 0; hour < 24; hour++) {
                // Days of week
                for (let day = 0; day < 7; day++) {
                    const activity = Math.random(); // Mock activity level
                    const x = startX + hour * cellWidth;
                    const y = startY + day * cellHeight;

                    // Color based on activity level
                    if (activity > 0.8) ctx.fillStyle = '#ff4444';
                    else if (activity > 0.6) ctx.fillStyle = '#ff8844';
                    else if (activity > 0.4) ctx.fillStyle = '#ffaa44';
                    else if (activity > 0.2) ctx.fillStyle = '#44ff44';
                    else ctx.fillStyle = '#444444';

                    ctx.fillRect(x, y, cellWidth - 2, cellHeight - 2);
                }
            }

            // Labels
            ctx.fillStyle = '#ffffff';
            ctx.font = '12px Arial';
            ctx.textAlign = 'left';
            
            const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
            days.forEach((day, index) => {
                ctx.fillText(day, 10, startY + index * cellHeight + 15);
            });

            // Hour labels
            for (let i = 0; i < 24; i += 4) {
                ctx.fillText(i.toString(), startX + i * cellWidth, startY - 10);
            }

            // Legend
            ctx.fillText('Activity Level:', 50, 220);
            const colors = ['#444444', '#44ff44', '#ffaa44', '#ff8844', '#ff4444'];
            const labels = ['Low', '', '', '', 'High'];
            
            colors.forEach((color, index) => {
                ctx.fillStyle = color;
                ctx.fillRect(50 + index * 30, 230, 25, 15);
                ctx.fillStyle = '#ffffff';
                if (labels[index]) ctx.fillText(labels[index], 50 + index * 30, 260);
            });

            const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'heatmap.png' });

            const embed = new EmbedBuilder()
                .setColor('#9932cc')
                .setTitle('🔥 Activity Heatmap')
                .setDescription('Server activity patterns over the past week')
                .setImage('attachment://heatmap.png')
                .setTimestamp();

            await interaction.editReply({ embeds: [embed], files: [attachment] });

        } else if (subcommand === 'user') {
            const user = interaction.options.getUser('user') || interaction.user;
            
            // Mock user activity data
            const userStats = {
                messagesThisWeek: Math.floor(Math.random() * 500) + 100,
                voiceHours: Math.floor(Math.random() * 20) + 5,
                mostActiveChannel: '#general',
                joinedDaysAgo: Math.floor(Math.random() * 365) + 1,
                activityScore: Math.floor(Math.random() * 100) + 1
            };

            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle(`📊 ${user.username}'s Activity Stats`)
                .setThumbnail(user.displayAvatarURL())
                .addFields(
                    { name: '💬 Messages This Week', value: userStats.messagesThisWeek.toString(), inline: true },
                    { name: '🔊 Voice Hours', value: `${userStats.voiceHours}h`, inline: true },
                    { name: '📈 Activity Score', value: `${userStats.activityScore}/100`, inline: true },
                    { name: '🏆 Most Active Channel', value: userStats.mostActiveChannel, inline: true },
                    { name: '📅 Member Since', value: `${userStats.joinedDaysAgo} days ago`, inline: true },
                    { name: '⭐ Rank', value: `#${Math.floor(Math.random() * 50) + 1}`, inline: true }
                )
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        }
    }
};

// Track activity (would be called from message events)
function trackActivity(guildId, userId, channelId, type) {
    if (!activityData.has(guildId)) {
        activityData.set(guildId, new Map());
    }
    
    const guildData = activityData.get(guildId);
    const hour = new Date().getHours();
    const key = `${userId}-${channelId}-${hour}`;
    
    if (!guildData.has(key)) {
        guildData.set(key, { messages: 0, voice: 0 });
    }
    
    const userData = guildData.get(key);
    if (type === 'message') userData.messages++;
    if (type === 'voice') userData.voice++;
}

module.exports.trackActivity = trackActivity;