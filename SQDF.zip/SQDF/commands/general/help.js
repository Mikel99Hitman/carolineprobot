const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Show all bot commands'),
    
    async execute(interaction) {
        const helpEmbed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('📋 Commands List')
            .setDescription('All available bot commands')
            .addFields(
                {
                    name: '👑 Admin Commands',
                    value: '`/setup` - Setup bot\n`/warn` - Warn member\n`/kick` - Kick member\n`/ban` - Ban member\n`/clear` - Delete messages',
                    inline: true
                },
                {
                    name: '🎵 Music Commands',
                    value: '`/play` - Play song\n`/stop` - Stop music\n`/skip` - Skip song\n`/queue` - Playlist',
                    inline: true
                },
                {
                    name: '📊 Level Commands',
                    value: '`/rank` - Your current rank\n`/leaderboard` - Leaderboard\n`/setxp` - Modify points',
                    inline: true
                },
                {
                    name: '🎫 Ticket Commands',
                    value: '`/ticket` - Create ticket\n`/close` - Close ticket\n`/add` - Add member to ticket',
                    inline: true
                },
                {
                    name: '📝 General Commands',
                    value: '`/userinfo` - Member info\n`/serverinfo` - Server info\n`/avatar` - Member avatar',
                    inline: true
                },
                {
                    name: '🔗 Invite Commands',
                    value: '`/invites` - Your invites count\n`/inviteleaderboard` - Invite leaderboard',
                    inline: true
                }
            )
            .setFooter({ text: 'ProBot by Mikel', iconURL: interaction.client.user.displayAvatarURL() })
            .setTimestamp();

        await interaction.reply({ embeds: [helpEmbed] });
    }
};