const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('botstatus')
        .setDescription('Comprehensive bot status and information'),

    async execute(interaction) {
        const client = interaction.client;
        const uptime = process.uptime();
        const memUsage = process.memoryUsage();

        // Calculate uptime
        const days = Math.floor(uptime / 86400);
        const hours = Math.floor((uptime % 86400) / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        const seconds = Math.floor(uptime % 60);

        // System stats
        const totalMemory = Math.round(memUsage.heapTotal / 1024 / 1024);
        const usedMemory = Math.round(memUsage.heapUsed / 1024 / 1024);
        const memoryPercent = Math.round((usedMemory / totalMemory) * 100);

        // Bot stats
        const totalGuilds = client.guilds.cache.size;
        const totalUsers = client.users.cache.size;
        const totalChannels = client.channels.cache.size;
        const totalCommands = client.commands?.size || 0;

        // Performance metrics
        const ping = client.ws.ping;
        const apiLatency = Date.now() - interaction.createdTimestamp;

        const embed = new EmbedBuilder()
            .setColor('#5865f2')
            .setTitle('🤖 ProBot Status Dashboard')
            .setThumbnail(client.user.displayAvatarURL())
            .addFields(
                { name: '⏱️ Uptime', value: `${days}d ${hours}h ${minutes}m ${seconds}s`, inline: true },
                { name: '🏓 Ping', value: `${ping}ms`, inline: true },
                { name: '📡 API Latency', value: `${apiLatency}ms`, inline: true },
                { name: '🖥️ Memory Usage', value: `${usedMemory}MB / ${totalMemory}MB (${memoryPercent}%)`, inline: true },
                { name: '🏠 Servers', value: totalGuilds.toLocaleString(), inline: true },
                { name: '👥 Users', value: totalUsers.toLocaleString(), inline: true },
                { name: '📝 Channels', value: totalChannels.toLocaleString(), inline: true },
                { name: '⚡ Commands', value: totalCommands.toLocaleString(), inline: true },
                { name: '📊 Node.js', value: process.version, inline: true }
            )
            .addFields({
                name: '🎯 Features Status',
                value: [
                    '✅ Logging System - Active',
                    '✅ Economy System - Active', 
                    '✅ Leveling System - Active',
                    '✅ Music System - Active',
                    '✅ Moderation - Active',
                    '✅ AI Features - Active',
                    '✅ Analytics - Active',
                    '✅ Auto-Moderation - Active'
                ].join('\n'),
                inline: false
            })
            .addFields({
                name: '📈 Performance Status',
                value: getPerformanceStatus(ping, memoryPercent, uptime),
                inline: true
            })
            .addFields({
                name: '🔧 System Health',
                value: getSystemHealth(ping, memoryPercent),
                inline: true
            })
            .setFooter({ 
                text: `ProBot v2.0 | Made by Mikel | ${totalGuilds} servers`, 
                iconURL: client.user.displayAvatarURL() 
            })
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};

function getPerformanceStatus(ping, memoryPercent, uptime) {
    if (ping < 100 && memoryPercent < 70 && uptime > 3600) {
        return '🟢 Excellent';
    } else if (ping < 200 && memoryPercent < 85) {
        return '🟡 Good';
    } else {
        return '🔴 Needs Attention';
    }
}

function getSystemHealth(ping, memoryPercent) {
    const issues = [];
    
    if (ping > 200) issues.push('High latency');
    if (memoryPercent > 85) issues.push('High memory usage');
    
    if (issues.length === 0) return '✅ All systems operational';
    return `⚠️ Issues: ${issues.join(', ')}`;
}