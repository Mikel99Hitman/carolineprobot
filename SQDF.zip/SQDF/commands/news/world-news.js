const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('world-news')
        .setDescription('🌍 World News & Global Updates System')
        .addSubcommand(subcommand =>
            subcommand
                .setName('breaking-news')
                .setDescription('Get breaking world news')
                .addStringOption(option =>
                    option.setName('region')
                        .setDescription('News region')
                        .addChoices(
                            { name: 'Global 🌍', value: 'global' },
                            { name: 'Middle East 🕌', value: 'middleeast' },
                            { name: 'Europe 🇪🇺', value: 'europe' },
                            { name: 'Asia 🌏', value: 'asia' },
                            { name: 'Americas 🌎', value: 'americas' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('tech-news')
                .setDescription('Latest technology news')
                .addStringOption(option =>
                    option.setName('category')
                        .setDescription('Tech category')
                        .addChoices(
                            { name: 'All Tech', value: 'all' },
                            { name: 'AI & Machine Learning', value: 'ai' },
                            { name: 'Cryptocurrency', value: 'crypto' },
                            { name: 'Space & Science', value: 'space' }
                        ))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        await interaction.deferReply();

        if (subcommand === 'breaking-news') {
            const region = interaction.options.getString('region') || 'global';
            const embed = new EmbedBuilder()
                .setTitle('🌍 World Breaking News')
                .setDescription('Latest global news and updates')
                .addFields(
                    { name: '🚨 Breaking News', value: '🌍 Global climate summit begins\n🏛️ New trade agreements signed\n📊 Economic markets update', inline: false }
                )
                .setColor('#3498db')
                .setTimestamp();
            await interaction.editReply({ embeds: [embed] });
        } else {
            const embed = new EmbedBuilder()
                .setTitle('💻 Technology News')
                .setDescription('Latest tech developments and innovations')
                .addFields(
                    { name: '🤖 Tech Updates', value: '🤖 New AI breakthrough announced\n₿ Bitcoin reaches new milestone\n🚀 SpaceX successful launch', inline: false }
                )
                .setColor('#9b59b6')
                .setTimestamp();
            await interaction.editReply({ embeds: [embed] });
        }
    }
};