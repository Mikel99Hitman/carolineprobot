const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('entertainment-news')
        .setDescription('🎬 Movies & TV Shows News System')
        .addSubcommand(subcommand =>
            subcommand
                .setName('movie-news')
                .setDescription('Latest movie news and releases')
                .addStringOption(option =>
                    option.setName('category')
                        .setDescription('Movie category')
                        .addChoices(
                            { name: 'All Movies', value: 'all' },
                            { name: 'Hollywood 🎬', value: 'hollywood' },
                            { name: 'Marvel & DC 🦸', value: 'superhero' },
                            { name: 'Horror 👻', value: 'horror' },
                            { name: 'Animation 🎨', value: 'animation' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('tv-shows')
                .setDescription('TV shows and series updates')
                .addStringOption(option =>
                    option.setName('platform')
                        .setDescription('Streaming platform')
                        .addChoices(
                            { name: 'All Platforms', value: 'all' },
                            { name: 'Netflix 📺', value: 'netflix' },
                            { name: 'Disney+ 🏰', value: 'disney' },
                            { name: 'HBO Max 🎭', value: 'hbo' },
                            { name: 'Amazon Prime 📦', value: 'prime' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('box-office')
                .setDescription('Box office results and rankings')
                .addStringOption(option =>
                    option.setName('period')
                        .setDescription('Time period')
                        .addChoices(
                            { name: 'This Weekend', value: 'weekend' },
                            { name: 'This Month', value: 'month' },
                            { name: 'This Year', value: 'year' }
                        ))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        await interaction.deferReply();

        if (subcommand === 'movie-news') {
            const embed = new EmbedBuilder()
                .setTitle('🎬 Latest Movie News')
                .setDescription('Breaking entertainment news and movie updates')
                .addFields(
                    { name: '🚨 Breaking News', value: '🎬 New Marvel movie announced\n🏆 Oscar nominations revealed\n🎭 Director signs new project', inline: false },
                    { name: '🎥 Upcoming Releases', value: '🦸 Deadpool 3 - July 2024\n🎬 Dune Part 3 - 2026\n👻 A Quiet Place 3 - 2025', inline: false }
                )
                .setColor('#e74c3c')
                .setTimestamp();
            await interaction.editReply({ embeds: [embed] });
        } else if (subcommand === 'tv-shows') {
            const embed = new EmbedBuilder()
                .setTitle('📺 TV Shows & Series News')
                .setDescription('Latest updates from streaming platforms')
                .addFields(
                    { name: '🔥 Trending Shows', value: '📺 The Bear Season 3 renewed\n🏰 Mandalorian new season\n🎭 House of Dragon finale', inline: false },
                    { name: '📅 New Releases', value: '📺 Netflix: New series this week\n🏰 Disney+: Marvel shows update\n🎭 HBO: Drama series premiere', inline: false }
                )
                .setColor('#9b59b6')
                .setTimestamp();
            await interaction.editReply({ embeds: [embed] });
        } else {
            const embed = new EmbedBuilder()
                .setTitle('💰 Box Office Results')
                .setDescription('Current box office rankings and earnings')
                .addFields(
                    { name: '🏆 Top Movies', value: '1️⃣ Dune Part 2 - $150M\n2️⃣ Kung Fu Panda 4 - $120M\n3️⃣ Ghostbusters - $95M', inline: false }
                )
                .setColor('#f39c12')
                .setTimestamp();
            await interaction.editReply({ embeds: [embed] });
        }
    }
};