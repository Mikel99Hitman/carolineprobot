const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('sports-news')
        .setDescription('⚽ Sports News & Live Updates System')
        .addSubcommand(subcommand =>
            subcommand
                .setName('latest-news')
                .setDescription('Get latest sports news')
                .addStringOption(option =>
                    option.setName('sport')
                        .setDescription('Sport category')
                        .addChoices(
                            { name: 'All Sports', value: 'all' },
                            { name: 'Football ⚽', value: 'football' },
                            { name: 'Basketball 🏀', value: 'basketball' },
                            { name: 'Tennis 🎾', value: 'tennis' },
                            { name: 'Formula 1 🏎️', value: 'f1' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('live-scores')
                .setDescription('View live sports scores')
                .addStringOption(option =>
                    option.setName('league')
                        .setDescription('Sports league')
                        .addChoices(
                            { name: 'Premier League', value: 'epl' },
                            { name: 'La Liga', value: 'laliga' },
                            { name: 'NBA', value: 'nba' }
                        ))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        await interaction.deferReply();

        if (subcommand === 'latest-news') {
            const sport = interaction.options.getString('sport') || 'all';
            const embed = new EmbedBuilder()
                .setTitle('⚽ Latest Sports News')
                .setDescription('Breaking sports news and updates')
                .addFields(
                    { name: '🚨 Breaking News', value: '🚨 Messi scores hat-trick\n⚽ Real Madrid signs new striker\n🏀 Lakers win 112-108', inline: false }
                )
                .setColor('#00ff00')
                .setTimestamp();
            await interaction.editReply({ embeds: [embed] });
        } else {
            const embed = new EmbedBuilder()
                .setTitle('🏆 Live Sports Scores')
                .setDescription('Current matches and live scores')
                .addFields(
                    { name: '🔴 Live Now', value: '🔴 Arsenal 2-1 Chelsea\n🔴 Man City 1-0 Liverpool', inline: false }
                )
                .setColor('#ff0000')
                .setTimestamp();
            await interaction.editReply({ embeds: [embed] });
        }
    }
};