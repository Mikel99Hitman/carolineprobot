const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('palestine-news')
        .setDescription('🇵🇸 Palestine News & Updates System')
        .addSubcommand(subcommand =>
            subcommand
                .setName('latest-news')
                .setDescription('آخر أخبار فلسطين - Latest Palestine news')
                .addStringOption(option =>
                    option.setName('category')
                        .setDescription('فئة الأخبار - News category')
                        .addChoices(
                            { name: 'جميع الأخبار - All News', value: 'all' },
                            { name: 'الأخبار السياسية - Political', value: 'political' },
                            { name: 'الأخبار الاجتماعية - Social', value: 'social' },
                            { name: 'الثقافة والتراث - Culture', value: 'culture' },
                            { name: 'الاقتصاد - Economy', value: 'economy' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('gaza-updates')
                .setDescription('تحديثات غزة - Gaza Strip updates')
                .addStringOption(option =>
                    option.setName('type')
                        .setDescription('نوع التحديث - Update type')
                        .addChoices(
                            { name: 'الوضع الإنساني - Humanitarian', value: 'humanitarian' },
                            { name: 'الإعمار والتنمية - Reconstruction', value: 'reconstruction' },
                            { name: 'التعليم والصحة - Education & Health', value: 'education' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('westbank-news')
                .setDescription('أخبار الضفة الغربية - West Bank news')
                .addStringOption(option =>
                    option.setName('region')
                        .setDescription('المنطقة - Region')
                        .addChoices(
                            { name: 'القدس - Jerusalem', value: 'jerusalem' },
                            { name: 'رام الله - Ramallah', value: 'ramallah' },
                            { name: 'نابلس - Nablus', value: 'nablus' },
                            { name: 'الخليل - Hebron', value: 'hebron' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('notifications')
                .setDescription('إعداد إشعارات الأخبار - Setup news notifications')
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('قناة الإشعارات - Notifications channel')
                        .setRequired(true))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        await interaction.deferReply();

        if (subcommand === 'latest-news') {
            const category = interaction.options.getString('category') || 'all';
            const embed = new EmbedBuilder()
                .setTitle('🇵🇸 آخر أخبار فلسطين - Latest Palestine News')
                .setDescription('أحدث الأخبار والتطورات من فلسطين - Latest news and developments from Palestine')
                .addFields(
                    { name: '🚨 الأخبار العاجلة - Breaking News', value: '🇵🇸 تطورات سياسية جديدة في رام الله\n🏛️ اجتماعات دبلوماسية مهمة\n📊 تقارير اقتصادية جديدة', inline: false },
                    { name: '🏛️ الأخبار السياسية - Political News', value: '🤝 مفاوضات سلام جديدة\n🌍 دعم دولي متزايد\n📜 قرارات حكومية مهمة', inline: false },
                    { name: '🎓 التعليم والثقافة - Education & Culture', value: '🎓 افتتاح مدارس جديدة\n📚 مشاريع ثقافية\n🎨 فعاليات تراثية', inline: false }
                )
                .setColor('#00ff00')
                .setTimestamp()
                .setFooter({ text: 'أخبار فلسطين • Palestine News' });
            await interaction.editReply({ embeds: [embed] });

        } else if (subcommand === 'gaza-updates') {
            const embed = new EmbedBuilder()
                .setTitle('🏘️ تحديثات قطاع غزة - Gaza Strip Updates')
                .setDescription('آخر التطورات والأخبار من قطاع غزة - Latest developments from Gaza Strip')
                .addFields(
                    { name: '🏥 الوضع الإنساني - Humanitarian Status', value: '🏥 تحسينات في الخدمات الصحية\n🍞 توزيع المساعدات الغذائية\n💧 مشاريع المياه النظيفة', inline: false },
                    { name: '🏗️ الإعمار والتنمية - Reconstruction', value: '🏗️ مشاريع إعمار جديدة\n🏠 بناء وحدات سكنية\n⚡ تحسين شبكة الكهرباء', inline: false }
                )
                .setColor('#ff6b35')
                .setTimestamp()
                .setFooter({ text: 'تحديثات غزة • Gaza Updates' });
            await interaction.editReply({ embeds: [embed] });

        } else if (subcommand === 'westbank-news') {
            const region = interaction.options.getString('region') || 'jerusalem';
            const embed = new EmbedBuilder()
                .setTitle('🏛️ أخبار الضفة الغربية - West Bank News')
                .setDescription('أحدث الأخبار من مدن الضفة الغربية - Latest news from West Bank cities')
                .addFields(
                    { name: '🕌 القدس - Jerusalem', value: '🕌 أخبار المسجد الأقصى\n🏛️ تطورات في البلدة القديمة\n🎓 أنشطة تعليمية وثقافية', inline: false },
                    { name: '🏛️ رام الله - Ramallah', value: '🏛️ اجتماعات حكومية\n💼 تطورات اقتصادية\n🎨 فعاليات ثقافية', inline: false }
                )
                .setColor('#3498db')
                .setTimestamp()
                .setFooter({ text: 'أخبار الضفة الغربية • West Bank News' });
            await interaction.editReply({ embeds: [embed] });

        } else {
            const channel = interaction.options.getChannel('channel');
            const embed = new EmbedBuilder()
                .setTitle('🔔 إعداد إشعارات أخبار فلسطين - Palestine News Notifications')
                .setDescription(`سيتم إرسال إشعارات أخبار فلسطين إلى <#${channel.id}>\nPalestine news notifications will be sent to <#${channel.id}>`)
                .addFields(
                    { name: '✅ تم التفعيل - Enabled', value: 'الأخبار العاجلة - Breaking news\nالتحديثات السياسية - Political updates\nالأخبار الثقافية - Cultural news', inline: false }
                )
                .setColor('#9b59b6')
                .setTimestamp()
                .setFooter({ text: 'إشعارات فلسطين • Palestine Notifications' });
            await interaction.editReply({ embeds: [embed] });
        }
    }
};