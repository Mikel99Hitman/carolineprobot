const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('screening')
        .setDescription('Advanced member screening system')
        .addSubcommand(subcommand =>
            subcommand
                .setName('setup')
                .setDescription('Setup member screening')
                .addIntegerOption(option =>
                    option.setName('min_account_age')
                        .setDescription('Minimum account age in days')
                        .setRequired(true)
                        .setMinValue(1)
                        .setMaxValue(365))
                .addBooleanOption(option =>
                    option.setName('require_avatar')
                        .setDescription('Require profile picture')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('check')
                .setDescription('Check a member')
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('User to check')
                        .setRequired(true)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'setup') {
            const minAge = interaction.options.getInteger('min_account_age');
            const requireAvatar = interaction.options.getBoolean('require_avatar') || false;

            // Store settings (simplified)
            global.screeningSettings = global.screeningSettings || new Map();
            global.screeningSettings.set(interaction.guild.id, {
                minAccountAge: minAge,
                requireAvatar
            });

            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('🛡️ Screening Setup Complete')
                .setDescription('Member screening has been configured')
                .addFields(
                    { name: 'Minimum Account Age', value: `${minAge} days`, inline: true },
                    { name: 'Require Avatar', value: requireAvatar ? 'Yes' : 'No', inline: true }
                )
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

        } else if (subcommand === 'check') {
            const user = interaction.options.getUser('user');
            const member = interaction.guild.members.cache.get(user.id);

            if (!member) {
                return interaction.reply({ content: '❌ Member not found!', ephemeral: true });
            }

            const accountAge = Math.floor((Date.now() - user.createdTimestamp) / (1000 * 60 * 60 * 24));
            const hasAvatar = user.avatar !== null;
            const joinedRecently = Math.floor((Date.now() - member.joinedTimestamp) / (1000 * 60 * 60 * 24)) < 1;

            // Risk assessment
            let riskLevel = 'Low';
            let riskColor = '#00ff00';
            const riskFactors = [];

            if (accountAge < 7) {
                riskFactors.push('Very new account');
                riskLevel = 'High';
                riskColor = '#ff0000';
            } else if (accountAge < 30) {
                riskFactors.push('New account');
                riskLevel = 'Medium';
                riskColor = '#ffaa00';
            }

            if (!hasAvatar) {
                riskFactors.push('No profile picture');
                if (riskLevel === 'Low') riskLevel = 'Medium';
                if (riskLevel === 'Medium') riskColor = '#ffaa00';
            }

            if (joinedRecently) {
                riskFactors.push('Joined very recently');
            }

            const embed = new EmbedBuilder()
                .setColor(riskColor)
                .setTitle('🔍 Member Screening Report')
                .setThumbnail(user.displayAvatarURL())
                .addFields(
                    { name: '👤 User', value: `${user} (${user.tag})`, inline: false },
                    { name: '📅 Account Age', value: `${accountAge} days`, inline: true },
                    { name: '🖼️ Has Avatar', value: hasAvatar ? 'Yes' : 'No', inline: true },
                    { name: '📥 Joined', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true },
                    { name: '⚠️ Risk Level', value: riskLevel, inline: true },
                    { name: '🔍 Risk Factors', value: riskFactors.length > 0 ? riskFactors.join('\n') : 'None detected', inline: false }
                )
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        }
    }
};