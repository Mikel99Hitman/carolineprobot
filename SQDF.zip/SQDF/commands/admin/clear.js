const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('clear')
        .setDescription('حذف عدد معين من الرسائل')
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('عدد الرسائل المراد حذفها (1-100)')
                .setRequired(true)
                .setMinValue(1)
                .setMaxValue(100))
        .addUserOption(option =>
            option.setName('user')
                .setDescription('حذف رسائل مستخدم معين فقط')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    async execute(interaction) {
        const amount = interaction.options.getInteger('amount');
        const targetUser = interaction.options.getUser('user');

        await interaction.deferReply({ ephemeral: true });

        try {
            let messages;
            
            if (targetUser) {
                // حذف رسائل مستخدم معين
                const fetchedMessages = await interaction.channel.messages.fetch({ limit: 100 });
                messages = fetchedMessages.filter(msg => msg.author.id === targetUser.id).first(amount);
            } else {
                // حذف عدد معين من الرسائل
                messages = await interaction.channel.messages.fetch({ limit: amount });
            }

            const deletedMessages = await interaction.channel.bulkDelete(messages, true);

            const successEmbed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('🗑️ تم حذف الرسائل')
                .setDescription(`تم حذف **${deletedMessages.size}** رسالة${targetUser ? ` من ${targetUser}` : ''}`)
                .setTimestamp();

            await interaction.editReply({ embeds: [successEmbed] });

            // حذف رسالة التأكيد بعد 5 ثوان
            setTimeout(async () => {
                try {
                    await interaction.deleteReply();
                } catch (error) {
                    console.log('Could not delete reply message');
                }
            }, 5000);

        } catch (error) {
            console.error('Error deleting messages:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('❌ خطأ')
                .setDescription('حدث خطأ أثناء حذف الرسائل. تأكد من أن الرسائل ليست أقدم من 14 يوم.');

            await interaction.editReply({ embeds: [errorEmbed] });
        }
    }
};