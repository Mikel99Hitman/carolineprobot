const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('slowmode')
        .setDescription('Set channel slowmode')
        .addIntegerOption(option =>
            option.setName('seconds')
                .setDescription('Slowmode duration in seconds (0 to disable)')
                .setRequired(true)
                .setMinValue(0)
                .setMaxValue(21600))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

    async execute(interaction) {
        const seconds = interaction.options.getInteger('seconds');
        
        await interaction.channel.setRateLimitPerUser(seconds);

        const embed = new EmbedBuilder()
            .setColor(seconds > 0 ? '#ffaa00' : '#00ff00')
            .setTitle('⏱️ Slowmode Updated')
            .setDescription(seconds > 0 ? 
                `Slowmode set to ${seconds} seconds` : 
                'Slowmode disabled')
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};