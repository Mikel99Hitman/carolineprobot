const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const User = require('../../models/User');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('warn')
        .setDescription('تحذير عضو')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('العضو المراد تحذيره')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('سبب التحذير')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

    async execute(interaction) {
        const targetUser = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'لم يتم تحديد سبب';
        const member = interaction.guild.members.cache.get(targetUser.id);

        if (!member) {
            return interaction.reply({ content: '❌ العضو غير موجود في السيرفر!', ephemeral: true });
        }

        if (member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: '❌ لا يمكن تحذير المشرفين!', ephemeral: true });
        }

        let userData = await User.findOne({ 
            userId: targetUser.id, 
            guildId: interaction.guild.id 
        });

        if (!userData) {
            userData = new User({
                userId: targetUser.id,
                guildId: interaction.guild.id
            });
        }

        userData.warnings += 1;
        await userData.save();

        const warnEmbed = new EmbedBuilder()
            .setColor('#ff9900')
            .setTitle('⚠️ تحذير')
            .setDescription(`تم تحذير ${targetUser}`)
            .addFields(
                { name: 'السبب', value: reason, inline: true },
                { name: 'عدد التحذيرات', value: userData.warnings.toString(), inline: true },
                { name: 'المشرف', value: interaction.user.toString(), inline: true }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [warnEmbed] });

        // إرسال رسالة خاصة للعضو
        try {
            const dmEmbed = new EmbedBuilder()
                .setColor('#ff9900')
                .setTitle('⚠️ تحذير')
                .setDescription(`تم تحذيرك في سيرفر **${interaction.guild.name}**`)
                .addFields(
                    { name: 'السبب', value: reason },
                    { name: 'عدد التحذيرات', value: userData.warnings.toString() }
                );

            await targetUser.send({ embeds: [dmEmbed] });
        } catch (error) {
            console.log('Could not send DM to user');
        }

        // إجراءات تلقائية حسب عدد التحذيرات
        if (userData.warnings >= 3) {
            try {
                await member.timeout(24 * 60 * 60 * 1000, 'تجاوز عدد التحذيرات المسموح'); // 24 ساعة
                
                const timeoutEmbed = new EmbedBuilder()
                    .setColor('#ff0000')
                    .setTitle('🔇 كتم تلقائي')
                    .setDescription(`تم كتم ${targetUser} لمدة 24 ساعة لتجاوز عدد التحذيرات المسموح`);

                await interaction.followUp({ embeds: [timeoutEmbed] });
            } catch (error) {
                console.error('Error timing out user:', error);
            }
        }
    }
};