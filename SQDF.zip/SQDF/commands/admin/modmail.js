const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const Modmail = require('../../models/Modmail');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('modmail')
        .setDescription('Modmail system')
        .addSubcommand(subcommand =>
            subcommand
                .setName('setup')
                .setDescription('Setup modmail category')
                .addChannelOption(option =>
                    option.setName('category')
                        .setDescription('Modmail category')
                        .addChannelTypes(ChannelType.GuildCategory)
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('close')
                .setDescription('Close modmail thread'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('reply')
                .setDescription('Reply to modmail')
                .addStringOption(option =>
                    option.setName('message')
                        .setDescription('Reply message')
                        .setRequired(true)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'setup') {
            const category = interaction.options.getChannel('category');

            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle('📧 Modmail Setup')
                .setDescription(`Modmail category set to ${category.name}`)
                .addFields({ name: 'Usage', value: 'Users can DM the bot to create modmail threads' })
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

        } else if (subcommand === 'close') {
            const modmail = await Modmail.findOne({ 
                channelId: interaction.channel.id, 
                status: 'open' 
            });

            if (!modmail) {
                return interaction.reply({ content: '❌ This is not a modmail thread!', ephemeral: true });
            }

            modmail.status = 'closed';
            await modmail.save();

            const embed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('📧 Modmail Closed')
                .setDescription('This modmail thread has been closed')
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

            setTimeout(async () => {
                try {
                    await interaction.channel.delete();
                } catch (error) {
                    console.error('Error deleting modmail channel:', error);
                }
            }, 5000);
        }
    }
};