const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const Guild = require('../../models/Guild');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup')
        .setDescription('Setup bot for server')
        .addSubcommand(subcommand =>
            subcommand
                .setName('welcome')
                .setDescription('Setup welcome system')
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('Welcome channel')
                        .setRequired(true)
                        .addChannelTypes(ChannelType.GuildText))
                .addStringOption(option =>
                    option.setName('message')
                        .setDescription('Welcome message (use {user} for member and {server} for server)')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('logs')
                .setDescription('Setup logs system')
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('Logs channel')
                        .setRequired(true)
                        .addChannelTypes(ChannelType.GuildText)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('levels')
                .setDescription('Setup levels system')
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('Level notifications channel')
                        .setRequired(true)
                        .addChannelTypes(ChannelType.GuildText)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('protection')
                .setDescription('Setup protection system')
                .addBooleanOption(option =>
                    option.setName('antispam')
                        .setDescription('Enable anti-spam')
                        .setRequired(true))
                .addBooleanOption(option =>
                    option.setName('antilink')
                        .setDescription('Enable anti-link')
                        .setRequired(true)))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        let guildData = await Guild.findOne({ guildId: interaction.guild.id });
        
        if (!guildData) {
            guildData = new Guild({ guildId: interaction.guild.id });
        }

        const embed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('⚙️ Setup completed successfully!')
            .setTimestamp();

        switch (subcommand) {
            case 'welcome':
                const welcomeChannel = interaction.options.getChannel('channel');
                const welcomeMessage = interaction.options.getString('message') || 'Welcome {user} to {server}!';
                
                guildData.welcomeChannel = welcomeChannel.id;
                guildData.welcomeMessage = welcomeMessage;
                
                embed.setDescription(`Welcome system setup in ${welcomeChannel}\nMessage: ${welcomeMessage}`);
                break;

            case 'logs':
                const logChannel = interaction.options.getChannel('channel');
                guildData.logChannel = logChannel.id;
                
                embed.setDescription(`Logs system setup in ${logChannel}`);
                break;

            case 'levels':
                const levelChannel = interaction.options.getChannel('channel');
                guildData.levelUpChannel = levelChannel.id;
                
                embed.setDescription(`Levels system setup in ${levelChannel}`);
                break;

            case 'protection':
                const antiSpam = interaction.options.getBoolean('antispam');
                const antiLink = interaction.options.getBoolean('antilink');
                
                guildData.antiSpam = antiSpam;
                guildData.antiLink = antiLink;
                
                embed.setDescription(`Protection system setup:\n🛡️ Anti-spam: ${antiSpam ? 'Enabled' : 'Disabled'}\n🔗 Anti-link: ${antiLink ? 'Enabled' : 'Disabled'}`);
                break;
        }

        await guildData.save();
        await interaction.reply({ embeds: [embed] });
    }
};