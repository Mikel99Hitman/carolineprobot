const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('lock')
        .setDescription('Lock/unlock channel')
        .addSubcommand(subcommand =>
            subcommand
                .setName('channel')
                .setDescription('Lock current channel'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('unlock')
                .setDescription('Unlock current channel'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('server')
                .setDescription('Lock entire server'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'channel') {
            await interaction.channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
                SendMessages: false
            });

            const embed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('🔒 Channel Locked')
                .setDescription(`${interaction.channel} has been locked`)
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

        } else if (subcommand === 'unlock') {
            await interaction.channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
                SendMessages: null
            });

            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('🔓 Channel Unlocked')
                .setDescription(`${interaction.channel} has been unlocked`)
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

        } else if (subcommand === 'server') {
            await interaction.deferReply();

            const channels = interaction.guild.channels.cache.filter(ch => ch.type === 0);
            let count = 0;

            for (const [id, channel] of channels) {
                try {
                    await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
                        SendMessages: false
                    });
                    count++;
                } catch (error) {
                    console.error(`Failed to lock ${channel.name}`);
                }
            }

            const embed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('🔒 Server Locked')
                .setDescription(`Locked ${count} channels`)
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        }
    }
};