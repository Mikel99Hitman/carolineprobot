const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const CustomCommand = require('../../models/CustomCommand');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('customcmd')
        .setDescription('Manage custom commands')
        .addSubcommand(subcommand =>
            subcommand
                .setName('create')
                .setDescription('Create custom command')
                .addStringOption(option =>
                    option.setName('name')
                        .setDescription('Command name')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('response')
                        .setDescription('Command response')
                        .setRequired(true))
                .addBooleanOption(option =>
                    option.setName('embed')
                        .setDescription('Send as embed')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('delete')
                .setDescription('Delete custom command')
                .addStringOption(option =>
                    option.setName('name')
                        .setDescription('Command name')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('list')
                .setDescription('List custom commands'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'create') {
            const name = interaction.options.getString('name').toLowerCase();
            const response = interaction.options.getString('response');
            const embed = interaction.options.getBoolean('embed') || false;

            const existing = await CustomCommand.findOne({ guildId: interaction.guild.id, name });
            if (existing) {
                return interaction.reply({ content: '❌ Command already exists!', ephemeral: true });
            }

            const customCmd = new CustomCommand({
                guildId: interaction.guild.id,
                name,
                response,
                authorId: interaction.user.id,
                embed
            });

            await customCmd.save();

            const successEmbed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('✅ Custom Command Created')
                .setDescription(`Command \`${name}\` has been created!`)
                .addFields(
                    { name: 'Response', value: response.substring(0, 1000), inline: false },
                    { name: 'Embed', value: embed ? 'Yes' : 'No', inline: true }
                )
                .setTimestamp();

            await interaction.reply({ embeds: [successEmbed] });

        } else if (subcommand === 'list') {
            const commands = await CustomCommand.find({ guildId: interaction.guild.id }).sort({ uses: -1 });

            if (commands.length === 0) {
                return interaction.reply({ content: '❌ No custom commands found!', ephemeral: true });
            }

            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle('🛠️ Custom Commands')
                .setDescription(commands.map(cmd => `\`${cmd.name}\` (${cmd.uses} uses)`).join('\n'))
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        }
    }
};