const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, ChannelType } = require('discord.js');
const Verification = require('../../models/Verification');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('verify')
        .setDescription('Setup verification system')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Verification channel')
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(true))
        .addRoleOption(option =>
            option.setName('role')
                .setDescription('Role to give after verification')
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    async execute(interaction) {
        const channel = interaction.options.getChannel('channel');
        const role = interaction.options.getRole('role');

        const embed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('✅ Verification Required')
            .setDescription('Click the button below to verify and gain access to the server!')
            .addFields(
                { name: '📋 Rules', value: '• Be respectful\n• Follow Discord ToS\n• No spam or harassment', inline: false },
                { name: '🎯 What you get', value: `• Access to all channels\n• ${role} role\n• Ability to chat and participate`, inline: false }
            )
            .setFooter({ text: 'Verification is required to access this server' })
            .setTimestamp();

        const button = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('verify_user')
                    .setLabel('Verify')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('✅')
            );

        const message = await channel.send({ embeds: [embed], components: [button] });

        const verification = new Verification({
            guildId: interaction.guild.id,
            channelId: channel.id,
            roleId: role.id,
            messageId: message.id
        });

        await verification.save();

        const successEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('✅ Verification Setup Complete')
            .setDescription(`Verification system setup in ${channel}`)
            .addFields(
                { name: 'Verification Role', value: role.toString(), inline: true },
                { name: 'Channel', value: channel.toString(), inline: true }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [successEmbed] });
    }
};