const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('statschannels')
        .setDescription('Create server statistics channels')
        .addChannelOption(option =>
            option.setName('category')
                .setDescription('Category for stats channels')
                .addChannelTypes(ChannelType.GuildCategory)
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

    async execute(interaction) {
        await interaction.deferReply();
        
        const category = interaction.options.getChannel('category');
        const guild = interaction.guild;

        try {
            // Create stats channels
            const channels = await Promise.all([
                guild.channels.create({
                    name: `👥 Members: ${guild.memberCount}`,
                    type: ChannelType.GuildVoice,
                    parent: category.id,
                    permissionOverwrites: [{
                        id: guild.roles.everyone.id,
                        deny: ['Connect']
                    }]
                }),
                guild.channels.create({
                    name: `🤖 Bots: ${guild.members.cache.filter(m => m.user.bot).size}`,
                    type: ChannelType.GuildVoice,
                    parent: category.id,
                    permissionOverwrites: [{
                        id: guild.roles.everyone.id,
                        deny: ['Connect']
                    }]
                }),
                guild.channels.create({
                    name: `🚀 Boosts: ${guild.premiumSubscriptionCount}`,
                    type: ChannelType.GuildVoice,
                    parent: category.id,
                    permissionOverwrites: [{
                        id: guild.roles.everyone.id,
                        deny: ['Connect']
                    }]
                }),
                guild.channels.create({
                    name: `📝 Channels: ${guild.channels.cache.size}`,
                    type: ChannelType.GuildVoice,
                    parent: category.id,
                    permissionOverwrites: [{
                        id: guild.roles.everyone.id,
                        deny: ['Connect']
                    }]
                })
            ]);

            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('📊 Stats Channels Created')
                .setDescription(`Created ${channels.length} statistics channels in ${category}`)
                .addFields(
                    { name: 'Channels Created', value: channels.map(ch => ch.name).join('\n'), inline: false },
                    { name: 'Auto Update', value: 'These channels will update automatically', inline: false }
                )
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

            // Update stats every 10 minutes
            setInterval(async () => {
                try {
                    await channels[0].setName(`👥 Members: ${guild.memberCount}`);
                    await channels[1].setName(`🤖 Bots: ${guild.members.cache.filter(m => m.user.bot).size}`);
                    await channels[2].setName(`🚀 Boosts: ${guild.premiumSubscriptionCount}`);
                    await channels[3].setName(`📝 Channels: ${guild.channels.cache.size}`);
                } catch (error) {
                    console.error('Error updating stats channels:', error);
                }
            }, 600000);

        } catch (error) {
            console.error('Error creating stats channels:', error);
            await interaction.editReply({ content: '❌ Failed to create stats channels!' });
        }
    }
};