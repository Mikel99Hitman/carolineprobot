const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const Guild = require('../../models/Guild');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('webhook')
        .setDescription('Setup webhook for logging')
        .addStringOption(option =>
            option.setName('url')
                .setDescription('Webhook URL for external logging')
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const webhookUrl = interaction.options.getString('url');

        // Validate webhook URL
        if (!webhookUrl.includes('discord.com/api/webhooks/')) {
            return interaction.reply({ content: '❌ Invalid webhook URL!', ephemeral: true });
        }

        let guildData = await Guild.findOne({ guildId: interaction.guild.id });
        if (!guildData) {
            guildData = new Guild({ guildId: interaction.guild.id });
        }

        guildData.webhookUrl = webhookUrl;
        await guildData.save();

        const embed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('✅ Webhook Configured')
            .setDescription('Webhook URL has been set successfully! All server logs will now be sent to the configured webhook.')
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};