const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('nick')
        .setDescription('Change user nickname')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to change nickname')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('nickname')
                .setDescription('New nickname (leave empty to reset)')
                .setRequired(false)
                .setMaxLength(32))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageNicknames),

    async execute(interaction) {
        const user = interaction.options.getUser('user');
        const nickname = interaction.options.getString('nickname');
        const member = interaction.guild.members.cache.get(user.id);

        if (!member) {
            return interaction.reply({ content: '❌ Member not found!', ephemeral: true });
        }

        const oldNick = member.displayName;
        await member.setNickname(nickname);

        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('✏️ Nickname Changed')
            .addFields(
                { name: 'User', value: user.toString(), inline: true },
                { name: 'Old Nickname', value: oldNick, inline: true },
                { name: 'New Nickname', value: nickname || user.username, inline: true }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};