const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const WordFilter = require('../../models/WordFilter');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('filter')
        .setDescription('Manage word filter')
        .addSubcommand(subcommand =>
            subcommand
                .setName('add')
                .setDescription('Add filtered word')
                .addStringOption(option =>
                    option.setName('word')
                        .setDescription('Word to filter')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('remove')
                .setDescription('Remove filtered word')
                .addStringOption(option =>
                    option.setName('word')
                        .setDescription('Word to remove')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('list')
                .setDescription('List filtered words'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        
        let filter = await WordFilter.findOne({ guildId: interaction.guild.id });
        if (!filter) {
            filter = new WordFilter({ guildId: interaction.guild.id, words: [] });
        }

        if (subcommand === 'add') {
            const word = interaction.options.getString('word').toLowerCase();
            
            if (filter.words.includes(word)) {
                return interaction.reply({ content: '❌ Word already filtered!', ephemeral: true });
            }

            filter.words.push(word);
            await filter.save();

            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('✅ Word Added to Filter')
                .setDescription(`Added "${word}" to the filter list`);

            await interaction.reply({ embeds: [embed] });

        } else if (subcommand === 'list') {
            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle('🚫 Filtered Words')
                .setDescription(filter.words.length > 0 ? 
                    filter.words.map(w => `\`${w}\``).join(', ') : 
                    'No words filtered');

            await interaction.reply({ embeds: [embed], ephemeral: true });
        }
    }
};