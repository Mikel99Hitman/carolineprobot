const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('backup')
        .setDescription('Server backup system')
        .addSubcommand(subcommand =>
            subcommand
                .setName('create')
                .setDescription('Create server backup'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('load')
                .setDescription('Load server backup')
                .addStringOption(option =>
                    option.setName('id')
                        .setDescription('Backup ID')
                        .setRequired(true)))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        
        if (subcommand === 'create') {
            await interaction.deferReply();
            
            const guild = interaction.guild;
            const backup = {
                id: Date.now().toString(),
                name: guild.name,
                icon: guild.iconURL(),
                channels: guild.channels.cache.map(ch => ({
                    name: ch.name,
                    type: ch.type,
                    position: ch.position,
                    parent: ch.parent?.name
                })),
                roles: guild.roles.cache.map(role => ({
                    name: role.name,
                    color: role.hexColor,
                    permissions: role.permissions.toArray()
                }))
            };

            // Save backup (simplified - would use database)
            console.log('Backup created:', backup.id);

            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('✅ Backup Created')
                .setDescription(`Backup ID: \`${backup.id}\``)
                .addFields(
                    { name: 'Channels', value: backup.channels.length.toString(), inline: true },
                    { name: 'Roles', value: backup.roles.length.toString(), inline: true }
                );

            await interaction.editReply({ embeds: [embed] });
        }
    }
};