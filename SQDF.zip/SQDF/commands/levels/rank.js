const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const Canvas = require('canvas');
const User = require('../../models/User');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('rank')
        .setDescription('Show your rank or another member\'s rank')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('Member to show rank for')
                .setRequired(false)),

    async execute(interaction) {
        const targetUser = interaction.options.getUser('user') || interaction.user;
        const member = interaction.guild.members.cache.get(targetUser.id);

        if (!member) {
            return interaction.reply({ content: '❌ Member not found in server!', ephemeral: true });
        }

        let userData = await User.findOne({ 
            userId: targetUser.id, 
            guildId: interaction.guild.id 
        });

        if (!userData) {
            userData = new User({
                userId: targetUser.id,
                guildId: interaction.guild.id
            });
            await userData.save();
        }

        // Calculate rank
        const allUsers = await User.find({ guildId: interaction.guild.id })
            .sort({ level: -1, xp: -1 });
        const rank = allUsers.findIndex(user => user.userId === targetUser.id) + 1;

        // Create rank image
        const canvas = Canvas.createCanvas(800, 300);
        const ctx = canvas.getContext('2d');

        // Gradient background
        const gradient = ctx.createLinearGradient(0, 0, 800, 300);
        gradient.addColorStop(0, '#667eea');
        gradient.addColorStop(1, '#764ba2');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, 800, 300);

        // Experience bar
        const requiredXp = userData.level * 100;
        const xpPercentage = userData.xp / requiredXp;
        
        ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.fillRect(200, 200, 500, 30);
        
        ctx.fillStyle = '#00ff00';
        ctx.fillRect(200, 200, 500 * xpPercentage, 30);

        // Text
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 30px Arial';
        ctx.fillText(member.displayName, 200, 80);

        ctx.font = '20px Arial';
        ctx.fillText(`Level: ${userData.level}`, 200, 120);
        ctx.fillText(`XP: ${userData.xp}/${requiredXp}`, 200, 150);
        ctx.fillText(`Rank: #${rank}`, 200, 180);
        ctx.fillText(`Messages: ${userData.messages}`, 500, 120);

        // User image
        try {
            const avatar = await Canvas.loadImage(targetUser.displayAvatarURL({ extension: 'png', size: 128 }));
            ctx.beginPath();
            ctx.arc(100, 150, 60, 0, Math.PI * 2, true);
            ctx.closePath();
            ctx.clip();
            ctx.drawImage(avatar, 40, 90, 120, 120);
        } catch (error) {
            console.error('Error loading avatar:', error);
        }

        const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'rank.png' });

        const rankEmbed = new EmbedBuilder()
            .setColor('#667eea')
            .setTitle(`📊 ${member.displayName}'s Rank`)
            .setImage('attachment://rank.png')
            .setTimestamp();

        await interaction.reply({ embeds: [rankEmbed], files: [attachment] });
    }
};