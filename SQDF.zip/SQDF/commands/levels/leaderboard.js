const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const User = require('../../models/User');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('leaderboard')
        .setDescription('عرض لوحة المتصدرين')
        .addStringOption(option =>
            option.setName('type')
                .setDescription('نوع اللوحة')
                .setRequired(false)
                .addChoices(
                    { name: 'المستويات', value: 'levels' },
                    { name: 'الرسائل', value: 'messages' },
                    { name: 'الدعوات', value: 'invites' }
                )),

    async execute(interaction) {
        const type = interaction.options.getString('type') || 'levels';
        
        let sortField, title, emoji;
        switch (type) {
            case 'levels':
                sortField = { level: -1, xp: -1 };
                title = '🏆 متصدري المستويات';
                emoji = '📊';
                break;
            case 'messages':
                sortField = { messages: -1 };
                title = '💬 متصدري الرسائل';
                emoji = '📝';
                break;
            case 'invites':
                sortField = { invites: -1 };
                title = '🔗 متصدري الدعوات';
                emoji = '📨';
                break;
        }

        const topUsers = await User.find({ guildId: interaction.guild.id });
        let sortedUsers;
        
        switch (type) {
            case 'levels':
                sortedUsers = topUsers.sort((a, b) => {
                    if (b.level !== a.level) return b.level - a.level;
                    return b.xp - a.xp;
                }).slice(0, 10);
                break;
            case 'messages':
                sortedUsers = topUsers.sort((a, b) => b.messages - a.messages).slice(0, 10);
                break;
            case 'invites':
                sortedUsers = topUsers.sort((a, b) => b.invites - a.invites).slice(0, 10);
                break;
        }

        if (sortedUsers.length === 0) {
            return interaction.reply({ content: '❌ لا توجد بيانات للعرض!', ephemeral: true });
        }

        const leaderboardEmbed = new EmbedBuilder()
            .setColor('#ffd700')
            .setTitle(title)
            .setThumbnail(interaction.guild.iconURL())
            .setTimestamp();

        let description = '';
        for (let i = 0; i < sortedUsers.length; i++) {
            const user = sortedUsers[i];
            const member = interaction.guild.members.cache.get(user.user_id);
            
            if (!member) continue;

            const position = i + 1;
            const medal = position === 1 ? '🥇' : position === 2 ? '🥈' : position === 3 ? '🥉' : `${position}.`;
            
            let value;
            switch (type) {
                case 'levels':
                    value = `المستوى ${user.level} (${user.xp} XP)`;
                    break;
                case 'messages':
                    value = `${user.messages} رسالة`;
                    break;
                case 'invites':
                    value = `${user.invites} دعوة`;
                    break;
            }

            description += `${medal} **${member.displayName}** - ${value}\n`;
        }

        leaderboardEmbed.setDescription(description);

        // إضافة موقع المستخدم الحالي
        const currentUser = await User.findOne({ 
            userId: interaction.user.id, 
            guildId: interaction.guild.id 
        });

        if (currentUser) {
            const allUsers = await User.find({ guildId: interaction.guild.id });
            let userRank;
            
            switch (type) {
                case 'levels':
                    const levelSorted = allUsers.sort((a, b) => {
                        if (b.level !== a.level) return b.level - a.level;
                        return b.xp - a.xp;
                    });
                    userRank = levelSorted.findIndex(user => user.user_id === interaction.user.id) + 1;
                    break;
                case 'messages':
                    const messageSorted = allUsers.sort((a, b) => b.messages - a.messages);
                    userRank = messageSorted.findIndex(user => user.user_id === interaction.user.id) + 1;
                    break;
                case 'invites':
                    const inviteSorted = allUsers.sort((a, b) => b.invites - a.invites);
                    userRank = inviteSorted.findIndex(user => user.user_id === interaction.user.id) + 1;
                    break;
            }
            
            let userValue;
            switch (type) {
                case 'levels':
                    userValue = `المستوى ${currentUser.level} (${currentUser.xp} XP)`;
                    break;
                case 'messages':
                    userValue = `${currentUser.messages} رسالة`;
                    break;
                case 'invites':
                    userValue = `${currentUser.invites} دعوة`;
                    break;
            }

            leaderboardEmbed.addFields({
                name: 'موقعك',
                value: `#${userRank} - ${userValue}`,
                inline: false
            });
        }

        await interaction.reply({ embeds: [leaderboardEmbed] });
    }
};