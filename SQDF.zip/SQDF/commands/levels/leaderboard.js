const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const User = require('../../models/User');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('leaderboard')
        .setDescription('عرض لوحة المتصدرين')
        .addStringOption(option =>
            option.setName('type')
                .setDescription('نوع اللوحة')
                .setRequired(false)
                .addChoices(
                    { name: 'المستويات', value: 'levels' },
                    { name: 'الرسائل', value: 'messages' },
                    { name: 'الدعوات', value: 'invites' }
                )),

    async execute(interaction) {
        const type = interaction.options.getString('type') || 'levels';
        
        let sortField, title, emoji;
        switch (type) {
            case 'levels':
                sortField = { level: -1, xp: -1 };
                title = '🏆 متصدري المستويات';
                emoji = '📊';
                break;
            case 'messages':
                sortField = { messages: -1 };
                title = '💬 متصدري الرسائل';
                emoji = '📝';
                break;
            case 'invites':
                sortField = { invites: -1 };
                title = '🔗 متصدري الدعوات';
                emoji = '📨';
                break;
        }

        const topUsers = await User.find({ guildId: interaction.guild.id })
            .sort(sortField)
            .limit(10);

        if (topUsers.length === 0) {
            return interaction.reply({ content: '❌ لا توجد بيانات للعرض!', ephemeral: true });
        }

        const leaderboardEmbed = new EmbedBuilder()
            .setColor('#ffd700')
            .setTitle(title)
            .setThumbnail(interaction.guild.iconURL())
            .setTimestamp();

        let description = '';
        for (let i = 0; i < topUsers.length; i++) {
            const user = topUsers[i];
            const member = interaction.guild.members.cache.get(user.userId);
            
            if (!member) continue;

            const position = i + 1;
            const medal = position === 1 ? '🥇' : position === 2 ? '🥈' : position === 3 ? '🥉' : `${position}.`;
            
            let value;
            switch (type) {
                case 'levels':
                    value = `المستوى ${user.level} (${user.xp} XP)`;
                    break;
                case 'messages':
                    value = `${user.messages} رسالة`;
                    break;
                case 'invites':
                    value = `${user.invites} دعوة`;
                    break;
            }

            description += `${medal} **${member.displayName}** - ${value}\n`;
        }

        leaderboardEmbed.setDescription(description);

        // إضافة موقع المستخدم الحالي
        const currentUser = await User.findOne({ 
            userId: interaction.user.id, 
            guildId: interaction.guild.id 
        });

        if (currentUser) {
            const allUsers = await User.find({ guildId: interaction.guild.id }).sort(sortField);
            const userRank = allUsers.findIndex(user => user.userId === interaction.user.id) + 1;
            
            let userValue;
            switch (type) {
                case 'levels':
                    userValue = `المستوى ${currentUser.level} (${currentUser.xp} XP)`;
                    break;
                case 'messages':
                    userValue = `${currentUser.messages} رسالة`;
                    break;
                case 'invites':
                    userValue = `${currentUser.invites} دعوة`;
                    break;
            }

            leaderboardEmbed.addFields({
                name: 'موقعك',
                value: `#${userRank} - ${userValue}`,
                inline: false
            });
        }

        await interaction.reply({ embeds: [leaderboardEmbed] });
    }
};