const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, ChannelType } = require('discord.js');
const Giveaway = require('../../models/Giveaway');
const ms = require('ms');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('giveaway')
        .setDescription('Start a giveaway')
        .addStringOption(option =>
            option.setName('duration')
                .setDescription('Duration (e.g., 1h, 30m, 1d)')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('prize')
                .setDescription('Prize description')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('winners')
                .setDescription('Number of winners')
                .setRequired(true)
                .setMinValue(1)
                .setMaxValue(20))
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Channel to host the giveaway')
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(false))
        .addRoleOption(option =>
            option.setName('required_role')
                .setDescription('Required role to participate')
                .setRequired(false))
        .addIntegerOption(option =>
            option.setName('required_level')
                .setDescription('Required level to participate')
                .setRequired(false)
                .setMinValue(1))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    async execute(interaction) {
        const duration = interaction.options.getString('duration');
        const prize = interaction.options.getString('prize');
        const winners = interaction.options.getInteger('winners');
        const channel = interaction.options.getChannel('channel') || interaction.channel;
        const requiredRole = interaction.options.getRole('required_role');
        const requiredLevel = interaction.options.getInteger('required_level');

        const time = ms(duration);
        if (!time || time < 10000) {
            return interaction.reply({ content: '❌ Invalid duration! Minimum is 10 seconds.', ephemeral: true });
        }

        const endTime = new Date(Date.now() + time);

        const giveawayEmbed = new EmbedBuilder()
            .setColor('#ff6b6b')
            .setTitle('🎉 GIVEAWAY 🎉')
            .setDescription(`**Prize:** ${prize}\\n**Winners:** ${winners}\\n**Ends:** <t:${Math.floor(endTime.getTime() / 1000)}:R>\\n**Hosted by:** ${interaction.user}`)
            .setFooter({ text: 'Click the button below to enter!' })
            .setTimestamp(endTime);

        if (requiredRole || requiredLevel) {
            let requirements = '**Requirements:**\\n';
            if (requiredRole) requirements += `• Have the ${requiredRole} role\\n`;
            if (requiredLevel) requirements += `• Be level ${requiredLevel} or higher\\n`;
            giveawayEmbed.addFields({ name: '📋 Entry Requirements', value: requirements });
        }

        const enterButton = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('enter_giveaway')
                    .setLabel('🎉 Enter Giveaway')
                    .setStyle(ButtonStyle.Primary)
            );

        const giveawayMessage = await channel.send({ embeds: [giveawayEmbed], components: [enterButton] });

        await Giveaway.create({
            guildId: interaction.guild.id,
            channelId: channel.id,
            messageId: giveawayMessage.id,
            hostId: interaction.user.id,
            prize,
            winners,
            endTime,
            requirements: {
                role: requiredRole?.id || null,
                level: requiredLevel || 0
            }
        });

        // Set timeout to end giveaway
        setTimeout(async () => {
            await endGiveaway(giveawayMessage.id);
        }, time);

        await interaction.reply({ content: `✅ Giveaway started in ${channel}!`, ephemeral: true });
    }
};

async function endGiveaway(messageId) {
    try {
        const giveaway = await Giveaway.findOne({ messageId });
        if (!giveaway || giveaway.ended) return;

        // Note: client reference needs to be passed or accessed differently
        // This function needs to be called with proper client context
        
        await Giveaway.findOneAndUpdate(
            { messageId },
            { ended: true }
        );

        // Additional logic would need client access for message editing
        console.log('Giveaway ended:', messageId);

    } catch (error) {
        console.error('Error ending giveaway:', error);
    }
}