const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('role')
        .setDescription('Advanced role management')
        .addSubcommand(subcommand =>
            subcommand
                .setName('give')
                .setDescription('Give role to user')
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('User to give role')
                        .setRequired(true))
                .addRoleOption(option =>
                    option.setName('role')
                        .setDescription('Role to give')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('remove')
                .setDescription('Remove role from user')
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('User to remove role from')
                        .setRequired(true))
                .addRoleOption(option =>
                    option.setName('role')
                        .setDescription('Role to remove')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('all')
                .setDescription('Give role to all members')
                .addRoleOption(option =>
                    option.setName('role')
                        .setDescription('Role to give to all')
                        .setRequired(true)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'give') {
            const user = interaction.options.getUser('user');
            const role = interaction.options.getRole('role');
            const member = interaction.guild.members.cache.get(user.id);

            if (!member) {
                return interaction.reply({ content: '❌ Member not found!', ephemeral: true });
            }

            await member.roles.add(role);

            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('✅ Role Added')
                .setDescription(`Added ${role} to ${user}`)
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

        } else if (subcommand === 'all') {
            await interaction.deferReply();
            
            const role = interaction.options.getRole('role');
            const members = await interaction.guild.members.fetch();
            let count = 0;

            for (const [id, member] of members) {
                if (!member.user.bot && !member.roles.cache.has(role.id)) {
                    try {
                        await member.roles.add(role);
                        count++;
                    } catch (error) {
                        console.error(`Failed to add role to ${member.user.tag}`);
                    }
                }
            }

            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('✅ Mass Role Assignment')
                .setDescription(`Added ${role} to ${count} members`)
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        }
    }
};