const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const ReactionRole = require('../../models/ReactionRole');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('reactionroles')
        .setDescription('Setup reaction roles')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Channel to send reaction roles message')
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(true))
        .addStringOption(option =>
            option.setName('title')
                .setDescription('Title for the reaction roles embed')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('description')
                .setDescription('Description for the reaction roles embed')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    async execute(interaction) {
        const channel = interaction.options.getChannel('channel');
        const title = interaction.options.getString('title') || 'Reaction Roles';
        const description = interaction.options.getString('description') || 'React to get roles!';

        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle(title)
            .setDescription(description)
            .setFooter({ text: 'React with the emojis below to get roles!' })
            .setTimestamp();

        const message = await channel.send({ embeds: [embed] });

        const reactionRole = new ReactionRole({
            guildId: interaction.guild.id,
            messageId: message.id,
            channelId: channel.id,
            title,
            description,
            roles: []
        });

        await reactionRole.save();

        const successEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('✅ Reaction Roles Setup')
            .setDescription(`Reaction roles message created in ${channel}!\nUse \`/addrole\` to add roles to this message.`)
            .addFields(
                { name: 'Message ID', value: message.id, inline: true },
                { name: 'Channel', value: channel.toString(), inline: true }
            );

        await interaction.reply({ embeds: [successEmbed] });
    }
};