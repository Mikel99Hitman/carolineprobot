const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const AutoRole = require('../../models/AutoRole');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('autorole')
        .setDescription('Manage auto roles')
        .addSubcommand(subcommand =>
            subcommand
                .setName('add')
                .setDescription('Add an auto role')
                .addStringOption(option =>
                    option.setName('type')
                        .setDescription('Auto role type')
                        .addChoices(
                            { name: 'On Join', value: 'join' },
                            { name: 'Level Requirement', value: 'level' },
                            { name: 'Server Boost', value: 'boost' },
                            { name: 'Time in Server', value: 'time' }
                        )
                        .setRequired(true))
                .addRoleOption(option =>
                    option.setName('role')
                        .setDescription('Role to assign')
                        .setRequired(true))
                .addIntegerOption(option =>
                    option.setName('level')
                        .setDescription('Required level (for level type)')
                        .setMinValue(1)
                        .setRequired(false))
                .addIntegerOption(option =>
                    option.setName('hours')
                        .setDescription('Hours in server (for time type)')
                        .setMinValue(1)
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('list')
                .setDescription('List all auto roles'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('remove')
                .setDescription('Remove an auto role')
                .addRoleOption(option =>
                    option.setName('role')
                        .setDescription('Role to remove from auto roles')
                        .setRequired(true)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'add') {
            const type = interaction.options.getString('type');
            const role = interaction.options.getRole('role');
            const level = interaction.options.getInteger('level');
            const hours = interaction.options.getInteger('hours');

            if (type === 'level' && !level) {
                return interaction.reply({ content: '❌ Level is required for level type auto role!', ephemeral: true });
            }

            if (type === 'time' && !hours) {
                return interaction.reply({ content: '❌ Hours is required for time type auto role!', ephemeral: true });
            }

            const autoRole = new AutoRole({
                guildId: interaction.guild.id,
                type,
                roleId: role.id,
                requirement: {
                    level: level || 0,
                    timeInServer: hours || 0
                }
            });

            await autoRole.save();

            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('✅ Auto Role Added')
                .setDescription(`Auto role **${role.name}** has been configured!`)
                .addFields(
                    { name: 'Type', value: type, inline: true },
                    { name: 'Role', value: role.toString(), inline: true }
                );

            if (level) embed.addFields({ name: 'Required Level', value: level.toString(), inline: true });
            if (hours) embed.addFields({ name: 'Required Hours', value: hours.toString(), inline: true });

            await interaction.reply({ embeds: [embed] });

        } else if (subcommand === 'list') {
            const autoRoles = await AutoRole.find({ guildId: interaction.guild.id, enabled: true });

            if (autoRoles.length === 0) {
                return interaction.reply({ content: '❌ No auto roles configured!', ephemeral: true });
            }

            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle('🤖 Auto Roles')
                .setDescription('List of all configured auto roles');

            autoRoles.forEach(autoRole => {
                const role = interaction.guild.roles.cache.get(autoRole.roleId);
                if (role) {
                    let description = `Type: ${autoRole.type}`;
                    if (autoRole.requirement.level > 0) description += `\nLevel: ${autoRole.requirement.level}`;
                    if (autoRole.requirement.timeInServer > 0) description += `\nTime: ${autoRole.requirement.timeInServer}h`;

                    embed.addFields({ name: role.name, value: description, inline: true });
                }
            });

            await interaction.reply({ embeds: [embed] });

        } else if (subcommand === 'remove') {
            const role = interaction.options.getRole('role');

            const result = await AutoRole.deleteOne({ guildId: interaction.guild.id, roleId: role.id });

            if (result.deletedCount === 0) {
                return interaction.reply({ content: '❌ This role is not configured as an auto role!', ephemeral: true });
            }

            const embed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('🗑️ Auto Role Removed')
                .setDescription(`Auto role **${role.name}** has been removed!`);

            await interaction.reply({ embeds: [embed] });
        }
    }
};