const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const ReactionRole = require('../../models/ReactionRole');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('addrole')
        .setDescription('Add a role to reaction roles message')
        .addStringOption(option =>
            option.setName('message_id')
                .setDescription('Message ID of the reaction roles message')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('emoji')
                .setDescription('Emoji for the role')
                .setRequired(true))
        .addRoleOption(option =>
            option.setName('role')
                .setDescription('Role to assign')
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    async execute(interaction) {
        const messageId = interaction.options.getString('message_id');
        const emoji = interaction.options.getString('emoji');
        const role = interaction.options.getRole('role');

        const reactionRole = await ReactionRole.findOne({
            guildId: interaction.guild.id,
            messageId: messageId
        });

        if (!reactionRole) {
            return interaction.reply({ content: '❌ Reaction roles message not found!', ephemeral: true });
        }

        // Check if emoji already exists
        if (reactionRole.roles.some(r => r.emoji === emoji)) {
            return interaction.reply({ content: '❌ This emoji is already used!', ephemeral: true });
        }

        // Add role to the reaction role system
        reactionRole.roles.push({
            emoji: emoji,
            roleId: role.id
        });

        await reactionRole.save();

        // Get the message and add reaction
        const channel = interaction.guild.channels.cache.get(reactionRole.channelId);
        const message = await channel.messages.fetch(messageId);

        try {
            await message.react(emoji);
        } catch (error) {
            console.error('Error adding reaction:', error);
        }

        // Update the embed
        const updatedEmbed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle(reactionRole.title)
            .setDescription(reactionRole.description)
            .addFields(
                reactionRole.roles.map(r => ({
                    name: r.emoji,
                    value: `<@&${r.roleId}>`,
                    inline: true
                }))
            )
            .setFooter({ text: 'React with the emojis below to get roles!' })
            .setTimestamp();

        await message.edit({ embeds: [updatedEmbed] });

        const successEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('✅ Role Added')
            .setDescription(`Successfully added ${role} with emoji ${emoji} to the reaction roles!`);

        await interaction.reply({ embeds: [successEmbed] });
    }
};