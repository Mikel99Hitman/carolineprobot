const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const Poll = require('../../models/Poll');
const ms = require('ms');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('poll')
        .setDescription('Create a poll')
        .addStringOption(option =>
            option.setName('question')
                .setDescription('Poll question')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('options')
                .setDescription('Poll options separated by | (max 10)')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('duration')
                .setDescription('Poll duration (e.g., 1h, 30m, 1d)')
                .setRequired(false))
        .addBooleanOption(option =>
            option.setName('multiple')
                .setDescription('Allow multiple votes')
                .setRequired(false))
        .addBooleanOption(option =>
            option.setName('anonymous')
                .setDescription('Anonymous voting')
                .setRequired(false)),

    async execute(interaction) {
        const question = interaction.options.getString('question');
        const optionsString = interaction.options.getString('options');
        const duration = interaction.options.getString('duration') || '1h';
        const allowMultiple = interaction.options.getBoolean('multiple') || false;
        const anonymous = interaction.options.getBoolean('anonymous') || false;

        const optionTexts = optionsString.split('|').map(opt => opt.trim()).slice(0, 10);
        
        if (optionTexts.length < 2) {
            return interaction.reply({ content: '❌ You need at least 2 options!', ephemeral: true });
        }

        const time = ms(duration);
        if (!time || time < 60000) {
            return interaction.reply({ content: '❌ Invalid duration! Minimum is 1 minute.', ephemeral: true });
        }

        const endTime = new Date(Date.now() + time);
        const emojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

        const options = optionTexts.map((text, index) => ({
            text,
            emoji: emojis[index],
            votes: []
        }));

        const pollEmbed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('📊 Poll')
            .setDescription(`**${question}**`)
            .addFields(
                options.map(opt => ({
                    name: `${opt.emoji} ${opt.text}`,
                    value: '0 votes (0%)',
                    inline: true
                }))
            )
            .addFields(
                { name: 'Settings', value: `Multiple votes: ${allowMultiple ? '✅' : '❌'}\nAnonymous: ${anonymous ? '✅' : '❌'}`, inline: true },
                { name: 'Ends', value: `<t:${Math.floor(endTime.getTime() / 1000)}:R>`, inline: true }
            )
            .setFooter({ text: `Created by ${interaction.user.tag}` })
            .setTimestamp();

        const buttons = [];
        for (let i = 0; i < Math.min(options.length, 5); i++) {
            buttons.push(
                new ButtonBuilder()
                    .setCustomId(`poll_vote_${i}`)
                    .setLabel(options[i].text)
                    .setEmoji(options[i].emoji)
                    .setStyle(ButtonStyle.Primary)
            );
        }

        const row1 = new ActionRowBuilder().addComponents(buttons);
        const components = [row1];

        if (options.length > 5) {
            const buttons2 = [];
            for (let i = 5; i < Math.min(options.length, 10); i++) {
                buttons2.push(
                    new ButtonBuilder()
                        .setCustomId(`poll_vote_${i}`)
                        .setLabel(options[i].text)
                        .setEmoji(options[i].emoji)
                        .setStyle(ButtonStyle.Primary)
                );
            }
            components.push(new ActionRowBuilder().addComponents(buttons2));
        }

        const pollMessage = await interaction.reply({ embeds: [pollEmbed], components, fetchReply: true });

        const poll = new Poll({
            guildId: interaction.guild.id,
            channelId: interaction.channel.id,
            messageId: pollMessage.id,
            creatorId: interaction.user.id,
            question,
            options,
            endTime,
            allowMultiple,
            anonymous
        });

        await poll.save();

        setTimeout(async () => {
            await endPoll(poll._id);
        }, time);
    }
};

async function endPoll(pollId) {
    try {
        const poll = await Poll.findById(pollId);
        if (!poll || poll.ended) return;

        poll.ended = true;
        await poll.save();

        // Update the poll message with results
        // Implementation would go here
    } catch (error) {
        console.error('Error ending poll:', error);
    }
}