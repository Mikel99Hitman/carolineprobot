const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, ChannelType } = require('discord.js');
const Ticket = require('../../models/Ticket');
const Guild = require('../../models/Guild');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('إنشاء تذكرة دعم جديدة')
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('سبب إنشاء التذكرة')
                .setRequired(false)
                .addChoices(
                    { name: 'دعم عام', value: 'general' },
                    { name: 'مشكلة تقنية', value: 'technical' },
                    { name: 'شكوى', value: 'complaint' },
                    { name: 'اقتراح', value: 'suggestion' }
                )),

    async execute(interaction) {
        const guildData = await Guild.findOne({ guildId: interaction.guild.id });
        
        if (!guildData || !guildData.ticket_category) {
            return interaction.reply({ 
                content: '❌ نظام التذاكر غير مُعد! استخدم `/setup tickets` لإعداده.', 
                ephemeral: true 
            });
        }

        const category = interaction.guild.channels.cache.get(guildData.ticket_category);
        if (!category) {
            return interaction.reply({ 
                content: '❌ فئة التذاكر غير موجودة!', 
                ephemeral: true 
            });
        }

        // التحقق من وجود تذكرة مفتوحة
        const existingTicket = await Ticket.findOne({
            userId: interaction.user.id,
            guildId: interaction.guild.id,
            status: 'open'
        });

        if (existingTicket) {
            return interaction.reply({ 
                content: '❌ لديك تذكرة مفتوحة بالفعل!', 
                ephemeral: true 
            });
        }

        const reason = interaction.options.getString('reason') || 'general';
        const ticketId = `ticket-${interaction.user.id}-${Date.now()}`;

        try {
            // إنشاء قناة التذكرة
            const ticketChannel = await interaction.guild.channels.create({
                name: `🎫-${interaction.user.username}`,
                type: ChannelType.GuildText,
                parent: category.id,
                permissionOverwrites: [
                    {
                        id: interaction.guild.id,
                        deny: [PermissionFlagsBits.ViewChannel],
                    },
                    {
                        id: interaction.user.id,
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory
                        ],
                    },
                    {
                        id: interaction.client.user.id,
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ManageChannels
                        ],
                    }
                ],
            });

            // حفظ التذكرة في قاعدة البيانات
            await Ticket.create({
                ticketId,
                guildId: interaction.guild.id,
                userId: interaction.user.id,
                channelId: ticketChannel.id,
                reason
            });

            // رسالة التذكرة
            const ticketEmbed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle('🎫 تذكرة دعم جديدة')
                .setDescription(`مرحباً ${interaction.user}!\nتم إنشاء تذكرتك بنجاح.`)
                .addFields(
                    { name: 'السبب', value: getReasonText(reason), inline: true },
                    { name: 'التاريخ', value: new Date().toLocaleString('ar-SA'), inline: true }
                )
                .setFooter({ text: 'سيتم الرد عليك قريباً' })
                .setTimestamp();

            const closeButton = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('close_ticket')
                        .setLabel('إغلاق التذكرة')
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji('🔒')
                );

            await ticketChannel.send({ 
                content: `${interaction.user}`, 
                embeds: [ticketEmbed], 
                components: [closeButton] 
            });

            await interaction.reply({ 
                content: `✅ تم إنشاء تذكرتك في ${ticketChannel}`, 
                ephemeral: true 
            });

        } catch (error) {
            console.error('Error creating ticket:', error);
            await interaction.reply({ 
                content: '❌ حدث خطأ أثناء إنشاء التذكرة!', 
                ephemeral: true 
            });
        }
    }
};

function getReasonText(reason) {
    const reasons = {
        'general': 'دعم عام',
        'technical': 'مشكلة تقنية',
        'complaint': 'شكوى',
        'suggestion': 'اقتراح'
    };
    return reasons[reason] || 'غير محدد';
}