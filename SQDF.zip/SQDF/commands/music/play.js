const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus } = require('@discordjs/voice');
const play = require('play-dl');

const queue = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('play')
        .setDescription('تشغيل أغنية من YouTube')
        .addStringOption(option =>
            option.setName('song')
                .setDescription('اسم الأغنية أو رابط YouTube')
                .setRequired(true)),

    async execute(interaction) {
        const voiceChannel = interaction.member.voice.channel;
        if (!voiceChannel) {
            return interaction.reply({ content: '❌ يجب أن تكون في قناة صوتية!', ephemeral: true });
        }

        const permissions = voiceChannel.permissionsFor(interaction.client.user);
        if (!permissions.has('Connect') || !permissions.has('Speak')) {
            return interaction.reply({ content: '❌ ليس لدي صلاحيات للانضمام أو التحدث في هذه القناة!', ephemeral: true });
        }

        await interaction.deferReply();

        const song = interaction.options.getString('song');
        let songInfo;

        try {
            if (play.yt_validate(song) === 'video') {
                songInfo = await play.video_info(song);
            } else {
                const searched = await play.search(song, { limit: 1 });
                if (searched.length === 0) {
                    return interaction.editReply('❌ لم أجد أي نتائج لهذا البحث!');
                }
                songInfo = searched[0];
            }
        } catch (error) {
            console.error(error);
            return interaction.editReply('❌ حدث خطأ أثناء البحث عن الأغنية!');
        }

        const songData = {
            title: songInfo.title,
            url: songInfo.url,
            duration: songInfo.durationInSec,
            thumbnail: songInfo.thumbnails[0]?.url,
            requester: interaction.user
        };

        const serverQueue = queue.get(interaction.guild.id);

        if (!serverQueue) {
            const queueConstruct = {
                textChannel: interaction.channel,
                voiceChannel: voiceChannel,
                connection: null,
                player: null,
                songs: [],
                playing: true
            };

            queue.set(interaction.guild.id, queueConstruct);
            queueConstruct.songs.push(songData);

            try {
                const connection = joinVoiceChannel({
                    channelId: voiceChannel.id,
                    guildId: interaction.guild.id,
                    adapterCreator: interaction.guild.voiceAdapterCreator,
                });

                queueConstruct.connection = connection;
                await playSong(interaction.guild, queueConstruct.songs[0]);

                const embed = new EmbedBuilder()
                    .setColor('#00ff00')
                    .setTitle('🎵 بدء التشغيل')
                    .setDescription(`**${songData.title}**`)
                    .setThumbnail(songData.thumbnail)
                    .addFields(
                        { name: 'المدة', value: formatTime(songData.duration), inline: true },
                        { name: 'طلب بواسطة', value: songData.requester.toString(), inline: true }
                    );

                await interaction.editReply({ embeds: [embed] });
            } catch (error) {
                console.error(error);
                queue.delete(interaction.guild.id);
                return interaction.editReply('❌ حدث خطأ أثناء الانضمام للقناة الصوتية!');
            }
        } else {
            serverQueue.songs.push(songData);

            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle('📝 تمت الإضافة للقائمة')
                .setDescription(`**${songData.title}**`)
                .setThumbnail(songData.thumbnail)
                .addFields(
                    { name: 'الموضع في القائمة', value: serverQueue.songs.length.toString(), inline: true },
                    { name: 'المدة', value: formatTime(songData.duration), inline: true },
                    { name: 'طلب بواسطة', value: songData.requester.toString(), inline: true }
                );

            await interaction.editReply({ embeds: [embed] });
        }
    }
};

async function playSong(guild, song) {
    const serverQueue = queue.get(guild.id);
    if (!song) {
        serverQueue.connection.destroy();
        queue.delete(guild.id);
        return;
    }

    try {
        const stream = await play.stream(song.url);
        const resource = createAudioResource(stream.stream, { inputType: stream.type });
        
        if (!serverQueue.player) {
            serverQueue.player = createAudioPlayer();
            serverQueue.connection.subscribe(serverQueue.player);
        }

        serverQueue.player.play(resource);

        serverQueue.player.on(AudioPlayerStatus.Idle, () => {
            serverQueue.songs.shift();
            playSong(guild, serverQueue.songs[0]);
        });

    } catch (error) {
        console.error(error);
        serverQueue.songs.shift();
        playSong(guild, serverQueue.songs[0]);
    }
}

function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
}