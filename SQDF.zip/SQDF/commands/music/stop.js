const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

// استيراد الـ queue من ملف play.js
const queue = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('stop')
        .setDescription('إيقاف الموسيقى وإفراغ القائمة'),

    async execute(interaction) {
        const voiceChannel = interaction.member.voice.channel;
        if (!voiceChannel) {
            return interaction.reply({ content: '❌ يجب أن تكون في قناة صوتية!', ephemeral: true });
        }

        const serverQueue = queue.get(interaction.guild.id);
        if (!serverQueue) {
            return interaction.reply({ content: '❌ لا توجد موسيقى قيد التشغيل!', ephemeral: true });
        }

        serverQueue.songs = [];
        if (serverQueue.player) {
            serverQueue.player.stop();
        }
        if (serverQueue.connection) {
            serverQueue.connection.destroy();
        }
        queue.delete(interaction.guild.id);

        const stopEmbed = new EmbedBuilder()
            .setColor('#ff0000')
            .setTitle('⏹️ تم إيقاف الموسيقى')
            .setDescription('تم إيقاف الموسيقى وإفراغ القائمة')
            .setTimestamp();

        await interaction.reply({ embeds: [stopEmbed] });
    }
};