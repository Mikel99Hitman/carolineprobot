const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Economy = require('../../models/Economy');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('daily')
        .setDescription('Claim your daily reward'),

    async execute(interaction) {
        let economyData = await Economy.findOne({
            userId: interaction.user.id,
            guildId: interaction.guild.id
        });

        if (!economyData) {
            economyData = await Economy.create({
                userId: interaction.user.id,
                guildId: interaction.guild.id,
                balance: 0,
                bank: 0
            });
        }

        const now = new Date();
        const lastDaily = economyData.last_daily;

        if (lastDaily && now - new Date(lastDaily) < 24 * 60 * 60 * 1000) {
            const timeLeft = 24 * 60 * 60 * 1000 - (now - new Date(lastDaily));
            const hours = Math.floor(timeLeft / (60 * 60 * 1000));
            const minutes = Math.floor((timeLeft % (60 * 60 * 1000)) / (60 * 1000));

            const errorEmbed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('⏰ Daily Already Claimed')
                .setDescription(`You can claim your daily reward again in **${hours}h ${minutes}m**`);

            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        const dailyAmount = Math.floor(Math.random() * 500) + 100;
        
        await Economy.findOneAndUpdate(
            { userId: interaction.user.id, guildId: interaction.guild.id },
            { 
                balance: economyData.balance + dailyAmount,
                lastDaily: now
            }
        );

        await Economy.addTransaction(
            interaction.user.id,
            interaction.guild.id,
            'earn',
            dailyAmount,
            'Daily reward'
        );

        const dailyEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('🎁 Daily Reward Claimed!')
            .setDescription(`You received **$${dailyAmount.toLocaleString()}**!`)
            .addFields(
                { name: '💰 New Balance', value: `$${(economyData.balance + dailyAmount).toLocaleString()}`, inline: true }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [dailyEmbed] });
    }
};