const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Economy = require('../../models/Economy');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('balance')
        .setDescription('Check your or another user\'s balance')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to check balance for')
                .setRequired(false)),

    async execute(interaction) {
        const targetUser = interaction.options.getUser('user') || interaction.user;
        
        let economyData = await Economy.findOne({
            userId: targetUser.id,
            guildId: interaction.guild.id
        });

        if (!economyData) {
            economyData = await Economy.create({
                userId: targetUser.id,
                guildId: interaction.guild.id,
                balance: 0,
                bank: 0
            });
        }

        const balanceEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle(`💰 ${targetUser.username}'s Balance`)
            .setThumbnail(targetUser.displayAvatarURL())
            .addFields(
                { name: '💵 Wallet', value: `$${economyData.balance.toLocaleString()}`, inline: true },
                { name: '🏦 Bank', value: `$${economyData.bank.toLocaleString()}`, inline: true },
                { name: '💎 Net Worth', value: `$${(economyData.balance + economyData.bank).toLocaleString()}`, inline: true }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [balanceEmbed] });
    }
};