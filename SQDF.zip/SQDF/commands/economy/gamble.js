const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Economy = require('../../models/Economy');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('gamble')
        .setDescription('Gamble your money')
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('Amount to gamble')
                .setRequired(true)
                .setMinValue(10)),

    async execute(interaction) {
        const amount = interaction.options.getInteger('amount');

        let economyData = await Economy.findOne({
            userId: interaction.user.id,
            guildId: interaction.guild.id
        });

        if (!economyData) {
            economyData = await Economy.create({
                userId: interaction.user.id,
                guildId: interaction.guild.id,
                balance: 0,
                bank: 0
            });
        }

        if (economyData.balance < amount) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('💸 Insufficient Funds')
                .setDescription(`You need **$${amount.toLocaleString()}** but only have **$${economyData.balance.toLocaleString()}**`);

            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        const random = Math.random();
        let multiplier = 0;
        let result = '';

        if (random < 0.45) {
            multiplier = 0;
            result = 'Lost';
        } else if (random < 0.80) {
            multiplier = 1.5;
            result = 'Won';
        } else if (random < 0.95) {
            multiplier = 2;
            result = 'Big Win';
        } else {
            multiplier = 3;
            result = 'Jackpot';
        }

        const winnings = Math.floor(amount * multiplier);
        const profit = winnings - amount;

        await Economy.findOneAndUpdate(
            { userId: interaction.user.id, guildId: interaction.guild.id },
            { balance: economyData.balance + profit }
        );

        await Economy.addTransaction(
            interaction.user.id,
            interaction.guild.id,
            profit >= 0 ? 'earn' : 'spend',
            Math.abs(profit),
            `Gambling - ${result}`
        );

        const color = profit >= 0 ? '#00ff00' : '#ff0000';
        const emoji = profit >= 0 ? '🎉' : '💸';

        const gambleEmbed = new EmbedBuilder()
            .setColor(color)
            .setTitle(`${emoji} ${result}!`)
            .setDescription(`You ${profit >= 0 ? 'won' : 'lost'} **$${Math.abs(profit).toLocaleString()}**!`)
            .addFields(
                { name: '🎲 Multiplier', value: `${multiplier}x`, inline: true },
                { name: '💰 New Balance', value: `$${(economyData.balance + profit).toLocaleString()}`, inline: true }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [gambleEmbed] });
    }
};