const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const Economy = require('../../models/Economy');

const shopItems = [
    { id: 'vip', name: 'VIP Role', price: 5000, description: 'Get VIP status' },
    { id: 'color', name: 'Custom Color', price: 2000, description: 'Custom role color' },
    { id: 'nickname', name: 'Nickname Change', price: 1000, description: 'Change your nickname' }
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('shop')
        .setDescription('View the server shop'),

    async execute(interaction) {
        const embed = new EmbedBuilder()
            .setColor('#ffd700')
            .setTitle('🛒 Server Shop')
            .setDescription('Purchase items with your coins!');

        shopItems.forEach(item => {
            embed.addFields({
                name: `${item.name} - $${item.price.toLocaleString()}`,
                value: item.description,
                inline: true
            });
        });

        const buttons = shopItems.map(item =>
            new ButtonBuilder()
                .setCustomId(`buy_${item.id}`)
                .setLabel(`Buy ${item.name}`)
                .setStyle(ButtonStyle.Primary)
        );

        const row = new ActionRowBuilder().addComponents(buttons.slice(0, 3));
        await interaction.reply({ embeds: [embed], components: [row] });
    }
};