const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Economy = require('../../models/Economy');

const jobs = [
    { name: 'Developer', min: 200, max: 800 },
    { name: 'Designer', min: 150, max: 600 },
    { name: 'Writer', min: 100, max: 400 },
    { name: 'Streamer', min: 300, max: 1000 },
    { name: 'Gamer', min: 50, max: 300 }
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('work')
        .setDescription('Work to earn money'),

    async execute(interaction) {
        let economyData = await Economy.findOne({
            userId: interaction.user.id,
            guildId: interaction.guild.id
        });

        if (!economyData) {
            economyData = await Economy.create({
                userId: interaction.user.id,
                guildId: interaction.guild.id,
                balance: 0,
                bank: 0
            });
        }

        const now = new Date();
        const lastWork = economyData.last_work;

        if (lastWork && now - new Date(lastWork) < 60 * 60 * 1000) {
            const timeLeft = 60 * 60 * 1000 - (now - new Date(lastWork));
            const minutes = Math.floor(timeLeft / (60 * 1000));

            const errorEmbed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('⏰ Work Cooldown')
                .setDescription(`You can work again in **${minutes} minutes**`);

            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        const job = jobs[Math.floor(Math.random() * jobs.length)];
        const earnings = Math.floor(Math.random() * (job.max - job.min + 1)) + job.min;

        await Economy.findOneAndUpdate(
            { userId: interaction.user.id, guildId: interaction.guild.id },
            { 
                balance: economyData.balance + earnings,
                lastWork: now
            }
        );

        await Economy.addTransaction(
            interaction.user.id,
            interaction.guild.id,
            'earn',
            earnings,
            `Worked as ${job.name}`
        );

        const workEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('💼 Work Complete!')
            .setDescription(`You worked as a **${job.name}** and earned **$${earnings.toLocaleString()}**!`)
            .addFields(
                { name: '💰 New Balance', value: `$${(economyData.balance + earnings).toLocaleString()}`, inline: true }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [workEmbed] });
    }
};