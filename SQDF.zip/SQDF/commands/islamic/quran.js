const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('quran')
        .setDescription('📖 القرآن الكريم - Holy Quran Reader')
        .addSubcommand(subcommand =>
            subcommand
                .setName('read-surah')
                .setDescription('قراءة سورة - Read a Surah')
                .addIntegerOption(option =>
                    option.setName('surah-number')
                        .setDescription('رقم السورة - Surah number (1-114)')
                        .setMinValue(1)
                        .setMaxValue(114)
                        .setRequired(true))
                .addIntegerOption(option =>
                    option.setName('ayah-start')
                        .setDescription('رقم الآية للبداية - Starting verse number')
                        .setMinValue(1)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('search-verse')
                .setDescription('البحث في القرآن - Search in Quran')
                .addStringOption(option =>
                    option.setName('keyword')
                        .setDescription('الكلمة المراد البحث عنها - Keyword to search')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('daily-verse')
                .setDescription('آية اليوم - Daily verse')
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('قناة آية اليوم - Daily verse channel')))
        .addSubcommand(subcommand =>
            subcommand
                .setName('surah-list')
                .setDescription('قائمة السور - List of Surahs')
                .addStringOption(option =>
                    option.setName('filter')
                        .setDescription('تصفية السور - Filter surahs')
                        .addChoices(
                            { name: 'جميع السور - All Surahs', value: 'all' },
                            { name: 'السور المكية - Meccan', value: 'meccan' },
                            { name: 'السور المدنية - Medinan', value: 'medinan' }
                        ))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        await interaction.deferReply();

        switch (subcommand) {
            case 'read-surah':
                await this.readSurah(interaction);
                break;
            case 'search-verse':
                await this.searchVerse(interaction);
                break;
            case 'daily-verse':
                await this.dailyVerse(interaction);
                break;
            case 'surah-list':
                await this.surahList(interaction);
                break;
        }
    },

    async readSurah(interaction) {
        const surahNumber = interaction.options.getInteger('surah-number');
        const ayahStart = interaction.options.getInteger('ayah-start') || 1;
        const surahData = this.getSurahData(surahNumber);

        const embed = new EmbedBuilder()
            .setTitle(`📖 ${surahData.arabicName} - ${surahData.englishName}`)
            .setDescription(`السورة رقم ${surahNumber} - ${surahData.type} - ${surahData.verses} آية`)
            .addFields(
                { name: '🕌 بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ', value: surahData.bismillah, inline: false },
                { name: `📝 الآيات ${ayahStart}-${Math.min(ayahStart + 4, surahData.verses)}`, value: surahData.ayahs.slice(ayahStart - 1, ayahStart + 4).join('\n\n'), inline: false },
                { name: '📊 معلومات السورة', value: `النوع: ${surahData.type}\nعدد الآيات: ${surahData.verses}\nترتيب النزول: ${surahData.revelationOrder}`, inline: false }
            )
            .setColor('#00ff00')
            .setTimestamp()
            .setFooter({ text: 'القرآن الكريم • Holy Quran' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`prev_ayah_${surahNumber}_${Math.max(1, ayahStart - 5)}`)
                    .setLabel('⬅️ السابق')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(ayahStart <= 1),
                new ButtonBuilder()
                    .setCustomId(`next_ayah_${surahNumber}_${Math.min(surahData.verses, ayahStart + 5)}`)
                    .setLabel('التالي ➡️')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(ayahStart + 4 >= surahData.verses),
                new ButtonBuilder()
                    .setCustomId(`tafsir_${surahNumber}_${ayahStart}`)
                    .setLabel('📚 التفسير')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async searchVerse(interaction) {
        const keyword = interaction.options.getString('keyword');
        const searchResults = this.searchInQuran(keyword);

        const embed = new EmbedBuilder()
            .setTitle(`🔍 البحث في القرآن: "${keyword}"`)
            .setDescription(`تم العثور على ${searchResults.length} نتيجة`)
            .addFields(
                { name: '📖 النتائج', value: searchResults.slice(0, 5).map(result => 
                    `**${result.surah}** (${result.ayah}): ${result.text.substring(0, 100)}...`
                ).join('\n\n'), inline: false }
            )
            .setColor('#3498db')
            .setTimestamp()
            .setFooter({ text: 'البحث في القرآن • Quran Search' });

        await interaction.editReply({ embeds: [embed] });
    },

    async dailyVerse(interaction) {
        const channel = interaction.options.getChannel('channel');
        const dailyVerse = this.getDailyVerse();

        const embed = new EmbedBuilder()
            .setTitle('🌅 آية اليوم - Daily Verse')
            .setDescription(channel ? `سيتم إرسال آية اليوم إلى <#${channel.id}>` : 'آية اليوم')
            .addFields(
                { name: `📖 ${dailyVerse.surahName}`, value: dailyVerse.arabicText, inline: false },
                { name: '🔤 Translation', value: dailyVerse.translation, inline: false },
                { name: '📍 المرجع', value: `سورة ${dailyVerse.surahName} - الآية ${dailyVerse.ayahNumber}`, inline: false }
            )
            .setColor('#ffd700')
            .setTimestamp()
            .setFooter({ text: 'آية اليوم • Daily Verse' });

        await interaction.editReply({ embeds: [embed] });
    },

    async surahList(interaction) {
        const filter = interaction.options.getString('filter') || 'all';
        const surahs = this.getSurahsList(filter);

        const embed = new EmbedBuilder()
            .setTitle('📚 قائمة سور القرآن الكريم')
            .setDescription(`${filter === 'all' ? 'جميع السور' : filter === 'meccan' ? 'السور المكية' : 'السور المدنية'} (${surahs.length} سورة)`)
            .addFields(
                { name: '📖 السور 1-38', value: surahs.slice(0, 38).map(s => `${s.number}. ${s.name}`).join('\n'), inline: true },
                { name: '📖 السور 39-76', value: surahs.slice(38, 76).map(s => `${s.number}. ${s.name}`).join('\n'), inline: true },
                { name: '📖 السور 77-114', value: surahs.slice(76).map(s => `${s.number}. ${s.name}`).join('\n'), inline: true }
            )
            .setColor('#9b59b6')
            .setTimestamp()
            .setFooter({ text: 'قائمة السور • Surah List' });

        await interaction.editReply({ embeds: [embed] });
    },

    getSurahData(surahNumber) {
        const surahs = {
            1: { arabicName: 'الفاتحة', englishName: 'Al-Fatiha', type: 'مكية', verses: 7, revelationOrder: 5 },
            2: { arabicName: 'البقرة', englishName: 'Al-Baqarah', type: 'مدنية', verses: 286, revelationOrder: 87 },
            3: { arabicName: 'آل عمران', englishName: 'Aal-E-Imran', type: 'مدنية', verses: 200, revelationOrder: 89 }
        };

        const surah = surahs[surahNumber] || surahs[1];
        
        const ayahs = surahNumber === 1 ? [
            '(1) بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
            '(2) الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ',
            '(3) الرَّحْمَٰنِ الرَّحِيمِ',
            '(4) مَالِكِ يَوْمِ الدِّينِ',
            '(5) إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ',
            '(6) اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ',
            '(7) صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ'
        ] : [
            '(1) الم',
            '(2) ذَٰلِكَ الْكِتَابُ لَا رَيْبَ ۛ فِيهِ ۛ هُدًى لِّلْمُتَّقِينَ',
            '(3) الَّذِينَ يُؤْمِنُونَ بِالْغَيْبِ وَيُقِيمُونَ الصَّلَاةَ وَمِمَّا رَزَقْنَاهُمْ يُنفِقُونَ',
            '(4) وَالَّذِينَ يُؤْمِنُونَ بِمَا أُنزِلَ إِلَيْكَ وَمَا أُنزِلَ مِن قَبْلِكَ وَبِالْآخِرَةِ هُمْ يُوقِنُونَ',
            '(5) أُولَٰئِكَ عَلَىٰ هُدًى مِّن رَّبِّهِمْ ۖ وَأُولَٰئِكَ هُمُ الْمُفْلِحُونَ'
        ];

        return {
            ...surah,
            bismillah: surahNumber === 1 ? '' : 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
            ayahs
        };
    },

    searchInQuran(keyword) {
        return [
            { surah: 'الفاتحة', ayah: 2, text: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ' },
            { surah: 'البقرة', ayah: 2, text: 'ذَٰلِكَ الْكِتَابُ لَا رَيْبَ ۛ فِيهِ ۛ هُدًى لِّلْمُتَّقِينَ' },
            { surah: 'آل عمران', ayah: 1, text: 'الم' }
        ].filter(result => result.text.includes(keyword));
    },

    getDailyVerse() {
        const verses = [
            {
                surahName: 'الفاتحة',
                ayahNumber: 2,
                arabicText: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ',
                translation: 'All praise is due to Allah, Lord of the worlds.'
            },
            {
                surahName: 'البقرة',
                ayahNumber: 255,
                arabicText: 'اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ',
                translation: 'Allah - there is no deity except Him, the Ever-Living, the Sustainer of existence.'
            }
        ];
        
        return verses[Math.floor(Math.random() * verses.length)];
    },

    getSurahsList(filter) {
        const allSurahs = [
            { number: 1, name: 'الفاتحة', type: 'meccan' },
            { number: 2, name: 'البقرة', type: 'medinan' },
            { number: 3, name: 'آل عمران', type: 'medinan' },
            { number: 4, name: 'النساء', type: 'medinan' },
            { number: 5, name: 'المائدة', type: 'medinan' }
        ];

        if (filter === 'all') return allSurahs;
        return allSurahs.filter(surah => surah.type === filter);
    }
};