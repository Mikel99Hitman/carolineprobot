const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const Canvas = require('canvas');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('image')
        .setDescription('Image manipulation')
        .addSubcommand(subcommand =>
            subcommand
                .setName('blur')
                .setDescription('Blur user avatar')
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('User to blur')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('invert')
                .setDescription('Invert user avatar')
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('User to invert')
                        .setRequired(false))),

    async execute(interaction) {
        await interaction.deferReply();
        
        const subcommand = interaction.options.getSubcommand();
        const user = interaction.options.getUser('user') || interaction.user;

        try {
            const canvas = Canvas.createCanvas(256, 256);
            const ctx = canvas.getContext('2d');

            const avatar = await Canvas.loadImage(user.displayAvatarURL({ extension: 'png', size: 256 }));
            
            if (subcommand === 'blur') {
                ctx.filter = 'blur(5px)';
            } else if (subcommand === 'invert') {
                ctx.filter = 'invert(100%)';
            }

            ctx.drawImage(avatar, 0, 0, 256, 256);

            const attachment = new AttachmentBuilder(canvas.toBuffer(), { 
                name: `${subcommand}-${user.username}.png` 
            });

            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle(`🖼️ ${subcommand.charAt(0).toUpperCase() + subcommand.slice(1)} Effect`)
                .setImage(`attachment://${subcommand}-${user.username}.png`)
                .setTimestamp();

            await interaction.editReply({ embeds: [embed], files: [attachment] });
        } catch (error) {
            await interaction.editReply({ content: '❌ Failed to process image!' });
        }
    }
};