const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const TempVoice = require('../../models/TempVoice');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('tempvoice')
        .setDescription('Setup temporary voice channels')
        .addChannelOption(option =>
            option.setName('creator')
                .setDescription('Channel to create temp voices from')
                .addChannelTypes(ChannelType.GuildVoice)
                .setRequired(true))
        .addChannelOption(option =>
            option.setName('category')
                .setDescription('Category for temp channels')
                .addChannelTypes(ChannelType.GuildCategory)
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

    async execute(interaction) {
        const creator = interaction.options.getChannel('creator');
        const category = interaction.options.getChannel('category');

        const tempVoice = new TempVoice({
            guildId: interaction.guild.id,
            creatorChannelId: creator.id,
            categoryId: category.id
        });

        await tempVoice.save();

        const embed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('🔊 Temp Voice Setup')
            .setDescription(`Users joining ${creator} will get their own temporary voice channel!`)
            .addFields(
                { name: 'Creator Channel', value: creator.toString(), inline: true },
                { name: 'Category', value: category.name, inline: true }
            );

        await interaction.reply({ embeds: [embed] });
    }
};