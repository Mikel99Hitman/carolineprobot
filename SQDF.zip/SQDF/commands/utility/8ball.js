const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('8ball')
        .setDescription('Ask the magic 8-ball a question')
        .addStringOption(option =>
            option.setName('question')
                .setDescription('Your question')
                .setRequired(true)),

    async execute(interaction) {
        const question = interaction.options.getString('question');
        const responses = [
            'Yes', 'No', 'Maybe', 'Definitely', 'Absolutely not',
            'Ask again later', 'Very likely', 'Unlikely', 'Certainly',
            'Don\'t count on it', 'Yes definitely', 'Reply hazy, try again'
        ];

        const answer = responses[Math.floor(Math.random() * responses.length)];

        const embed = new EmbedBuilder()
            .setColor('#9932cc')
            .setTitle('🎱 Magic 8-Ball')
            .addFields(
                { name: 'Question', value: question, inline: false },
                { name: 'Answer', value: answer, inline: false }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};