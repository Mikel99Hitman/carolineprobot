const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios = require('axios');

const conversationMemory = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ai')
        .setDescription('Advanced AI conversation with OpenAI')
        .addSubcommand(subcommand =>
            subcommand
                .setName('chat')
                .setDescription('Chat with AI using OpenAI')
                .addStringOption(option =>
                    option.setName('message')
                        .setDescription('Your message to AI')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('image')
                .setDescription('Generate image with AI')
                .addStringOption(option =>
                    option.setName('prompt')
                        .setDescription('Image description')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('reset')
                .setDescription('Reset conversation memory')),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        
        if (!process.env.OPENAI_API_KEY) {
            return interaction.reply({ 
                content: '❌ OpenAI API key not configured. Please set OPENAI_API_KEY in .env file.', 
                ephemeral: true 
            });
        }

        if (subcommand === 'chat') {
            await this.handleChat(interaction);
        } else if (subcommand === 'image') {
            await this.handleImage(interaction);
        } else if (subcommand === 'reset') {
            await this.handleReset(interaction);
        }
    },

    async handleChat(interaction) {
        await interaction.deferReply();
        
        const message = interaction.options.getString('message');
        const userId = interaction.user.id;

        try {
            const response = await axios.post('https://api.openai.com/v1/chat/completions', {
                model: 'gpt-3.5-turbo',
                messages: [
                    { role: 'system', content: 'You are a helpful Discord bot assistant. Be friendly and concise.' },
                    { role: 'user', content: message }
                ],
                max_tokens: 500,
                temperature: 0.7
            }, {
                headers: {
                    'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
                    'Content-Type': 'application/json'
                }
            });

            const aiResponse = response.data.choices[0].message.content;

            const embed = new EmbedBuilder()
                .setColor('#00aaff')
                .setTitle('🤖 AI Assistant')
                .addFields(
                    { name: '👤 You', value: message, inline: false },
                    { name: '🤖 AI', value: aiResponse, inline: false }
                )
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            console.error('OpenAI API Error:', error.response?.data || error.message);
            
            const fallbackResponse = this.generateFallbackResponse(message);
            
            const embed = new EmbedBuilder()
                .setColor('#ffaa00')
                .setTitle('🤖 AI Assistant (Offline Mode)')
                .addFields(
                    { name: '👤 You', value: message, inline: false },
                    { name: '🤖 AI', value: fallbackResponse, inline: false }
                )
                .setFooter({ text: 'Using offline AI - OpenAI API unavailable' })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        }
    },

    async handleImage(interaction) {
        await interaction.deferReply();
        
        const prompt = interaction.options.getString('prompt');

        try {
            const response = await axios.post('https://api.openai.com/v1/images/generations', {
                prompt: prompt,
                n: 1,
                size: '512x512'
            }, {
                headers: {
                    'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
                    'Content-Type': 'application/json'
                }
            });

            const imageUrl = response.data.data[0].url;

            const embed = new EmbedBuilder()
                .setColor('#ff6b6b')
                .setTitle('🎨 AI Image Generator')
                .setDescription(`**Prompt:** ${prompt}`)
                .setImage(imageUrl)
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            console.error('OpenAI Image API Error:', error.response?.data || error.message);
            
            await interaction.editReply({ 
                content: '❌ Failed to generate image. Please check your OpenAI API key and try again.', 
            });
        }
    },

    async handleReset(interaction) {
        const userId = interaction.user.id;
        conversationMemory.delete(userId);
        
        const embed = new EmbedBuilder()
            .setColor('#ff0000')
            .setTitle('🔄 Memory Reset')
            .setDescription('Conversation memory has been cleared!')
            .setTimestamp();

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },

    generateFallbackResponse(message) {
        const lowerMessage = message.toLowerCase();
        
        if (lowerMessage.includes('hello') || lowerMessage.includes('hi')) {
            return 'Hello! How can I help you today?';
        }
        
        if (lowerMessage.includes('how are you')) {
            return "I'm doing great! Thanks for asking. How are you?";
        }
        
        if (lowerMessage.includes('help')) {
            return 'I\'m here to help! What do you need assistance with?';
        }
        
        if (lowerMessage.includes('?')) {
            return 'That\'s an interesting question! I\'d need my full AI capabilities to give you a detailed answer.';
        }
        
        return 'I understand what you\'re saying. My full AI features require an OpenAI API connection.';
    }
};