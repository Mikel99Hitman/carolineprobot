const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

const conversationMemory = new Map();
const personalities = {
    friendly: {
        responses: ['That sounds great!', 'I love talking with you!', 'Tell me more about that!', 'How interesting!'],
        greetings: ['Hello friend!', 'Hey there! How are you?', 'Hi! Great to see you!'],
        questions: ['What do you think about that?', 'How does that make you feel?', 'Can you explain more?']
    },
    professional: {
        responses: ['I understand your point.', 'That\'s a valid perspective.', 'Thank you for sharing.'],
        greetings: ['Good day.', 'Hello.', 'Greetings.'],
        questions: ['Could you elaborate?', 'What are your thoughts?', 'How would you approach this?']
    },
    funny: {
        responses: ['Haha, that\'s hilarious!', 'You crack me up!', 'That\'s so funny!', 'LOL!'],
        greetings: ['Hey there, funny human!', 'What\'s up, comedian?', 'Ready for some laughs?'],
        questions: ['Got any jokes?', 'What\'s the funniest thing today?', 'Make me laugh!']
    }
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ai')
        .setDescription('Advanced AI conversation system')
        .addSubcommand(subcommand =>
            subcommand
                .setName('chat')
                .setDescription('Chat with AI')
                .addStringOption(option =>
                    option.setName('message')
                        .setDescription('Your message to AI')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('personality')
                .setDescription('Set AI personality')
                .addStringOption(option =>
                    option.setName('type')
                        .setDescription('AI personality type')
                        .addChoices(
                            { name: 'Friendly', value: 'friendly' },
                            { name: 'Professional', value: 'professional' },
                            { name: 'Funny', value: 'funny' }
                        )
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('memory')
                .setDescription('View conversation memory'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('reset')
                .setDescription('Reset conversation memory')),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        const userId = interaction.user.id;

        if (subcommand === 'chat') {
            const message = interaction.options.getString('message');
            const response = await generateAIResponse(userId, message);

            const embed = new EmbedBuilder()
                .setColor('#00aaff')
                .setTitle('🤖 AI Assistant')
                .addFields(
                    { name: '👤 You', value: message, inline: false },
                    { name: '🤖 AI', value: response, inline: false }
                )
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

        } else if (subcommand === 'personality') {
            const personality = interaction.options.getString('type');
            
            if (!conversationMemory.has(userId)) {
                conversationMemory.set(userId, { messages: [], personality: 'friendly' });
            }
            
            conversationMemory.get(userId).personality = personality;

            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('🎭 Personality Updated')
                .setDescription(`AI personality set to: **${personality}**`)
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

        } else if (subcommand === 'memory') {
            const memory = conversationMemory.get(userId);
            
            if (!memory || memory.messages.length === 0) {
                return interaction.reply({ content: '🧠 No conversation memory found!', ephemeral: true });
            }

            const recentMessages = memory.messages.slice(-5);
            const embed = new EmbedBuilder()
                .setColor('#9932cc')
                .setTitle('🧠 Conversation Memory')
                .setDescription(recentMessages.map(m => `**${m.role}:** ${m.content}`).join('\n'))
                .addFields({ name: 'Personality', value: memory.personality, inline: true })
                .setTimestamp();

            await interaction.reply({ embeds: [embed], ephemeral: true });

        } else if (subcommand === 'reset') {
            conversationMemory.delete(userId);
            
            const embed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('🔄 Memory Reset')
                .setDescription('Conversation memory has been cleared!')
                .setTimestamp();

            await interaction.reply({ embeds: [embed], ephemeral: true });
        }
    }
};

async function generateAIResponse(userId, message) {
    if (!conversationMemory.has(userId)) {
        conversationMemory.set(userId, { messages: [], personality: 'friendly' });
    }

    const memory = conversationMemory.get(userId);
    const personality = personalities[memory.personality];

    // Add user message to memory
    memory.messages.push({ role: 'user', content: message });

    // Keep only last 10 messages
    if (memory.messages.length > 10) {
        memory.messages = memory.messages.slice(-10);
    }

    // Generate contextual response
    let response = generateContextualResponse(message, memory, personality);

    // Add AI response to memory
    memory.messages.push({ role: 'ai', content: response });

    return response;
}

function generateContextualResponse(message, memory, personality) {
    const lowerMessage = message.toLowerCase();
    
    // Greeting detection
    if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('hey')) {
        return personality.greetings[Math.floor(Math.random() * personality.greetings.length)];
    }

    // Question detection
    if (lowerMessage.includes('?')) {
        return personality.questions[Math.floor(Math.random() * personality.questions.length)];
    }

    // Emotion detection
    if (lowerMessage.includes('sad') || lowerMessage.includes('upset')) {
        return "I'm sorry to hear that. Would you like to talk about it?";
    }

    if (lowerMessage.includes('happy') || lowerMessage.includes('excited')) {
        return "That's wonderful! I'm happy for you!";
    }

    // Context-aware responses based on previous messages
    const recentTopics = memory.messages.slice(-3).map(m => m.content.toLowerCase());
    
    if (recentTopics.some(topic => topic.includes('work') || topic.includes('job'))) {
        return "Work can be challenging. How are you managing everything?";
    }

    if (recentTopics.some(topic => topic.includes('game') || topic.includes('play'))) {
        return "Games are fun! What's your favorite type of game?";
    }

    // Default personality response
    return personality.responses[Math.floor(Math.random() * personality.responses.length)];
}

module.exports.conversationMemory = conversationMemory;