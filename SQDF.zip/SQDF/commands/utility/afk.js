const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const AFK = require('../../models/AFK');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('afk')
        .setDescription('Set AFK status')
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('AFK reason')
                .setRequired(false)),

    async execute(interaction) {
        const reason = interaction.options.getString('reason') || 'AFK';

        const afk = new AFK({
            userId: interaction.user.id,
            guildId: interaction.guild.id,
            reason
        });

        await afk.save();

        const embed = new EmbedBuilder()
            .setColor('#ffaa00')
            .setTitle('😴 AFK Status Set')
            .setDescription(`You are now AFK: **${reason}**`)
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });

        // Change nickname
        try {
            const member = interaction.guild.members.cache.get(interaction.user.id);
            if (member && !member.displayName.startsWith('[AFK]')) {
                await member.setNickname(`[AFK] ${member.displayName}`);
            }
        } catch (error) {
            console.log('Could not change nickname');
        }
    }
};