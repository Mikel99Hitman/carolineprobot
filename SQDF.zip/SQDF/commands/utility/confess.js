const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('confess')
        .setDescription('Send anonymous confession')
        .addStringOption(option =>
            option.setName('message')
                .setDescription('Your confession')
                .setRequired(true)
                .setMaxLength(1000))
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Channel to send confession')
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(false)),

    async execute(interaction) {
        const message = interaction.options.getString('message');
        const channel = interaction.options.getChannel('channel') || 
                       interaction.guild.channels.cache.find(ch => ch.name.includes('confession'));

        if (!channel) {
            return interaction.reply({ content: '❌ No confession channel found!', ephemeral: true });
        }

        const confessionNumber = Math.floor(Math.random() * 9999) + 1;

        const embed = new EmbedBuilder()
            .setColor('#800080')
            .setTitle(`🤫 Anonymous Confession #${confessionNumber}`)
            .setDescription(message)
            .setFooter({ text: 'This confession is anonymous' })
            .setTimestamp();

        await channel.send({ embeds: [embed] });

        const confirmEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('✅ Confession Sent')
            .setDescription(`Your confession has been sent to ${channel}`)
            .setTimestamp();

        await interaction.reply({ embeds: [confirmEmbed], ephemeral: true });
    }
};