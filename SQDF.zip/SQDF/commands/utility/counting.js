const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const Counting = require('../../models/Counting');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('counting')
        .setDescription('Setup counting channel')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Counting channel')
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

    async execute(interaction) {
        const channel = interaction.options.getChannel('channel');

        const counting = new Counting({
            guildId: interaction.guild.id,
            channelId: channel.id
        });

        await counting.save();

        const embed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('🔢 Counting Setup')
            .setDescription(`Counting game setup in ${channel}!\nUsers must count from 1 in order.`)
            .addFields(
                { name: 'Rules', value: '• Count in order\n• No double counting\n• Numbers only', inline: false }
            );

        await interaction.reply({ embeds: [embed] });
        await channel.send('**Counting Game Started!** Start with `1`');
    }
};