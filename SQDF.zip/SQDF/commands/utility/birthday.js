const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Birthday = require('../../models/Birthday');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('birthday')
        .setDescription('Birthday management')
        .addSubcommand(subcommand =>
            subcommand
                .setName('set')
                .setDescription('Set your birthday')
                .addStringOption(option =>
                    option.setName('date')
                        .setDescription('Birthday date (DD/MM/YYYY)')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('list')
                .setDescription('List upcoming birthdays'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('today')
                .setDescription('Show today\'s birthdays')),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'set') {
            const dateString = interaction.options.getString('date');
            const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
            
            if (!dateRegex.test(dateString)) {
                return interaction.reply({ content: '❌ Invalid date format! Use DD/MM/YYYY', ephemeral: true });
            }

            const [, day, month, year] = dateString.match(dateRegex);
            const birthday = new Date(year, month - 1, day);

            await Birthday.findOneAndUpdate(
                { userId: interaction.user.id, guildId: interaction.guild.id },
                { birthday },
                { upsert: true }
            );

            const embed = new EmbedBuilder()
                .setColor('#ff69b4')
                .setTitle('🎂 Birthday Set!')
                .setDescription(`Your birthday has been set to ${birthday.toLocaleDateString()}`)
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

        } else if (subcommand === 'today') {
            const today = new Date();
            const birthdays = await Birthday.find({ guildId: interaction.guild.id });
            
            const todayBirthdays = birthdays.filter(b => {
                const bday = new Date(b.birthday);
                return bday.getDate() === today.getDate() && bday.getMonth() === today.getMonth();
            });

            if (todayBirthdays.length === 0) {
                return interaction.reply({ content: '🎂 No birthdays today!', ephemeral: true });
            }

            const embed = new EmbedBuilder()
                .setColor('#ff69b4')
                .setTitle('🎉 Today\'s Birthdays!')
                .setDescription(todayBirthdays.map(b => `<@${b.userId}>`).join('\n'))
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        }
    }
};