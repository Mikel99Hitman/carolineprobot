const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('weather')
        .setDescription('Get weather information')
        .addStringOption(option =>
            option.setName('city')
                .setDescription('City name')
                .setRequired(true)),

    async execute(interaction) {
        const city = interaction.options.getString('city');
        
        // Mock weather data (would use real API)
        const weatherData = {
            city: city,
            temperature: Math.floor(Math.random() * 30) + 10,
            condition: ['Sunny', 'Cloudy', 'Rainy', 'Snowy'][Math.floor(Math.random() * 4)],
            humidity: Math.floor(Math.random() * 50) + 30,
            windSpeed: Math.floor(Math.random() * 20) + 5
        };

        const embed = new EmbedBuilder()
            .setColor('#87CEEB')
            .setTitle(`🌤️ Weather in ${weatherData.city}`)
            .addFields(
                { name: '🌡️ Temperature', value: `${weatherData.temperature}°C`, inline: true },
                { name: '☁️ Condition', value: weatherData.condition, inline: true },
                { name: '💧 Humidity', value: `${weatherData.humidity}%`, inline: true },
                { name: '💨 Wind Speed', value: `${weatherData.windSpeed} km/h`, inline: true }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};