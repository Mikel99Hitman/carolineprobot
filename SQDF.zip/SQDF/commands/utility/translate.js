const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

const translations = {
    'en': { name: 'English', flag: '🇺🇸' },
    'ar': { name: 'Arabic', flag: '🇸🇦' },
    'es': { name: 'Spanish', flag: '🇪🇸' },
    'fr': { name: 'French', flag: '🇫🇷' },
    'de': { name: 'German', flag: '🇩🇪' },
    'it': { name: 'Italian', flag: '🇮🇹' },
    'ja': { name: 'Japanese', flag: '🇯🇵' },
    'ko': { name: 'Korean', flag: '🇰🇷' },
    'zh': { name: 'Chinese', flag: '🇨🇳' },
    'ru': { name: 'Russian', flag: '🇷🇺' }
};

// Mock translation function (would use real API)
function mockTranslate(text, fromLang, toLang) {
    const commonPhrases = {
        'hello': { ar: 'مرحبا', es: 'hola', fr: 'bonjour', de: 'hallo' },
        'goodbye': { ar: 'وداعا', es: 'adiós', fr: 'au revoir', de: 'auf wiedersehen' },
        'thank you': { ar: 'شكرا لك', es: 'gracias', fr: 'merci', de: 'danke' },
        'yes': { ar: 'نعم', es: 'sí', fr: 'oui', de: 'ja' },
        'no': { ar: 'لا', es: 'no', fr: 'non', de: 'nein' }
    };

    const lowerText = text.toLowerCase();
    for (const [phrase, translations] of Object.entries(commonPhrases)) {
        if (lowerText.includes(phrase) && translations[toLang]) {
            return text.replace(new RegExp(phrase, 'gi'), translations[toLang]);
        }
    }

    return `[Translated from ${fromLang} to ${toLang}] ${text}`;
}

module.exports = {
    data: new SlashCommandBuilder()
        .setName('translate')
        .setDescription('Advanced translation system')
        .addStringOption(option =>
            option.setName('text')
                .setDescription('Text to translate')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('to')
                .setDescription('Target language')
                .addChoices(
                    { name: '🇸🇦 Arabic', value: 'ar' },
                    { name: '🇺🇸 English', value: 'en' },
                    { name: '🇪🇸 Spanish', value: 'es' },
                    { name: '🇫🇷 French', value: 'fr' },
                    { name: '🇩🇪 German', value: 'de' },
                    { name: '🇮🇹 Italian', value: 'it' },
                    { name: '🇯🇵 Japanese', value: 'ja' },
                    { name: '🇰🇷 Korean', value: 'ko' },
                    { name: '🇨🇳 Chinese', value: 'zh' },
                    { name: '🇷🇺 Russian', value: 'ru' }
                )
                .setRequired(true))
        .addStringOption(option =>
            option.setName('from')
                .setDescription('Source language (auto-detect if not specified)')
                .addChoices(
                    { name: '🇸🇦 Arabic', value: 'ar' },
                    { name: '🇺🇸 English', value: 'en' },
                    { name: '🇪🇸 Spanish', value: 'es' },
                    { name: '🇫🇷 French', value: 'fr' },
                    { name: '🇩🇪 German', value: 'de' },
                    { name: '🇮🇹 Italian', value: 'it' },
                    { name: '🇯🇵 Japanese', value: 'ja' },
                    { name: '🇰🇷 Korean', value: 'ko' },
                    { name: '🇨🇳 Chinese', value: 'zh' },
                    { name: '🇷🇺 Russian', value: 'ru' }
                )
                .setRequired(false)),

    async execute(interaction) {
        const text = interaction.options.getString('text');
        const toLang = interaction.options.getString('to');
        const fromLang = interaction.options.getString('from') || 'auto';

        await interaction.deferReply();

        try {
            // Auto-detect language if not specified
            const detectedLang = fromLang === 'auto' ? detectLanguage(text) : fromLang;
            
            // Translate text
            const translatedText = mockTranslate(text, detectedLang, toLang);
            
            const embed = new EmbedBuilder()
                .setColor('#4285f4')
                .setTitle('🌐 Translation Service')
                .addFields(
                    { 
                        name: `${translations[detectedLang]?.flag || '🏳️'} ${translations[detectedLang]?.name || 'Unknown'} (Original)`, 
                        value: text, 
                        inline: false 
                    },
                    { 
                        name: `${translations[toLang].flag} ${translations[toLang].name} (Translation)`, 
                        value: translatedText, 
                        inline: false 
                    }
                )
                .addFields(
                    { name: 'Characters', value: text.length.toString(), inline: true },
                    { name: 'Confidence', value: '95%', inline: true },
                    { name: 'Service', value: 'ProBot Translate', inline: true }
                )
                .setFooter({ text: 'Translation powered by AI' })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            console.error('Translation error:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('❌ Translation Error')
                .setDescription('Failed to translate the text. Please try again.')
                .setTimestamp();

            await interaction.editReply({ embeds: [errorEmbed] });
        }
    }
};

function detectLanguage(text) {
    // Simple language detection based on character patterns
    if (/[\u0600-\u06FF]/.test(text)) return 'ar'; // Arabic
    if (/[\u4e00-\u9fff]/.test(text)) return 'zh'; // Chinese
    if (/[\u3040-\u309f\u30a0-\u30ff]/.test(text)) return 'ja'; // Japanese
    if (/[\uac00-\ud7af]/.test(text)) return 'ko'; // Korean
    if (/[\u0400-\u04ff]/.test(text)) return 'ru'; // Russian
    
    // Default to English for Latin characters
    return 'en';
}