const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('voice')
        .setDescription('Advanced voice channel management')
        .addSubcommand(subcommand =>
            subcommand
                .setName('create')
                .setDescription('Create voice channel')
                .addStringOption(option =>
                    option.setName('name')
                        .setDescription('Channel name')
                        .setRequired(true))
                .addIntegerOption(option =>
                    option.setName('limit')
                        .setDescription('User limit')
                        .setMinValue(1)
                        .setMaxValue(99)
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('lock')
                .setDescription('Lock your voice channel'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('unlock')
                .setDescription('Unlock your voice channel'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('limit')
                .setDescription('Set user limit')
                .addIntegerOption(option =>
                    option.setName('number')
                        .setDescription('User limit (0 for unlimited)')
                        .setMinValue(0)
                        .setMaxValue(99)
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('rename')
                .setDescription('Rename your voice channel')
                .addStringOption(option =>
                    option.setName('name')
                        .setDescription('New channel name')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('kick')
                .setDescription('Kick user from voice channel')
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('User to kick')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('invite')
                .setDescription('Invite user to voice channel')
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('User to invite')
                        .setRequired(true))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        const member = interaction.member;

        if (subcommand === 'create') {
            const name = interaction.options.getString('name');
            const limit = interaction.options.getInteger('limit') || 0;

            if (!member.permissions.has(PermissionFlagsBits.ManageChannels)) {
                return interaction.reply({ content: '❌ You need Manage Channels permission!', ephemeral: true });
            }

            try {
                const channel = await interaction.guild.channels.create({
                    name: name,
                    type: ChannelType.GuildVoice,
                    userLimit: limit,
                    permissionOverwrites: [{
                        id: member.id,
                        allow: [PermissionFlagsBits.ManageChannels, PermissionFlagsBits.MoveMembers]
                    }]
                });

                const embed = new EmbedBuilder()
                    .setColor('#00ff00')
                    .setTitle('🔊 Voice Channel Created')
                    .setDescription(`Created ${channel} with limit: ${limit || 'Unlimited'}`)
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });

            } catch (error) {
                await interaction.reply({ content: '❌ Failed to create voice channel!', ephemeral: true });
            }

        } else if (['lock', 'unlock', 'limit', 'rename', 'kick', 'invite'].includes(subcommand)) {
            const voiceChannel = member.voice.channel;
            
            if (!voiceChannel) {
                return interaction.reply({ content: '❌ You must be in a voice channel!', ephemeral: true });
            }

            // Check if user has permission to manage this channel
            const hasPermission = voiceChannel.permissionsFor(member).has(PermissionFlagsBits.ManageChannels) ||
                                 member.permissions.has(PermissionFlagsBits.ManageChannels);

            if (!hasPermission) {
                return interaction.reply({ content: '❌ You don\'t have permission to manage this channel!', ephemeral: true });
            }

            try {
                if (subcommand === 'lock') {
                    await voiceChannel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
                        Connect: false
                    });
                    
                    const embed = new EmbedBuilder()
                        .setColor('#ff0000')
                        .setTitle('🔒 Voice Channel Locked')
                        .setDescription(`${voiceChannel} has been locked`)
                        .setTimestamp();

                    await interaction.reply({ embeds: [embed] });

                } else if (subcommand === 'unlock') {
                    await voiceChannel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
                        Connect: null
                    });
                    
                    const embed = new EmbedBuilder()
                        .setColor('#00ff00')
                        .setTitle('🔓 Voice Channel Unlocked')
                        .setDescription(`${voiceChannel} has been unlocked`)
                        .setTimestamp();

                    await interaction.reply({ embeds: [embed] });

                } else if (subcommand === 'limit') {
                    const limit = interaction.options.getInteger('number');
                    await voiceChannel.setUserLimit(limit);
                    
                    const embed = new EmbedBuilder()
                        .setColor('#0099ff')
                        .setTitle('👥 User Limit Updated')
                        .setDescription(`${voiceChannel} limit set to: ${limit || 'Unlimited'}`)
                        .setTimestamp();

                    await interaction.reply({ embeds: [embed] });

                } else if (subcommand === 'rename') {
                    const newName = interaction.options.getString('name');
                    const oldName = voiceChannel.name;
                    await voiceChannel.setName(newName);
                    
                    const embed = new EmbedBuilder()
                        .setColor('#0099ff')
                        .setTitle('✏️ Channel Renamed')
                        .addFields(
                            { name: 'Old Name', value: oldName, inline: true },
                            { name: 'New Name', value: newName, inline: true }
                        )
                        .setTimestamp();

                    await interaction.reply({ embeds: [embed] });

                } else if (subcommand === 'kick') {
                    const targetUser = interaction.options.getUser('user');
                    const targetMember = interaction.guild.members.cache.get(targetUser.id);
                    
                    if (!targetMember || !targetMember.voice.channel || targetMember.voice.channel.id !== voiceChannel.id) {
                        return interaction.reply({ content: '❌ User is not in your voice channel!', ephemeral: true });
                    }

                    await targetMember.voice.disconnect('Kicked by channel manager');
                    
                    const embed = new EmbedBuilder()
                        .setColor('#ff9900')
                        .setTitle('👢 User Kicked')
                        .setDescription(`${targetUser} has been kicked from ${voiceChannel}`)
                        .setTimestamp();

                    await interaction.reply({ embeds: [embed] });

                } else if (subcommand === 'invite') {
                    const targetUser = interaction.options.getUser('user');
                    const targetMember = interaction.guild.members.cache.get(targetUser.id);
                    
                    if (!targetMember) {
                        return interaction.reply({ content: '❌ User not found!', ephemeral: true });
                    }

                    // Give temporary connect permission
                    await voiceChannel.permissionOverwrites.edit(targetUser.id, {
                        Connect: true
                    });

                    const embed = new EmbedBuilder()
                        .setColor('#00ff00')
                        .setTitle('📨 User Invited')
                        .setDescription(`${targetUser} has been invited to ${voiceChannel}`)
                        .setTimestamp();

                    await interaction.reply({ embeds: [embed] });

                    // Send DM to invited user
                    try {
                        const dmEmbed = new EmbedBuilder()
                            .setColor('#0099ff')
                            .setTitle('🔊 Voice Channel Invitation')
                            .setDescription(`You've been invited to join ${voiceChannel} in ${interaction.guild.name}`)
                            .setTimestamp();

                        await targetUser.send({ embeds: [dmEmbed] });
                    } catch (error) {
                        console.log('Could not send DM to invited user');
                    }
                }

            } catch (error) {
                console.error('Voice management error:', error);
                await interaction.reply({ content: '❌ Failed to manage voice channel!', ephemeral: true });
            }
        }
    }
};