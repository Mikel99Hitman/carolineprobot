const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('calc')
        .setDescription('Calculate mathematical expressions')
        .addStringOption(option =>
            option.setName('expression')
                .setDescription('Mathematical expression')
                .setRequired(true)),

    async execute(interaction) {
        const expression = interaction.options.getString('expression');
        
        // Basic security check
        if (!/^[0-9+\-*/.() ]+$/.test(expression)) {
            return interaction.reply({ content: '❌ Invalid expression! Only numbers and basic operators allowed.', ephemeral: true });
        }

        try {
            const result = eval(expression);
            
            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('🧮 Calculator')
                .addFields(
                    { name: 'Expression', value: `\`${expression}\``, inline: false },
                    { name: 'Result', value: `\`${result}\``, inline: false }
                )
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            await interaction.reply({ content: '❌ Invalid mathematical expression!', ephemeral: true });
        }
    }
};