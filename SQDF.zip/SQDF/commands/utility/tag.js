const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Tag = require('../../models/Tag');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('tag')
        .setDescription('Tag system')
        .addSubcommand(subcommand =>
            subcommand
                .setName('create')
                .setDescription('Create a tag')
                .addStringOption(option =>
                    option.setName('name')
                        .setDescription('Tag name')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('content')
                        .setDescription('Tag content')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('get')
                .setDescription('Get a tag')
                .addStringOption(option =>
                    option.setName('name')
                        .setDescription('Tag name')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('list')
                .setDescription('List all tags'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('delete')
                .setDescription('Delete a tag')
                .addStringOption(option =>
                    option.setName('name')
                        .setDescription('Tag name')
                        .setRequired(true))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'create') {
            const name = interaction.options.getString('name').toLowerCase();
            const content = interaction.options.getString('content');

            const existingTag = await Tag.findOne({ guildId: interaction.guild.id, name });
            if (existingTag) {
                return interaction.reply({ content: '❌ Tag already exists!', ephemeral: true });
            }

            const tag = new Tag({
                guildId: interaction.guild.id,
                name,
                content,
                authorId: interaction.user.id
            });

            await tag.save();

            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('✅ Tag Created')
                .setDescription(`Tag **${name}** has been created!`)
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

        } else if (subcommand === 'get') {
            const name = interaction.options.getString('name').toLowerCase();
            const tag = await Tag.findOne({ guildId: interaction.guild.id, name });

            if (!tag) {
                return interaction.reply({ content: '❌ Tag not found!', ephemeral: true });
            }

            tag.uses += 1;
            await tag.save();

            await interaction.reply({ content: tag.content });

        } else if (subcommand === 'list') {
            const tags = await Tag.find({ guildId: interaction.guild.id }).sort({ uses: -1 }).limit(10);

            if (tags.length === 0) {
                return interaction.reply({ content: '❌ No tags found!', ephemeral: true });
            }

            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle('🏷️ Server Tags')
                .setDescription(tags.map(tag => `**${tag.name}** (${tag.uses} uses)`).join('\n'))
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        }
    }
};