const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType } = require('discord.js');
const Suggestion = require('../../models/Suggestion');
const Guild = require('../../models/Guild');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('suggest')
        .setDescription('Submit a suggestion')
        .addStringOption(option =>
            option.setName('suggestion')
                .setDescription('Your suggestion')
                .setRequired(true)
                .setMaxLength(1000)),

    async execute(interaction) {
        const suggestion = interaction.options.getString('suggestion');
        
        const guildData = await Guild.findOne({ guildId: interaction.guild.id });
        const suggestionChannel = guildData?.suggestionChannel ? 
            interaction.guild.channels.cache.get(guildData.suggestionChannel) : 
            interaction.guild.channels.cache.find(ch => ch.name.includes('suggestion'));

        if (!suggestionChannel) {
            return interaction.reply({ 
                content: '❌ No suggestion channel found! Please setup a suggestion channel first.', 
                ephemeral: true 
            });
        }

        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('💡 New Suggestion')
            .setDescription(suggestion)
            .addFields(
                { name: '👤 Suggested by', value: `${interaction.user} (${interaction.user.tag})`, inline: true },
                { name: '📊 Status', value: 'Pending', inline: true },
                { name: '📈 Votes', value: '👍 0 | 👎 0', inline: true }
            )
            .setThumbnail(interaction.user.displayAvatarURL())
            .setTimestamp();

        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('suggestion_upvote')
                    .setLabel('Upvote')
                    .setEmoji('👍')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('suggestion_downvote')
                    .setLabel('Downvote')
                    .setEmoji('👎')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('suggestion_approve')
                    .setLabel('Approve')
                    .setEmoji('✅')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('suggestion_reject')
                    .setLabel('Reject')
                    .setEmoji('❌')
                    .setStyle(ButtonStyle.Secondary)
            );

        const suggestionMessage = await suggestionChannel.send({ embeds: [embed], components: [buttons] });

        const suggestionDoc = new Suggestion({
            guildId: interaction.guild.id,
            channelId: suggestionChannel.id,
            messageId: suggestionMessage.id,
            userId: interaction.user.id,
            suggestion
        });

        await suggestionDoc.save();

        const successEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('✅ Suggestion Submitted!')
            .setDescription(`Your suggestion has been submitted to ${suggestionChannel}!`)
            .setTimestamp();

        await interaction.reply({ embeds: [successEmbed], ephemeral: true });
    }
};