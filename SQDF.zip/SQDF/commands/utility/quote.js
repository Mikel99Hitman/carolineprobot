const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Quote = require('../../models/Quote');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('quote')
        .setDescription('Quote management')
        .addSubcommand(subcommand =>
            subcommand
                .setName('add')
                .setDescription('Add a quote')
                .addStringOption(option =>
                    option.setName('message_id')
                        .setDescription('Message ID to quote')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('get')
                .setDescription('Get a quote')
                .addIntegerOption(option =>
                    option.setName('id')
                        .setDescription('Quote ID')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('random')
                .setDescription('Get random quote')),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'add') {
            const messageId = interaction.options.getString('message_id');
            
            try {
                const message = await interaction.channel.messages.fetch(messageId);
                const quoteCount = await Quote.countDocuments({ guildId: interaction.guild.id });
                
                const quote = new Quote({
                    guildId: interaction.guild.id,
                    messageId: message.id,
                    channelId: message.channel.id,
                    authorId: message.author.id,
                    content: message.content,
                    quotedBy: interaction.user.id,
                    quoteId: quoteCount + 1
                });

                await quote.save();

                const embed = new EmbedBuilder()
                    .setColor('#00ff00')
                    .setTitle('✅ Quote Added')
                    .setDescription(`Quote #${quote.quoteId} has been added!`)
                    .addFields({ name: 'Content', value: message.content.substring(0, 1000) });

                await interaction.reply({ embeds: [embed] });
            } catch (error) {
                await interaction.reply({ content: '❌ Message not found!', ephemeral: true });
            }

        } else if (subcommand === 'random') {
            const quotes = await Quote.find({ guildId: interaction.guild.id });
            if (quotes.length === 0) {
                return interaction.reply({ content: '❌ No quotes found!', ephemeral: true });
            }

            const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
            const author = await interaction.client.users.fetch(randomQuote.authorId);

            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle(`💬 Quote #${randomQuote.quoteId}`)
                .setDescription(randomQuote.content)
                .setFooter({ text: `- ${author.tag}`, iconURL: author.displayAvatarURL() })
                .setTimestamp(randomQuote.createdAt);

            await interaction.reply({ embeds: [embed] });
        }
    }
};