const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('gaming-tournaments')
        .setDescription('🏆 Advanced Gaming Tournament & Esports System')
        .addSubcommand(subcommand =>
            subcommand
                .setName('create-tournament')
                .setDescription('Create a new gaming tournament')
                .addStringOption(option =>
                    option.setName('game')
                        .setDescription('Tournament game')
                        .addChoices(
                            { name: 'Counter-Strike 2', value: 'cs2' },
                            { name: 'Valorant', value: 'valorant' },
                            { name: 'League of Legends', value: 'lol' },
                            { name: 'Rocket League', value: 'rl' },
                            { name: 'Fortnite', value: 'fortnite' },
                            { name: 'Apex Legends', value: 'apex' }
                        )
                        .setRequired(true))
                .addIntegerOption(option =>
                    option.setName('max-teams')
                        .setDescription('Maximum number of teams')
                        .setMinValue(4)
                        .setMaxValue(64)
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('prize-pool')
                        .setDescription('Tournament prize pool')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('team-registration')
                .setDescription('Register team for tournaments')
                .addStringOption(option =>
                    option.setName('team-name')
                        .setDescription('Team name')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('match-tracker')
                .setDescription('Track live matches and results')
                .addStringOption(option =>
                    option.setName('tournament-id')
                        .setDescription('Tournament ID')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('player-stats')
                .setDescription('View player statistics and rankings')
                .addUserOption(option =>
                    option.setName('player')
                        .setDescription('Player to view stats for')))
        .addSubcommand(subcommand =>
            subcommand
                .setName('leaderboards')
                .setDescription('View tournament leaderboards')
                .addStringOption(option =>
                    option.setName('category')
                        .setDescription('Leaderboard category')
                        .addChoices(
                            { name: 'Overall Rankings', value: 'overall' },
                            { name: 'Monthly Champions', value: 'monthly' },
                            { name: 'Game Specific', value: 'game' },
                            { name: 'Team Rankings', value: 'teams' }
                        ))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        switch (subcommand) {
            case 'create-tournament':
                await this.createTournament(interaction);
                break;
            case 'team-registration':
                await this.teamRegistration(interaction);
                break;
            case 'match-tracker':
                await this.matchTracker(interaction);
                break;
            case 'player-stats':
                await this.playerStats(interaction);
                break;
            case 'leaderboards':
                await this.leaderboards(interaction);
                break;
        }
    },

    async createTournament(interaction) {
        await interaction.deferReply();

        const game = interaction.options.getString('game');
        const maxTeams = interaction.options.getInteger('max-teams');
        const prizePool = interaction.options.getString('prize-pool');
        
        const tournamentData = this.generateTournamentData(game, maxTeams, prizePool);

        const embed = new EmbedBuilder()
            .setTitle('🏆 Tournament Created Successfully!')
            .setDescription(`**${tournamentData.gameName}** Tournament`)
            .addFields(
                { name: '🎮 Game', value: tournamentData.gameName, inline: true },
                { name: '👥 Max Teams', value: `${maxTeams} teams`, inline: true },
                { name: '💰 Prize Pool', value: prizePool, inline: true },
                { name: '🆔 Tournament ID', value: tournamentData.tournamentId, inline: true },
                { name: '📅 Start Date', value: tournamentData.startDate, inline: true },
                { name: '⏰ Registration Deadline', value: tournamentData.regDeadline, inline: true },
                { name: '📋 Tournament Format', value: tournamentData.format, inline: false },
                { name: '🏅 Prize Distribution', value: tournamentData.prizeDistribution.join('\n'), inline: false },
                { name: '📜 Rules & Requirements', value: tournamentData.rules.join('\n'), inline: false }
            )
            .setColor('#ffd700')
            .setTimestamp()
            .setFooter({ text: 'Gaming Tournaments • Competitive Gaming' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('register_team')
                    .setLabel('📝 Register Team')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('tournament_bracket')
                    .setLabel('🏆 View Bracket')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('tournament_rules')
                    .setLabel('📋 Full Rules')
                    .setStyle(ButtonStyle.Success)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async teamRegistration(interaction) {
        await interaction.deferReply();

        const teamName = interaction.options.getString('team-name');
        const registrationData = this.generateRegistrationData(teamName);

        const embed = new EmbedBuilder()
            .setTitle('👥 Team Registration System')
            .setDescription(`Registration for team: **${teamName}**`)
            .addFields(
                { name: '🏷️ Team Name', value: teamName, inline: true },
                { name: '👤 Team Captain', value: interaction.user.tag, inline: true },
                { name: '📊 Registration Status', value: registrationData.status, inline: true },
                { name: '🎮 Available Tournaments', value: registrationData.availableTournaments.join('\n'), inline: false },
                { name: '📋 Registration Requirements', value: registrationData.requirements.join('\n'), inline: false },
                { name: '💡 Team Management Tips', value: registrationData.tips.join('\n'), inline: false }
            )
            .setColor('#3498db')
            .setTimestamp()
            .setFooter({ text: 'Team Registration • Competitive Gaming' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('complete_registration')
                    .setLabel('✅ Complete Registration')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('invite_players')
                    .setLabel('👥 Invite Players')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('team_settings')
                    .setLabel('⚙️ Team Settings')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async matchTracker(interaction) {
        await interaction.deferReply();

        const tournamentId = interaction.options.getString('tournament-id');
        const matchData = this.generateMatchData(tournamentId);

        const embed = new EmbedBuilder()
            .setTitle('📊 Live Match Tracker')
            .setDescription(`Tournament: **${tournamentId}**`)
            .addFields(
                { name: '🏆 Tournament', value: matchData.tournamentName, inline: true },
                { name: '🎮 Current Round', value: matchData.currentRound, inline: true },
                { name: '⏰ Match Status', value: matchData.matchStatus, inline: true },
                { name: '🔴 Live Matches', value: matchData.liveMatches.join('\n'), inline: false },
                { name: '✅ Completed Matches', value: matchData.completedMatches.join('\n'), inline: false },
                { name: '📅 Upcoming Matches', value: matchData.upcomingMatches.join('\n'), inline: false },
                { name: '📈 Tournament Progress', value: matchData.progress, inline: false }
            )
            .setColor('#e74c3c')
            .setTimestamp()
            .setFooter({ text: 'Match Tracker • Live Updates' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('live_stream')
                    .setLabel('📺 Watch Live')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('match_predictions')
                    .setLabel('🎯 Predictions')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('tournament_bracket')
                    .setLabel('🏆 Full Bracket')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async playerStats(interaction) {
        await interaction.deferReply();

        const player = interaction.options.getUser('player') || interaction.user;
        const statsData = this.generatePlayerStats(player);

        const embed = new EmbedBuilder()
            .setTitle('📊 Player Statistics')
            .setDescription(`Stats for: **${player.tag}**`)
            .addFields(
                { name: '🏆 Overall Rank', value: statsData.overallRank, inline: true },
                { name: '🎮 Tournaments Played', value: statsData.tournamentsPlayed, inline: true },
                { name: '🥇 Wins', value: statsData.wins, inline: true },
                { name: '📊 Win Rate', value: statsData.winRate, inline: true },
                { name: '💰 Total Earnings', value: statsData.totalEarnings, inline: true },
                { name: '⭐ Skill Rating', value: statsData.skillRating, inline: true },
                { name: '🎯 Game Statistics', value: statsData.gameStats.join('\n'), inline: false },
                { name: '🏅 Recent Achievements', value: statsData.achievements.join('\n'), inline: false },
                { name: '📈 Performance Trends', value: statsData.trends.join('\n'), inline: false }
            )
            .setColor('#9b59b6')
            .setTimestamp()
            .setFooter({ text: 'Player Statistics • Competitive Profile' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('detailed_stats')
                    .setLabel('📈 Detailed Stats')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('match_history')
                    .setLabel('📋 Match History')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('compare_players')
                    .setLabel('⚖️ Compare Players')
                    .setStyle(ButtonStyle.Success)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async leaderboards(interaction) {
        await interaction.deferReply();

        const category = interaction.options.getString('category') || 'overall';
        const leaderboardData = this.generateLeaderboardData(category);

        const embed = new EmbedBuilder()
            .setTitle('🏆 Gaming Leaderboards')
            .setDescription(`**${leaderboardData.categoryName}** Rankings`)
            .addFields(
                { name: '📊 Category', value: leaderboardData.categoryName, inline: true },
                { name: '👥 Total Players', value: leaderboardData.totalPlayers, inline: true },
                { name: '📅 Last Updated', value: leaderboardData.lastUpdated, inline: true },
                { name: '🥇 Top 10 Players', value: leaderboardData.topPlayers.join('\n'), inline: false },
                { name: '📈 Rising Stars', value: leaderboardData.risingStars.join('\n'), inline: false },
                { name: '🏆 Hall of Fame', value: leaderboardData.hallOfFame.join('\n'), inline: false }
            )
            .setColor('#f39c12')
            .setTimestamp()
            .setFooter({ text: 'Leaderboards • Competitive Rankings' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('full_leaderboard')
                    .setLabel('📊 Full Rankings')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('filter_rankings')
                    .setLabel('🔍 Filter Results')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('season_history')
                    .setLabel('📅 Season History')
                    .setStyle(ButtonStyle.Success)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    generateTournamentData(game, maxTeams, prizePool) {
        const gameNames = {
            'cs2': 'Counter-Strike 2',
            'valorant': 'Valorant',
            'lol': 'League of Legends',
            'rl': 'Rocket League',
            'fortnite': 'Fortnite',
            'apex': 'Apex Legends'
        };

        return {
            gameName: gameNames[game],
            tournamentId: `TOUR-${Date.now().toString().slice(-6)}`,
            startDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString(),
            regDeadline: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toLocaleDateString(),
            format: maxTeams <= 8 ? 'Single Elimination' : 'Double Elimination',
            prizeDistribution: [
                '🥇 1st Place: 50% of prize pool',
                '🥈 2nd Place: 30% of prize pool',
                '🥉 3rd Place: 15% of prize pool',
                '🏆 4th Place: 5% of prize pool'
            ],
            rules: [
                '✅ Teams must have 5 registered players',
                '✅ All players must be Discord verified',
                '✅ No cheating or exploits allowed',
                '✅ Matches streamed on official channels'
            ]
        };
    },

    generateRegistrationData(teamName) {
        return {
            status: '🟡 Pending Verification',
            availableTournaments: [
                '🎮 CS2 Championship - $5,000 Prize Pool',
                '🎯 Valorant Masters - $3,000 Prize Pool',
                '⚽ Rocket League Cup - $2,000 Prize Pool',
                '🏆 Multi-Game League - $10,000 Prize Pool'
            ],
            requirements: [
                '✅ Team captain must be Discord verified',
                '✅ Minimum 5 players, maximum 7 players',
                '✅ All players must accept team invitation',
                '✅ Team logo and description required'
            ],
            tips: [
                '💡 Choose a memorable team name',
                '💡 Recruit players with complementary skills',
                '💡 Practice together regularly',
                '💡 Study opponent strategies'
            ]
        };
    },

    generateMatchData(tournamentId) {
        return {
            tournamentName: 'CS2 Championship 2024',
            currentRound: 'Quarter Finals',
            matchStatus: '🔴 3 matches live',
            liveMatches: [
                '🔴 Team Alpha vs Team Beta - Map 2/3',
                '🔴 Team Gamma vs Team Delta - Map 1/3',
                '🔴 Team Echo vs Team Foxtrot - Map 3/3'
            ],
            completedMatches: [
                '✅ Team Zulu defeated Team Yankee (2-1)',
                '✅ Team X-Ray defeated Team Whiskey (2-0)',
                '✅ Team Victor defeated Team Uniform (2-1)'
            ],
            upcomingMatches: [
                '📅 Semi-Final 1 - Tomorrow 3:00 PM',
                '📅 Semi-Final 2 - Tomorrow 6:00 PM',
                '📅 Grand Final - Sunday 8:00 PM'
            ],
            progress: '🏆 Quarter Finals: 75% Complete'
        };
    },

    generatePlayerStats(player) {
        return {
            overallRank: `#${Math.floor(Math.random() * 1000) + 1}`,
            tournamentsPlayed: `${Math.floor(Math.random() * 50) + 10}`,
            wins: `${Math.floor(Math.random() * 30) + 5}`,
            winRate: `${Math.floor(Math.random() * 40) + 60}%`,
            totalEarnings: `$${Math.floor(Math.random() * 5000) + 500}`,
            skillRating: `${Math.floor(Math.random() * 2000) + 1000} SR`,
            gameStats: [
                '🎮 CS2: Global Elite Rank',
                '🎯 Valorant: Immortal 2',
                '⚽ Rocket League: Champion 3',
                '🏆 Apex: Predator Tier'
            ],
            achievements: [
                '🏆 Tournament Winner x3',
                '🥇 Monthly Champion',
                '⭐ MVP Award x2',
                '🎯 Perfect Game Achievement'
            ],
            trends: [
                '📈 Win rate increased 15% this month',
                '🎯 Skill rating climbing steadily',
                '🏆 Consistent tournament placements',
                '👥 Strong team performance'
            ]
        };
    },

    generateLeaderboardData(category) {
        const categories = {
            'overall': 'Overall Rankings',
            'monthly': 'Monthly Champions',
            'game': 'Game Specific',
            'teams': 'Team Rankings'
        };

        return {
            categoryName: categories[category],
            totalPlayers: '12,847 active players',
            lastUpdated: 'Updated 5 minutes ago',
            topPlayers: [
                '🥇 ProGamer2024 - 2,847 SR',
                '🥈 ElitePlayer - 2,756 SR',
                '🥉 ChampionX - 2,689 SR',
                '4️⃣ SkillMaster - 2,634 SR',
                '5️⃣ GameLegend - 2,598 SR',
                '6️⃣ ProShooter - 2,567 SR',
                '7️⃣ TacticalAce - 2,534 SR',
                '8️⃣ CyberWarrior - 2,501 SR',
                '9️⃣ GameChanger - 2,478 SR',
                '🔟 EliteGamer - 2,445 SR'
            ],
            risingStars: [
                '⭐ NewTalent (+347 SR this week)',
                '⭐ RisingPro (+298 SR this week)',
                '⭐ FutureChamp (+276 SR this week)'
            ],
            hallOfFame: [
                '👑 LegendaryPro - All-time #1',
                '👑 ChampionKing - 15x Tournament Winner',
                '👑 SkillGod - Highest Peak Rating'
            ]
        };
    }
};