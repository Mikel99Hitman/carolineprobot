const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('gaming-news')
        .setDescription('🎮 Gaming News & Events System')
        .addSubcommand(subcommand =>
            subcommand
                .setName('latest-news')
                .setDescription('Get latest gaming news and updates')
                .addStringOption(option =>
                    option.setName('category')
                        .setDescription('News category')
                        .addChoices(
                            { name: 'All Gaming News', value: 'all' },
                            { name: 'Esports', value: 'esports' },
                            { name: 'Game Releases', value: 'releases' },
                            { name: 'Updates & Patches', value: 'updates' },
                            { name: 'FiveM News', value: 'fivem' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('live-events')
                .setDescription('View live gaming events and tournaments')
                .addStringOption(option =>
                    option.setName('game')
                        .setDescription('Specific game events')
                        .addChoices(
                            { name: 'All Games', value: 'all' },
                            { name: 'CS2', value: 'cs2' },
                            { name: 'Valorant', value: 'valorant' },
                            { name: 'League of Legends', value: 'lol' },
                            { name: 'Fortnite', value: 'fortnite' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('auto-notifications')
                .setDescription('Setup automatic gaming news notifications')
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('Channel for notifications')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('frequency')
                        .setDescription('Notification frequency')
                        .addChoices(
                            { name: 'Real-time', value: 'realtime' },
                            { name: 'Hourly', value: 'hourly' },
                            { name: 'Daily', value: 'daily' },
                            { name: 'Weekly', value: 'weekly' }
                        ))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        switch (subcommand) {
            case 'latest-news':
                await this.latestNews(interaction);
                break;
            case 'live-events':
                await this.liveEvents(interaction);
                break;
            case 'auto-notifications':
                await this.autoNotifications(interaction);
                break;
        }
    },

    async latestNews(interaction) {
        await interaction.deferReply();

        const category = interaction.options.getString('category') || 'all';
        const newsData = this.generateNewsData(category);

        const embed = new EmbedBuilder()
            .setTitle('🎮 Latest Gaming News')
            .setDescription('Breaking news and updates from the gaming world')
            .addFields(
                { name: '📰 Category', value: newsData.categoryName, inline: true },
                { name: '📅 Last Updated', value: newsData.lastUpdated, inline: true },
                { name: '🔥 Trending', value: newsData.trending, inline: true },
                { name: '🚨 Breaking News', value: newsData.breakingNews.join('\n'), inline: false },
                { name: '🎯 Esports Updates', value: newsData.esportsNews.join('\n'), inline: false },
                { name: '🎮 Game Releases', value: newsData.gameReleases.join('\n'), inline: false },
                { name: '🔄 Updates & Patches', value: newsData.gameUpdates.join('\n'), inline: false }
            )
            .setColor('#ff6b35')
            .setTimestamp()
            .setFooter({ text: 'Gaming News • Live Updates' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('refresh_news')
                    .setLabel('🔄 Refresh')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('detailed_news')
                    .setLabel('📖 Full Articles')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('setup_alerts')
                    .setLabel('🔔 Setup Alerts')
                    .setStyle(ButtonStyle.Success)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async liveEvents(interaction) {
        await interaction.deferReply();

        const game = interaction.options.getString('game') || 'all';
        const eventsData = this.generateEventsData(game);

        const embed = new EmbedBuilder()
            .setTitle('🏆 Live Gaming Events')
            .setDescription('Current tournaments and gaming events worldwide')
            .addFields(
                { name: '🎮 Game Filter', value: eventsData.gameFilter, inline: true },
                { name: '🔴 Live Now', value: eventsData.liveCount, inline: true },
                { name: '📅 Upcoming', value: eventsData.upcomingCount, inline: true },
                { name: '🔴 Live Tournaments', value: eventsData.liveTournaments.join('\n'), inline: false },
                { name: '📅 Upcoming Events', value: eventsData.upcomingEvents.join('\n'), inline: false },
                { name: '🏆 Major Championships', value: eventsData.majorEvents.join('\n'), inline: false },
                { name: '💰 Prize Pools', value: eventsData.prizePools.join('\n'), inline: false }
            )
            .setColor('#e74c3c')
            .setTimestamp()
            .setFooter({ text: 'Live Events • Tournament Tracker' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('watch_live')
                    .setLabel('📺 Watch Live')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('event_calendar')
                    .setLabel('📅 Event Calendar')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('set_reminders')
                    .setLabel('⏰ Set Reminders')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async autoNotifications(interaction) {
        await interaction.deferReply();

        const channel = interaction.options.getChannel('channel');
        const frequency = interaction.options.getString('frequency') || 'daily';
        const notificationData = this.generateNotificationData(channel, frequency);

        const embed = new EmbedBuilder()
            .setTitle('🔔 Auto Gaming Notifications')
            .setDescription('Automated gaming news and event notifications setup')
            .addFields(
                { name: '📺 Target Channel', value: `<#${channel.id}>`, inline: true },
                { name: '⏰ Frequency', value: notificationData.frequencyName, inline: true },
                { name: '📊 Status', value: notificationData.status, inline: true },
                { name: '📰 News Categories', value: notificationData.newsCategories.join('\n'), inline: false },
                { name: '🎮 Event Types', value: notificationData.eventTypes.join('\n'), inline: false },
                { name: '⚙️ Notification Settings', value: notificationData.settings.join('\n'), inline: false },
                { name: '📈 Statistics', value: notificationData.statistics.join('\n'), inline: false }
            )
            .setColor('#9b59b6')
            .setTimestamp()
            .setFooter({ text: 'Auto Notifications • Gaming Updates' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('enable_notifications')
                    .setLabel('✅ Enable Notifications')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('customize_settings')
                    .setLabel('⚙️ Customize Settings')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('test_notification')
                    .setLabel('🧪 Test Notification')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    generateNewsData(category) {
        const categories = {
            'all': 'All Gaming News',
            'esports': 'Esports News',
            'releases': 'Game Releases',
            'updates': 'Updates & Patches',
            'fivem': 'FiveM News'
        };

        return {
            categoryName: categories[category],
            lastUpdated: 'Updated 5 minutes ago',
            trending: '#CS2Major trending',
            breakingNews: [
                '🚨 CS2 Major Championship starts today!',
                '🔥 New Valorant Agent revealed: Clove',
                '⚡ Fortnite Chapter 5 Season 2 launches',
                '🎮 Steam breaks concurrent player record'
            ],
            esportsNews: [
                '🏆 Team Vitality wins IEM Katowice',
                '🥇 Faker extends contract with T1',
                '📊 Valorant Champions viewership hits 1.5M',
                '🎯 New BLAST tournament announced'
            ],
            gameReleases: [
                '🎮 Helldivers 2 breaks Steam records',
                '🚀 Skull and Bones launches March 2024',
                '⚔️ Dragon\'s Dogma 2 release date confirmed',
                '🏎️ F1 24 announced for summer release'
            ],
            gameUpdates: [
                '🔄 CS2 receives major anti-cheat update',
                '⚡ Valorant Episode 8 Act 2 goes live',
                '🛠️ Apex Legends Season 20 patch notes',
                '🎯 Overwatch 2 balance changes deployed'
            ]
        };
    },

    generateEventsData(game) {
        const games = {
            'all': 'All Games',
            'cs2': 'Counter-Strike 2',
            'valorant': 'Valorant',
            'lol': 'League of Legends',
            'fortnite': 'Fortnite'
        };

        return {
            gameFilter: games[game],
            liveCount: '12 events live',
            upcomingCount: '47 events this week',
            liveTournaments: [
                '🔴 IEM Katowice 2024 - CS2 (Live)',
                '🔴 VCT Masters Madrid - Valorant (Live)',
                '🔴 LCS Spring Split - League of Legends',
                '🔴 FNCS Global Championship - Fortnite'
            ],
            upcomingEvents: [
                '📅 ESL Pro League S19 - Tomorrow 3:00 PM',
                '📅 Valorant Champions Tour - March 15',
                '📅 LEC Spring Playoffs - March 20',
                '📅 Fortnite World Cup - April 2024'
            ],
            majorEvents: [
                '🏆 CS2 Major Copenhagen - March 2024',
                '🏆 Valorant Champions 2024 - August',
                '🏆 Worlds 2024 - October',
                '🏆 Fortnite World Championship - TBA'
            ],
            prizePools: [
                '💰 IEM Katowice: $1,000,000',
                '💰 VCT Masters: $500,000',
                '💰 LCS Spring: $200,000',
                '💰 FNCS Global: $4,000,000'
            ]
        };
    },

    generateNotificationData(channel, frequency) {
        const frequencies = {
            'realtime': 'Real-time Updates',
            'hourly': 'Every Hour',
            'daily': 'Daily Digest',
            'weekly': 'Weekly Summary'
        };

        return {
            frequencyName: frequencies[frequency],
            status: '🟡 Pending Setup',
            newsCategories: [
                '✅ Breaking Gaming News',
                '✅ Esports Tournament Updates',
                '✅ Game Release Announcements',
                '✅ Patch Notes & Updates',
                '✅ FiveM Server News'
            ],
            eventTypes: [
                '🏆 Major Tournament Starts',
                '🎮 New Game Releases',
                '🔄 Important Game Updates',
                '💰 Prize Pool Announcements',
                '📺 Live Stream Notifications'
            ],
            settings: [
                '🔔 Mention @everyone for major events',
                '📱 Rich embed notifications',
                '🎯 Filter by game preferences',
                '⏰ Timezone: Server Default',
                '🚫 Spam protection enabled'
            ],
            statistics: [
                '📊 0 notifications sent (new setup)',
                '👥 Server members will be notified',
                '🎯 Estimated 5-15 notifications/day',
                '📈 Engagement rate: N/A (new)'
            ]
        };
    }
};