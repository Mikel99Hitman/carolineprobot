const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('fivem-roleplay')
        .setDescription('🎮 Advanced FiveM Roleplay Management System')
        .addSubcommand(subcommand =>
            subcommand
                .setName('server-status')
                .setDescription('Check FiveM server status and player count')
                .addStringOption(option =>
                    option.setName('server-ip')
                        .setDescription('FiveM server IP address')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('character-creator')
                .setDescription('Create and manage roleplay characters'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('job-system')
                .setDescription('Manage roleplay jobs and careers')
                .addStringOption(option =>
                    option.setName('action')
                        .setDescription('Job system action')
                        .addChoices(
                            { name: 'View Available Jobs', value: 'jobs' },
                            { name: 'Apply for Job', value: 'apply' },
                            { name: 'Job Statistics', value: 'stats' },
                            { name: 'Salary Calculator', value: 'salary' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('economy-tracker')
                .setDescription('Track server economy and transactions')
                .addStringOption(option =>
                    option.setName('type')
                        .setDescription('Economy tracking type')
                        .addChoices(
                            { name: 'Bank Account', value: 'bank' },
                            { name: 'Business Stats', value: 'business' },
                            { name: 'Property Values', value: 'property' },
                            { name: 'Market Analysis', value: 'market' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('whitelist-manager')
                .setDescription('Manage server whitelist applications')
                .addStringOption(option =>
                    option.setName('action')
                        .setDescription('Whitelist action')
                        .addChoices(
                            { name: 'Submit Application', value: 'apply' },
                            { name: 'Check Status', value: 'status' },
                            { name: 'Review Applications', value: 'review' }
                        ))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        switch (subcommand) {
            case 'server-status':
                await this.serverStatus(interaction);
                break;
            case 'character-creator':
                await this.characterCreator(interaction);
                break;
            case 'job-system':
                await this.jobSystem(interaction);
                break;
            case 'economy-tracker':
                await this.economyTracker(interaction);
                break;
            case 'whitelist-manager':
                await this.whitelistManager(interaction);
                break;
        }
    },

    async serverStatus(interaction) {
        await interaction.deferReply();

        const serverIP = interaction.options.getString('server-ip');
        const serverData = this.generateServerData(serverIP);

        const embed = new EmbedBuilder()
            .setTitle('🎮 FiveM Server Status')
            .setDescription(`Server: \`${serverIP}\``)
            .addFields(
                { name: '🟢 Status', value: serverData.status, inline: true },
                { name: '👥 Players Online', value: `${serverData.playersOnline}/${serverData.maxPlayers}`, inline: true },
                { name: '📊 Server Load', value: serverData.serverLoad, inline: true },
                { name: '🌐 Server Name', value: serverData.serverName, inline: false },
                { name: '🎯 Game Mode', value: serverData.gameMode, inline: true },
                { name: '🗺️ Current Map', value: serverData.currentMap, inline: true },
                { name: '⏱️ Uptime', value: serverData.uptime, inline: true },
                { name: '👮 Active Police', value: serverData.activePolice, inline: true },
                { name: '🚑 Active EMS', value: serverData.activeEMS, inline: true },
                { name: '🔧 Active Mechanics', value: serverData.activeMechanics, inline: true },
                { name: '📈 Recent Activity', value: serverData.recentActivity.join('\n'), inline: false }
            )
            .setColor(serverData.status === '🟢 Online' ? '#00ff00' : '#ff0000')
            .setTimestamp()
            .setFooter({ text: 'FiveM Server Monitor • Live Data' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('refresh_status')
                    .setLabel('🔄 Refresh')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('player_list')
                    .setLabel('👥 Player List')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('server_rules')
                    .setLabel('📋 Server Rules')
                    .setStyle(ButtonStyle.Success)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async characterCreator(interaction) {
        const modal = new ModalBuilder()
            .setCustomId('character_creation_modal')
            .setTitle('🎭 Create Roleplay Character');

        const nameInput = new TextInputBuilder()
            .setCustomId('character_name')
            .setLabel('Character Full Name')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('John Smith')
            .setRequired(true);

        const ageInput = new TextInputBuilder()
            .setCustomId('character_age')
            .setLabel('Character Age')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('25')
            .setRequired(true);

        const backgroundInput = new TextInputBuilder()
            .setCustomId('character_background')
            .setLabel('Character Background Story')
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder('Tell us about your character\'s history, personality, and goals...')
            .setRequired(true);

        const jobInput = new TextInputBuilder()
            .setCustomId('desired_job')
            .setLabel('Desired Job/Career')
            .setStyle(TextInputStyle.Short)
            .setPlaceholder('Police Officer, Doctor, Mechanic, etc.')
            .setRequired(false);

        const skillsInput = new TextInputBuilder()
            .setCustomId('character_skills')
            .setLabel('Special Skills & Traits')
            .setStyle(TextInputStyle.Paragraph)
            .setPlaceholder('Driving, Medical Knowledge, Combat Training, etc.')
            .setRequired(false);

        const firstRow = new ActionRowBuilder().addComponents(nameInput);
        const secondRow = new ActionRowBuilder().addComponents(ageInput);
        const thirdRow = new ActionRowBuilder().addComponents(backgroundInput);
        const fourthRow = new ActionRowBuilder().addComponents(jobInput);
        const fifthRow = new ActionRowBuilder().addComponents(skillsInput);

        modal.addComponents(firstRow, secondRow, thirdRow, fourthRow, fifthRow);

        await interaction.showModal(modal);
    },

    generateServerData(serverIP) {
        return {
            status: '🟢 Online',
            playersOnline: Math.floor(Math.random() * 200) + 50,
            maxPlayers: 250,
            serverLoad: `${Math.floor(Math.random() * 30) + 40}%`,
            serverName: 'Los Santos Roleplay | Serious RP',
            gameMode: 'Roleplay',
            currentMap: 'Los Santos',
            uptime: `${Math.floor(Math.random() * 24) + 1}h ${Math.floor(Math.random() * 60)}m`,
            activePolice: Math.floor(Math.random() * 15) + 5,
            activeEMS: Math.floor(Math.random() * 8) + 3,
            activeMechanics: Math.floor(Math.random() * 6) + 2,
            recentActivity: [
                '🚔 Police chase in progress - Downtown',
                '🚑 Medical emergency - Sandy Shores',
                '🏪 Store robbery reported - Vinewood',
                '🚗 Car accident - Highway 1'
            ]
        };
    }
};