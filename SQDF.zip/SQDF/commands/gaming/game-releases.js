const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('game-releases')
        .setDescription('🎮 Game Release Tracker & Notifications')
        .addSubcommand(subcommand =>
            subcommand
                .setName('upcoming-releases')
                .setDescription('View upcoming game releases')
                .addStringOption(option =>
                    option.setName('platform')
                        .setDescription('Gaming platform')
                        .addChoices(
                            { name: 'All Platforms', value: 'all' },
                            { name: 'PC (Steam)', value: 'pc' },
                            { name: 'PlayStation', value: 'ps' },
                            { name: 'Xbox', value: 'xbox' },
                            { name: 'Nintendo Switch', value: 'switch' },
                            { name: 'Mobile', value: 'mobile' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('recent-releases')
                .setDescription('View recently released games')
                .addStringOption(option =>
                    option.setName('timeframe')
                        .setDescription('Time period')
                        .addChoices(
                            { name: 'This Week', value: 'week' },
                            { name: 'This Month', value: 'month' },
                            { name: 'Last 3 Months', value: '3months' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('game-updates')
                .setDescription('Track game updates and patches')
                .addStringOption(option =>
                    option.setName('game-title')
                        .setDescription('Specific game to track')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('wishlist-tracker')
                .setDescription('Track your gaming wishlist')
                .addStringOption(option =>
                    option.setName('action')
                        .setDescription('Wishlist action')
                        .addChoices(
                            { name: 'View Wishlist', value: 'view' },
                            { name: 'Add Game', value: 'add' },
                            { name: 'Remove Game', value: 'remove' },
                            { name: 'Price Alerts', value: 'alerts' }
                        ))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        switch (subcommand) {
            case 'upcoming-releases':
                await this.upcomingReleases(interaction);
                break;
            case 'recent-releases':
                await this.recentReleases(interaction);
                break;
            case 'game-updates':
                await this.gameUpdates(interaction);
                break;
            case 'wishlist-tracker':
                await this.wishlistTracker(interaction);
                break;
        }
    },

    async upcomingReleases(interaction) {
        await interaction.deferReply();

        const platform = interaction.options.getString('platform') || 'all';
        const releasesData = this.generateUpcomingReleases(platform);

        const embed = new EmbedBuilder()
            .setTitle('🎮 Upcoming Game Releases')
            .setDescription('Most anticipated games coming soon')
            .addFields(
                { name: '🎯 Platform', value: releasesData.platformName, inline: true },
                { name: '📅 Time Period', value: releasesData.timePeriod, inline: true },
                { name: '🔥 Most Hyped', value: releasesData.mostHyped, inline: true },
                { name: '🚀 This Month', value: releasesData.thisMonth.join('\n'), inline: false },
                { name: '📅 Next Month', value: releasesData.nextMonth.join('\n'), inline: false },
                { name: '🎯 Q2 2024 Highlights', value: releasesData.q2Highlights.join('\n'), inline: false },
                { name: '⭐ AAA Releases', value: releasesData.aaaReleases.join('\n'), inline: false }
            )
            .setColor('#3498db')
            .setTimestamp()
            .setFooter({ text: 'Game Releases • Release Tracker' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('add_to_wishlist')
                    .setLabel('⭐ Add to Wishlist')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('set_release_alerts')
                    .setLabel('🔔 Set Alerts')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('view_trailers')
                    .setLabel('📺 View Trailers')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async recentReleases(interaction) {
        await interaction.deferReply();

        const timeframe = interaction.options.getString('timeframe') || 'week';
        const recentData = this.generateRecentReleases(timeframe);

        const embed = new EmbedBuilder()
            .setTitle('🎮 Recent Game Releases')
            .setDescription('Latest games that just launched')
            .addFields(
                { name: '📅 Time Period', value: recentData.timePeriodName, inline: true },
                { name: '🎮 Total Releases', value: recentData.totalReleases, inline: true },
                { name: '⭐ Highest Rated', value: recentData.highestRated, inline: true },
                { name: '🔥 Hot Releases', value: recentData.hotReleases.join('\n'), inline: false },
                { name: '🎯 Indie Gems', value: recentData.indieGems.join('\n'), inline: false },
                { name: '📊 User Reviews', value: recentData.userReviews.join('\n'), inline: false },
                { name: '💰 Price Ranges', value: recentData.priceRanges.join('\n'), inline: false }
            )
            .setColor('#e74c3c')
            .setTimestamp()
            .setFooter({ text: 'Recent Releases • Gaming Library' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('view_reviews')
                    .setLabel('📖 Read Reviews')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('compare_prices')
                    .setLabel('💰 Compare Prices')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('download_demos')
                    .setLabel('🎮 Find Demos')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async gameUpdates(interaction) {
        await interaction.deferReply();

        const gameTitle = interaction.options.getString('game-title');
        const updatesData = this.generateGameUpdates(gameTitle);

        const embed = new EmbedBuilder()
            .setTitle('🔄 Game Updates & Patches')
            .setDescription('Latest game updates and patch notes')
            .addFields(
                { name: '🎮 Game Focus', value: updatesData.gameFocus, inline: true },
                { name: '📅 Last Update', value: updatesData.lastUpdate, inline: true },
                { name: '📊 Update Size', value: updatesData.updateSize, inline: true },
                { name: '🔥 Recent Updates', value: updatesData.recentUpdates.join('\n'), inline: false },
                { name: '🛠️ Bug Fixes', value: updatesData.bugFixes.join('\n'), inline: false },
                { name: '✨ New Features', value: updatesData.newFeatures.join('\n'), inline: false },
                { name: '⚖️ Balance Changes', value: updatesData.balanceChanges.join('\n'), inline: false }
            )
            .setColor('#f39c12')
            .setTimestamp()
            .setFooter({ text: 'Game Updates • Patch Tracker' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('full_patch_notes')
                    .setLabel('📋 Full Patch Notes')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('update_notifications')
                    .setLabel('🔔 Update Alerts')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('community_feedback')
                    .setLabel('💬 Community Feedback')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async wishlistTracker(interaction) {
        await interaction.deferReply();

        const action = interaction.options.getString('action') || 'view';
        const wishlistData = this.generateWishlistData(action, interaction.user);

        const embed = new EmbedBuilder()
            .setTitle('⭐ Gaming Wishlist Tracker')
            .setDescription(`Wishlist management for ${interaction.user.tag}`)
            .addFields(
                { name: '🎯 Action', value: wishlistData.actionName, inline: true },
                { name: '📊 Wishlist Size', value: wishlistData.wishlistSize, inline: true },
                { name: '💰 Total Value', value: wishlistData.totalValue, inline: true },
                { name: '⭐ Your Wishlist', value: wishlistData.wishlistGames.join('\n'), inline: false },
                { name: '💸 Price Alerts', value: wishlistData.priceAlerts.join('\n'), inline: false },
                { name: '📅 Release Reminders', value: wishlistData.releaseReminders.join('\n'), inline: false },
                { name: '🎯 Recommendations', value: wishlistData.recommendations.join('\n'), inline: false }
            )
            .setColor('#9b59b6')
            .setTimestamp()
            .setFooter({ text: 'Wishlist Tracker • Personal Gaming' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('add_game_wishlist')
                    .setLabel('➕ Add Game')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('manage_alerts')
                    .setLabel('🔔 Manage Alerts')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('share_wishlist')
                    .setLabel('📤 Share Wishlist')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    generateUpcomingReleases(platform) {
        const platforms = {
            'all': 'All Platforms',
            'pc': 'PC (Steam)',
            'ps': 'PlayStation',
            'xbox': 'Xbox',
            'switch': 'Nintendo Switch',
            'mobile': 'Mobile'
        };

        return {
            platformName: platforms[platform],
            timePeriod: 'Next 6 months',
            mostHyped: 'Dragon\'s Dogma 2',
            thisMonth: [
                '🎮 Dragon\'s Dogma 2 - March 22, 2024',
                '🏎️ F1 Manager 2024 - March 28, 2024',
                '⚔️ Rise of the Ronin - March 22, 2024',
                '🎯 Skull and Bones - March 9, 2024'
            ],
            nextMonth: [
                '🌟 Stellar Blade - April 26, 2024',
                '🎮 Sand Land - April 25, 2024',
                '🏰 Manor Lords - April 2024',
                '🎯 Helldivers 2 DLC - April 2024'
            ],
            q2Highlights: [
                '🎮 Elden Ring: Shadow of the Erdtree - June 2024',
                '🏎️ F1 24 - May 31, 2024',
                '⚔️ Warhammer 40K: Space Marine 2 - Q2 2024',
                '🌟 Black Myth: Wukong - Q2 2024'
            ],
            aaaReleases: [
                '🎮 Dragon\'s Dogma 2 - $69.99',
                '🌟 Stellar Blade - $59.99',
                '⚔️ Rise of the Ronin - $69.99',
                '🎯 Elden Ring DLC - $39.99'
            ]
        };
    },

    generateRecentReleases(timeframe) {
        const timeframes = {
            'week': 'This Week',
            'month': 'This Month',
            '3months': 'Last 3 Months'
        };

        return {
            timePeriodName: timeframes[timeframe],
            totalReleases: '47 new games',
            highestRated: 'Helldivers 2 (92/100)',
            hotReleases: [
                '🔥 Helldivers 2 - 92% Positive (Steam)',
                '🎮 Granblue Fantasy Relink - 89% Positive',
                '⚔️ Skull and Bones - 67% Mixed Reviews',
                '🎯 Pacific Drive - 85% Positive'
            ],
            indieGems: [
                '💎 Pizza Tower - 96% Overwhelmingly Positive',
                '🎨 Cocoon - 94% Very Positive',
                '🎮 Dredge - 91% Very Positive',
                '⭐ Bomb Rush Cyberfunk - 88% Very Positive'
            ],
            userReviews: [
                '📊 Average Score: 78/100',
                '👥 Most Reviewed: Helldivers 2',
                '⭐ Hidden Gem: Pizza Tower',
                '💔 Biggest Disappointment: Skull and Bones'
            ],
            priceRanges: [
                '💰 AAA Games: $59.99 - $69.99',
                '🎮 Mid-tier: $29.99 - $49.99',
                '💎 Indie Games: $9.99 - $24.99',
                '🆓 Free-to-Play: Helldivers 2 (with PS+)'
            ]
        };
    },

    generateGameUpdates(gameTitle) {
        return {
            gameFocus: gameTitle || 'All Popular Games',
            lastUpdate: '2 hours ago',
            updateSize: 'Various (50MB - 15GB)',
            recentUpdates: [
                '🔄 CS2: Anti-cheat improvements (247MB)',
                '⚡ Valorant: Episode 8 Act 2 (1.2GB)',
                '🛠️ Apex Legends: Season 20 patch (3.4GB)',
                '🎯 Fortnite: Chapter 5 hotfix (156MB)'
            ],
            bugFixes: [
                '🐛 CS2: Fixed smoke grenade rendering',
                '🔧 Valorant: Resolved audio issues',
                '⚡ Apex: Fixed legend ability bugs',
                '🛠️ Fortnite: Stability improvements'
            ],
            newFeatures: [
                '✨ CS2: New map rotation system',
                '🎯 Valorant: Improved replay system',
                '🎮 Apex: New firing range features',
                '🌟 Fortnite: Creative mode updates'
            ],
            balanceChanges: [
                '⚖️ CS2: AK-47 recoil adjustments',
                '🎯 Valorant: Agent ability tweaks',
                '⚡ Apex: Weapon damage rebalance',
                '🔄 Fortnite: Building mechanics update'
            ]
        };
    },

    generateWishlistData(action, user) {
        const actions = {
            'view': 'View Wishlist',
            'add': 'Add Game',
            'remove': 'Remove Game',
            'alerts': 'Price Alerts'
        };

        return {
            actionName: actions[action],
            wishlistSize: '12 games',
            totalValue: '$647.88',
            wishlistGames: [
                '⭐ Dragon\'s Dogma 2 - $69.99 (Releases March 22)',
                '🌟 Stellar Blade - $59.99 (Releases April 26)',
                '🎮 Elden Ring DLC - $39.99 (Releases June 2024)',
                '🏎️ F1 24 - $69.99 (Releases May 31)',
                '⚔️ Black Myth: Wukong - $59.99 (TBA 2024)'
            ],
            priceAlerts: [
                '💸 Cyberpunk 2077: 50% off alert set',
                '🔔 Baldur\'s Gate 3: 25% off alert set',
                '💰 Elden Ring: Any discount alert',
                '⚡ Helldivers 2: Price drop alert'
            ],
            releaseReminders: [
                '📅 Dragon\'s Dogma 2 - 5 days reminder set',
                '📅 Stellar Blade - 1 month reminder set',
                '📅 Elden Ring DLC - 3 months reminder set'
            ],
            recommendations: [
                '🎯 Similar to your taste: Lies of P',
                '🌟 Trending in your genre: Granblue Fantasy',
                '💎 Hidden gem: Pizza Tower',
                '🔥 Popular choice: Helldivers 2'
            ]
        };
    }
};