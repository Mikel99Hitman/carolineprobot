const pool = require('../database/connection');

class Poll {
    static async findOne(filter) {
        const { guildId, messageId } = filter;
        const result = await pool.query('SELECT * FROM polls WHERE guild_id = $1 AND message_id = $2', [guildId, messageId]);
        return result.rows[0];
    }

    static async create(pollData) {
        const { guildId, channelId, messageId, creatorId, question, options, endTime, ended = false, allowMultiple = false, anonymous = false } = pollData;
        const result = await pool.query(`
            INSERT INTO polls (guild_id, channel_id, message_id, creator_id, question, options, end_time, ended, allow_multiple, anonymous)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            RETURNING *
        `, [guildId, channelId, messageId, creatorId, question, JSON.stringify(options), endTime, ended, allowMultiple, anonymous]);
        return result.rows[0];
    }

    static async findOneAndUpdate(filter, update) {
        const { guildId, messageId } = filter;
        const fields = [];
        const values = [];
        let paramCount = 1;

        Object.keys(update).forEach(key => {
            const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
            if (key === 'options') {
                fields.push(`${dbKey} = $${paramCount}`);
                values.push(JSON.stringify(update[key]));
            } else {
                fields.push(`${dbKey} = $${paramCount}`);
                values.push(update[key]);
            }
            paramCount++;
        });

        values.push(guildId, messageId);
        
        const result = await pool.query(`
            UPDATE polls SET ${fields.join(', ')} WHERE guild_id = $${paramCount} AND message_id = $${paramCount + 1} RETURNING *
        `, values);
        
        return result.rows[0];
    }

    static async find(filter = {}) {
        let query = 'SELECT * FROM polls';
        const values = [];
        
        if (filter.guildId) {
            query += ' WHERE guild_id = $1';
            values.push(filter.guildId);
        }
        
        const result = await pool.query(query, values);
        return result.rows;
    }
}

module.exports = Poll;