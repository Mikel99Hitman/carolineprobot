const pool = require('../database/connection');

class Guild {
    static async findOne(filter) {
        const { guildId } = filter;
        const result = await pool.query('SELECT * FROM guilds WHERE guild_id = $1', [guildId]);
        return result.rows[0];
    }

    static async findByGuildId(guildId) {
        const result = await pool.query('SELECT * FROM guilds WHERE guild_id = $1', [guildId]);
        return result.rows[0];
    }

    static async create(guildData) {
        const { guildId, prefix = '!', welcomeChannel, welcomeMessage = 'Welcome {user} to {server}!', 
                logChannel, webhookUrl, levelUpChannel, autoRole, antiSpam = false, 
                antiRaid = false, antiLink = false, musicChannel, ticketCategory, applicationChannel } = guildData;
        
        const result = await pool.query(`
            INSERT INTO guilds (guild_id, prefix, welcome_channel, welcome_message, log_channel, 
                              webhook_url, level_up_channel, auto_role, anti_spam, anti_raid, 
                              anti_link, music_channel, ticket_category, application_channel)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
            RETURNING *
        `, [guildId, prefix, welcomeChannel, welcomeMessage, logChannel, webhookUrl, 
            levelUpChannel, autoRole, antiSpam, antiRaid, antiLink, musicChannel, 
            ticketCategory, applicationChannel]);
        
        return result.rows[0];
    }

    static async updateByGuildId(guildId, updateData) {
        const fields = [];
        const values = [];
        let paramCount = 1;

        Object.keys(updateData).forEach(key => {
            const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
            fields.push(`${dbKey} = $${paramCount}`);
            values.push(updateData[key]);
            paramCount++;
        });

        values.push(guildId);
        
        const result = await pool.query(`
            UPDATE guilds SET ${fields.join(', ')} WHERE guild_id = $${paramCount} RETURNING *
        `, values);
        
        return result.rows[0];
    }

    static async findOneAndUpdate(filter, update, options = {}) {
        const existing = await this.findByGuildId(filter.guildId);
        if (existing) {
            return await this.updateByGuildId(filter.guildId, update);
        } else if (options.upsert) {
            return await this.create({ guildId: filter.guildId, ...update });
        }
        return null;
    }
}

module.exports = Guild;