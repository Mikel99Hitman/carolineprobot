const mongoose = require('mongoose');

const guildSchema = new mongoose.Schema({
    guildId: { type: String, required: true, unique: true },
    prefix: { type: String, default: '!' },
    welcomeChannel: { type: String, default: null },
    welcomeMessage: { type: String, default: 'Welcome {user} to {server}!' },
    logChannel: { type: String, default: null },
    webhookUrl: { type: String, default: null },
    levelUpChannel: { type: String, default: null },
    autoRole: { type: String, default: null },
    antiSpam: { type: Boolean, default: false },
    antiRaid: { type: Boolean, default: false },
    antiLink: { type: Boolean, default: false },
    musicChannel: { type: String, default: null },
    ticketCategory: { type: String, default: null },
    applicationChannel: { type: String, default: null }
});

module.exports = mongoose.model('Guild', guildSchema);