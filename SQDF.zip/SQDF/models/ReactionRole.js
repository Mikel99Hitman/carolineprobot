const pool = require('../database/connection');

class ReactionRole {
    static async create(reactionRoleData) {
        const { guildId, messageId, channelId, roles = [], title = 'Reaction Roles', 
                description = 'React to get roles!' } = reactionRoleData;
        
        const client = await pool.connect();
        try {
            await client.query('BEGIN');
            
            const result = await client.query(`
                INSERT INTO reaction_roles (guild_id, message_id, channel_id, title, description)
                VALUES ($1, $2, $3, $4, $5)
                RETURNING *
            `, [guildId, messageId, channelId, title, description]);
            
            const reactionRole = result.rows[0];
            
            for (const role of roles) {
                await client.query(`
                    INSERT INTO reaction_role_mappings (reaction_role_id, emoji, role_id)
                    VALUES ($1, $2, $3)
                `, [reactionRole.id, role.emoji, role.roleId]);
            }
            
            await client.query('COMMIT');
            return reactionRole;
        } catch (error) {
            await client.query('ROLLBACK');
            throw error;
        } finally {
            client.release();
        }
    }

    static async findOne(filter) {
        const keys = Object.keys(filter);
        const values = Object.values(filter);
        const conditions = keys.map((key, index) => {
            const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
            return `${dbKey} = $${index + 1}`;
        });
        
        const result = await pool.query(`
            SELECT rr.*, 
                   COALESCE(
                       json_agg(
                           json_build_object('emoji', rrm.emoji, 'roleId', rrm.role_id)
                       ) FILTER (WHERE rrm.id IS NOT NULL), 
                       '[]'
                   ) as roles
            FROM reaction_roles rr
            LEFT JOIN reaction_role_mappings rrm ON rr.id = rrm.reaction_role_id
            WHERE ${conditions.join(' AND ')}
            GROUP BY rr.id
        `, values);
        
        return result.rows[0];
    }

    static async find(filter = {}) {
        let query = `
            SELECT rr.*, 
                   COALESCE(
                       json_agg(
                           json_build_object('emoji', rrm.emoji, 'roleId', rrm.role_id)
                       ) FILTER (WHERE rrm.id IS NOT NULL), 
                       '[]'
                   ) as roles
            FROM reaction_roles rr
            LEFT JOIN reaction_role_mappings rrm ON rr.id = rrm.reaction_role_id
        `;
        
        const values = [];
        const conditions = [];
        let paramCount = 1;

        Object.keys(filter).forEach(key => {
            const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
            conditions.push(`rr.${dbKey} = $${paramCount}`);
            values.push(filter[key]);
            paramCount++;
        });

        if (conditions.length > 0) {
            query += ` WHERE ${conditions.join(' AND ')}`;
        }
        
        query += ' GROUP BY rr.id';
        
        const result = await pool.query(query, values);
        return result.rows;
    }

    static async addRole(messageId, emoji, roleId) {
        const reactionRole = await this.findOne({ messageId });
        if (reactionRole) {
            await pool.query(`
                INSERT INTO reaction_role_mappings (reaction_role_id, emoji, role_id)
                VALUES ($1, $2, $3)
            `, [reactionRole.id, emoji, roleId]);
        }
    }

    static async deleteOne(filter) {
        const keys = Object.keys(filter);
        const values = Object.values(filter);
        const conditions = keys.map((key, index) => {
            const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
            return `${dbKey} = $${index + 1}`;
        });
        
        await pool.query(`DELETE FROM reaction_roles WHERE ${conditions.join(' AND ')}`, values);
    }
}

module.exports = ReactionRole;