const mongoose = require('mongoose');

const reactionRoleSchema = new mongoose.Schema({
    guildId: { type: String, required: true },
    messageId: { type: String, required: true },
    channelId: { type: String, required: true },
    roles: [{
        emoji: String,
        roleId: String
    }],
    title: { type: String, default: 'Reaction Roles' },
    description: { type: String, default: 'React to get roles!' }
});

module.exports = mongoose.model('ReactionRole', reactionRoleSchema);