const pool = require('../database/connection');

class AFK {
    static async findOne(filter) {
        const { userId, guildId } = filter;
        const result = await pool.query('SELECT * FROM afk WHERE user_id = $1 AND guild_id = $2', [userId, guildId]);
        return result.rows[0];
    }

    static async create(afkData) {
        const { userId, guildId, reason = 'AFK' } = afkData;
        const result = await pool.query(`
            INSERT INTO afk (user_id, guild_id, reason, timestamp)
            VALUES ($1, $2, $3, NOW())
            RETURNING *
        `, [userId, guildId, reason]);
        return result.rows[0];
    }

    static async deleteOne(filter) {
        const { userId, guildId } = filter;
        await pool.query('DELETE FROM afk WHERE user_id = $1 AND guild_id = $2', [userId, guildId]);
    }
}

module.exports = AFK;