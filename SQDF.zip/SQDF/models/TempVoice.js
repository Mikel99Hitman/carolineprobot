const pool = require('../database/connection');

class TempVoice {
    static async findOne(filter) {
        const { guildId } = filter;
        const result = await pool.query('SELECT * FROM temp_voice WHERE guild_id = $1', [guildId]);
        return result.rows[0];
    }

    static async create(tempVoiceData) {
        const { guildId, creatorChannelId, categoryId } = tempVoiceData;
        const result = await pool.query(`
            INSERT INTO temp_voice (guild_id, creator_channel_id, category_id)
            VALUES ($1, $2, $3)
            RETURNING *
        `, [guildId, creatorChannelId, categoryId]);
        return result.rows[0];
    }

    static async addTempChannel(guildId, channelId, ownerId) {
        await pool.query(`
            INSERT INTO temp_channels (guild_id, channel_id, owner_id)
            VALUES ($1, $2, $3)
        `, [guildId, channelId, ownerId]);
    }

    static async removeTempChannel(channelId) {
        await pool.query('DELETE FROM temp_channels WHERE channel_id = $1', [channelId]);
    }

    static async getTempChannels(guildId) {
        const result = await pool.query('SELECT * FROM temp_channels WHERE guild_id = $1', [guildId]);
        return result.rows;
    }

    static async findTempChannel(channelId) {
        const result = await pool.query('SELECT * FROM temp_channels WHERE channel_id = $1', [channelId]);
        return result.rows[0];
    }
}

module.exports = TempVoice;