const mongoose = require('mongoose');

const ticketSchema = new mongoose.Schema({
    ticketId: { type: String, required: true, unique: true },
    guildId: { type: String, required: true },
    userId: { type: String, required: true },
    channelId: { type: String, required: true },
    status: { type: String, enum: ['open', 'closed'], default: 'open' },
    reason: { type: String, default: 'عام' },
    createdAt: { type: Date, default: Date.now },
    closedAt: { type: Date, default: null }
});

module.exports = mongoose.model('Ticket', ticketSchema);