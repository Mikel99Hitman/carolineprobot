const pool = require('../database/connection');

class Birthday {
    static async findOne(filter) {
        const { userId, guildId } = filter;
        const result = await pool.query('SELECT * FROM birthdays WHERE user_id = $1 AND guild_id = $2', [userId, guildId]);
        return result.rows[0];
    }

    static async create(birthdayData) {
        const { userId, guildId, birthday, timezone = 'UTC', private = false } = birthdayData;
        const result = await pool.query(`
            INSERT INTO birthdays (user_id, guild_id, birthday, timezone, private)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING *
        `, [userId, guildId, birthday, timezone, private]);
        return result.rows[0];
    }

    static async find(filter = {}) {
        let query = 'SELECT * FROM birthdays';
        const values = [];
        
        if (filter.guildId) {
            query += ' WHERE guild_id = $1';
            values.push(filter.guildId);
        }
        
        const result = await pool.query(query, values);
        return result.rows;
    }

    static async findOneAndUpdate(filter, update) {
        const { userId, guildId } = filter;
        const fields = [];
        const values = [];
        let paramCount = 1;

        Object.keys(update).forEach(key => {
            fields.push(`${key} = $${paramCount}`);
            values.push(update[key]);
            paramCount++;
        });

        values.push(userId, guildId);
        
        const result = await pool.query(`
            UPDATE birthdays SET ${fields.join(', ')} WHERE user_id = $${paramCount} AND guild_id = $${paramCount + 1} RETURNING *
        `, values);
        
        return result.rows[0];
    }
}

module.exports = Birthday;