const mongoose = require('mongoose');

const starboardSchema = new mongoose.Schema({
    guildId: { type: String, required: true },
    channelId: { type: String, required: true },
    threshold: { type: Number, default: 3 },
    emoji: { type: String, default: '⭐' },
    starredMessages: [{
        messageId: String,
        starboardMessageId: String,
        stars: Number
    }]
});

module.exports = mongoose.model('Starboard', starboardSchema);