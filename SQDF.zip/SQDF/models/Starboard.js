const pool = require('../database/connection');

class Starboard {
    static async findOne(filter) {
        const { guildId } = filter;
        const result = await pool.query('SELECT * FROM starboard WHERE guild_id = $1', [guildId]);
        return result.rows[0];
    }

    static async create(starboardData) {
        const { guildId, channelId, threshold = 3, emoji = '⭐' } = starboardData;
        const result = await pool.query(`
            INSERT INTO starboard (guild_id, channel_id, threshold, emoji)
            VALUES ($1, $2, $3, $4)
            RETURNING *
        `, [guildId, channelId, threshold, emoji]);
        return result.rows[0];
    }

    static async findOneAndUpdate(filter, update, options = {}) {
        const { guildId } = filter;
        const existing = await this.findOne(filter);
        
        if (existing) {
            const fields = [];
            const values = [];
            let paramCount = 1;

            Object.keys(update).forEach(key => {
                fields.push(`${key} = $${paramCount}`);
                values.push(update[key]);
                paramCount++;
            });

            values.push(guildId);
            
            const result = await pool.query(`
                UPDATE starboard SET ${fields.join(', ')} WHERE guild_id = $${paramCount} RETURNING *
            `, values);
            
            return result.rows[0];
        } else if (options.upsert) {
            return await this.create({ guildId, ...update });
        }
        return null;
    }

    static async addStarredMessage(guildId, messageId, starboardMessageId, stars) {
        await pool.query(`
            INSERT INTO starred_messages (guild_id, message_id, starboard_message_id, stars)
            VALUES ($1, $2, $3, $4)
        `, [guildId, messageId, starboardMessageId, stars]);
    }

    static async updateStarredMessage(messageId, stars) {
        await pool.query(`
            UPDATE starred_messages SET stars = $1 WHERE message_id = $2
        `, [stars, messageId]);
    }

    static async getStarredMessage(messageId) {
        const result = await pool.query('SELECT * FROM starred_messages WHERE message_id = $1', [messageId]);
        return result.rows[0];
    }
}

module.exports = Starboard;