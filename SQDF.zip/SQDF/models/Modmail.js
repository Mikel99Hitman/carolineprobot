const mongoose = require('mongoose');

const modmailSchema = new mongoose.Schema({
    userId: { type: String, required: true },
    guildId: { type: String, required: true },
    channelId: { type: String, required: true },
    status: { type: String, enum: ['open', 'closed'], default: 'open' },
    messages: [{
        authorId: String,
        content: String,
        timestamp: { type: Date, default: Date.now },
        isStaff: Boolean
    }],
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Modmail', modmailSchema);