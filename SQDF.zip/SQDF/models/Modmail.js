const pool = require('../database/connection');

class Modmail {
    static async findOne(filter) {
        const { userId, guildId, channelId } = filter;
        let query = 'SELECT * FROM modmail WHERE ';
        const values = [];
        const conditions = [];
        let paramCount = 1;

        if (userId) {
            conditions.push(`user_id = $${paramCount}`);
            values.push(userId);
            paramCount++;
        }
        if (guildId) {
            conditions.push(`guild_id = $${paramCount}`);
            values.push(guildId);
            paramCount++;
        }
        if (channelId) {
            conditions.push(`channel_id = $${paramCount}`);
            values.push(channelId);
            paramCount++;
        }

        query += conditions.join(' AND ');
        const result = await pool.query(query, values);
        return result.rows[0];
    }

    static async create(modmailData) {
        const { userId, guildId, channelId, status = 'open' } = modmailData;
        const result = await pool.query(`
            INSERT INTO modmail (user_id, guild_id, channel_id, status)
            VALUES ($1, $2, $3, $4)
            RETURNING *
        `, [userId, guildId, channelId, status]);
        return result.rows[0];
    }

    static async findOneAndUpdate(filter, update) {
        const existing = await this.findOne(filter);
        if (!existing) return null;

        const fields = [];
        const values = [];
        let paramCount = 1;

        Object.keys(update).forEach(key => {
            fields.push(`${key} = $${paramCount}`);
            values.push(update[key]);
            paramCount++;
        });

        values.push(existing.id);
        
        const result = await pool.query(`
            UPDATE modmail SET ${fields.join(', ')} WHERE id = $${paramCount} RETURNING *
        `, values);
        
        return result.rows[0];
    }
}

module.exports = Modmail;