const pool = require('../database/connection');

class CustomCommand {
    static async find(filter = {}) {
        let query = 'SELECT * FROM custom_commands';
        const values = [];
        
        if (filter.guildId) {
            query += ' WHERE guild_id = $1';
            values.push(filter.guildId);
        }
        
        const result = await pool.query(query, values);
        return result.rows;
    }

    static async findOne(filter) {
        const { guildId, name } = filter;
        const result = await pool.query('SELECT * FROM custom_commands WHERE guild_id = $1 AND name = $2', [guildId, name]);
        return result.rows[0];
    }

    static async create(commandData) {
        const { guildId, name, response, authorId, uses = 0, embed = false, deleteAfter = 0, requiredRole = null } = commandData;
        const result = await pool.query(`
            INSERT INTO custom_commands (guild_id, name, response, author_id, uses, embed, delete_after, required_role)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            RETURNING *
        `, [guildId, name, response, authorId, uses, embed, deleteAfter, requiredRole]);
        return result.rows[0];
    }

    static async findOneAndUpdate(filter, update) {
        const { guildId, name } = filter;
        const fields = [];
        const values = [];
        let paramCount = 1;

        Object.keys(update).forEach(key => {
            const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
            fields.push(`${dbKey} = $${paramCount}`);
            values.push(update[key]);
            paramCount++;
        });

        values.push(guildId, name);
        
        const result = await pool.query(`
            UPDATE custom_commands SET ${fields.join(', ')} WHERE guild_id = $${paramCount} AND name = $${paramCount + 1} RETURNING *
        `, values);
        
        return result.rows[0];
    }

    static async deleteOne(filter) {
        const { guildId, name } = filter;
        await pool.query('DELETE FROM custom_commands WHERE guild_id = $1 AND name = $2', [guildId, name]);
    }
}

module.exports = CustomCommand;