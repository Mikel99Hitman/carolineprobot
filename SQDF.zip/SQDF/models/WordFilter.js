const pool = require('../database/connection');

class WordFilter {
    static async findOne(filter) {
        const { guildId } = filter;
        const result = await pool.query('SELECT * FROM word_filter WHERE guild_id = $1', [guildId]);
        return result.rows[0];
    }

    static async create(filterData) {
        const { guildId, words = [], action = 'delete', whitelist = [], enabled = true } = filterData;
        const result = await pool.query(`
            INSERT INTO word_filter (guild_id, words, action, whitelist, enabled)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING *
        `, [guildId, JSON.stringify(words), action, JSON.stringify(whitelist), enabled]);
        return result.rows[0];
    }

    static async findOneAndUpdate(filter, update, options = {}) {
        const { guildId } = filter;
        const existing = await this.findOne(filter);
        
        if (existing) {
            const fields = [];
            const values = [];
            let paramCount = 1;

            Object.keys(update).forEach(key => {
                if (key === 'words' || key === 'whitelist') {
                    fields.push(`${key} = $${paramCount}`);
                    values.push(JSON.stringify(update[key]));
                } else {
                    fields.push(`${key} = $${paramCount}`);
                    values.push(update[key]);
                }
                paramCount++;
            });

            values.push(guildId);
            
            const result = await pool.query(`
                UPDATE word_filter SET ${fields.join(', ')} WHERE guild_id = $${paramCount} RETURNING *
            `, values);
            
            return result.rows[0];
        } else if (options.upsert) {
            return await this.create({ guildId, ...update });
        }
        return null;
    }

    static async addWord(guildId, word) {
        const filter = await this.findOne({ guildId });
        if (filter) {
            const words = JSON.parse(filter.words || '[]');
            words.push(word);
            await this.findOneAndUpdate({ guildId }, { words });
        }
    }

    static async removeWord(guildId, word) {
        const filter = await this.findOne({ guildId });
        if (filter) {
            const words = JSON.parse(filter.words || '[]');
            const index = words.indexOf(word);
            if (index > -1) {
                words.splice(index, 1);
                await this.findOneAndUpdate({ guildId }, { words });
            }
        }
    }
}

module.exports = WordFilter;