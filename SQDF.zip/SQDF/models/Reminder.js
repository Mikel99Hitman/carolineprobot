const pool = require('../database/connection');

class Reminder {
    static async create(reminderData) {
        const { userId, guildId, channelId, message, remindTime, recurring = {}, completed = false } = reminderData;
        const result = await pool.query(`
            INSERT INTO reminders (user_id, guild_id, channel_id, message, remind_time, recurring_enabled, recurring_interval, completed)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            RETURNING *
        `, [userId, guildId, channelId, message, remindTime, recurring.enabled || false, recurring.interval || null, completed]);
        return result.rows[0];
    }

    static async find(filter = {}) {
        let query = 'SELECT * FROM reminders';
        const values = [];
        const conditions = [];
        let paramCount = 1;

        Object.keys(filter).forEach(key => {
            const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
            conditions.push(`${dbKey} = $${paramCount}`);
            values.push(filter[key]);
            paramCount++;
        });

        if (conditions.length > 0) {
            query += ` WHERE ${conditions.join(' AND ')}`;
        }
        
        const result = await pool.query(query, values);
        return result.rows;
    }

    static async findOne(filter) {
        const { userId, guildId } = filter;
        const result = await pool.query('SELECT * FROM reminders WHERE user_id = $1 AND guild_id = $2', [userId, guildId]);
        return result.rows[0];
    }

    static async findOneAndUpdate(filter, update) {
        const existing = await this.findOne(filter);
        if (!existing) return null;

        const fields = [];
        const values = [];
        let paramCount = 1;

        Object.keys(update).forEach(key => {
            const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
            fields.push(`${dbKey} = $${paramCount}`);
            values.push(update[key]);
            paramCount++;
        });

        values.push(existing.id);
        
        const result = await pool.query(`
            UPDATE reminders SET ${fields.join(', ')} WHERE id = $${paramCount} RETURNING *
        `, values);
        
        return result.rows[0];
    }

    static async deleteOne(filter) {
        const { userId, guildId } = filter;
        await pool.query('DELETE FROM reminders WHERE user_id = $1 AND guild_id = $2', [userId, guildId]);
    }
}

module.exports = Reminder;