const pool = require('../database/connection');

class Counting {
    static async findOne(filter) {
        const { guildId, channelId } = filter;
        const result = await pool.query('SELECT * FROM counting WHERE guild_id = $1 AND channel_id = $2', [guildId, channelId]);
        return result.rows[0];
    }

    static async create(countingData) {
        const { guildId, channelId, currentNumber = 0, lastUserId = null, highestNumber = 0, fails = 0 } = countingData;
        const result = await pool.query(`
            INSERT INTO counting (guild_id, channel_id, current_number, last_user_id, highest_number, fails)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING *
        `, [guildId, channelId, currentNumber, lastUserId, highestNumber, fails]);
        return result.rows[0];
    }

    static async findOneAndUpdate(filter, update, options = {}) {
        const { guildId, channelId } = filter;
        const existing = await this.findOne(filter);
        
        if (existing) {
            const fields = [];
            const values = [];
            let paramCount = 1;

            Object.keys(update).forEach(key => {
                const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
                fields.push(`${dbKey} = $${paramCount}`);
                values.push(update[key]);
                paramCount++;
            });

            values.push(guildId, channelId);
            
            const result = await pool.query(`
                UPDATE counting SET ${fields.join(', ')} WHERE guild_id = $${paramCount} AND channel_id = $${paramCount + 1} RETURNING *
            `, values);
            
            return result.rows[0];
        } else if (options.upsert) {
            return await this.create({ guildId, channelId, ...update });
        }
        return null;
    }
}

module.exports = Counting;