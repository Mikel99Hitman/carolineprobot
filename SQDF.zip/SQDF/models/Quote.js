const pool = require('../database/connection');

class Quote {
    static async find(filter = {}) {
        let query = 'SELECT * FROM quotes';
        const values = [];
        
        if (filter.guildId) {
            query += ' WHERE guild_id = $1';
            values.push(filter.guildId);
        }
        
        const result = await pool.query(query, values);
        return result.rows;
    }

    static async findOne(filter) {
        const { guildId, quoteId } = filter;
        const result = await pool.query('SELECT * FROM quotes WHERE guild_id = $1 AND quote_id = $2', [guildId, quoteId]);
        return result.rows[0];
    }

    static async create(quoteData) {
        const { guildId, messageId, channelId, authorId, content, quotedBy, quoteId } = quoteData;
        const result = await pool.query(`
            INSERT INTO quotes (guild_id, message_id, channel_id, author_id, content, quoted_by, quote_id)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            RETURNING *
        `, [guildId, messageId, channelId, authorId, content, quotedBy, quoteId]);
        return result.rows[0];
    }

    static async deleteOne(filter) {
        const { guildId, quoteId } = filter;
        await pool.query('DELETE FROM quotes WHERE guild_id = $1 AND quote_id = $2', [guildId, quoteId]);
    }

    static async countDocuments(filter) {
        const { guildId } = filter;
        const result = await pool.query('SELECT COUNT(*) FROM quotes WHERE guild_id = $1', [guildId]);
        return parseInt(result.rows[0].count);
    }
}

module.exports = Quote;