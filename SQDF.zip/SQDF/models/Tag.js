const pool = require('../database/connection');

class Tag {
    static async find(filter = {}) {
        let query = 'SELECT * FROM tags';
        const values = [];
        
        if (filter.guildId) {
            query += ' WHERE guild_id = $1';
            values.push(filter.guildId);
        }
        
        const result = await pool.query(query, values);
        return result.rows;
    }

    static async findOne(filter) {
        const { guildId, name } = filter;
        const result = await pool.query('SELECT * FROM tags WHERE guild_id = $1 AND name = $2', [guildId, name]);
        return result.rows[0];
    }

    static async create(tagData) {
        const { guildId, name, content, authorId, uses = 0 } = tagData;
        const result = await pool.query(`
            INSERT INTO tags (guild_id, name, content, author_id, uses)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING *
        `, [guildId, name, content, authorId, uses]);
        return result.rows[0];
    }

    static async findOneAndUpdate(filter, update) {
        const { guildId, name } = filter;
        const fields = [];
        const values = [];
        let paramCount = 1;

        Object.keys(update).forEach(key => {
            const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
            fields.push(`${dbKey} = $${paramCount}`);
            values.push(update[key]);
            paramCount++;
        });

        values.push(guildId, name);
        
        const result = await pool.query(`
            UPDATE tags SET ${fields.join(', ')} WHERE guild_id = $${paramCount} AND name = $${paramCount + 1} RETURNING *
        `, values);
        
        return result.rows[0];
    }

    static async deleteOne(filter) {
        const { guildId, name } = filter;
        await pool.query('DELETE FROM tags WHERE guild_id = $1 AND name = $2', [guildId, name]);
    }
}

module.exports = Tag;