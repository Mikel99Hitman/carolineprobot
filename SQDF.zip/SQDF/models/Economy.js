const mongoose = require('mongoose');

const economySchema = new mongoose.Schema({
    userId: { type: String, required: true },
    guildId: { type: String, required: true },
    balance: { type: Number, default: 0 },
    bank: { type: Number, default: 0 },
    lastDaily: { type: Date, default: null },
    lastWeekly: { type: Date, default: null },
    lastWork: { type: Date, default: null },
    inventory: [{
        item: String,
        quantity: Number,
        purchaseDate: { type: Date, default: Date.now }
    }],
    transactions: [{
        type: { type: String, enum: ['earn', 'spend', 'transfer'] },
        amount: Number,
        description: String,
        date: { type: Date, default: Date.now }
    }]
});

economySchema.index({ userId: 1, guildId: 1 }, { unique: true });

module.exports = mongoose.model('Economy', economySchema);