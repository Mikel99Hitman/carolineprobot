const pool = require('../database/connection');

class Economy {
    static async findOne(filter) {
        const { userId, guildId } = filter;
        const result = await pool.query('SELECT * FROM economy WHERE user_id = $1 AND guild_id = $2', [userId, guildId]);
        return result.rows[0];
    }

    static async create(economyData) {
        const { userId, guildId, balance = 0, bank = 0, lastDaily, lastWeekly, lastWork } = economyData;
        
        const result = await pool.query(`
            INSERT INTO economy (user_id, guild_id, balance, bank, last_daily, last_weekly, last_work)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            RETURNING *
        `, [userId, guildId, balance, bank, lastDaily, lastWeekly, lastWork]);
        
        return result.rows[0];
    }

    static async findOneAndUpdate(filter, update, options = {}) {
        const { userId, guildId } = filter;
        const existing = await this.findOne(filter);
        
        if (existing) {
            const fields = [];
            const values = [];
            let paramCount = 1;

            Object.keys(update).forEach(key => {
                if (update[key] !== undefined) {
                    const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
                    fields.push(`${dbKey} = $${paramCount}`);
                    values.push(update[key]);
                    paramCount++;
                }
            });

            values.push(userId, guildId);
            
            const result = await pool.query(`
                UPDATE economy SET ${fields.join(', ')} WHERE user_id = $${paramCount} AND guild_id = $${paramCount + 1} RETURNING *
            `, values);
            
            return result.rows[0];
        } else if (options.upsert) {
            return await this.create({ userId, guildId, ...update });
        }
        return null;
    }

    static async addInventoryItem(userId, guildId, item, quantity = 1) {
        await pool.query(`
            INSERT INTO inventory (user_id, guild_id, item, quantity)
            VALUES ($1, $2, $3, $4)
        `, [userId, guildId, item, quantity]);
    }

    static async getInventory(userId, guildId) {
        const result = await pool.query('SELECT * FROM inventory WHERE user_id = $1 AND guild_id = $2', [userId, guildId]);
        return result.rows;
    }

    static async addTransaction(userId, guildId, type, amount, description) {
        await pool.query(`
            INSERT INTO transactions (user_id, guild_id, type, amount, description)
            VALUES ($1, $2, $3, $4, $5)
        `, [userId, guildId, type, amount, description]);
    }

    static async getTransactions(userId, guildId, limit = 10) {
        const result = await pool.query(`
            SELECT * FROM transactions 
            WHERE user_id = $1 AND guild_id = $2 
            ORDER BY created_at DESC 
            LIMIT $3
        `, [userId, guildId, limit]);
        return result.rows;
    }

    static async find(filter = {}) {
        let query = 'SELECT * FROM economy';
        const values = [];
        
        if (filter.guildId) {
            query += ' WHERE guild_id = $1';
            values.push(filter.guildId);
        }
        
        const result = await pool.query(query, values);
        return result.rows;
    }
}

module.exports = Economy;