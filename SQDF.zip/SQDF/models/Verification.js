const pool = require('../database/connection');

class Verification {
    static async findOne(filter) {
        const keys = Object.keys(filter);
        const values = Object.values(filter);
        const conditions = keys.map((key, index) => {
            const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
            return `${dbKey} = $${index + 1}`;
        });
        
        const result = await pool.query(`SELECT * FROM verification WHERE ${conditions.join(' AND ')}`, values);
        return result.rows[0];
    }

    static async create(verificationData) {
        const { guildId, channelId, roleId, messageId, type = 'button', enabled = true } = verificationData;
        
        const result = await pool.query(`
            INSERT INTO verification (guild_id, channel_id, role_id, message_id, type, enabled)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING *
        `, [guildId, channelId, roleId, messageId, type, enabled]);
        
        return result.rows[0];
    }

    static async findOneAndUpdate(filter, update) {
        const existing = await this.findOne(filter);
        
        if (existing) {
            const fields = [];
            const values = [];
            let paramCount = 1;

            Object.keys(update).forEach(key => {
                const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
                fields.push(`${dbKey} = $${paramCount}`);
                values.push(update[key]);
                paramCount++;
            });

            values.push(existing.id);
            
            const result = await pool.query(`
                UPDATE verification SET ${fields.join(', ')} WHERE id = $${paramCount} RETURNING *
            `, values);
            
            return result.rows[0];
        }
        return null;
    }
}

module.exports = Verification;