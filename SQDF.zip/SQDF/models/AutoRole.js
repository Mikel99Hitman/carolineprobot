const pool = require('../database/connection');

class AutoRole {
    static async find(filter = {}) {
        let query = 'SELECT * FROM auto_roles';
        const values = [];
        
        if (filter.guildId) {
            query += ' WHERE guild_id = $1';
            values.push(filter.guildId);
        }
        
        const result = await pool.query(query, values);
        return result.rows;
    }

    static async create(autoRoleData) {
        const { guildId, type, roleId, requirement = {}, enabled = true } = autoRoleData;
        const result = await pool.query(`
            INSERT INTO auto_roles (guild_id, type, role_id, level_requirement, time_requirement, boost_tier, enabled)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            RETURNING *
        `, [guildId, type, roleId, requirement.level || 0, requirement.timeInServer || 0, requirement.boostTier || 0, enabled]);
        return result.rows[0];
    }

    static async deleteOne(filter) {
        const { guildId, roleId } = filter;
        await pool.query('DELETE FROM auto_roles WHERE guild_id = $1 AND role_id = $2', [guildId, roleId]);
    }
}

module.exports = AutoRole;