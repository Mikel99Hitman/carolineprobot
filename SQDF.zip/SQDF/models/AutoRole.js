const mongoose = require('mongoose');

const autoRoleSchema = new mongoose.Schema({
    guildId: { type: String, required: true },
    type: { type: String, enum: ['join', 'level', 'boost', 'time'], required: true },
    roleId: { type: String, required: true },
    requirement: {
        level: { type: Number, default: 0 },
        timeInServer: { type: Number, default: 0 }, // in hours
        boostTier: { type: Number, default: 0 }
    },
    enabled: { type: Boolean, default: true }
});

module.exports = mongoose.model('AutoRole', autoRoleSchema);