const pool = require('../database/connection');

class Suggestion {
    static async create(suggestionData) {
        const { guildId, channelId, messageId, userId, suggestion, status = 'pending' } = suggestionData;
        const result = await pool.query(`
            INSERT INTO suggestions (guild_id, channel_id, message_id, user_id, suggestion, status)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING *
        `, [guildId, channelId, messageId, userId, suggestion, status]);
        return result.rows[0];
    }

    static async findOne(filter) {
        const { messageId } = filter;
        const result = await pool.query('SELECT * FROM suggestions WHERE message_id = $1', [messageId]);
        return result.rows[0];
    }

    static async find(filter = {}) {
        let query = 'SELECT * FROM suggestions';
        const values = [];
        
        if (filter.guildId) {
            query += ' WHERE guild_id = $1';
            values.push(filter.guildId);
        }
        
        const result = await pool.query(query, values);
        return result.rows;
    }

    static async findOneAndUpdate(filter, update) {
        const { messageId } = filter;
        const fields = [];
        const values = [];
        let paramCount = 1;

        Object.keys(update).forEach(key => {
            const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
            fields.push(`${dbKey} = $${paramCount}`);
            values.push(update[key]);
            paramCount++;
        });

        values.push(messageId);
        
        const result = await pool.query(`
            UPDATE suggestions SET ${fields.join(', ')} WHERE message_id = $${paramCount} RETURNING *
        `, values);
        
        return result.rows[0];
    }

    static async addVote(messageId, userId, voteType) {
        await pool.query(`
            INSERT INTO suggestion_votes (message_id, user_id, vote_type)
            VALUES ($1, $2, $3)
            ON CONFLICT (message_id, user_id) DO UPDATE SET vote_type = $3
        `, [messageId, userId, voteType]);
    }

    static async getVotes(messageId) {
        const result = await pool.query(`
            SELECT vote_type, COUNT(*) as count
            FROM suggestion_votes
            WHERE message_id = $1
            GROUP BY vote_type
        `, [messageId]);
        return result.rows;
    }
}

module.exports = Suggestion;