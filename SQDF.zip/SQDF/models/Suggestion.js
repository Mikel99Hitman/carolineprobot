const mongoose = require('mongoose');

const suggestionSchema = new mongoose.Schema({
    guildId: { type: String, required: true },
    channelId: { type: String, required: true },
    messageId: { type: String, required: true },
    userId: { type: String, required: true },
    suggestion: { type: String, required: true },
    status: { type: String, enum: ['pending', 'approved', 'rejected', 'implemented'], default: 'pending' },
    upvotes: [String],
    downvotes: [String],
    staffResponse: { type: String, default: null },
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Suggestion', suggestionSchema);