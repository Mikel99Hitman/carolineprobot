# ProBot Troubleshooting Guide

## Common Issues & Solutions

### 1. Bot Won't Start
**Error**: `Cannot find module 'discord.js'`
**Solution**: Run `npm install`

**Error**: `Invalid token`
**Solution**: Check BOT_TOKEN in .env file

### 2. Database Issues
**Error**: `Connection refused`
**Solution**: 
- Start PostgreSQL service
- Check DATABASE_URL in .env
- Run `setup-db.bat`

### 3. Commands Not Working
**Error**: Commands not responding
**Solution**: Run `node deploy-commands.js`

### 4. Permission Errors
**Error**: Missing permissions
**Solution**: Check bot permissions in Discord server

## Quick Fixes

### Reset Everything
```bash
fix.bat
```

### Fresh Install
```bash
rmdir /s node_modules
del package-lock.json
npm install
```

### Database Reset
```bash
setup-db.bat
```

## File Structure Check
- ✅ .env (configured)
- ✅ node_modules/ (installed)
- ✅ commands/ (all folders)
- ✅ events/ (all files)
- ✅ models/ (PostgreSQL models)
- ✅ database/ (connection files)

## Support
If issues persist:
1. Check Code Issues Panel in IDE
2. Review console logs
3. Verify all environment variables
4. Ensure PostgreSQL is running

---
**ProBot by Mikel** - Version 3.0.0