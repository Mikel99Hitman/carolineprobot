const mongoose = require('mongoose');
const pool = require('./database/connection');

// MongoDB Models (old)
const MongoGuild = require('./models-backup/Guild');
const MongoUser = require('./models-backup/User');
const MongoEconomy = require('./models-backup/Economy');

// PostgreSQL Models (new)
const Guild = require('./models/Guild');
const User = require('./models/User');
const Economy = require('./models/Economy');

async function migrateData() {
    try {
        console.log('🔄 Starting migration from MongoDB to PostgreSQL...');
        
        // Connect to MongoDB
        await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/probot');
        console.log('✅ Connected to MongoDB');
        
        // Migrate Guilds
        console.log('📊 Migrating guilds...');
        const mongoGuilds = await MongoGuild.find({});
        for (const guild of mongoGuilds) {
            await Guild.create({
                guildId: guild.guildId,
                prefix: guild.prefix,
                welcomeChannel: guild.welcomeChannel,
                welcomeMessage: guild.welcomeMessage,
                logChannel: guild.logChannel,
                webhookUrl: guild.webhookUrl,
                levelUpChannel: guild.levelUpChannel,
                autoRole: guild.autoRole,
                antiSpam: guild.antiSpam,
                antiRaid: guild.antiRaid,
                antiLink: guild.antiLink,
                musicChannel: guild.musicChannel,
                ticketCategory: guild.ticketCategory,
                applicationChannel: guild.applicationChannel
            });
        }
        console.log(`✅ Migrated ${mongoGuilds.length} guilds`);
        
        // Migrate Users
        console.log('👥 Migrating users...');
        const mongoUsers = await MongoUser.find({});
        for (const user of mongoUsers) {
            await User.create({
                userId: user.userId,
                guildId: user.guildId,
                xp: user.xp,
                level: user.level,
                messages: user.messages,
                voice: user.voice,
                warnings: user.warnings,
                invites: user.invites
            });
        }
        console.log(`✅ Migrated ${mongoUsers.length} users`);
        
        // Migrate Economy
        console.log('💰 Migrating economy data...');
        const mongoEconomy = await MongoEconomy.find({});
        for (const economy of mongoEconomy) {
            await Economy.create({
                userId: economy.userId,
                guildId: economy.guildId,
                balance: economy.balance,
                bank: economy.bank,
                lastDaily: economy.lastDaily,
                lastWeekly: economy.lastWeekly,
                lastWork: economy.lastWork
            });
            
            // Migrate inventory
            if (economy.inventory && economy.inventory.length > 0) {
                for (const item of economy.inventory) {
                    await Economy.addInventoryItem(economy.userId, economy.guildId, item.item, item.quantity);
                }
            }
            
            // Migrate transactions
            if (economy.transactions && economy.transactions.length > 0) {
                for (const transaction of economy.transactions) {
                    await Economy.addTransaction(
                        economy.userId, 
                        economy.guildId, 
                        transaction.type, 
                        transaction.amount, 
                        transaction.description
                    );
                }
            }
        }
        console.log(`✅ Migrated ${mongoEconomy.length} economy records`);
        
        console.log('🎉 Migration completed successfully!');
        console.log('📝 Please update your .env file to use DATABASE_URL instead of MONGODB_URI');
        console.log('🔧 Install PostgreSQL dependencies: npm install pg pg-pool');
        console.log('🗑️  You can now remove mongoose from package.json');
        
    } catch (error) {
        console.error('❌ Migration failed:', error);
    } finally {
        await mongoose.disconnect();
        await pool.end();
    }
}

// Run migration if called directly
if (require.main === module) {
    migrateData();
}

module.exports = migrateData;