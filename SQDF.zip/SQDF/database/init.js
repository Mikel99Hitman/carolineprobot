const pool = require('./connection');

const initDatabase = async () => {
    try {
        await pool.query(`
            CREATE TABLE IF NOT EXISTS guilds (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) UNIQUE NOT NULL,
                prefix VARCHAR(10) DEFAULT '!',
                welcome_channel VARCHAR(20),
                welcome_message TEXT DEFAULT 'Welcome {user} to {server}!',
                log_channel VARCHAR(20),
                webhook_url TEXT,
                level_up_channel VARCHAR(20),
                auto_role VARCHAR(20),
                anti_spam BOOLEAN DEFAULT false,
                anti_raid BOOLEAN DEFAULT false,
                anti_link BOOLEAN DEFAULT false,
                music_channel VARCHAR(20),
                ticket_category VARCHAR(20),
                application_channel VARCHAR(20),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                xp INTEGER DEFAULT 0,
                level INTEGER DEFAULT 1,
                messages INTEGER DEFAULT 0,
                voice INTEGER DEFAULT 0,
                warnings INTEGER DEFAULT 0,
                invites INTEGER DEFAULT 0,
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, guild_id)
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS economy (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                balance BIGINT DEFAULT 0,
                bank BIGINT DEFAULT 0,
                last_daily TIMESTAMP,
                last_weekly TIMESTAMP,
                last_work TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, guild_id)
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS inventory (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                item VARCHAR(100) NOT NULL,
                quantity INTEGER DEFAULT 1,
                purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS transactions (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                type VARCHAR(20) CHECK (type IN ('earn', 'spend', 'transfer')),
                amount BIGINT NOT NULL,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS tickets (
                id SERIAL PRIMARY KEY,
                ticket_id VARCHAR(50) UNIQUE NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                user_id VARCHAR(20) NOT NULL,
                channel_id VARCHAR(20) NOT NULL,
                status VARCHAR(10) DEFAULT 'open' CHECK (status IN ('open', 'closed')),
                reason TEXT DEFAULT 'عام',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                closed_at TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS giveaways (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                channel_id VARCHAR(20) NOT NULL,
                message_id VARCHAR(20) NOT NULL,
                host_id VARCHAR(20) NOT NULL,
                prize TEXT NOT NULL,
                winners INTEGER NOT NULL,
                end_time TIMESTAMP NOT NULL,
                participants TEXT[],
                ended BOOLEAN DEFAULT false,
                required_role VARCHAR(20),
                required_level INTEGER DEFAULT 0,
                required_invites INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS reaction_roles (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                message_id VARCHAR(20) NOT NULL,
                channel_id VARCHAR(20) NOT NULL,
                title VARCHAR(100) DEFAULT 'Reaction Roles',
                description TEXT DEFAULT 'React to get roles!',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS reaction_role_mappings (
                id SERIAL PRIMARY KEY,
                reaction_role_id INTEGER REFERENCES reaction_roles(id) ON DELETE CASCADE,
                emoji VARCHAR(100) NOT NULL,
                role_id VARCHAR(20) NOT NULL
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS verification (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                channel_id VARCHAR(20) NOT NULL,
                role_id VARCHAR(20) NOT NULL,
                message_id VARCHAR(20),
                type VARCHAR(10) DEFAULT 'button' CHECK (type IN ('button', 'captcha', 'reaction')),
                enabled BOOLEAN DEFAULT true,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS afk (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                reason TEXT DEFAULT 'AFK',
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, guild_id)
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS auto_roles (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                type VARCHAR(10) CHECK (type IN ('join', 'level', 'boost', 'time')),
                role_id VARCHAR(20) NOT NULL,
                level_requirement INTEGER DEFAULT 0,
                time_requirement INTEGER DEFAULT 0,
                boost_tier INTEGER DEFAULT 0,
                enabled BOOLEAN DEFAULT true,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS birthdays (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                birthday DATE NOT NULL,
                timezone VARCHAR(50) DEFAULT 'UTC',
                private BOOLEAN DEFAULT false,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, guild_id)
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS counting (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                channel_id VARCHAR(20) NOT NULL,
                current_number INTEGER DEFAULT 0,
                last_user_id VARCHAR(20),
                highest_number INTEGER DEFAULT 0,
                fails INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(guild_id, channel_id)
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS custom_commands (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                name VARCHAR(100) NOT NULL,
                response TEXT NOT NULL,
                author_id VARCHAR(20) NOT NULL,
                uses INTEGER DEFAULT 0,
                embed BOOLEAN DEFAULT false,
                delete_after INTEGER DEFAULT 0,
                required_role VARCHAR(20),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(guild_id, name)
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS modmail (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                channel_id VARCHAR(20) NOT NULL,
                status VARCHAR(10) DEFAULT 'open' CHECK (status IN ('open', 'closed')),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS polls (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                channel_id VARCHAR(20) NOT NULL,
                message_id VARCHAR(20) NOT NULL,
                creator_id VARCHAR(20) NOT NULL,
                question TEXT NOT NULL,
                options JSONB NOT NULL,
                end_time TIMESTAMP NOT NULL,
                ended BOOLEAN DEFAULT false,
                allow_multiple BOOLEAN DEFAULT false,
                anonymous BOOLEAN DEFAULT false,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS quotes (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                message_id VARCHAR(20) NOT NULL,
                channel_id VARCHAR(20) NOT NULL,
                author_id VARCHAR(20) NOT NULL,
                content TEXT NOT NULL,
                quoted_by VARCHAR(20) NOT NULL,
                quote_id INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS reminders (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                channel_id VARCHAR(20) NOT NULL,
                message TEXT NOT NULL,
                remind_time TIMESTAMP NOT NULL,
                recurring_enabled BOOLEAN DEFAULT false,
                recurring_interval VARCHAR(20),
                completed BOOLEAN DEFAULT false,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS starboard (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                channel_id VARCHAR(20) NOT NULL,
                threshold INTEGER DEFAULT 3,
                emoji VARCHAR(10) DEFAULT '⭐',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS starred_messages (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                message_id VARCHAR(20) NOT NULL,
                starboard_message_id VARCHAR(20) NOT NULL,
                stars INTEGER NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS suggestions (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                channel_id VARCHAR(20) NOT NULL,
                message_id VARCHAR(20) NOT NULL,
                user_id VARCHAR(20) NOT NULL,
                suggestion TEXT NOT NULL,
                status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected', 'implemented')),
                staff_response TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS suggestion_votes (
                id SERIAL PRIMARY KEY,
                message_id VARCHAR(20) NOT NULL,
                user_id VARCHAR(20) NOT NULL,
                vote_type VARCHAR(10) CHECK (vote_type IN ('upvote', 'downvote')),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(message_id, user_id)
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS tags (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                name VARCHAR(100) NOT NULL,
                content TEXT NOT NULL,
                author_id VARCHAR(20) NOT NULL,
                uses INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(guild_id, name)
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS temp_voice (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                creator_channel_id VARCHAR(20) NOT NULL,
                category_id VARCHAR(20) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS temp_channels (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                channel_id VARCHAR(20) NOT NULL,
                owner_id VARCHAR(20) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS word_filter (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                words JSONB DEFAULT '[]',
                action VARCHAR(10) DEFAULT 'delete' CHECK (action IN ('delete', 'warn', 'mute')),
                whitelist JSONB DEFAULT '[]',
                enabled BOOLEAN DEFAULT true,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        console.log('✅ PostgreSQL tables created successfully');
    } catch (error) {
        console.error('❌ Error creating PostgreSQL tables:', error);
    }
};

module.exports = initDatabase;