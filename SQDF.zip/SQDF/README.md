# ProBot by Mikel - Professional Discord Bot

A professional Discord bot with advanced features for server management.

## 🌟 Features

### 🎯 Core Systems
- **Leveling & XP System** - Track member activity and award levels
- **Welcome System** - Automatic welcome with custom images
- **Comprehensive Logging** - Log all server events with webhook support
- **Protection System** - Anti-spam, anti-link, anti-caps, anti-mention
- **Music System** - Play music from YouTube
- **Ticket System** - Create support tickets for members
- **Application System** - Staff application forms
- **Invite Tracking** - Track member invites
- **Economy System** - Virtual currency with work, daily rewards, gambling
- **Reaction Roles** - Assign roles via reactions
- **Giveaway System** - Host giveaways with requirements
- **Auto Moderation** - Advanced auto-moderation features

### 🎵 Music Commands
- `/play` - Play music from YouTube
- `/stop` - Stop music playback
- `/skip` - Skip current song
- `/queue` - View music queue

### 👑 Admin Commands
- `/setup` - Configure bot settings
- `/warn` - Warn members
- `/kick` - Kick members
- `/ban` - Ban members
- `/clear` - Delete messages
- `/automod` - Configure auto moderation
- `/webhook` - Setup webhook for logging

### 📊 Leveling Commands
- `/rank` - View member rank
- `/leaderboard` - View leaderboards
- `/setxp` - Modify member XP

### 🎫 Ticket Commands
- `/ticket` - Create support ticket
- `/close` - Close ticket
- `/add` - Add member to ticket

### 💰 Economy Commands
- `/balance` - Check balance
- `/daily` - Claim daily reward
- `/work` - Work to earn money
- `/gamble` - Gamble money

### 🎭 Role Commands
- `/reactionroles` - Setup reaction roles
- `/addrole` - Add role to reaction roles

### 🎉 Giveaway Commands
- `/giveaway` - Start a giveaway

### 📝 General Commands
- `/help` - Command list
- `/userinfo` - User information
- `/serverinfo` - Server information
- `/avatar` - User avatar
- `/application` - Staff application form

## 🚀 Installation & Setup

### Requirements
- Node.js v16.9.0 or higher
- MongoDB
- Discord Developer Account

### Installation Steps

1. **Clone the project**
```bash
git clone <repository-url>
cd SQDF
```

2. **Install dependencies**
```bash
npm install
```

3. **Setup environment variables**
Edit the `.env` file:
```env
BOT_TOKEN=your_bot_token_here
MONGODB_URI=mongodb://localhost:27017/probot
CLIENT_ID=your_client_id_here
GUILD_ID=your_guild_id_here
```

4. **Run MongoDB**
Make sure MongoDB is running on your system

5. **Deploy commands**
```bash
node deploy-commands.js
```

6. **Start the bot**
```bash
npm start
```

## ⚙️ Initial Setup

After inviting the bot to your server, use these commands for setup:

### Setup Welcome System
```
/setup welcome channel:#welcome-channel message:Welcome {user} to {server}!
```

### Setup Logging System
```
/setup logs channel:#logs-channel
/webhook url:your_webhook_url_here
```

### Setup Leveling System
```
/setup levels channel:#level-up-channel
```

### Setup Protection System
```
/setup protection antispam:true antilink:true
/automod setup anti_spam:true anti_link:true anti_caps:true anti_mention:true
```

### Setup Reaction Roles
```
/reactionroles channel:#roles title:"Choose Your Roles" description:"React to get roles!"
/addrole message_id:123456789 emoji:🎮 role:@Gamer
```

### Start a Giveaway
```
/giveaway duration:1h prize:"Discord Nitro" winners:1 channel:#giveaways
```

## 🗂️ هيكل المشروع

```
SQDF/
├── commands/           # مجلد الأوامر
│   ├── admin/         # أوامر الإدارة
│   ├── general/       # أوامر عامة
│   ├── levels/        # أوامر المستويات
│   ├── music/         # أوامر الموسيقى
│   └── tickets/       # أوامر التذاكر
├── events/            # معالجات الأحداث
├── models/            # نماذج قاعدة البيانات
├── index.js           # الملف الرئيسي
├── deploy-commands.js # تسجيل الأوامر
└── package.json       # معلومات المشروع
```

## 🔧 التخصيص

يمكنك تخصيص البوت عبر:
- تعديل الرسائل في ملفات الأوامر
- إضافة أوامر جديدة في مجلد `commands`
- تعديل نماذج قاعدة البيانات في مجلد `models`
- إضافة أحداث جديدة في مجلد `events`

## 📝 الترخيص

هذا المشروع مرخص تحت رخصة MIT.

## 🤝 المساهمة

نرحب بالمساهمات! يرجى إنشاء Pull Request أو فتح Issue للاقتراحات.

## 📞 الدعم

للحصول على الدعم، يمكنك:
- فتح Issue في GitHub
- التواصل مع المطور: Mikel

---

**تم تطوير البوت بواسطة Mikel**