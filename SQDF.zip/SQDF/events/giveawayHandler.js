const { Events, EmbedBuilder } = require('discord.js');
const Giveaway = require('../models/Giveaway');
const User = require('../models/User');

module.exports = {
    name: 'giveawayInteraction',
    async handleGiveawayButton(interaction) {
        if (interaction.customId !== 'enter_giveaway') return;

        const giveaway = await Giveaway.findOne({
            messageId: interaction.message.id,
            ended: false
        });

        if (!giveaway) {
            return interaction.reply({ content: '❌ This giveaway has ended or doesn\'t exist!', ephemeral: true });
        }

        if (giveaway.participants.includes(interaction.user.id)) {
            return interaction.reply({ content: '❌ You are already entered in this giveaway!', ephemeral: true });
        }

        // Check requirements
        const member = interaction.member;
        
        if (giveaway.requirements.role) {
            if (!member.roles.cache.has(giveaway.requirements.role)) {
                const role = interaction.guild.roles.cache.get(giveaway.requirements.role);
                return interaction.reply({ 
                    content: `❌ You need the ${role} role to enter this giveaway!`, 
                    ephemeral: true 
                });
            }
        }

        if (giveaway.requirements.level > 0) {
            const userData = await User.findOne({
                userId: interaction.user.id,
                guildId: interaction.guild.id
            });

            if (!userData || userData.level < giveaway.requirements.level) {
                return interaction.reply({ 
                    content: `❌ You need to be level ${giveaway.requirements.level} or higher to enter this giveaway!`, 
                    ephemeral: true 
                });
            }
        }

        // Add user to participants
        giveaway.participants.push(interaction.user.id);
        await giveaway.save();

        const successEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('🎉 Entry Confirmed!')
            .setDescription(`You have successfully entered the giveaway for **${giveaway.prize}**!`)
            .addFields(
                { name: 'Total Entries', value: giveaway.participants.length.toString(), inline: true },
                { name: 'Ends', value: `<t:${Math.floor(giveaway.endTime.getTime() / 1000)}:R>`, inline: true }
            );

        await interaction.reply({ embeds: [successEmbed], ephemeral: true });
    }
};