const { Events, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const Canvas = require('canvas');
const Guild = require('../models/Guild');
const User = require('../models/User');
const Logger = require('../utils/Logger');

module.exports = {
    name: Events.GuildMemberAdd,
    async execute(member) {
        // Log member join
        await Logger.log(member.guild, 'MEMBER_JOIN', {
            user: member.user,
            memberCount: member.guild.memberCount
        });

        const guildData = await Guild.findOne({ guildId: member.guild.id });
        if (!guildData || !guildData.welcomeChannel) return;

        const channel = member.guild.channels.cache.get(guildData.welcomeChannel);
        if (!channel) return;

        // Create welcome image
        const canvas = Canvas.createCanvas(800, 400);
        const ctx = canvas.getContext('2d');

        // Gradient background
        const gradient = ctx.createLinearGradient(0, 0, 800, 400);
        gradient.addColorStop(0, '#667eea');
        gradient.addColorStop(1, '#764ba2');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, 800, 400);

        // Welcome text
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 40px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('Welcome!', 400, 100);

        ctx.font = '30px Arial';
        ctx.fillText(member.user.username, 400, 150);

        ctx.font = '20px Arial';
        ctx.fillText(`Member #${member.guild.memberCount}`, 400, 200);

        // User avatar
        try {
            const avatar = await Canvas.loadImage(member.user.displayAvatarURL({ extension: 'png', size: 128 }));
            ctx.beginPath();
            ctx.arc(400, 280, 50, 0, Math.PI * 2, true);
            ctx.closePath();
            ctx.clip();
            ctx.drawImage(avatar, 350, 230, 100, 100);
        } catch (error) {
            console.error('Error loading avatar:', error);
        }

        const attachment = new AttachmentBuilder(canvas.toBuffer(), { name: 'welcome.png' });

        const welcomeEmbed = new EmbedBuilder()
            .setColor('#667eea')
            .setTitle('🎉 New Member!')
            .setDescription(guildData.welcomeMessage
                .replace('{user}', `<@${member.id}>`)
                .replace('{server}', member.guild.name)
                .replace('{memberCount}', member.guild.memberCount))
            .setImage('attachment://welcome.png')
            .setTimestamp();

        await channel.send({ embeds: [welcomeEmbed], files: [attachment] });

        // Add auto role
        if (guildData.autoRole) {
            const role = member.guild.roles.cache.get(guildData.autoRole);
            if (role) {
                await member.roles.add(role);
            }
        }

        // Create user data
        const userData = new User({
            userId: member.id,
            guildId: member.guild.id
        });
        await userData.save();
    }
};