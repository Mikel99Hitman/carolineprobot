const { Events } = require('discord.js');
const ReactionRole = require('../models/ReactionRole');

module.exports = {
    name: Events.MessageReactionRemove,
    async execute(reaction, user) {
        if (user.bot) return;

        // Handle partial reactions
        if (reaction.partial) {
            try {
                await reaction.fetch();
            } catch (error) {
                console.error('Error fetching reaction:', error);
                return;
            }
        }

        const reactionRole = await ReactionRole.findOne({
            guildId: reaction.message.guild.id,
            messageId: reaction.message.id
        });

        if (!reactionRole) return;

        const roleData = reactionRole.roles.find(r => r.emoji === reaction.emoji.toString());
        if (!roleData) return;

        const member = reaction.message.guild.members.cache.get(user.id);
        const role = reaction.message.guild.roles.cache.get(roleData.roleId);

        if (!member || !role) return;

        try {
            await member.roles.remove(role);
            console.log(`Removed role ${role.name} from ${member.user.tag}`);
        } catch (error) {
            console.error('Error removing role:', error);
        }
    }
};