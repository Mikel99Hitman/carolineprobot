const { Events } = require('discord.js');
const Logger = require('../utils/Logger');

module.exports = {
    name: Events.GuildMemberRemove,
    async execute(member) {
        await Logger.log(member.guild, 'MEMBER_LEAVE', {
            user: member.user,
            joinedAt: member.joinedTimestamp,
            memberCount: member.guild.memberCount
        });
    }
};