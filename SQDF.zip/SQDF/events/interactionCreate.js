const { Events, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const Ticket = require('../models/Ticket');
const Verification = require('../models/Verification');
const applicationHandler = require('../commands/general/application');
const giveawayHandler = require('./giveawayHandler');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        if (interaction.isChatInputCommand()) {
            const command = interaction.client.commands.get(interaction.commandName);
            if (!command) return;

            try {
                await command.execute(interaction);
            } catch (error) {
                console.error(error);
                const errorEmbed = new EmbedBuilder()
                    .setColor('#ff0000')
                    .setTitle('❌ Error')
                    .setDescription('An error occurred while executing the command!');

                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp({ embeds: [errorEmbed], ephemeral: true });
                } else {
                    await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                }
            }
        }

        if (interaction.isButton()) {
            if (interaction.customId === 'close_ticket') {
                await handleTicketClose(interaction);
            } else if (interaction.customId === 'open_application') {
                await applicationHandler.handleApplicationButton(interaction);
            } else if (interaction.customId.startsWith('accept_app_') || interaction.customId.startsWith('reject_app_')) {
                await handleApplicationResponse(interaction);
            } else if (interaction.customId === 'enter_giveaway') {
                await giveawayHandler.handleGiveawayButton(interaction);
            } else if (interaction.customId === 'verify_user') {
                await handleVerification(interaction);
            } else if (interaction.customId.startsWith('buy_')) {
                await handleShopPurchase(interaction);
            }
        }

        if (interaction.isModalSubmit()) {
            if (interaction.customId === 'application_modal') {
                await applicationHandler.handleApplicationModal(interaction);
            }
        }
    }
};

async function handleTicketClose(interaction) {
    const ticket = await Ticket.findOne({
        channelId: interaction.channel.id,
        status: 'open'
    });

    if (!ticket) {
        return interaction.reply({ content: '❌ هذه ليست تذكرة صالحة!', ephemeral: true });
    }

    // التحقق من الصلاحيات
    const member = interaction.member;
    const isTicketOwner = ticket.user_id === interaction.user.id;
    const hasPermission = member.permissions.has(PermissionFlagsBits.ManageChannels);

    if (!isTicketOwner && !hasPermission) {
        return interaction.reply({ content: '❌ ليس لديك صلاحية لإغلاق هذه التذكرة!', ephemeral: true });
    }

    try {
        // تحديث حالة التذكرة
        await Ticket.findOneAndUpdate(
            { channelId: interaction.channel.id },
            { status: 'closed', closedAt: new Date() }
        );

        const closeEmbed = new EmbedBuilder()
            .setColor('#ff0000')
            .setTitle('🔒 تم إغلاق التذكرة')
            .setDescription(`تم إغلاق التذكرة بواسطة ${interaction.user}`)
            .setTimestamp();

        await interaction.reply({ embeds: [closeEmbed] });

        // حذف القناة بعد 5 ثوان
        setTimeout(async () => {
            try {
                await interaction.channel.delete();
            } catch (error) {
                console.error('Error deleting ticket channel:', error);
            }
        }, 5000);

    } catch (error) {
        console.error('Error closing ticket:', error);
        await interaction.reply({ content: '❌ حدث خطأ أثناء إغلاق التذكرة!', ephemeral: true });
    }
}

async function handleApplicationResponse(interaction) {
    const userId = interaction.customId.split('_')[2];
    const action = interaction.customId.startsWith('accept_app_') ? 'accept' : 'reject';
    
    const user = await interaction.client.users.fetch(userId);
    if (!user) {
        return interaction.reply({ content: '❌ User not found!', ephemeral: true });
    }

    const embed = new EmbedBuilder()
        .setTimestamp();

    if (action === 'accept') {
        embed.setColor('#00ff00')
            .setTitle('✅ Application Accepted!')
            .setDescription(`Congratulations! Your staff application for **${interaction.guild.name}** has been accepted!`)
            .addFields({ name: 'Next Steps', value: 'You will be contacted soon to complete the process.' });
    } else {
        embed.setColor('#ff0000')
            .setTitle('❌ Application Rejected')
            .setDescription(`We regret to inform you that your staff application for **${interaction.guild.name}** has been rejected.`)
            .addFields({ name: 'Note', value: 'You can reapply after improving your qualifications.' });
    }

    try {
        await user.send({ embeds: [embed] });
        
        const responseEmbed = new EmbedBuilder()
            .setColor(action === 'accept' ? '#00ff00' : '#ff0000')
            .setDescription(`${action === 'accept' ? '✅ Accepted' : '❌ Rejected'} ${user}'s application and sent notification.`);

        await interaction.reply({ embeds: [responseEmbed], ephemeral: true });
        
        // Disable buttons
        const disabledRow = interaction.message.components[0];
        disabledRow.components.forEach(button => button.setDisabled(true));
        
        await interaction.message.edit({ components: [disabledRow] });
        
    } catch (error) {
        console.error('Error sending DM:', error);
        await interaction.reply({ 
            content: `${action === 'accept' ? '✅ Accepted' : '❌ Rejected'} the application but couldn't send notification to user.`, 
            ephemeral: true 
        });
    }
}
async function handleVerification(interaction) {
    const verification = await Verification.findOne({
        guildId: interaction.guild.id,
        messageId: interaction.message.id
    });

    if (!verification) {
        return interaction.reply({ content: '❌ Verification system not found!', ephemeral: true });
    }

    const role = interaction.guild.roles.cache.get(verification.role_id);
    if (!role) {
        return interaction.reply({ content: '❌ Verification role not found!', ephemeral: true });
    }

    const member = interaction.member;
    if (member.roles.cache.has(role.id)) {
        return interaction.reply({ content: '✅ You are already verified!', ephemeral: true });
    }

    await member.roles.add(role);

    const embed = new EmbedBuilder()
        .setColor('#00ff00')
        .setTitle('✅ Verification Successful')
        .setDescription(`Welcome to ${interaction.guild.name}! You now have access to all channels.`)
        .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
}

async function handleShopPurchase(interaction) {
    const itemId = interaction.customId.split('_')[1];
    const Economy = require('../models/Economy');
    
    const shopItems = {
        'vip': { name: 'VIP Role', price: 5000, roleId: null },
        'color': { name: 'Custom Color', price: 2000, roleId: null },
        'nickname': { name: 'Nickname Change', price: 1000, roleId: null }
    };

    const item = shopItems[itemId];
    if (!item) {
        return interaction.reply({ content: '❌ Item not found!', ephemeral: true });
    }

    let economyData = await Economy.findOne({
        userId: interaction.user.id,
        guildId: interaction.guild.id
    });

    if (!economyData || economyData.balance < item.price) {
        return interaction.reply({ content: '❌ Insufficient funds!', ephemeral: true });
    }

    await Economy.findOneAndUpdate(
        { userId: interaction.user.id, guildId: interaction.guild.id },
        { balance: economyData.balance - item.price }
    );

    await Economy.addTransaction(
        interaction.user.id,
        interaction.guild.id,
        'spend',
        item.price,
        `Purchased ${item.name}`
    );

    const embed = new EmbedBuilder()
        .setColor('#00ff00')
        .setTitle('🛒 Purchase Successful')
        .setDescription(`You purchased **${item.name}** for $${item.price.toLocaleString()}!`)
        .addFields({ name: 'New Balance', value: `$${(economyData.balance - item.price).toLocaleString()}`, inline: true })
        .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
}