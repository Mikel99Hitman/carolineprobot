const { Events } = require('discord.js');
const Logger = require('../utils/Logger');

module.exports = {
    name: Events.MessageUpdate,
    async execute(oldMessage, newMessage) {
        if (newMessage.author?.bot || !newMessage.guild) return;
        if (oldMessage.content === newMessage.content) return;

        await Logger.log(newMessage.guild, 'MESSAGE_EDIT', {
            author: newMessage.author,
            channel: newMessage.channel,
            oldContent: oldMessage.content?.substring(0, 1000) || 'No content',
            newContent: newMessage.content?.substring(0, 1000) || 'No content'
        });
    }
};