const { Events, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const Logger = require('../utils/Logger');

const joinTimes = new Map();
const RAID_THRESHOLD = 5; // 5 users
const RAID_TIME_WINDOW = 10000; // 10 seconds

module.exports = {
    name: Events.GuildMemberAdd,
    async execute(member) {
        const now = Date.now();
        const guildId = member.guild.id;
        
        if (!joinTimes.has(guildId)) {
            joinTimes.set(guildId, []);
        }
        
        const joins = joinTimes.get(guildId);
        joins.push({ userId: member.id, timestamp: now });
        
        // Clean old joins
        const recentJoins = joins.filter(join => now - join.timestamp < RAID_TIME_WINDOW);
        joinTimes.set(guildId, recentJoins);
        
        if (recentJoins.length >= RAID_THRESHOLD) {
            // Potential raid detected
            await handleRaid(member.guild, recentJoins);
        }
    }
};

async function handleRaid(guild, recentJoins) {
    try {
        // Kick recent joiners
        for (const join of recentJoins) {
            const member = guild.members.cache.get(join.userId);
            if (member && member.kickable) {
                await member.kick('Anti-raid protection');
            }
        }
        
        // Lock server temporarily
        const channels = guild.channels.cache.filter(ch => ch.type === 0);
        for (const [id, channel] of channels) {
            try {
                await channel.permissionOverwrites.edit(guild.roles.everyone, {
                    SendMessages: false
                });
            } catch (error) {
                console.error(`Failed to lock ${channel.name}`);
            }
        }
        
        await Logger.log(guild, 'RAID_DETECTED', {
            joinCount: recentJoins.length,
            action: 'Server locked and raiders kicked'
        });
        
        // Auto-unlock after 5 minutes
        setTimeout(async () => {
            for (const [id, channel] of channels) {
                try {
                    await channel.permissionOverwrites.edit(guild.roles.everyone, {
                        SendMessages: null
                    });
                } catch (error) {
                    console.error(`Failed to unlock ${channel.name}`);
                }
            }
        }, 300000);
        
    } catch (error) {
        console.error('Error handling raid:', error);
    }
}