const { Events } = require('discord.js');
const Logger = require('../utils/Logger');

module.exports = {
    name: Events.VoiceStateUpdate,
    async execute(oldState, newState) {
        if (!oldState.channel && newState.channel) {
            // User joined voice channel
            await Logger.log(newState.guild, 'VOICE_JOIN', {
                member: newState.member,
                channel: newState.channel
            });
        } else if (oldState.channel && !newState.channel) {
            // User left voice channel
            await Logger.log(oldState.guild, 'VOICE_LEAVE', {
                member: oldState.member,
                channelName: oldState.channel.name
            });
        }
    }
};