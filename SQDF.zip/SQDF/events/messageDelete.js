const { Events } = require('discord.js');
const Logger = require('../utils/Logger');

module.exports = {
    name: Events.MessageDelete,
    async execute(message) {
        if (message.author?.bot || !message.guild) return;

        await Logger.log(message.guild, 'MESSAGE_DELETE', {
            author: message.author,
            channel: message.channel,
            content: message.content?.substring(0, 1000) || 'No content'
        });
    }
};