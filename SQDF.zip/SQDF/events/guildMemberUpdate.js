const { Events, EmbedBuilder } = require('discord.js');
const Logger = require('../utils/Logger');

module.exports = {
    name: Events.GuildMemberUpdate,
    async execute(oldMember, newMember) {
        // Check for boost changes
        const oldBoost = oldMember.premiumSince;
        const newBoost = newMember.premiumSince;

        if (!oldBoost && newBoost) {
            // Member started boosting
            await Logger.log(newMember.guild, 'MEMBER_BOOST_START', {
                user: newMember.user,
                boostTier: newMember.guild.premiumTier,
                totalBoosts: newMember.guild.premiumSubscriptionCount
            });

            const embed = new EmbedBuilder()
                .setColor('#ff73fa')
                .setTitle('🚀 Server Boosted!')
                .setDescription(`${newMember.user} just boosted the server!`)
                .addFields(
                    { name: 'Boost Tier', value: newMember.guild.premiumTier.toString(), inline: true },
                    { name: 'Total Boosts', value: newMember.guild.premiumSubscriptionCount.toString(), inline: true }
                )
                .setThumbnail(newMember.user.displayAvatarURL())
                .setTimestamp();

            // Send to general channel or boost log channel
            const channel = newMember.guild.channels.cache.find(ch => 
                ch.name.includes('general') || ch.name.includes('boost')
            );
            
            if (channel) {
                await channel.send({ embeds: [embed] });
            }

        } else if (oldBoost && !newBoost) {
            // Member stopped boosting
            await Logger.log(newMember.guild, 'MEMBER_BOOST_END', {
                user: newMember.user,
                boostTier: newMember.guild.premiumTier,
                totalBoosts: newMember.guild.premiumSubscriptionCount
            });
        }
    }
};