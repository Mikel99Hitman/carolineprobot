require('dotenv').config();
const { Client, GatewayIntentBits, Collection, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const initDatabase = require('./database/init');
const fs = require('fs');
const path = require('path');

// Console Banner
console.log('\x1b[33m' + ' ═══════════════════════════════════════════════════════════ ⚠️');
console.log(' ⚠️                                                           ⚠️');
console.log(' ⚠️ ███╗   ███╗██╗██╗  ██╗███████╗██╗                      ⚠️');
console.log(' ⚠️ ████╗ ████║██║██║ ██╔╝██╔════╝██║                      ⚠️');
console.log(' ⚠️ ██╔████╔██║██║█████╔╝ █████╗  ██║                      ⚠️');
console.log(' ⚠️ ██║╚██╔╝██║██║██╔═██╗ ██╔══╝  ██║                      ⚠️');
console.log(' ⚠️ ██║ ╚═╝ ██║██║██║  ██╗███████╗███████╗                 ⚠️');
console.log(' ⚠️ ╚═╝     ╚═╝╚═╝╚═╝  ╚═╝╚══════╝╚══════╝                 ⚠️');
console.log(' ⚠️                                                           ⚠️');
console.log(' ⚠️ ██████╗ ██████╗  ██████╗ ██████╗  ██████╗ ████████╗     ⚠️');
console.log(' ⚠️ ██╔══██╗██╔══██╗██╔═══██╗██╔══██╗██╔═══██╗╚══██╔══╝     ⚠️');
console.log(' ⚠️ ██████╔╝██████╔╝██║   ██║██████╔╝██║   ██║   ██║        ⚠️');
console.log(' ⚠️ ██╔═══╝ ██╔══██╗██║   ██║██╔══██╗██║   ██║   ██║        ⚠️');
console.log(' ⚠️ ██║     ██║  ██║╚██████╔╝██████╔╝╚██████╔╝   ██║        ⚠️');
console.log(' ⚠️ ╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚═════╝  ╚═════╝    ╚═╝        ⚠️');
console.log(' ⚠️                                                           ⚠️');
console.log(' ⚠️                    By Mikel99Hitman                      ⚠️');
console.log(' ⚠️                                                           ⚠️');
console.log(' ⚠️ ═══════════════════════════════════════════════════════════ ⚠️' + '\x1b[0m');
console.log('\n');
console.log('\x1b[36m' + ' 🚀 Version: 3.0.0 Professional' + '\x1b[0m');
console.log('\x1b[36m' + ' 📅 Starting: ' + new Date().toLocaleString() + '\x1b[0m');
console.log('\n');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildModeration
    ]
});

client.commands = new Collection();
client.events = new Collection();

// Load commands
const commandsPath = path.join(__dirname, 'commands');
if (fs.existsSync(commandsPath)) {
    const commandFolders = fs.readdirSync(commandsPath);
    for (const folder of commandFolders) {
        const folderPath = path.join(commandsPath, folder);
        const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));
        
        for (const file of commandFiles) {
            const filePath = path.join(folderPath, file);
            const command = require(filePath);
            if ('data' in command && 'execute' in command) {
                client.commands.set(command.data.name, command);
            }
        }
    }
}

// Load events
const eventsPath = path.join(__dirname, 'events');
if (fs.existsSync(eventsPath)) {
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));
    for (const file of eventFiles) {
        const filePath = path.join(eventsPath, file);
        const event = require(filePath);
        if (event.once) {
            client.once(event.name, (...args) => event.execute(...args));
        } else {
            client.on(event.name, (...args) => event.execute(...args));
        }
    }
}

// Connect to database
initDatabase().then(() => {
    console.log('✅ Connected to PostgreSQL');
}).catch(err => {
    console.error('❌ PostgreSQL connection error:', err);
});

client.login(process.env.BOT_TOKEN);