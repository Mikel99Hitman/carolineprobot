# ProBot by Mikel - Discord Bot v3.0.0

## 🚀 Quick Start

### 1. Setup
```bash
setup.bat
```

### 2. Test
```bash
test.bat
```

### 3. Run
```bash
start-final.bat
```

## 📁 Project Structure

```
SQDF/
├── commands/          # All bot commands
├── events/           # Discord events
├── models/           # PostgreSQL models
├── database/         # Database connection
├── utils/            # Utility functions
├── .env              # Environment variables
└── *.bat             # Batch files for easy management
```

## 🔧 Configuration

Edit `.env` file:
```env
BOT_TOKEN=your_bot_token_here
DATABASE_URL=postgresql://postgres:password@localhost:5432/probot
CLIENT_ID=your_client_id_here
GUILD_ID=your_guild_id_here
```

## 🛠️ Available Scripts

- `setup.bat` - Initial setup and installation
- `test.bat` - Run all tests
- `check.bat` - System health check
- `fix.bat` - Quick fixes for common issues
- `start-final.bat` - Start the bot
- `setup-db.bat` - Database setup only

## 🎯 Features

- ✅ Leveling & XP System
- ✅ Economy System (Daily, Work, Shop)
- ✅ Ticket System
- ✅ Music System
- ✅ Moderation Tools
- ✅ Welcome System
- ✅ Giveaway System
- ✅ Application System
- ✅ Reaction Roles
- ✅ Auto Moderation

## 🔍 Troubleshooting

If you encounter issues:

1. Run `test.bat` to identify problems
2. Run `fix.bat` for quick fixes
3. Check `TROUBLESHOOTING.md` for detailed solutions
4. Use Code Issues Panel in your IDE

## 📊 Database

Uses PostgreSQL with automatic table creation.
All models converted from MongoDB to PostgreSQL.

## 🤝 Support

- Check Code Issues Panel for detailed error analysis
- Review console logs for runtime errors
- Ensure all environment variables are configured

---
**Developed by Mikel** - Version 3.0.0 Professional