const { EmbedBuilder, WebhookClient } = require('discord.js');
const Guild = require('../models/Guild');

class Logger {
    static async log(guild, type, data) {
        try {
            const guildData = await Guild.findOne({ guildId: guild.id });
            if (!guildData || !guildData.logChannel) return;

            const logChannel = guild.channels.cache.get(guildData.logChannel);
            if (!logChannel) return;

            const embed = this.createLogEmbed(type, data);
            await logChannel.send({ embeds: [embed] });

            // Send to webhook if configured
            if (guildData.webhookUrl) {
                const webhook = new WebhookClient({ url: guildData.webhookUrl });
                await webhook.send({ embeds: [embed] });
            }
        } catch (error) {
            console.error('Logging error:', error);
        }
    }

    static createLogEmbed(type, data) {
        const embed = new EmbedBuilder().setTimestamp();

        switch (type) {
            case 'MESSAGE_DELETE':
                embed.setColor('#ff0000')
                    .setTitle('🗑️ Message Deleted')
                    .addFields(
                        { name: 'Author', value: `${data.author} (${data.author.tag})`, inline: true },
                        { name: 'Channel', value: `${data.channel}`, inline: true },
                        { name: 'Content', value: data.content || 'No content', inline: false }
                    );
                break;

            case 'MESSAGE_EDIT':
                embed.setColor('#ffaa00')
                    .setTitle('✏️ Message Edited')
                    .addFields(
                        { name: 'Author', value: `${data.author} (${data.author.tag})`, inline: true },
                        { name: 'Channel', value: `${data.channel}`, inline: true },
                        { name: 'Before', value: data.oldContent || 'No content', inline: false },
                        { name: 'After', value: data.newContent || 'No content', inline: false }
                    );
                break;

            case 'MEMBER_JOIN':
                embed.setColor('#00ff00')
                    .setTitle('📥 Member Joined')
                    .setThumbnail(data.user.displayAvatarURL())
                    .addFields(
                        { name: 'User', value: `${data.user} (${data.user.tag})`, inline: true },
                        { name: 'Account Created', value: `<t:${Math.floor(data.user.createdTimestamp / 1000)}:R>`, inline: true },
                        { name: 'Member Count', value: data.memberCount.toString(), inline: true }
                    );
                break;

            case 'MEMBER_LEAVE':
                embed.setColor('#ff0000')
                    .setTitle('📤 Member Left')
                    .setThumbnail(data.user.displayAvatarURL())
                    .addFields(
                        { name: 'User', value: `${data.user} (${data.user.tag})`, inline: true },
                        { name: 'Joined', value: data.joinedAt ? `<t:${Math.floor(data.joinedAt / 1000)}:R>` : 'Unknown', inline: true },
                        { name: 'Member Count', value: data.memberCount.toString(), inline: true }
                    );
                break;

            case 'MEMBER_BAN':
                embed.setColor('#8b0000')
                    .setTitle('🔨 Member Banned')
                    .addFields(
                        { name: 'User', value: `${data.user} (${data.user.tag})`, inline: true },
                        { name: 'Moderator', value: data.executor ? `${data.executor}` : 'Unknown', inline: true },
                        { name: 'Reason', value: data.reason || 'No reason provided', inline: false }
                    );
                break;

            case 'VOICE_JOIN':
                embed.setColor('#00ff00')
                    .setTitle('🔊 Voice Channel Joined')
                    .addFields(
                        { name: 'User', value: `${data.member}`, inline: true },
                        { name: 'Channel', value: `${data.channel}`, inline: true }
                    );
                break;

            case 'VOICE_LEAVE':
                embed.setColor('#ff0000')
                    .setTitle('🔇 Voice Channel Left')
                    .addFields(
                        { name: 'User', value: `${data.member}`, inline: true },
                        { name: 'Channel', value: data.channelName, inline: true }
                    );
                break;

            default:
                embed.setColor('#0099ff')
                    .setTitle('📋 Server Event')
                    .setDescription(`Event: ${type}`);
        }

        return embed;
    }
}

module.exports = Logger;