const pool = require('./connection');

const initDatabase = async () => {
    try {
        await pool.query(`
            CREATE TABLE IF NOT EXISTS guilds (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) UNIQUE NOT NULL,
                prefix VARCHAR(10) DEFAULT '!',
                welcome_channel VARCHAR(20),
                welcome_message TEXT DEFAULT 'Welcome {user} to {server}!',
                log_channel VARCHAR(20),
                webhook_url TEXT,
                level_up_channel VARCHAR(20),
                auto_role VARCHAR(20),
                anti_spam BOOLEAN DEFAULT false,
                anti_raid BOOLEAN DEFAULT false,
                anti_link BOOLEAN DEFAULT false,
                music_channel VARCHAR(20),
                ticket_category VARCHAR(20),
                application_channel VARCHAR(20),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                xp INTEGER DEFAULT 0,
                level INTEGER DEFAULT 1,
                messages INTEGER DEFAULT 0,
                voice INTEGER DEFAULT 0,
                warnings INTEGER DEFAULT 0,
                invites INTEGER DEFAULT 0,
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, guild_id)
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS economy (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                balance BIGINT DEFAULT 0,
                bank BIGINT DEFAULT 0,
                last_daily TIMESTAMP,
                last_weekly TIMESTAMP,
                last_work TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(user_id, guild_id)
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS inventory (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                item VARCHAR(100) NOT NULL,
                quantity INTEGER DEFAULT 1,
                purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS transactions (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                type VARCHAR(20) CHECK (type IN ('earn', 'spend', 'transfer')),
                amount BIGINT NOT NULL,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS tickets (
                id SERIAL PRIMARY KEY,
                ticket_id VARCHAR(50) UNIQUE NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                user_id VARCHAR(20) NOT NULL,
                channel_id VARCHAR(20) NOT NULL,
                status VARCHAR(10) DEFAULT 'open' CHECK (status IN ('open', 'closed')),
                reason TEXT DEFAULT 'عام',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                closed_at TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS giveaways (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                channel_id VARCHAR(20) NOT NULL,
                message_id VARCHAR(20) NOT NULL,
                host_id VARCHAR(20) NOT NULL,
                prize TEXT NOT NULL,
                winners INTEGER NOT NULL,
                end_time TIMESTAMP NOT NULL,
                participants TEXT[],
                ended BOOLEAN DEFAULT false,
                required_role VARCHAR(20),
                required_level INTEGER DEFAULT 0,
                required_invites INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS reaction_roles (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                message_id VARCHAR(20) NOT NULL,
                channel_id VARCHAR(20) NOT NULL,
                title VARCHAR(100) DEFAULT 'Reaction Roles',
                description TEXT DEFAULT 'React to get roles!',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS reaction_role_mappings (
                id SERIAL PRIMARY KEY,
                reaction_role_id INTEGER REFERENCES reaction_roles(id) ON DELETE CASCADE,
                emoji VARCHAR(100) NOT NULL,
                role_id VARCHAR(20) NOT NULL
            );
        `);

        console.log('✅ PostgreSQL tables created successfully');
    } catch (error) {
        console.error('❌ Error creating PostgreSQL tables:', error);
    }
};

module.exports = initDatabase;