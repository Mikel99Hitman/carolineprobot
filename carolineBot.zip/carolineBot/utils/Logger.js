const { EmbedBuilder, WebhookClient } = require('discord.js');
const { Pool } = require('pg');
const axios = require('axios');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

class Logger {
    static async log(guild, type, data) {
        try {
            // Get guild data from PostgreSQL
            const result = await pool.query(
                'SELECT log_channel, webhook_url FROM guilds WHERE guild_id = $1',
                [guild.id]
            );

            if (result.rows.length === 0) return;

            const guildData = result.rows[0];
            const embed = this.createLogEmbed(type, data);

            // Send to log channel
            if (guildData.log_channel) {
                const logChannel = guild.channels.cache.get(guildData.log_channel);
                if (logChannel) {
                    await logChannel.send({ embeds: [embed] });
                }
            }

            // Send to webhook
            if (guildData.webhook_url) {
                await this.sendWebhook(guildData.webhook_url, embed);
            }

            // Save log to database
            await this.saveLogToDatabase(guild.id, type, data);

        } catch (error) {
            console.error('Logging error:', error);
        }
    }

    static async sendWebhook(webhookUrl, embed) {
        try {
            await axios.post(webhookUrl, {
                embeds: [embed.toJSON()],
                username: 'Caroline Bot Logs',
                avatar_url: 'https://cdn.discordapp.com/avatars/bot_id/avatar.png'
            });
        } catch (error) {
            console.error('Webhook error:', error);
        }
    }

    static async saveLogToDatabase(guildId, type, data) {
        try {
            await pool.query(`
                CREATE TABLE IF NOT EXISTS logs (
                    id SERIAL PRIMARY KEY,
                    guild_id VARCHAR(20) NOT NULL,
                    log_type VARCHAR(50) NOT NULL,
                    user_id VARCHAR(20),
                    channel_id VARCHAR(20),
                    content TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            `);

            await pool.query(`
                INSERT INTO logs (guild_id, log_type, user_id, channel_id, content)
                VALUES ($1, $2, $3, $4, $5)
            `, [
                guildId,
                type,
                data.author?.id || data.user?.id || data.member?.id || null,
                data.channel?.id || null,
                JSON.stringify(data)
            ]);
        } catch (error) {
            console.error('Database log error:', error);
        }
    }

    static createLogEmbed(type, data) {
        const embed = new EmbedBuilder().setTimestamp();

        switch (type) {
            case 'MESSAGE_DELETE':
                embed.setColor('#ff0000')
                    .setTitle('🗑️ Message Deleted')
                    .addFields(
                        { name: '👤 Author', value: `${data.author} (${data.author.tag})`, inline: true },
                        { name: '📍 Channel', value: `${data.channel}`, inline: true },
                        { name: '📝 Content', value: data.content || 'No content', inline: false }
                    )
                    .setFooter({ text: `User ID: ${data.author.id}` });
                break;

            case 'MESSAGE_EDIT':
                embed.setColor('#ffaa00')
                    .setTitle('✏️ Message Edited')
                    .addFields(
                        { name: '👤 Author', value: `${data.author} (${data.author.tag})`, inline: true },
                        { name: '📍 Channel', value: `${data.channel}`, inline: true },
                        { name: '📝 Before', value: data.oldContent || 'No content', inline: false },
                        { name: '📝 After', value: data.newContent || 'No content', inline: false }
                    )
                    .setFooter({ text: `User ID: ${data.author.id}` });
                break;

            case 'MEMBER_JOIN':
                embed.setColor('#00ff00')
                    .setTitle('📥 Member Joined')
                    .setThumbnail(data.user.displayAvatarURL())
                    .addFields(
                        { name: '👤 User', value: `${data.user} (${data.user.tag})`, inline: true },
                        { name: '📅 Account Created', value: `<t:${Math.floor(data.user.createdTimestamp / 1000)}:R>`, inline: true },
                        { name: '👥 Member Count', value: data.memberCount.toString(), inline: true }
                    )
                    .setFooter({ text: `User ID: ${data.user.id}` });
                break;

            case 'MEMBER_LEAVE':
                embed.setColor('#ff0000')
                    .setTitle('📤 Member Left')
                    .setThumbnail(data.user.displayAvatarURL())
                    .addFields(
                        { name: '👤 User', value: `${data.user} (${data.user.tag})`, inline: true },
                        { name: '📅 Joined', value: data.joinedAt ? `<t:${Math.floor(data.joinedAt / 1000)}:R>` : 'Unknown', inline: true },
                        { name: '👥 Member Count', value: data.memberCount.toString(), inline: true }
                    )
                    .setFooter({ text: `User ID: ${data.user.id}` });
                break;

            case 'MEMBER_BAN':
                embed.setColor('#8b0000')
                    .setTitle('🔨 Member Banned')
                    .addFields(
                        { name: '👤 User', value: `${data.user} (${data.user.tag})`, inline: true },
                        { name: '👮 Moderator', value: data.executor ? `${data.executor}` : 'Unknown', inline: true },
                        { name: '📝 Reason', value: data.reason || 'No reason provided', inline: false }
                    )
                    .setFooter({ text: `User ID: ${data.user.id}` });
                break;

            case 'MEMBER_UNBAN':
                embed.setColor('#00ff00')
                    .setTitle('🔓 Member Unbanned')
                    .addFields(
                        { name: '👤 User', value: `${data.user} (${data.user.tag})`, inline: true },
                        { name: '👮 Moderator', value: data.executor ? `${data.executor}` : 'Unknown', inline: true }
                    )
                    .setFooter({ text: `User ID: ${data.user.id}` });
                break;

            case 'MEMBER_KICK':
                embed.setColor('#ff6600')
                    .setTitle('👢 Member Kicked')
                    .addFields(
                        { name: '👤 User', value: `${data.user} (${data.user.tag})`, inline: true },
                        { name: '👮 Moderator', value: data.executor ? `${data.executor}` : 'Unknown', inline: true },
                        { name: '📝 Reason', value: data.reason || 'No reason provided', inline: false }
                    )
                    .setFooter({ text: `User ID: ${data.user.id}` });
                break;

            case 'VOICE_JOIN':
                embed.setColor('#00ff00')
                    .setTitle('🔊 Voice Channel Joined')
                    .addFields(
                        { name: '👤 User', value: `${data.member}`, inline: true },
                        { name: '🎤 Channel', value: `${data.channel}`, inline: true }
                    )
                    .setFooter({ text: `User ID: ${data.member.id}` });
                break;

            case 'VOICE_LEAVE':
                embed.setColor('#ff0000')
                    .setTitle('🔇 Voice Channel Left')
                    .addFields(
                        { name: '👤 User', value: `${data.member}`, inline: true },
                        { name: '🎤 Channel', value: data.channelName, inline: true }
                    )
                    .setFooter({ text: `User ID: ${data.member.id}` });
                break;

            case 'VOICE_MOVE':
                embed.setColor('#ffaa00')
                    .setTitle('🔄 Voice Channel Moved')
                    .addFields(
                        { name: '👤 User', value: `${data.member}`, inline: true },
                        { name: '🎤 From', value: data.oldChannel, inline: true },
                        { name: '🎤 To', value: data.newChannel, inline: true }
                    )
                    .setFooter({ text: `User ID: ${data.member.id}` });
                break;

            case 'ROLE_ADD':
                embed.setColor('#00ff00')
                    .setTitle('➕ Role Added')
                    .addFields(
                        { name: '👤 User', value: `${data.member}`, inline: true },
                        { name: '🎭 Role', value: `${data.role}`, inline: true },
                        { name: '👮 By', value: data.executor ? `${data.executor}` : 'Unknown', inline: true }
                    )
                    .setFooter({ text: `User ID: ${data.member.id}` });
                break;

            case 'ROLE_REMOVE':
                embed.setColor('#ff0000')
                    .setTitle('➖ Role Removed')
                    .addFields(
                        { name: '👤 User', value: `${data.member}`, inline: true },
                        { name: '🎭 Role', value: `${data.role}`, inline: true },
                        { name: '👮 By', value: data.executor ? `${data.executor}` : 'Unknown', inline: true }
                    )
                    .setFooter({ text: `User ID: ${data.member.id}` });
                break;

            case 'CHANNEL_CREATE':
                embed.setColor('#00ff00')
                    .setTitle('📁 Channel Created')
                    .addFields(
                        { name: '📍 Channel', value: `${data.channel}`, inline: true },
                        { name: '📝 Type', value: data.channel.type.toString(), inline: true },
                        { name: '👮 By', value: data.executor ? `${data.executor}` : 'Unknown', inline: true }
                    );
                break;

            case 'CHANNEL_DELETE':
                embed.setColor('#ff0000')
                    .setTitle('🗑️ Channel Deleted')
                    .addFields(
                        { name: '📍 Channel', value: data.channelName, inline: true },
                        { name: '📝 Type', value: data.channelType, inline: true },
                        { name: '👮 By', value: data.executor ? `${data.executor}` : 'Unknown', inline: true }
                    );
                break;

            case 'INVITE_CREATE':
                embed.setColor('#00ff00')
                    .setTitle('🔗 Invite Created')
                    .addFields(
                        { name: '👤 Creator', value: `${data.inviter}`, inline: true },
                        { name: '📍 Channel', value: `${data.channel}`, inline: true },
                        { name: '🔗 Code', value: data.code, inline: true },
                        { name: '⏰ Expires', value: data.expiresAt ? `<t:${Math.floor(data.expiresAt / 1000)}:R>` : 'Never', inline: true }
                    );
                break;

            case 'COMMAND_USE':
                embed.setColor('#0099ff')
                    .setTitle('⚡ Command Used')
                    .addFields(
                        { name: '👤 User', value: `${data.user}`, inline: true },
                        { name: '📍 Channel', value: `${data.channel}`, inline: true },
                        { name: '💻 Command', value: `/${data.command}`, inline: true }
                    )
                    .setFooter({ text: `User ID: ${data.user.id}` });
                break;

            case 'GIVEAWAY_START':
                embed.setColor('#ff6b6b')
                    .setTitle('🎉 Giveaway Started')
                    .addFields(
                        { name: '👤 Host', value: `${data.host}`, inline: true },
                        { name: '🎁 Prize', value: data.prize, inline: true },
                        { name: '🏆 Winners', value: data.winners.toString(), inline: true },
                        { name: '📍 Channel', value: `${data.channel}`, inline: true }
                    );
                break;

            case 'GIVEAWAY_END':
                embed.setColor('#00ff00')
                    .setTitle('🎉 Giveaway Ended')
                    .addFields(
                        { name: '🎁 Prize', value: data.prize, inline: true },
                        { name: '🏆 Winners', value: data.winners.join(', '), inline: false },
                        { name: '👥 Participants', value: data.participants.toString(), inline: true }
                    );
                break;

            default:
                embed.setColor('#0099ff')
                    .setTitle('📋 Server Event')
                    .setDescription(`Event: ${type}`)
                    .addFields(
                        { name: '📊 Data', value: JSON.stringify(data).substring(0, 1000), inline: false }
                    );
        }

        return embed;
    }

    // Quick log methods for common events
    static async logMessageDelete(message) {
        await this.log(message.guild, 'MESSAGE_DELETE', {
            author: message.author,
            channel: message.channel,
            content: message.content?.substring(0, 1000) || 'No content'
        });
    }

    static async logMessageEdit(oldMessage, newMessage) {
        await this.log(newMessage.guild, 'MESSAGE_EDIT', {
            author: newMessage.author,
            channel: newMessage.channel,
            oldContent: oldMessage.content?.substring(0, 1000) || 'No content',
            newContent: newMessage.content?.substring(0, 1000) || 'No content'
        });
    }

    static async logMemberJoin(member) {
        await this.log(member.guild, 'MEMBER_JOIN', {
            user: member.user,
            memberCount: member.guild.memberCount
        });
    }

    static async logMemberLeave(member) {
        await this.log(member.guild, 'MEMBER_LEAVE', {
            user: member.user,
            joinedAt: member.joinedTimestamp,
            memberCount: member.guild.memberCount
        });
    }

    static async logCommandUse(interaction) {
        await this.log(interaction.guild, 'COMMAND_USE', {
            user: interaction.user,
            channel: interaction.channel,
            command: interaction.commandName
        });
    }
}

module.exports = Logger;