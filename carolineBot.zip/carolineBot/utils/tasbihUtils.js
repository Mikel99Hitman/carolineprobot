const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

// This will be integrated into the main interactionCreate handler
const handleTasbihInteraction = async (interaction) => {
    const customId = interaction.customId;
    const parts = customId.split('_');
    
    try {
        if (customId.startsWith('tasbih_count_')) {
            await handleTasbihCount(interaction, parts);
        } else if (customId.startsWith('tasbih_target_')) {
            await handleTasbihTarget(interaction, parts);
        } else if (customId === 'tasbih_stats') {
            await handleTasbihStats(interaction);
        } else if (customId === 'tasbih_leaderboard') {
            await handleTasbihLeaderboard(interaction);
        } else if (customId.startsWith('tasbih_reset_')) {
            await handleTasbihReset(interaction, parts);
        }
    } catch (error) {
        console.error('Error handling tasbih interaction:', error);
        await interaction.reply({ 
            content: '❌ حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى.', 
            ephemeral: true 
        });
    }
};

const handleTasbihCount = async (interaction, parts) => {
    const dhikrType = parts[2];
    const currentCount = parseInt(parts[3]);
    const target = parseInt(parts[4]);
    const newCount = currentCount + 1;
    
    // Update database
    await updateTasbihCount(interaction.user.id, dhikrType);
    
    const dhikrData = getDhikrData(dhikrType);
    const isCompleted = newCount >= target;
    
    const embed = new EmbedBuilder()
        .setTitle('📿 السبحة الإلكترونية')
        .setDescription(`**${dhikrData.arabic}**\n*${dhikrData.transliteration}*\n\n${dhikrData.meaning}`)
        .addFields(
            { name: '🔢 العداد', value: `**${newCount}**`, inline: true },
            { name: '🎯 الهدف', value: `**${target}**`, inline: true },
            { name: '⏱️ الوقت', value: getElapsedTime(), inline: true },
            { name: '📊 التقدم', value: getProgressBar(newCount, target), inline: false }
        )
        .setColor(isCompleted ? '#ffd700' : '#00ff00')
        .setTimestamp()
        .setFooter({ text: 'السبحة الإلكترونية • Digital Tasbih' });

    if (isCompleted) {
        embed.addFields(
            { name: '🎉 مبروك!', value: `لقد أكملت ${target} تسبيحة!`, inline: false },
            { name: '🏆 الإنجاز', value: getCompletionReward(target), inline: false }
        );
    } else {
        embed.addFields(
            { name: '🎁 الفضل', value: dhikrData.benefit, inline: false }
        );
    }

    const row1 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(`tasbih_count_${dhikrType}_${newCount}_${target}`)
                .setLabel(isCompleted ? '🎉 مكتمل' : '📿 سبّح')
                .setStyle(isCompleted ? ButtonStyle.Success : ButtonStyle.Primary)
                .setDisabled(isCompleted),
            new ButtonBuilder()
                .setCustomId(`tasbih_reset_${dhikrType}`)
                .setLabel('🔄 إعادة تعيين')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId('tasbih_stats')
                .setLabel('📊 الإحصائيات')
                .setStyle(ButtonStyle.Success)
        );

    const row2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(`tasbih_target_33_${dhikrType}`)
                .setLabel('🎯 33')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId(`tasbih_target_99_${dhikrType}`)
                .setLabel('🎯 99')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId(`tasbih_target_100_${dhikrType}`)
                .setLabel('🎯 100')
                .setStyle(ButtonStyle.Secondary),
            new ButtonBuilder()
                .setCustomId(`tasbih_continue_${dhikrType}`)
                .setLabel('➕ المتابعة')
                .setStyle(ButtonStyle.Success)
                .setDisabled(!isCompleted)
        );

    await interaction.update({ embeds: [embed], components: [row1, row2] });
};

const updateTasbihCount = async (userId, dhikrType) => {
    try {
        await pool.query(`
            INSERT INTO tasbih_stats (user_id, ${dhikrType}, total_count, last_activity)
            VALUES ($1, 1, 1, NOW())
            ON CONFLICT (user_id)
            DO UPDATE SET
                ${dhikrType} = tasbih_stats.${dhikrType} + 1,
                total_count = tasbih_stats.total_count + 1,
                last_activity = NOW()
        `, [userId]);
    } catch (error) {
        console.error('Error updating tasbih count:', error);
    }
};

const getDhikrData = (type) => {
    const dhikrTypes = {
        subhanallah: {
            arabic: 'سُبْحَانَ اللَّهِ',
            transliteration: 'SubhanAllah',
            meaning: 'Glory be to Allah',
            benefit: 'تنزيه الله عن كل نقص وعيب'
        },
        alhamdulillah: {
            arabic: 'الْحَمْدُ لِلَّهِ',
            transliteration: 'Alhamdulillah',
            meaning: 'All praise is due to Allah',
            benefit: 'حمد الله على جميع نعمه'
        },
        allahuakbar: {
            arabic: 'اللَّهُ أَكْبَرُ',
            transliteration: 'Allahu Akbar',
            meaning: 'Allah is the Greatest',
            benefit: 'تعظيم الله وإقرار بكبريائه'
        },
        lailahaillallah: {
            arabic: 'لَا إِلَٰهَ إِلَّا اللَّهُ',
            transliteration: 'La ilaha illa Allah',
            meaning: 'There is no god but Allah',
            benefit: 'شهادة التوحيد وإقرار بوحدانية الله'
        },
        astaghfirullah: {
            arabic: 'أَسْتَغْفِرُ اللَّهَ',
            transliteration: 'Astaghfirullah',
            meaning: 'I seek forgiveness from Allah',
            benefit: 'طلب المغفرة من الله'
        },
        lahawla: {
            arabic: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ',
            transliteration: 'La hawla wa la quwwata illa billah',
            meaning: 'There is no power except with Allah',
            benefit: 'الاعتراف بأن القوة والحول من الله وحده'
        },
        salawat: {
            arabic: 'صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ',
            transliteration: 'Sallallahu alayhi wa sallam',
            meaning: 'May Allah bless him and grant him peace',
            benefit: 'الصلاة على النبي محمد'
        }
    };

    return dhikrTypes[type] || dhikrTypes.subhanallah;
};

const getProgressBar = (current, target) => {
    const percentage = Math.min((current / target) * 100, 100);
    const filledBars = Math.floor(percentage / 10);
    const emptyBars = 10 - filledBars;
    
    return '🟩'.repeat(filledBars) + '⬜'.repeat(emptyBars) + ` ${percentage.toFixed(1)}%`;
};

const getElapsedTime = () => {
    const minutes = Math.floor(Math.random() * 10);
    const seconds = Math.floor(Math.random() * 60);
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
};

const getCompletionReward = (target) => {
    const rewards = {
        33: '🌟 أجر التسبيح الكامل',
        99: '🏆 أجر الأسماء الحسنى',
        100: '💎 أجر المئة تسبيحة',
        1000: '👑 أجر الألف تسبيحة'
    };
    
    return rewards[target] || '🎁 بارك الله فيك';
};

module.exports = {
    handleTasbihInteraction
};