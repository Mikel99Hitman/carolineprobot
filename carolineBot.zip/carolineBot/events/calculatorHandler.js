const { EmbedBuilder } = require('discord.js');

// تخزين حالة الآلة الحاسبة لكل مستخدم
const calculatorStates = new Map();

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        if (!interaction.isButton() || !interaction.customId.startsWith('calc_')) return;

        const userId = interaction.user.id;
        const action = interaction.customId.replace('calc_', '');
        
        // الحصول على الحالة الحالية أو إنشاء واحدة جديدة
        let state = calculatorStates.get(userId) || {
            display: '0',
            previousValue: null,
            operation: null,
            waitingForOperand: false
        };

        try {
            switch (action) {
                case 'clear':
                    state = {
                        display: '0',
                        previousValue: null,
                        operation: null,
                        waitingForOperand: false
                    };
                    break;

                case 'delete':
                    if (state.display.length > 1) {
                        state.display = state.display.slice(0, -1);
                    } else {
                        state.display = '0';
                    }
                    break;

                case '0': case '1': case '2': case '3': case '4':
                case '5': case '6': case '7': case '8': case '9':
                    if (state.waitingForOperand) {
                        state.display = action;
                        state.waitingForOperand = false;
                    } else {
                        state.display = state.display === '0' ? action : state.display + action;
                    }
                    break;

                case 'dot':
                    if (state.waitingForOperand) {
                        state.display = '0.';
                        state.waitingForOperand = false;
                    } else if (state.display.indexOf('.') === -1) {
                        state.display += '.';
                    }
                    break;

                case 'add': case 'subtract': case 'multiply': case 'divide': case 'percent':
                case 'sin': case 'cos': case 'tan': case 'sqrt': case 'power': case 'log': case 'pi':
                    const inputValue = parseFloat(state.display);

                    // Handle single operand functions
                    if (['sin', 'cos', 'tan', 'sqrt', 'power', 'log', 'pi'].includes(action)) {
                        const result = calculateScientific(inputValue, action);
                        state.display = String(result);
                        state.waitingForOperand = true;
                        break;
                    }

                    if (state.previousValue === null) {
                        state.previousValue = inputValue;
                    } else if (state.operation) {
                        const currentValue = state.previousValue || 0;
                        const newValue = calculate(currentValue, inputValue, state.operation);

                        state.display = String(newValue);
                        state.previousValue = newValue;
                    }

                    state.waitingForOperand = true;
                    state.operation = action;
                    break;

                case 'equals':
                    const inputVal = parseFloat(state.display);

                    if (state.previousValue !== null && state.operation) {
                        const newValue = calculate(state.previousValue, inputVal, state.operation);
                        
                        state.display = String(newValue);
                        state.previousValue = null;
                        state.operation = null;
                        state.waitingForOperand = true;
                    }
                    break;
            }

            // تحديث الحالة
            calculatorStates.set(userId, state);

            // تحديث العرض
            const embed = new EmbedBuilder()
                .setTitle('🧮 Scientific Calculator')
                .setDescription(`\`\`\`\n${formatDisplay(state.display)}\n\`\`\``)
                .setColor('#2F3136')
                .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
                .setTimestamp();

            await interaction.update({ embeds: [embed] });

        } catch (error) {
            console.error('Calculator error:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setTitle('🧮 Scientific Calculator')
                .setDescription('```\nError\n```')
                .setColor('#FF0000')
                .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
                .setTimestamp();

            await interaction.update({ embeds: [errorEmbed] });
            
            // إعادة تعيين الحالة
            calculatorStates.delete(userId);
        }
    }
};

function calculateScientific(value, operation) {
    switch (operation) {
        case 'sin':
            return Math.sin(value * Math.PI / 180); // Convert to radians
        case 'cos':
            return Math.cos(value * Math.PI / 180);
        case 'tan':
            return Math.tan(value * Math.PI / 180);
        case 'sqrt':
            if (value < 0) throw new Error('Square root of negative number');
            return Math.sqrt(value);
        case 'power':
            return Math.pow(value, 2);
        case 'log':
            if (value <= 0) throw new Error('Logarithm of non-positive number');
            return Math.log10(value);
        case 'pi':
            return Math.PI;
        default:
            return value;
    }
}

function calculate(firstOperand, secondOperand, operation) {
    switch (operation) {
        case 'add':
            return firstOperand + secondOperand;
        case 'subtract':
            return firstOperand - secondOperand;
        case 'multiply':
            return firstOperand * secondOperand;
        case 'divide':
            if (secondOperand === 0) {
                throw new Error('Division by zero');
            }
            return firstOperand / secondOperand;
        case 'percent':
            return firstOperand * (secondOperand / 100);
        default:
            return secondOperand;
    }
}

function formatDisplay(display) {
    // تحديد طول العرض وتنسيق الأرقام
    if (display.length > 15) {
        const num = parseFloat(display);
        if (num > 999999999999999 || num < -999999999999999) {
            return num.toExponential(8);
        }
        return num.toPrecision(15);
    }
    return display;
}