const { Events, EmbedBuilder } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    name: 'giveawayInteraction',
    
    async handleGiveawayButton(interaction) {
        if (!['enter_giveaway', 'giveaway_info'].includes(interaction.customId)) return;

        try {
            if (interaction.customId === 'enter_giveaway') {
                await this.handleGiveawayEntry(interaction);
            } else if (interaction.customId === 'giveaway_info') {
                await this.handleGiveawayInfo(interaction);
            }
        } catch (error) {
            console.error('Giveaway handler error:', error);
            await interaction.reply({ content: '❌ An error occurred while processing your request.', ephemeral: true });
        }
    },

    async handleGiveawayEntry(interaction) {
        const result = await pool.query(
            'SELECT * FROM giveaways WHERE message_id = $1 AND ended = false',
            [interaction.message.id]
        );

        if (result.rows.length === 0) {
            return interaction.reply({ content: '❌ This giveaway has ended or doesn\'t exist!', ephemeral: true });
        }

        const giveaway = result.rows[0];
        const participants = giveaway.participants || [];

        if (participants.includes(interaction.user.id)) {
            return interaction.reply({ content: '❌ You are already entered in this giveaway!', ephemeral: true });
        }

        // Check requirements
        const member = interaction.member;
        
        if (giveaway.required_role) {
            if (!member.roles.cache.has(giveaway.required_role)) {
                const role = interaction.guild.roles.cache.get(giveaway.required_role);
                return interaction.reply({ 
                    content: `❌ You need the ${role} role to enter this giveaway!`, 
                    ephemeral: true 
                });
            }
        }

        if (giveaway.required_level > 0) {
            const userResult = await pool.query(
                'SELECT level FROM users WHERE user_id = $1 AND guild_id = $2',
                [interaction.user.id, interaction.guild.id]
            );

            const userLevel = userResult.rows[0]?.level || 0;
            if (userLevel < giveaway.required_level) {
                return interaction.reply({ 
                    content: `❌ You need to be level ${giveaway.required_level} or higher to enter this giveaway!`, 
                    ephemeral: true 
                });
            }
        }

        // Add user to participants
        const newParticipants = [...participants, interaction.user.id];
        await pool.query(
            'UPDATE giveaways SET participants = $1 WHERE message_id = $2',
            [newParticipants, interaction.message.id]
        );

        // Update the giveaway embed with new participant count
        const embed = interaction.message.embeds[0];
        const newEmbed = new EmbedBuilder(embed.data)
            .setFields(
                { name: '📊 Participants', value: newParticipants.length.toString(), inline: true },
                { name: '🎯 Status', value: '🟢 Active', inline: true },
                { name: '🕰️ Time Left', value: `<t:${Math.floor(new Date(giveaway.end_time).getTime() / 1000)}:R>`, inline: true }
            );

        // Add requirements field if exists
        if (giveaway.required_role || giveaway.required_level) {
            let requirements = '**Requirements:**\n';
            if (giveaway.required_role) {
                const role = interaction.guild.roles.cache.get(giveaway.required_role);
                requirements += `• Have the ${role} role\n`;
            }
            if (giveaway.required_level) requirements += `• Be level ${giveaway.required_level} or higher\n`;
            newEmbed.addFields({ name: '📋 Entry Requirements', value: requirements });
        }

        await interaction.message.edit({ embeds: [newEmbed] });

        const successEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('🎉 Entry Confirmed!')
            .setDescription(`You have successfully entered the giveaway for **${giveaway.prize}**!`)
            .addFields(
                { name: '📊 Total Entries', value: newParticipants.length.toString(), inline: true },
                { name: '⏰ Ends', value: `<t:${Math.floor(new Date(giveaway.end_time).getTime() / 1000)}:R>`, inline: true },
                { name: '🏆 Winners', value: giveaway.winners_count.toString(), inline: true }
            )
            .setFooter({ text: 'Good luck!' })
            .setTimestamp();

        await interaction.reply({ embeds: [successEmbed], ephemeral: true });
    },

    async handleGiveawayInfo(interaction) {
        const result = await pool.query(
            'SELECT * FROM giveaways WHERE message_id = $1',
            [interaction.message.id]
        );

        if (result.rows.length === 0) {
            return interaction.reply({ content: '❌ Giveaway not found!', ephemeral: true });
        }

        const giveaway = result.rows[0];
        const participants = giveaway.participants || [];
        const host = await interaction.client.users.fetch(giveaway.host_id);

        const infoEmbed = new EmbedBuilder()
            .setColor('#4169e1')
            .setTitle('📊 Giveaway Information')
            .setDescription(`Detailed information about this giveaway`)
            .addFields(
                { name: '🎁 Prize', value: giveaway.prize, inline: true },
                { name: '🏆 Winners', value: giveaway.winners_count.toString(), inline: true },
                { name: '👥 Host', value: host.tag, inline: true },
                { name: '📊 Participants', value: participants.length.toString(), inline: true },
                { name: '🎯 Status', value: giveaway.ended ? '🔴 Ended' : '🟢 Active', inline: true },
                { name: '📅 Created', value: `<t:${Math.floor(new Date(giveaway.created_at).getTime() / 1000)}:R>`, inline: true }
            )
            .setTimestamp();

        if (!giveaway.ended) {
            infoEmbed.addFields({ 
                name: '⏰ Ends', 
                value: `<t:${Math.floor(new Date(giveaway.end_time).getTime() / 1000)}:R>`, 
                inline: true 
            });
        }

        if (giveaway.required_role || giveaway.required_level) {
            let requirements = '';
            if (giveaway.required_role) {
                const role = interaction.guild.roles.cache.get(giveaway.required_role);
                requirements += `• Have the ${role} role\n`;
            }
            if (giveaway.required_level) requirements += `• Be level ${giveaway.required_level} or higher\n`;
            infoEmbed.addFields({ name: '📋 Requirements', value: requirements, inline: false });
        }

        if (giveaway.ended && giveaway.winners && giveaway.winners.length > 0) {
            const winnerMentions = giveaway.winners.map(id => `<@${id}>`).join(', ');
            infoEmbed.addFields({ name: '🏆 Winners', value: winnerMentions, inline: false });
        }

        await interaction.reply({ embeds: [infoEmbed], ephemeral: true });
    }
};