const { EmbedBuilder } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        // Handle confession modal
        if (interaction.isModalSubmit() && interaction.customId === 'confession_modal') {
            const confessionText = interaction.fields.getTextInputValue('confession_text');
            
            // Find confession channel
            let channel = interaction.guild.channels.cache.find(ch => 
                ch.name.toLowerCase().includes('confession') || 
                ch.name.toLowerCase().includes('confess') ||
                ch.name.toLowerCase().includes('anonymous')
            ) || interaction.channel;

            try {
                // Import the confess command to use its sendConfession method
                const confessCommand = require('../commands/utility/confess.js');
                await confessCommand.sendConfession(interaction, channel, confessionText);
            } catch (error) {
                console.error('Modal confession error:', error);
                await interaction.reply({ 
                    content: '❌ Failed to send confession. Please try again.', 
                    ephemeral: true 
                });
            }
        }

        // Handle confession reaction buttons
        if (interaction.isButton() && interaction.customId.startsWith('confession_')) {
            const action = interaction.customId.split('_')[1];
            const confessionNumber = interaction.customId.split('_')[2];

            try {
                if (action === 'react') {
                    await interaction.reply({ 
                        content: '❤️ You sent support to this confession!', 
                        ephemeral: true 
                    });
                } else if (action === 'hug') {
                    await interaction.reply({ 
                        content: '🤗 You sent a virtual hug to this confession!', 
                        ephemeral: true 
                    });
                }

                // Update button with reaction count (optional)
                const embed = interaction.message.embeds[0];
                if (embed) {
                    const newEmbed = EmbedBuilder.from(embed);
                    
                    // Add reaction indicator
                    if (!embed.footer.text.includes('❤️')) {
                        newEmbed.setFooter({ 
                            text: embed.footer.text + ' • ❤️ Supported by community' 
                        });
                        
                        await interaction.message.edit({ 
                            embeds: [newEmbed], 
                            components: interaction.message.components 
                        });
                    }
                }

            } catch (error) {
                console.error('Confession button error:', error);
            }
        }
    }
};