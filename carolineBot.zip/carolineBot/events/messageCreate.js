const { Events, EmbedBuilder } = require('discord.js');
const User = require('../models/User');
const Guild = require('../models/Guild');

const cooldowns = new Map();

module.exports = {
    name: Events.MessageCreate,
    async execute(message) {
        if (message.author.bot || !message.guild) return;

        const guildData = await Guild.findOne({ guildId: message.guild.id }) || 
                         new Guild({ guildId: message.guild.id });

        // Leveling system
        await handleLeveling(message, guildData);

        // Protection system
        await handleProtection(message, guildData);
    }
};

async function handleLeveling(message, guildData) {
    const userId = message.author.id;
    const guildId = message.guild.id;

    // Avoid spam in leveling
    const cooldownKey = `${userId}-${guildId}`;
    if (cooldowns.has(cooldownKey)) return;
    cooldowns.set(cooldownKey, true);
    setTimeout(() => cooldowns.delete(cooldownKey), 60000); // One minute

    let userData = await User.findOne({ userId, guildId });
    if (!userData) {
        userData = new User({ userId, guildId });
    }

    const xpGain = Math.floor(Math.random() * 15) + 10;
    userData.xp += xpGain;
    userData.messages += 1;

    const requiredXp = userData.level * 100;
    if (userData.xp >= requiredXp) {
        userData.level += 1;
        userData.xp = 0;

        const levelUpEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('🎉 Congratulations!')
            .setDescription(`${message.author} reached level **${userData.level}**!`)
            .setThumbnail(message.author.displayAvatarURL())
            .setTimestamp();

        const channel = guildData.levelUpChannel ? 
                       message.guild.channels.cache.get(guildData.levelUpChannel) : 
                       message.channel;
        
        if (channel) {
            channel.send({ embeds: [levelUpEmbed] });
        }
    }

    await userData.save();
}

async function handleProtection(message, guildData) {
    if (message.member.permissions.has('Administrator')) return;

    // Anti-link protection
    if (guildData.antiLink && (message.content.includes('http') || message.content.includes('discord.gg'))) {
        await message.delete();
        const embed = new EmbedBuilder()
            .setColor('#ff0000')
            .setDescription('❌ Links are not allowed in this server!');
        
        const reply = await message.channel.send({ embeds: [embed] });
        setTimeout(() => reply.delete(), 5000);
        return;
    }

    // Anti-spam protection
    if (guildData.antiSpam) {
        const userMessages = message.channel.messages.cache
            .filter(m => m.author.id === message.author.id && Date.now() - m.createdTimestamp < 5000);
        
        if (userMessages.size > 5) {
            await message.delete();
            const embed = new EmbedBuilder()
                .setColor('#ff0000')
                .setDescription('❌ Stop spamming!');
            
            const reply = await message.channel.send({ embeds: [embed] });
            setTimeout(() => reply.delete(), 5000);
        }
    }
}