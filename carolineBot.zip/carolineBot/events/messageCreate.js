const { Events, EmbedBuilder } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

const cooldowns = new Map();

module.exports = {
    name: Events.MessageCreate,
    async execute(message) {
        if (message.author.bot || !message.guild) return;

        try {
            // Get guild data
            const guildResult = await pool.query(
                'SELECT * FROM guilds WHERE guild_id = $1',
                [message.guild.id]
            );

            let guildData = guildResult.rows[0];
            if (!guildData) {
                await pool.query(
                    'INSERT INTO guilds (guild_id) VALUES ($1)',
                    [message.guild.id]
                );
                guildData = { guild_id: message.guild.id };
            }

            // Handle different systems
            await handleLeveling(message, guildData);
            await handleProtection(message, guildData);
            
            // Handle counting game
            const countingHandler = require('./countingHandler');
            await countingHandler.handleCountingMessage(message);

        } catch (error) {
            console.error('MessageCreate error:', error);
        }
    }
};

async function handleLeveling(message, guildData) {
    const userId = message.author.id;
    const guildId = message.guild.id;

    // Avoid spam in leveling
    const cooldownKey = `${userId}-${guildId}`;
    if (cooldowns.has(cooldownKey)) return;
    cooldowns.set(cooldownKey, true);
    setTimeout(() => cooldowns.delete(cooldownKey), 60000); // One minute

    // Get or create user data
    let userResult = await pool.query(
        'SELECT * FROM users WHERE user_id = $1 AND guild_id = $2',
        [userId, guildId]
    );

    let userData = userResult.rows[0];
    if (!userData) {
        await pool.query(
            'INSERT INTO users (user_id, guild_id) VALUES ($1, $2)',
            [userId, guildId]
        );
        userData = { user_id: userId, guild_id: guildId, xp: 0, level: 1, messages: 0 };
    }

    const xpGain = Math.floor(Math.random() * 15) + 10;
    const newXp = (userData.xp || 0) + xpGain;
    const newMessages = (userData.messages || 0) + 1;
    const currentLevel = userData.level || 1;

    const requiredXp = currentLevel * 100;
    let newLevel = currentLevel;
    let finalXp = newXp;

    if (newXp >= requiredXp) {
        newLevel = currentLevel + 1;
        finalXp = 0;

        // Update user data
        await pool.query(
            'UPDATE users SET xp = $1, level = $2, messages = $3 WHERE user_id = $4 AND guild_id = $5',
            [finalXp, newLevel, newMessages, userId, guildId]
        );

        const levelUpEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('🎉 Congratulations!')
            .setDescription(`${message.author} reached level **${newLevel}**!`)
            .addFields(
                { name: '📊 Level', value: newLevel.toString(), inline: true },
                { name: '💬 Messages', value: newMessages.toString(), inline: true },
                { name: '⭐ XP', value: `${finalXp}/${newLevel * 100}`, inline: true }
            )
            .setThumbnail(message.author.displayAvatarURL())
            .setTimestamp();

        const channel = guildData.level_up_channel ? 
                       message.guild.channels.cache.get(guildData.level_up_channel) : 
                       message.channel;
        
        if (channel) {
            await channel.send({ embeds: [levelUpEmbed] });
        }
    } else {
        // Update user data without level up
        await pool.query(
            'UPDATE users SET xp = $1, messages = $2 WHERE user_id = $3 AND guild_id = $4',
            [finalXp, newMessages, userId, guildId]
        );
    }
}

async function handleProtection(message, guildData) {
    if (message.member.permissions.has('Administrator')) return;

    // Anti-link protection
    if (guildData.anti_link && (message.content.includes('http') || message.content.includes('discord.gg'))) {
        await message.delete();
        const embed = new EmbedBuilder()
            .setColor('#ff0000')
            .setDescription('❌ Links are not allowed in this server!')
            .setFooter({ text: 'Anti-Link Protection' });
        
        const reply = await message.channel.send({ embeds: [embed] });
        setTimeout(() => reply.delete().catch(() => {}), 5000);
        return;
    }

    // Anti-spam protection
    if (guildData.anti_spam) {
        const userMessages = message.channel.messages.cache
            .filter(m => m.author.id === message.author.id && Date.now() - m.createdTimestamp < 5000);
        
        if (userMessages.size > 5) {
            await message.delete();
            const embed = new EmbedBuilder()
                .setColor('#ff0000')
                .setDescription('❌ Stop spamming!')
                .setFooter({ text: 'Anti-Spam Protection' });
            
            const reply = await message.channel.send({ embeds: [embed] });
            setTimeout(() => reply.delete().catch(() => {}), 5000);
        }
    }
}