const { Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        // Handle slash commands
        if (interaction.isChatInputCommand()) {
            const command = interaction.client.commands.get(interaction.commandName);

            if (!command) {
                console.error(`No command matching ${interaction.commandName} was found.`);
                return;
            }

            try {
                // Log command usage
                const Logger = require('../utils/Logger');
                await Logger.logCommandUse(interaction);
                
                await command.execute(interaction);
            } catch (error) {
                console.error(error);
                const errorMessage = { content: 'There was an error while executing this command!', ephemeral: true };
                
                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp(errorMessage);
                } else {
                    await interaction.reply(errorMessage);
                }
            }
        }
        // Handle button interactions
        else if (interaction.isButton()) {
            console.log(`Button clicked: ${interaction.customId}`);
            
            // Handle calculator buttons
            if (interaction.customId.startsWith('calc_')) {
                const calculatorHandler = require('./calculatorHandler');
                await calculatorHandler.execute(interaction);
                return;
            }
            
            // Handle confession buttons
            if (interaction.customId.startsWith('confession_')) {
                const confessionHandler = require('./confessionHandler');
                await confessionHandler.execute(interaction);
                return;
            }
            
            // Handle giveaway buttons
            if (['enter_giveaway', 'giveaway_info'].includes(interaction.customId)) {
                const giveawayHandler = require('./giveawayHandler');
                await giveawayHandler.handleGiveawayButton(interaction);
                return;
            }
            
            // Handle tasbih (Islamic counter) buttons
            if (interaction.customId.startsWith('tasbih_')) {
                const { handleTasbihInteraction } = require('../utils/tasbihUtils');
                await handleTasbihInteraction(interaction);
                return;
            }
            
            await handleButtonInteraction(interaction);
        }
        // Handle select menu interactions
        else if (interaction.isStringSelectMenu()) {
            await handleSelectMenuInteraction(interaction);
        }
        // Handle modal interactions
        else if (interaction.isModalSubmit()) {
            // Handle confession modal
            if (interaction.customId === 'confession_modal') {
                const confessionHandler = require('./confessionHandler');
                await confessionHandler.execute(interaction);
                return;
            }
            
            if (interaction.customId === 'application_modal') {
                const applicationCommand = require('../commands/general/application.js');
                await applicationCommand.handleApplicationModal(interaction);
            }
        }
    },
};

async function handleButtonInteraction(interaction) {
    const { customId } = interaction;
    const lang = detectLanguage(interaction.message.embeds[0]?.title || '');
    
    console.log(`Processing button: ${customId} in language: ${lang}`);

    try {
        switch (customId) {
            case 'detailed_analysis':
                await handleDetailedAnalysis(interaction, lang);
                break;
            case 'translate_text':
                await handleTranslateText(interaction, lang);
                break;
            case 'continue_chat':
                await handleContinueChat(interaction, lang);
                break;
            case 'change_personality':
                await handleChangePersonality(interaction, lang);
                break;
            case 'regenerate_content':
                await handleRegenerateContent(interaction, lang);
                break;
            case 'improve_content':
                await handleImproveContent(interaction, lang);
                break;
            case 'next_lesson':
                await handleNextLesson(interaction, lang);
                break;
            case 'quiz_me':
                await handleQuizMe(interaction, lang);
                break;
            case 'practice_exercises':
                await handlePracticeExercises(interaction, lang);
                break;
            case 'generate_more_images':
                await handleGenerateMoreImages(interaction, lang);
                break;
            case 'improve_prompt':
                await handleImprovePrompt(interaction, lang);
                break;
            case 'save_image':
                await handleSaveImage(interaction, lang);
                break;
            case 'optimize_code':
                await handleOptimizeCode(interaction, lang);
                break;
            case 'explain_code':
                await handleExplainCode(interaction, lang);
                break;
            case 'generate_tests':
                await handleGenerateTests(interaction, lang);
                break;
            case 'fix_issues':
            case 'detailed_report':
            case 'analyze_generated':
            case 'optimize_generated':
            case 'export_code':
            case 'view_optimized':
            case 'compare_versions':
            case 'benchmark_test':
                await handleCodeAction(interaction, lang, customId);
                break;
            case 'open_application':
                const applicationCommand = require('../commands/general/application.js');
                await applicationCommand.handleApplicationButton(interaction);
                break;
            case customId.startsWith('accept_app_') ? customId : null:
            case customId.startsWith('reject_app_') ? customId : null:
                await handleApplicationAction(interaction, customId);
                break;
            default:
                await interaction.reply({
                    content: '❌ Unknown button!',
                    ephemeral: true
                });
        }
    } catch (error) {
        console.error('Button interaction error:', error);
        await interaction.reply({
            content: '❌ An error occurred while processing the request!',
            ephemeral: true
        });
    }
}

async function handleDetailedAnalysis(interaction, lang) {
    await interaction.deferReply({ ephemeral: true });

    const embed = new EmbedBuilder()
        .setTitle(lang === 'ar' ? '📊 تحليل مفصل' : '📊 Detailed Analysis')
        .setDescription(lang === 'ar' ? 'تحليل شامل ومفصل للنص' : 'Comprehensive and detailed text analysis')
        .addFields(
            { name: lang === 'ar' ? '🔍 تحليل النحو' : '🔍 Grammar Analysis', value: lang === 'ar' ? 'النحو سليم بنسبة 95%' : 'Grammar is 95% correct', inline: true },
            { name: lang === 'ar' ? '📈 مستوى التعقيد' : '📈 Complexity Level', value: lang === 'ar' ? 'متوسط' : 'Medium', inline: true },
            { name: lang === 'ar' ? '🎯 الجمهور المستهدف' : '🎯 Target Audience', value: lang === 'ar' ? 'عام' : 'General', inline: true },
            { name: lang === 'ar' ? '📊 إحصائيات مفصلة' : '📊 Detailed Statistics', value: lang === 'ar' ? '• عدد الكلمات: 150\n• عدد الجمل: 8\n• متوسط طول الجملة: 18 كلمة' : '• Word count: 150\n• Sentence count: 8\n• Average sentence length: 18 words', inline: false }
        )
        .setColor('#3498db')
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
}

async function handleTranslateText(interaction, lang) {
    await interaction.deferReply({ ephemeral: true });

    const targetLang = lang === 'ar' ? 'en' : 'ar';
    const embed = new EmbedBuilder()
        .setTitle(targetLang === 'ar' ? '🌐 النص المترجم' : '🌐 Translated Text')
        .setDescription(targetLang === 'ar' ? 'ترجمة النص إلى العربية' : 'Text translated to English')
        .addFields({
            name: targetLang === 'ar' ? '📝 الترجمة' : '📝 Translation',
            value: targetLang === 'ar' ? 'هذا نص مترجم تلقائياً بواسطة الذكاء الاصطناعي' : 'This is an automatically translated text by AI',
            inline: false
        })
        .setColor('#e74c3c')
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
}

async function handleContinueChat(interaction, lang) {
    await interaction.deferReply({ ephemeral: true });

    const embed = new EmbedBuilder()
        .setTitle(lang === 'ar' ? '💬 متابعة المحادثة' : '💬 Continue Conversation')
        .setDescription(lang === 'ar' ? 'استخدم الأمر /ai-advanced smart-chat لمتابعة المحادثة' : 'Use /ai-advanced smart-chat command to continue the conversation')
        .setColor('#9b59b6')
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
}

async function handleChangePersonality(interaction, lang) {
    await interaction.deferReply({ ephemeral: true });

    const embed = new EmbedBuilder()
        .setTitle(lang === 'ar' ? '🎭 تغيير الشخصية' : '🎭 Change Personality')
        .setDescription(lang === 'ar' ? 'استخدم الأمر /ai-advanced smart-chat مع اختيار شخصية مختلفة' : 'Use /ai-advanced smart-chat command with a different personality choice')
        .addFields({
            name: lang === 'ar' ? '🎯 الشخصيات المتاحة' : '🎯 Available Personalities',
            value: lang === 'ar' ? '• مهني\n• ودود\n• إبداعي\n• أكاديمي' : '• Professional\n• Friendly\n• Creative\n• Academic',
            inline: false
        })
        .setColor('#f39c12')
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
}

async function handleRegenerateContent(interaction, lang) {
    await interaction.deferReply();

    const embed = new EmbedBuilder()
        .setTitle(lang === 'ar' ? '🔄 إعادة توليد المحتوى' : '🔄 Regenerating Content')
        .setDescription(lang === 'ar' ? 'جاري إعادة توليد محتوى جديد...' : 'Generating new content...')
        .setColor('#f39c12')
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });

    // Simulate regeneration
    setTimeout(async () => {
        const newEmbed = new EmbedBuilder()
            .setTitle(lang === 'ar' ? '✅ تم إعادة التوليد' : '✅ Content Regenerated')
            .setDescription(lang === 'ar' ? 'تم إنشاء محتوى جديد بنجاح' : 'New content generated successfully')
            .addFields({
                name: lang === 'ar' ? '📄 المحتوى الجديد' : '📄 New Content',
                value: lang === 'ar' ? 'هذا محتوى جديد تم توليده بواسطة الذكاء الاصطناعي مع تحسينات إضافية' : 'This is new content generated by AI with additional improvements',
                inline: false
            })
            .setColor('#27ae60')
            .setTimestamp();

        await interaction.editReply({ embeds: [newEmbed], components: [] });
    }, 2000);
}

async function handleImproveContent(interaction, lang) {
    await interaction.deferReply();

    const embed = new EmbedBuilder()
        .setTitle(lang === 'ar' ? '✨ تحسين المحتوى' : '✨ Improving Content')
        .setDescription(lang === 'ar' ? 'جاري تحسين المحتوى...' : 'Improving content...')
        .setColor('#f39c12')
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });

    setTimeout(async () => {
        const improvedEmbed = new EmbedBuilder()
            .setTitle(lang === 'ar' ? '✅ تم التحسين' : '✅ Content Improved')
            .setDescription(lang === 'ar' ? 'تم تحسين المحتوى بنجاح' : 'Content improved successfully')
            .addFields(
                { name: lang === 'ar' ? '📈 التحسينات' : '📈 Improvements', value: lang === 'ar' ? '• تحسين الأسلوب\n• إضافة تفاصيل\n• تحسين التنسيق' : '• Style enhancement\n• Added details\n• Improved formatting', inline: false },
                { name: lang === 'ar' ? '📄 المحتوى المحسن' : '📄 Improved Content', value: lang === 'ar' ? 'هذا المحتوى تم تحسينه ليكون أكثر وضوحاً وفائدة للقارئ' : 'This content has been improved to be clearer and more useful for the reader', inline: false }
            )
            .setColor('#27ae60')
            .setTimestamp();

        await interaction.editReply({ embeds: [improvedEmbed], components: [] });
    }, 2000);
}

async function handleNextLesson(interaction, lang) {
    await interaction.deferReply({ ephemeral: true });

    const embed = new EmbedBuilder()
        .setTitle(lang === 'ar' ? '➡️ الدرس التالي' : '➡️ Next Lesson')
        .setDescription(lang === 'ar' ? 'استخدم الأمر /ai-advanced ai-tutor مرة أخرى للحصول على درس جديد' : 'Use /ai-advanced ai-tutor command again to get a new lesson')
        .setColor('#3498db')
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
}

async function handleQuizMe(interaction, lang) {
    await interaction.deferReply({ ephemeral: true });

    const embed = new EmbedBuilder()
        .setTitle(lang === 'ar' ? '🧠 اختبار سريع' : '🧠 Quick Quiz')
        .setDescription(lang === 'ar' ? 'إليك سؤال للمراجعة:' : 'Here\'s a review question:')
        .addFields({
            name: lang === 'ar' ? '❓ السؤال' : '❓ Question',
            value: lang === 'ar' ? 'ما هي أهم المفاهيم التي تعلمتها في هذا الدرس؟' : 'What are the most important concepts you learned in this lesson?',
            inline: false
        })
        .setColor('#e67e22')
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
}

async function handlePracticeExercises(interaction, lang) {
    await interaction.deferReply({ ephemeral: true });

    const embed = new EmbedBuilder()
        .setTitle(lang === 'ar' ? '📝 تمارين تطبيقية' : '📝 Practice Exercises')
        .setDescription(lang === 'ar' ? 'تمارين لتطبيق ما تعلمته' : 'Exercises to apply what you learned')
        .addFields({
            name: lang === 'ar' ? '🎯 التمارين' : '🎯 Exercises',
            value: lang === 'ar' ? '1. طبق المفهوم الأول\n2. حل المشكلة التالية\n3. أنشئ مثالاً جديداً' : '1. Apply the first concept\n2. Solve the following problem\n3. Create a new example',
            inline: false
        })
        .setColor('#27ae60')
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
}

// Additional handlers for AI image and code commands
async function handleGenerateMoreImages(interaction, lang) {
    await interaction.deferReply();

    const embed = new EmbedBuilder()
        .setTitle(lang === 'ar' ? '🎨 توليد المزيد من الصور' : '🎨 Generating More Images')
        .setDescription(lang === 'ar' ? 'جاري توليد صور إضافية...' : 'Generating additional images...')
        .setColor('#f39c12')
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
}

async function handleImprovePrompt(interaction, lang) {
    await interaction.deferReply({ ephemeral: true });

    const embed = new EmbedBuilder()
        .setTitle(lang === 'ar' ? '✨ تحسين الوصف' : '✨ Improve Prompt')
        .setDescription(lang === 'ar' ? 'نصائح لتحسين وصف الصورة' : 'Tips for improving image description')
        .addFields({
            name: lang === 'ar' ? '💡 نصائح' : '💡 Tips',
            value: lang === 'ar' ? '• كن أكثر تفصيلاً\n• استخدم كلمات وصفية\n• حدد الأسلوب المطلوب' : '• Be more detailed\n• Use descriptive words\n• Specify the desired style',
            inline: false
        })
        .setColor('#9b59b6')
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
}

async function handleSaveImage(interaction, lang) {
    await interaction.deferReply({ ephemeral: true });

    const embed = new EmbedBuilder()
        .setTitle(lang === 'ar' ? '💾 حفظ الصورة' : '💾 Save Image')
        .setDescription(lang === 'ar' ? 'انقر بزر الماوس الأيمن على الصورة واختر "حفظ الصورة"' : 'Right-click on the image and select "Save Image"')
        .setColor('#27ae60')
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
}

async function handleOptimizeCode(interaction, lang) {
    await interaction.deferReply({ ephemeral: true });

    const embed = new EmbedBuilder()
        .setTitle(lang === 'ar' ? '⚡ تحسين الكود' : '⚡ Code Optimization')
        .setDescription(lang === 'ar' ? 'نصائح لتحسين الكود' : 'Code optimization tips')
        .addFields({
            name: lang === 'ar' ? '🔧 التحسينات' : '🔧 Optimizations',
            value: lang === 'ar' ? '• استخدم متغيرات const/let\n• تجنب التكرار\n• استخدم دوال مساعدة' : '• Use const/let variables\n• Avoid repetition\n• Use helper functions',
            inline: false
        })
        .setColor('#e67e22')
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
}

async function handleExplainCode(interaction, lang) {
    await interaction.deferReply({ ephemeral: true });

    const embed = new EmbedBuilder()
        .setTitle(lang === 'ar' ? '📖 شرح الكود' : '📖 Code Explanation')
        .setDescription(lang === 'ar' ? 'شرح مفصل للكود المُولد' : 'Detailed explanation of the generated code')
        .addFields({
            name: lang === 'ar' ? '💡 الشرح' : '💡 Explanation',
            value: lang === 'ar' ? 'هذا الكود يقوم بتنفيذ الوظيفة المطلوبة باستخدام أفضل الممارسات' : 'This code implements the required functionality using best practices',
            inline: false
        })
        .setColor('#3498db')
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
}

async function handleGenerateTests(interaction, lang) {
    await interaction.deferReply({ ephemeral: true });

    const embed = new EmbedBuilder()
        .setTitle(lang === 'ar' ? '🧪 توليد الاختبارات' : '🧪 Generate Tests')
        .setDescription(lang === 'ar' ? 'اختبارات وحدة للكود المُولد' : 'Unit tests for the generated code')
        .addFields({
            name: lang === 'ar' ? '📝 الاختبارات' : '📝 Tests',
            value: '```javascript\n// Test example\ntest("function works correctly", () => {\n  expect(myFunction()).toBe(expected);\n});\n```',
            inline: false
        })
        .setColor('#27ae60')
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
}

function detectLanguage(text) {
    const arabicPattern = /[\u0600-\u06FF]/;
    return arabicPattern.test(text) ? 'ar' : 'en';
}

async function handleCodeAction(interaction, lang, action) {
    await interaction.deferReply({ ephemeral: true });

    const actionMessages = {
        fix_issues: {
            ar: { title: '🔧 إصلاح المشاكل', desc: 'تم إصلاح جميع المشاكل المكتشفة تلقائياً' },
            en: { title: '🔧 Fix Issues', desc: 'All detected issues have been automatically fixed' }
        },
        detailed_report: {
            ar: { title: '📋 تقرير مفصل', desc: 'تقرير شامل عن جودة الكود وأدائه' },
            en: { title: '📋 Detailed Report', desc: 'Comprehensive report on code quality and performance' }
        },
        analyze_generated: {
            ar: { title: '🔍 تحليل الكود', desc: 'تحليل شامل للكود المُولد' },
            en: { title: '🔍 Analyze Code', desc: 'Comprehensive analysis of generated code' }
        },
        optimize_generated: {
            ar: { title: '⚡ تحسين الكود', desc: 'تم تحسين الكود لأداء أفضل' },
            en: { title: '⚡ Optimize Code', desc: 'Code optimized for better performance' }
        },
        export_code: {
            ar: { title: '📤 تصدير الكود', desc: 'انسخ الكود من الرسالة أعلاه' },
            en: { title: '📤 Export Code', desc: 'Copy the code from the message above' }
        },
        view_optimized: {
            ar: { title: '👀 عرض الكود المحسن', desc: 'الكود المحسن جاهز للعرض' },
            en: { title: '👀 View Optimized Code', desc: 'Optimized code ready for viewing' }
        },
        compare_versions: {
            ar: { title: '📊 مقارنة الإصدارات', desc: 'مقارنة بين الكود الأصلي والمحسن' },
            en: { title: '📊 Compare Versions', desc: 'Comparison between original and optimized code' }
        },
        benchmark_test: {
            ar: { title: '⚡ اختبار الأداء', desc: 'نتائج اختبار الأداء متاحة' },
            en: { title: '⚡ Benchmark Test', desc: 'Performance test results available' }
        }
    };

    const message = actionMessages[action]?.[lang] || actionMessages[action]?.en;
    
    const embed = new EmbedBuilder()
        .setTitle(message.title)
        .setDescription(message.desc)
        .setColor('#27ae60')
        .setTimestamp();

    await interaction.editReply({ embeds: [embed] });
}

async function handleApplicationAction(interaction, customId) {
    const userId = customId.split('_')[2];
    const action = customId.startsWith('accept_') ? 'accept' : 'reject';
    
    const embed = new EmbedBuilder()
        .setTitle(action === 'accept' ? '✅ Application Accepted' : '❌ Application Rejected')
        .setDescription(`Application for <@${userId}> has been ${action}ed by ${interaction.user}`)
        .setColor(action === 'accept' ? '#00ff00' : '#ff0000')
        .setTimestamp();
    
    await interaction.reply({ embeds: [embed] });
}

async function handleSelectMenuInteraction(interaction) {
    // Handle select menu interactions if needed
    await interaction.reply({
        content: 'Select menu interaction handled!',
        ephemeral: true
    });
}