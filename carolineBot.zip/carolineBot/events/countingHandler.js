const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    async handleCountingMessage(message) {
        if (message.author.bot || !message.guild) return;

        try {
            // Check if this is a counting channel
            const result = await pool.query(
                'SELECT * FROM counting WHERE guild_id = $1 AND channel_id = $2',
                [message.guild.id, message.channel.id]
            );

            if (result.rows.length === 0) return;

            const countingData = result.rows[0];
            const messageContent = message.content.trim();
            
            // Check if message is a number
            const number = parseInt(messageContent);
            if (isNaN(number) || messageContent !== number.toString()) {
                return message.react('❌');
            }

            const expectedNumber = countingData.current_number + 1;
            const lastUserId = countingData.last_user_id;

            // Check if same user is counting twice in a row
            if (lastUserId === message.author.id) {
                await message.react('🚫');
                await message.reply('❌ You cannot count twice in a row!');
                return;
            }

            // Check if number is correct
            if (number === expectedNumber) {
                // Correct number
                await message.react('✅');
                
                // Update database
                const newHighest = Math.max(number, countingData.highest_number);
                await pool.query(`
                    UPDATE counting 
                    SET current_number = $1, last_user_id = $2, highest_number = $3 
                    WHERE guild_id = $4 AND channel_id = $5
                `, [number, message.author.id, newHighest, message.guild.id, message.channel.id]);

                // Milestone celebrations
                if (number % 100 === 0) {
                    await message.reply(`🎉 **Milestone reached!** We've hit ${number}! Keep going! 🚀`);
                } else if (number % 50 === 0) {
                    await message.reply(`🎊 Great job! ${number} numbers counted! 📈`);
                }

            } else {
                // Wrong number - reset
                await message.react('💥');
                await pool.query(`
                    UPDATE counting 
                    SET current_number = 0, last_user_id = NULL, fails = fails + 1 
                    WHERE guild_id = $1 AND channel_id = $2
                `, [message.guild.id, message.channel.id]);

                await message.reply(`💥 **RESET!** Expected ${expectedNumber} but got ${number}. Start over from \`1\`!`);
            }

        } catch (error) {
            console.error('Counting game error:', error);
        }
    }
};