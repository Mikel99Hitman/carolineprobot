const { Events } = require('discord.js');
const { Pool } = require('pg');
const Logger = require('../utils/Logger');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    name: Events.MessageReactionAdd,
    async execute(reaction, user) {
        if (user.bot) return;

        // Handle partial reactions
        if (reaction.partial) {
            try {
                await reaction.fetch();
            } catch (error) {
                console.error('Error fetching reaction:', error);
                return;
            }
        }

        try {
            // Check for reaction roles
            const result = await pool.query(`
                SELECT rrm.role_id 
                FROM reaction_roles rr
                JOIN reaction_role_mappings rrm ON rr.id = rrm.reaction_role_id
                WHERE rr.guild_id = $1 AND rr.message_id = $2 AND rrm.emoji = $3
            `, [reaction.message.guild.id, reaction.message.id, reaction.emoji.toString()]);

            if (result.rows.length === 0) return;

            const roleId = result.rows[0].role_id;
            const member = reaction.message.guild.members.cache.get(user.id);
            const role = reaction.message.guild.roles.cache.get(roleId);

            if (!member || !role) return;

            await member.roles.add(role);
            
            // Log role addition
            await Logger.log(reaction.message.guild, 'ROLE_ADD', {
                member: member,
                role: role,
                executor: null
            });

            console.log(`Added role ${role.name} to ${member.user.tag}`);
        } catch (error) {
            console.error('Error adding role:', error);
        }
    }
};