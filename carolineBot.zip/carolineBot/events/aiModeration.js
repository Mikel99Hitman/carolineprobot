const { Events, EmbedBuilder } = require('discord.js');
const WordFilter = require('../models/WordFilter');
const User = require('../models/User');
const Logger = require('../utils/Logger');

const toxicPatterns = [
    /toxic|hate|stupid|idiot/i,
    /spam|scam|hack/i,
    /discord\.gg|bit\.ly|tinyurl/i
];

const spamTracker = new Map();

module.exports = {
    name: Events.MessageCreate,
    async execute(message) {
        if (message.author.bot || !message.guild) return;

        // AI-based content moderation
        await handleAIModeration(message);
        
        // Spam detection
        await handleSpamDetection(message);
        
        // Chatbot response
        await handleChatbot(message);
    }
};

async function handleAIModeration(message) {
    const content = message.content.toLowerCase();
    
    // Check for toxic content
    const isToxic = toxicPatterns.some(pattern => pattern.test(content));
    
    if (isToxic) {
        try {
            await message.delete();
            
            // Warn user
            let userData = await User.findOne({
                userId: message.author.id,
                guildId: message.guild.id
            });
            
            if (!userData) {
                userData = new User({
                    userId: message.author.id,
                    guildId: message.guild.id
                });
            }
            
            userData.warnings += 1;
            await userData.save();
            
            const embed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('🤖 AI Moderation')
                .setDescription(`${message.author}, your message was removed for inappropriate content.`)
                .addFields({ name: 'Warnings', value: userData.warnings.toString(), inline: true })
                .setTimestamp();
            
            const warning = await message.channel.send({ embeds: [embed] });
            setTimeout(() => warning.delete().catch(() => {}), 10000);
            
            // Auto-timeout for multiple warnings
            if (userData.warnings >= 3) {
                const member = message.guild.members.cache.get(message.author.id);
                if (member) {
                    await member.timeout(60000 * 10, 'AI Moderation - Multiple warnings');
                }
            }
            
            await Logger.log(message.guild, 'AI_MODERATION', {
                user: message.author,
                content: message.content,
                action: 'Message deleted',
                warnings: userData.warnings
            });
            
        } catch (error) {
            console.error('AI Moderation error:', error);
        }
    }
}

async function handleSpamDetection(message) {
    const userId = message.author.id;
    const now = Date.now();
    
    if (!spamTracker.has(userId)) {
        spamTracker.set(userId, []);
    }
    
    const userMessages = spamTracker.get(userId);
    userMessages.push(now);
    
    // Keep only messages from last 5 seconds
    const recentMessages = userMessages.filter(time => now - time < 5000);
    spamTracker.set(userId, recentMessages);
    
    if (recentMessages.length > 5) {
        try {
            // Delete recent messages
            const messages = await message.channel.messages.fetch({ limit: 10 });
            const userRecentMessages = messages.filter(m => 
                m.author.id === userId && now - m.createdTimestamp < 10000
            );
            
            await message.channel.bulkDelete(userRecentMessages);
            
            // Timeout user
            const member = message.guild.members.cache.get(userId);
            if (member) {
                await member.timeout(300000, 'Spam detection'); // 5 minutes
            }
            
            const embed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('🚫 Spam Detected')
                .setDescription(`${message.author} has been timed out for spamming.`)
                .setTimestamp();
            
            await message.channel.send({ embeds: [embed] });
            
        } catch (error) {
            console.error('Spam detection error:', error);
        }
    }
}

async function handleChatbot(message) {
    if (!global.chatbotChannels?.has(message.channel.id)) return;
    if (Math.random() > 0.3) return; // 30% chance to respond
    
    const { getChatbotResponse } = require('../commands/utility/chatbot');
    const response = getChatbotResponse(message.content);
    
    setTimeout(async () => {
        try {
            await message.channel.send(response);
        } catch (error) {
            console.error('Chatbot error:', error);
        }
    }, 1000 + Math.random() * 2000); // Random delay 1-3 seconds
}