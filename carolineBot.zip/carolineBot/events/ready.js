const { Events, ActivityType } = require('discord.js');

module.exports = {
    name: Events.ClientReady,
    once: true,
    execute(client) {
        console.log(`✅ ${client.user.tag} is online!`);
        
        client.user.setPresence({
            activities: [{
                name: `${client.guilds.cache.size} servers | /help`,
                type: ActivityType.Watching
            }],
            status: 'online'
        });

        // Update bot status every 30 seconds
        setInterval(() => {
            const activities = [
                `${client.guilds.cache.size} servers`,
                `${client.users.cache.size} users`,
                `/help for commands`
            ];
            
            const activity = activities[Math.floor(Math.random() * activities.length)];
            client.user.setActivity(activity, { type: ActivityType.Watching });
        }, 30000);
    }
};