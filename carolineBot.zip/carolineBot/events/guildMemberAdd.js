const { Events } = require('discord.js');
const Logger = require('../utils/Logger');

module.exports = {
    name: Events.GuildMemberAdd,
    async execute(member) {
        await Logger.logMemberJoin(member);
    }
};