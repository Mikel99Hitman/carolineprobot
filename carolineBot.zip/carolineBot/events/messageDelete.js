const { Events } = require('discord.js');
const Logger = require('../utils/Logger');

module.exports = {
    name: Events.MessageDelete,
    async execute(message) {
        if (message.author?.bot || !message.guild) return;
        await Logger.logMessageDelete(message);
    }
};