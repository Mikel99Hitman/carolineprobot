const { Events } = require('discord.js');
const Logger = require('../utils/Logger');

module.exports = {
    name: Events.MessageUpdate,
    async execute(oldMessage, newMessage) {
        if (newMessage.author?.bot || !newMessage.guild) return;
        if (oldMessage.content === newMessage.content) return;
        await Logger.logMessageEdit(oldMessage, newMessage);
    }
};