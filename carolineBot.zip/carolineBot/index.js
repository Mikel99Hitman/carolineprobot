require('dotenv').config();
const { Client, GatewayIntentBits, Collection, ActivityType } = require('discord.js');
const initDatabase = require('./database/init');
const fs = require('fs');
const path = require('path');

// Console Banner
console.log('\x1b[33m' + ' ═══════════════════════════════════════════════════════════ ⚠️');
console.log(' ⚠️                                                           ⚠️');
console.log(' ⚠️  ██████╗ █████╗ ██████╗  ██████╗ ██╗     ██╗███╗   ██╗███████╗ ⚠️');
console.log(' ⚠️ ██╔════╝██╔══██╗██╔══██╗██╔═══██╗██║     ██║████╗  ██║██╔════╝ ⚠️');
console.log(' ⚠️ ██║     ███████║██████╔╝██║   ██║██║     ██║██╔██╗ ██║█████╗   ⚠️');
console.log(' ⚠️ ██║     ██╔══██║██╔══██╗██║   ██║██║     ██║██║╚██╗██║██╔══╝   ⚠️');
console.log(' ⚠️ ╚██████╗██║  ██║██║  ██║╚██████╔╝███████╗██║██║ ╚████║███████╗ ⚠️');
console.log(' ⚠️  ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝╚═╝  ╚═══╝╚══════╝ ⚠️');
console.log(' ⚠️                                                           ⚠️');
console.log(' ⚠️ ██████╗  ██████╗ ████████╗                               ⚠️');
console.log(' ⚠️ ██╔══██╗██╔═══██╗╚══██╔══╝                               ⚠️');
console.log(' ⚠️ ██████╔╝██║   ██║   ██║                                  ⚠️');
console.log(' ⚠️ ██╔══██╗██║   ██║   ██║                                  ⚠️');
console.log(' ⚠️ ██████╔╝╚██████╔╝   ██║                                  ⚠️');
console.log(' ⚠️ ╚═════╝  ╚═════╝    ╚═╝                                  ⚠️');
console.log(' ⚠️                                                           ⚠️');
console.log(' ⚠️                    By Mikel99Hitman                      ⚠️');
console.log(' ⚠️                                                           ⚠️');
console.log(' ⚠️ ═══════════════════════════════════════════════════════════ ⚠️' + '\x1b[0m');
console.log('\n');
console.log('\x1b[36m' + ' 🚀 Caroline Bot v3.0.0 Professional' + '\x1b[0m');
console.log('\x1b[36m' + ' 📅 Starting: ' + new Date().toLocaleString() + '\x1b[0m');
console.log('\x1b[36m' + ' 🗄️ Database: PostgreSQL' + '\x1b[0m');
console.log('\x1b[36m' + ' 🔗 Webhooks: Enabled' + '\x1b[0m');
console.log('\x1b[36m' + ' 🌐 Multi-Language: Arabic/English' + '\x1b[0m');
console.log('\n');

// Validate environment variables
const requiredEnvVars = ['BOT_TOKEN', 'DATABASE_URL'];
const missingVars = requiredEnvVars.filter(varName => !process.env[varName]);

if (missingVars.length > 0) {
    console.error('\x1b[31m❌ Missing required environment variables:\x1b[0m');
    missingVars.forEach(varName => {
        console.error(`\x1b[31m   - ${varName}\x1b[0m`);
    });
    console.error('\x1b[33m💡 Please check your .env file\x1b[0m');
    process.exit(1);
}

// Validate Discord token format
if (!process.env.BOT_TOKEN.match(/^[A-Za-z0-9._-]+$/)) {
    console.error('\x1b[31m❌ Invalid BOT_TOKEN format\x1b[0m');
    process.exit(1);
}

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildModeration,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.GuildScheduledEvents
    ],
    allowedMentions: {
        parse: ['users', 'roles'],
        repliedUser: false
    }
});

// Initialize collections
client.commands = new Collection();
client.events = new Collection();
client.cooldowns = new Collection();
client.giveaways = new Collection();
client.tickets = new Collection();

// Bot statistics
const botStats = {
    startTime: Date.now(),
    commandsExecuted: 0,
    messagesProcessed: 0,
    errors: 0
};

// Load commands with better error handling
console.log('\x1b[33m📂 Loading commands...\\x1b[0m');
const commandsPath = path.join(__dirname, 'commands');
let totalCommands = 0;
const commandCategories = {};

if (fs.existsSync(commandsPath)) {
    const commandFolders = fs.readdirSync(commandsPath);
    
    for (const folder of commandFolders) {
        const folderPath = path.join(commandsPath, folder);
        if (!fs.statSync(folderPath).isDirectory()) continue;
        
        const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));
        let folderCommands = 0;
        commandCategories[folder] = [];
        
        for (const file of commandFiles) {
            const filePath = path.join(folderPath, file);
            try {
                // Clear require cache for hot reloading
                delete require.cache[require.resolve(filePath)];
                const command = require(filePath);
                
                if ('data' in command && 'execute' in command) {
                    // Validate command structure
                    if (!command.data.name || !command.data.description) {
                        console.warn(`\x1b[33m⚠️  Command ${file} missing name or description\x1b[0m`);
                        continue;
                    }
                    
                    client.commands.set(command.data.name, command);
                    commandCategories[folder].push(command.data.name);
                    folderCommands++;
                    totalCommands++;
                } else {
                    console.warn(`\x1b[33m⚠️  Command ${file} is missing data or execute property\x1b[0m`);
                }
            } catch (error) {
                console.error(`\x1b[31m❌ Error loading command ${file}:\x1b[0m`, error.message);
                if (process.env.NODE_ENV === 'development') {
                    console.error(error.stack);
                }
            }
        }
        
        if (folderCommands > 0) {
            console.log(`\x1b[32m   ✅ ${folder}: ${folderCommands} commands\x1b[0m`);
        }
    }
}

console.log(`\x1b[32m✅ Loaded ${totalCommands} commands across ${Object.keys(commandCategories).length} categories\x1b[0m\n`);

// Load events with better error handling
console.log('\x1b[33m⚡ Loading event handlers...\x1b[0m');
const eventsPath = path.join(__dirname, 'events');
let totalEvents = 0;

if (fs.existsSync(eventsPath)) {
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));
    
    for (const file of eventFiles) {
        const filePath = path.join(eventsPath, file);
        try {
            // Clear require cache for hot reloading
            delete require.cache[require.resolve(filePath)];
            const event = require(filePath);
            
            if (event.name) {
                if (event.once) {
                    client.once(event.name, (...args) => {
                        try {
                            event.execute(...args);
                        } catch (error) {
                            console.error(`\x1b[31m❌ Error in event ${event.name}:\x1b[0m`, error);
                        }
                    });
                } else {
                    client.on(event.name, (...args) => {
                        try {
                            event.execute(...args);
                        } catch (error) {
                            console.error(`\x1b[31m❌ Error in event ${event.name}:\x1b[0m`, error);
                        }
                    });
                }
                totalEvents++;
                console.log(`\x1b[32m   ✅ ${file}\x1b[0m`);
            } else {
                console.warn(`\x1b[33m⚠️  Event ${file} is missing name property\x1b[0m`);
            }
        } catch (error) {
            console.error(`\x1b[31m❌ Error loading event ${file}:\x1b[0m`, error.message);
            if (process.env.NODE_ENV === 'development') {
                console.error(error.stack);
            }
        }
    }
}

console.log(`\x1b[32m✅ Loaded ${totalEvents} event handlers\x1b[0m\n`);

// Connect to database with retry logic
console.log('\x1b[33m🗄️  Connecting to PostgreSQL...\x1b[0m');

async function connectDatabase(retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            await initDatabase();
            console.log('\x1b[32m✅ Connected to PostgreSQL successfully\x1b[0m');
            console.log('\x1b[32m✅ Database tables initialized\x1b[0m\n');
            return;
        } catch (err) {
            console.error(`\x1b[31m❌ PostgreSQL connection attempt ${i + 1} failed:\x1b[0m`, err.message);
            if (i === retries - 1) {
                console.error('\x1b[31m❌ Failed to connect to PostgreSQL after all retries\x1b[0m');
                process.exit(1);
            }
            console.log(`\x1b[33m🔄 Retrying in 5 seconds...\x1b[0m`);
            await new Promise(resolve => setTimeout(resolve, 5000));
        }
    }
}

// Enhanced error handling
process.on('unhandledRejection', (reason, promise) => {
    console.error('\x1b[31m❌ Unhandled Rejection at:\x1b[0m', promise);
    console.error('\x1b[31m❌ Reason:\x1b[0m', reason);
    botStats.errors++;
});

process.on('uncaughtException', (error) => {
    console.error('\x1b[31m❌ Uncaught Exception:\x1b[0m', error);
    botStats.errors++;
    // Don't exit immediately, log and continue
    if (error.code !== 'ECONNRESET') {
        process.exit(1);
    }
});

// Graceful shutdown
const shutdown = (signal) => {
    console.log(`\x1b[33m\n🔄 Received ${signal}, shutting down gracefully...\x1b[0m`);
    console.log('\x1b[36m📊 Bot Statistics:\x1b[0m');
    console.log(`\x1b[36m   - Uptime: ${Math.floor((Date.now() - botStats.startTime) / 1000)}s\x1b[0m`);
    console.log(`\x1b[36m   - Commands executed: ${botStats.commandsExecuted}\x1b[0m`);
    console.log(`\x1b[36m   - Messages processed: ${botStats.messagesProcessed}\x1b[0m`);
    console.log(`\x1b[36m   - Errors: ${botStats.errors}\x1b[0m`);
    
    if (client.isReady()) {
        client.destroy();
    }
    process.exit(0);
};

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

// Bot ready event
client.once('ready', () => {
    console.log('\x1b[32m🎉 Caroline Bot is online and ready!\x1b[0m');
    console.log(`\x1b[36m👤 Logged in as: ${client.user.tag}\x1b[0m`);
    console.log(`\x1b[36m🆔 Bot ID: ${client.user.id}\x1b[0m`);
    console.log(`\x1b[36m🏠 Servers: ${client.guilds.cache.size}\x1b[0m`);
    console.log(`\x1b[36m👥 Users: ${client.users.cache.size}\x1b[0m`);
    console.log(`\x1b[36m📝 Commands: ${totalCommands}\x1b[0m`);
    console.log(`\x1b[36m⚡ Events: ${totalEvents}\x1b[0m\n`);
    
    // Set bot activity
    const activities = [
        { name: 'Caroline Bot v3.0', type: ActivityType.Playing },
        { name: `${client.guilds.cache.size} servers`, type: ActivityType.Watching },
        { name: 'with PostgreSQL', type: ActivityType.Playing },
        { name: '/help for commands', type: ActivityType.Listening }
    ];
    
    let activityIndex = 0;
    const updateActivity = () => {
        client.user.setActivity(activities[activityIndex]);
        activityIndex = (activityIndex + 1) % activities.length;
    };
    
    updateActivity();
    setInterval(updateActivity, 30000); // Change every 30 seconds
});

// Enhanced command execution tracking
client.on('interactionCreate', async (interaction) => {
    if (interaction.isCommand()) {
        botStats.commandsExecuted++;
    }
});

client.on('messageCreate', (message) => {
    if (!message.author.bot) {
        botStats.messagesProcessed++;
    }
});

// Login with enhanced error handling
console.log('\x1b[33m🔐 Logging in to Discord...\x1b[0m');

async function loginBot() {
    try {
        await connectDatabase();
        await client.login(process.env.BOT_TOKEN);
    } catch (error) {
        console.error('\x1b[31m❌ Failed to login to Discord:\x1b[0m', error.message);
        
        if (error.code === 'TokenInvalid') {
            console.error('\x1b[31m💡 Please check your BOT_TOKEN in .env file\x1b[0m');
        } else if (error.code === 'DisallowedIntents') {
            console.error('\x1b[31m💡 Please enable required intents in Discord Developer Portal\x1b[0m');
        }
        
        process.exit(1);
    }
}

// Start the bot
loginBot();

// Export client for testing purposes
module.exports = client;