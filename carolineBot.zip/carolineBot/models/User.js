const pool = require('../database/connection');

class User {
    static async findOne(filter) {
        const { userId, guildId } = filter;
        const result = await pool.query('SELECT * FROM users WHERE user_id = $1 AND guild_id = $2', [userId, guildId]);
        return result.rows[0];
    }

    static async create(userData) {
        const { userId, guildId, xp = 0, level = 1, messages = 0, voice = 0, warnings = 0, invites = 0 } = userData;
        
        const result = await pool.query(`
            INSERT INTO users (user_id, guild_id, xp, level, messages, voice, warnings, invites)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            RETURNING *
        `, [userId, guildId, xp, level, messages, voice, warnings, invites]);
        
        return result.rows[0];
    }

    static async findOneAndUpdate(filter, update, options = {}) {
        const { userId, guildId } = filter;
        const existing = await this.findOne(filter);
        
        if (existing) {
            const fields = [];
            const values = [];
            let paramCount = 1;

            Object.keys(update).forEach(key => {
                if (update[key] !== undefined) {
                    fields.push(`${key} = $${paramCount}`);
                    values.push(update[key]);
                    paramCount++;
                }
            });

            values.push(userId, guildId);
            
            const result = await pool.query(`
                UPDATE users SET ${fields.join(', ')} WHERE user_id = $${paramCount} AND guild_id = $${paramCount + 1} RETURNING *
            `, values);
            
            return result.rows[0];
        } else if (options.upsert) {
            return await this.create({ userId, guildId, ...update });
        }
        return null;
    }

    static async find(filter = {}) {
        let query = 'SELECT * FROM users';
        const values = [];
        
        if (filter.guildId) {
            query += ' WHERE guild_id = $1';
            values.push(filter.guildId);
        }
        
        const result = await pool.query(query, values);
        return result.rows;
    }

    static async findByIdAndUpdate(id, update) {
        const fields = [];
        const values = [];
        let paramCount = 1;

        Object.keys(update).forEach(key => {
            fields.push(`${key} = $${paramCount}`);
            values.push(update[key]);
            paramCount++;
        });

        values.push(id);
        
        const result = await pool.query(`
            UPDATE users SET ${fields.join(', ')} WHERE id = $${paramCount} RETURNING *
        `, values);
        
        return result.rows[0];
    }
}

module.exports = User;