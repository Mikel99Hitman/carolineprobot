const mongoose = require('mongoose');

const countingSchema = new mongoose.Schema({
    guildId: { type: String, required: true },
    channelId: { type: String, required: true },
    currentNumber: { type: Number, default: 0 },
    lastUserId: { type: String, default: null },
    highestNumber: { type: Number, default: 0 },
    fails: { type: Number, default: 0 }
});

module.exports = mongoose.model('Counting', countingSchema);