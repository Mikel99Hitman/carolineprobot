const pool = require('../database/connection');

class Giveaway {
    static async create(giveawayData) {
        const { guildId, channelId, messageId, hostId, prize, winners, endTime, 
                participants = [], ended = false, requirements = {} } = giveawayData;
        
        const result = await pool.query(`
            INSERT INTO giveaways (guild_id, channel_id, message_id, host_id, prize, winners, 
                                 end_time, participants, ended, required_role, required_level, required_invites)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
            RETURNING *
        `, [guildId, channelId, messageId, hostId, prize, winners, endTime, participants, 
            ended, requirements.role, requirements.level || 0, requirements.invites || 0]);
        
        return result.rows[0];
    }

    static async findOne(filter) {
        const keys = Object.keys(filter);
        const values = Object.values(filter);
        const conditions = keys.map((key, index) => {
            const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
            return `${dbKey} = $${index + 1}`;
        });
        
        const result = await pool.query(`SELECT * FROM giveaways WHERE ${conditions.join(' AND ')}`, values);
        return result.rows[0];
    }

    static async find(filter = {}) {
        let query = 'SELECT * FROM giveaways';
        const values = [];
        const conditions = [];
        let paramCount = 1;

        Object.keys(filter).forEach(key => {
            const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
            conditions.push(`${dbKey} = $${paramCount}`);
            values.push(filter[key]);
            paramCount++;
        });

        if (conditions.length > 0) {
            query += ` WHERE ${conditions.join(' AND ')}`;
        }
        
        const result = await pool.query(query, values);
        return result.rows;
    }

    static async findOneAndUpdate(filter, update) {
        const existing = await this.findOne(filter);
        
        if (existing) {
            const fields = [];
            const values = [];
            let paramCount = 1;

            Object.keys(update).forEach(key => {
                const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
                fields.push(`${dbKey} = $${paramCount}`);
                values.push(update[key]);
                paramCount++;
            });

            values.push(existing.id);
            
            const result = await pool.query(`
                UPDATE giveaways SET ${fields.join(', ')} WHERE id = $${paramCount} RETURNING *
            `, values);
            
            return result.rows[0];
        }
        return null;
    }

    static async deleteOne(filter) {
        const keys = Object.keys(filter);
        const values = Object.values(filter);
        const conditions = keys.map((key, index) => {
            const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
            return `${dbKey} = $${index + 1}`;
        });
        
        await pool.query(`DELETE FROM giveaways WHERE ${conditions.join(' AND ')}`, values);
    }
}

module.exports = Giveaway;