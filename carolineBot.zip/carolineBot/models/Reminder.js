const mongoose = require('mongoose');

const reminderSchema = new mongoose.Schema({
    userId: { type: String, required: true },
    guildId: { type: String, required: true },
    channelId: { type: String, required: true },
    message: { type: String, required: true },
    remindTime: { type: Date, required: true },
    recurring: {
        enabled: { type: Boolean, default: false },
        interval: { type: String, default: null } // daily, weekly, monthly
    },
    completed: { type: Boolean, default: false }
});

module.exports = mongoose.model('Reminder', reminderSchema);