const mongoose = require('mongoose');

const quoteSchema = new mongoose.Schema({
    guildId: { type: String, required: true },
    messageId: { type: String, required: true },
    channelId: { type: String, required: true },
    authorId: { type: String, required: true },
    content: { type: String, required: true },
    quotedBy: { type: String, required: true },
    quoteId: { type: Number, required: true },
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Quote', quoteSchema);