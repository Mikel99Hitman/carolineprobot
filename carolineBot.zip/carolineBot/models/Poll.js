const mongoose = require('mongoose');

const pollSchema = new mongoose.Schema({
    guildId: { type: String, required: true },
    channelId: { type: String, required: true },
    messageId: { type: String, required: true },
    creatorId: { type: String, required: true },
    question: { type: String, required: true },
    options: [{
        text: String,
        emoji: String,
        votes: [String]
    }],
    endTime: { type: Date, required: true },
    ended: { type: Boolean, default: false },
    allowMultiple: { type: Boolean, default: false },
    anonymous: { type: Boolean, default: false }
});

module.exports = mongoose.model('Poll', pollSchema);