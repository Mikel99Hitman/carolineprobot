const mongoose = require('mongoose');

const birthdaySchema = new mongoose.Schema({
    userId: { type: String, required: true },
    guildId: { type: String, required: true },
    birthday: { type: Date, required: true },
    timezone: { type: String, default: 'UTC' },
    private: { type: Boolean, default: false }
});

module.exports = mongoose.model('Birthday', birthdaySchema);