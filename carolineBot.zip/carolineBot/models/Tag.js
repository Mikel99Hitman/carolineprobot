const mongoose = require('mongoose');

const tagSchema = new mongoose.Schema({
    guildId: { type: String, required: true },
    name: { type: String, required: true },
    content: { type: String, required: true },
    authorId: { type: String, required: true },
    uses: { type: Number, default: 0 },
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Tag', tagSchema);