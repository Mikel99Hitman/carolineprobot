const mongoose = require('mongoose');

const wordFilterSchema = new mongoose.Schema({
    guildId: { type: String, required: true },
    words: [String],
    action: { type: String, enum: ['delete', 'warn', 'mute'], default: 'delete' },
    whitelist: [String],
    enabled: { type: Boolean, default: true }
});

module.exports = mongoose.model('WordFilter', wordFilterSchema);