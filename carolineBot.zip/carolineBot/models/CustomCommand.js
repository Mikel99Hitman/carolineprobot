const mongoose = require('mongoose');

const customCommandSchema = new mongoose.Schema({
    guildId: { type: String, required: true },
    name: { type: String, required: true },
    response: { type: String, required: true },
    authorId: { type: String, required: true },
    uses: { type: Number, default: 0 },
    embed: { type: Boolean, default: false },
    deleteAfter: { type: Number, default: 0 },
    requiredRole: { type: String, default: null },
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('CustomCommand', customCommandSchema);