const mongoose = require('mongoose');

const tempVoiceSchema = new mongoose.Schema({
    guildId: { type: String, required: true },
    creatorChannelId: { type: String, required: true },
    categoryId: { type: String, required: true },
    tempChannels: [{
        channelId: String,
        ownerId: String,
        createdAt: { type: Date, default: Date.now }
    }]
});

module.exports = mongoose.model('TempVoice', tempVoiceSchema);