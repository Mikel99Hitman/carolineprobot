const pool = require('../database/connection');

class Ticket {
    static async findOne(filter) {
        const keys = Object.keys(filter);
        const values = Object.values(filter);
        const conditions = keys.map((key, index) => {
            const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
            return `${dbKey} = $${index + 1}`;
        });
        
        const result = await pool.query(`SELECT * FROM tickets WHERE ${conditions.join(' AND ')}`, values);
        return result.rows[0];
    }

    static async create(ticketData) {
        const { ticketId, guildId, userId, channelId, status = 'open', reason = 'عام' } = ticketData;
        
        const result = await pool.query(`
            INSERT INTO tickets (ticket_id, guild_id, user_id, channel_id, status, reason)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING *
        `, [ticketId, guildId, userId, channelId, status, reason]);
        
        return result.rows[0];
    }

    static async findOneAndUpdate(filter, update) {
        const existing = await this.findOne(filter);
        
        if (existing) {
            const fields = [];
            const values = [];
            let paramCount = 1;

            Object.keys(update).forEach(key => {
                const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
                fields.push(`${dbKey} = $${paramCount}`);
                values.push(update[key]);
                paramCount++;
            });

            values.push(existing.id);
            
            const result = await pool.query(`
                UPDATE tickets SET ${fields.join(', ')} WHERE id = $${paramCount} RETURNING *
            `, values);
            
            return result.rows[0];
        }
        return null;
    }

    static async find(filter = {}) {
        let query = 'SELECT * FROM tickets';
        const values = [];
        const conditions = [];
        let paramCount = 1;

        Object.keys(filter).forEach(key => {
            const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
            conditions.push(`${dbKey} = $${paramCount}`);
            values.push(filter[key]);
            paramCount++;
        });

        if (conditions.length > 0) {
            query += ` WHERE ${conditions.join(' AND ')}`;
        }
        
        const result = await pool.query(query, values);
        return result.rows;
    }

    static async deleteOne(filter) {
        const keys = Object.keys(filter);
        const values = Object.values(filter);
        const conditions = keys.map((key, index) => {
            const dbKey = key.replace(/([A-Z])/g, '_$1').toLowerCase();
            return `${dbKey} = $${index + 1}`;
        });
        
        await pool.query(`DELETE FROM tickets WHERE ${conditions.join(' AND ')}`, values);
    }
}

module.exports = Ticket;