# 📊 Caroline Bot - Logging System

## ✅ نعم، البوت يرسل جميع الـ logs في Discord عبر Webhooks

### 🎯 الميزات الرئيسية:
- **📝 تسجيل شامل** لجميع أحداث الخادم
- **🔗 إرسال عبر Discord Webhooks** تلقائياً
- **💾 حفظ في قاعدة البيانات** PostgreSQL
- **📍 إرسال لقناة مخصصة** في الخادم
- **🎨 رسائل منسقة** مع Embeds ملونة

### 📋 الأحداث المُسجلة:

#### 💬 أحداث الرسائل
- **🗑️ MESSAGE_DELETE** - حذف الرسائل
- **✏️ MESSAGE_EDIT** - تعديل الرسائل

#### 👥 أحداث الأعضاء  
- **📥 MEMBER_JOIN** - انضمام عضو جديد
- **📤 MEMBER_LEAVE** - مغادرة عضو
- **🔨 MEMBER_BAN** - حظر عضو
- **🔓 MEMBER_UNBAN** - إلغاء حظر عضو
- **👢 MEMBER_KICK** - طرد عضو

#### 🎤 أحداث الصوت
- **🔊 VOICE_JOIN** - دخول قناة صوتية
- **🔇 VOICE_LEAVE** - مغادرة قناة صوتية
- **🔄 VOICE_MOVE** - الانتقال بين القنوات

#### 🎭 أحداث الأدوار
- **➕ ROLE_ADD** - إضافة دور
- **➖ ROLE_REMOVE** - إزالة دور

#### 📁 أحداث القنوات
- **📁 CHANNEL_CREATE** - إنشاء قناة
- **🗑️ CHANNEL_DELETE** - حذف قناة

#### 🔗 أحداث الدعوات
- **🔗 INVITE_CREATE** - إنشاء دعوة

#### ⚡ أحداث الأوامر
- **💻 COMMAND_USE** - استخدام الأوامر

#### 🎉 أحداث الجوائز
- **🎉 GIVEAWAY_START** - بداية جائزة
- **🏆 GIVEAWAY_END** - انتهاء جائزة

### 🔧 كيفية الإعداد:

#### 1. إعداد قناة الـ logs:
```bash
/setup logs channel:#logs-channel
```

#### 2. إعداد Webhook:
```bash
/setup webhook url:https://discord.com/api/webhooks/your_webhook_url
```

#### 3. إعداد كامل:
```bash
/setup logs channel:#logs webhook:https://discord.com/api/webhooks/your_webhook_url
```

### 📊 مثال على رسالة Log:

```json
{
  "title": "🗑️ Message Deleted",
  "color": "#ff0000",
  "fields": [
    {
      "name": "👤 Author",
      "value": "@username (username#1234)",
      "inline": true
    },
    {
      "name": "📍 Channel", 
      "value": "#general",
      "inline": true
    },
    {
      "name": "📝 Content",
      "value": "The deleted message content",
      "inline": false
    }
  ],
  "footer": {
    "text": "User ID: 123456789"
  },
  "timestamp": "2024-12-20T10:30:00Z"
}
```

### 🗄️ حفظ في قاعدة البيانات:

```sql
CREATE TABLE logs (
    id SERIAL PRIMARY KEY,
    guild_id VARCHAR(20) NOT NULL,
    log_type VARCHAR(50) NOT NULL,
    user_id VARCHAR(20),
    channel_id VARCHAR(20),
    content TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 🔗 إرسال عبر Webhook:

```javascript
// يتم إرسال جميع الـ logs تلقائياً عبر:
// 1. قناة Discord المخصصة
// 2. Webhook URL المحدد
// 3. حفظ في قاعدة البيانات

await Logger.log(guild, 'MESSAGE_DELETE', {
    author: message.author,
    channel: message.channel,
    content: message.content
});
```

### ⚙️ الملفات المُحدثة:

- **✅ utils/Logger.js** - نظام الـ logging الرئيسي
- **✅ events/messageDelete.js** - تسجيل حذف الرسائل
- **✅ events/messageUpdate.js** - تسجيل تعديل الرسائل  
- **✅ events/guildMemberAdd.js** - تسجيل انضمام الأعضاء
- **✅ events/guildMemberRemove.js** - تسجيل مغادرة الأعضاء
- **✅ events/interactionCreate.js** - تسجيل استخدام الأوامر

### 🎯 المميزات:

#### ✅ شامل ومتكامل:
- **جميع الأحداث** مُسجلة
- **رسائل منسقة** وملونة
- **معلومات مفصلة** لكل حدث

#### ✅ مرن ومتعدد الوجهات:
- **قناة Discord** مخصصة
- **Discord Webhooks** تلقائية
- **قاعدة بيانات** للأرشفة

#### ✅ سهل الإعداد:
- **أمر واحد** للإعداد الكامل
- **تشغيل تلقائي** فور الإعداد
- **لا يحتاج تدخل** بعد الإعداد

---

## 🏆 النتيجة النهائية:

**نعم، Caroline Bot يرسل جميع الـ logs في Discord عبر Webhooks بشكل تلقائي وشامل!**

- ✅ **20+ نوع حدث** مُسجل
- ✅ **إرسال تلقائي** عبر Webhooks
- ✅ **رسائل منسقة** ومفصلة
- ✅ **حفظ في قاعدة البيانات**
- ✅ **سهل الإعداد** والاستخدام

**تم بواسطة: Mikel99Hitman**  
**التاريخ: ديسمبر 2024**