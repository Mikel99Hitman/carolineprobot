const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const User = require('../../models/User');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('stats')
        .setDescription('View server statistics'),

    async execute(interaction) {
        const guild = interaction.guild;
        const users = await User.find({ guildId: guild.id });
        
        const totalXP = users.reduce((sum, user) => sum + user.xp, 0);
        const totalMessages = users.reduce((sum, user) => sum + user.messages, 0);
        const avgLevel = users.length > 0 ? (users.reduce((sum, user) => sum + user.level, 0) / users.length).toFixed(1) : 0;

        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('📊 Server Statistics')
            .setThumbnail(guild.iconURL())
            .addFields(
                { name: '👥 Total Members', value: guild.memberCount.toString(), inline: true },
                { name: '🤖 Bots', value: guild.members.cache.filter(m => m.user.bot).size.toString(), inline: true },
                { name: '👤 Humans', value: guild.members.cache.filter(m => !m.user.bot).size.toString(), inline: true },
                { name: '💬 Total Messages', value: totalMessages.toLocaleString(), inline: true },
                { name: '⭐ Total XP', value: totalXP.toLocaleString(), inline: true },
                { name: '📈 Average Level', value: avgLevel, inline: true },
                { name: '📝 Text Channels', value: guild.channels.cache.filter(c => c.type === 0).size.toString(), inline: true },
                { name: '🔊 Voice Channels', value: guild.channels.cache.filter(c => c.type === 2).size.toString(), inline: true },
                { name: '🎭 Roles', value: guild.roles.cache.size.toString(), inline: true }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};