const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const User = require('../../models/User');
const Economy = require('../../models/Economy');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('insights')
        .setDescription('Advanced server insights and predictions'),

    async execute(interaction) {
        await interaction.deferReply();

        const guild = interaction.guild;
        const users = await User.find({ guildId: guild.id });
        const economy = await Economy.find({ guildId: guild.id });

        // Calculate insights
        const totalMessages = users.reduce((sum, u) => sum + u.messages, 0);
        const avgMessagesPerUser = totalMessages / users.length || 0;
        const totalEconomy = economy.reduce((sum, e) => sum + e.balance + e.bank, 0);
        
        // Activity prediction
        const recentActivity = users.filter(u => u.messages > avgMessagesPerUser).length;
        const activityTrend = recentActivity > users.length * 0.6 ? '📈 Growing' : '📉 Declining';
        
        // Member retention
        const activeMembers = users.filter(u => u.messages > 10).length;
        const retentionRate = ((activeMembers / guild.memberCount) * 100).toFixed(1);
        
        // Economy health
        const economyHealth = totalEconomy > 100000 ? '💰 Healthy' : '💸 Developing';
        
        // Engagement score
        const engagementScore = Math.min(100, Math.floor(
            (avgMessagesPerUser * 0.3) + 
            (parseFloat(retentionRate) * 0.4) + 
            (recentActivity / users.length * 100 * 0.3)
        ));

        const embed = new EmbedBuilder()
            .setColor('#9932cc')
            .setTitle('🔮 Server Insights & Predictions')
            .setDescription('AI-powered analysis of your server\'s health and trends')
            .addFields(
                { name: '📊 Activity Trend', value: activityTrend, inline: true },
                { name: '🎯 Engagement Score', value: `${engagementScore}/100`, inline: true },
                { name: '👥 Retention Rate', value: `${retentionRate}%`, inline: true },
                { name: '💰 Economy Health', value: economyHealth, inline: true },
                { name: '📈 Growth Potential', value: engagementScore > 70 ? 'High' : 'Medium', inline: true },
                { name: '🔥 Activity Level', value: avgMessagesPerUser > 50 ? 'Very Active' : 'Moderate', inline: true },
                { name: '📋 Recommendations', value: getRecommendations(engagementScore, retentionRate, avgMessagesPerUser), inline: false },
                { name: '🎯 Predicted Growth', value: `+${Math.floor(engagementScore / 10)}% next month`, inline: true },
                { name: '⭐ Server Rating', value: getServerRating(engagementScore), inline: true }
            )
            .setFooter({ text: 'Insights updated in real-time' })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    }
};

function getRecommendations(engagement, retention, avgMessages) {
    const recommendations = [];
    
    if (engagement < 50) recommendations.push('• Host more events');
    if (retention < 60) recommendations.push('• Improve welcome experience');
    if (avgMessages < 20) recommendations.push('• Create discussion topics');
    
    return recommendations.length > 0 ? recommendations.join('\n') : '• Server is performing well!';
}

function getServerRating(score) {
    if (score >= 90) return '⭐⭐⭐⭐⭐ Excellent';
    if (score >= 70) return '⭐⭐⭐⭐ Great';
    if (score >= 50) return '⭐⭐⭐ Good';
    if (score >= 30) return '⭐⭐ Fair';
    return '⭐ Needs Improvement';
}