const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('userinfo')
        .setDescription('Display detailed user information')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to display information for')
                .setRequired(false)),

    async execute(interaction) {
        const targetUser = interaction.options.getUser('user') || interaction.user;
        const member = interaction.guild.members.cache.get(targetUser.id);

        if (!member) {
            return interaction.reply({ content: '❌ User not found in server!', ephemeral: true });
        }

        try {
            // Get user data from PostgreSQL
            const userResult = await pool.query(
                'SELECT * FROM users WHERE user_id = $1 AND guild_id = $2',
                [targetUser.id, interaction.guild.id]
            );

            const userData = userResult.rows[0];

            // Get economy data
            const economyResult = await pool.query(
                'SELECT balance, bank FROM economy WHERE user_id = $1 AND guild_id = $2',
                [targetUser.id, interaction.guild.id]
            );

            const economyData = economyResult.rows[0];

            const userEmbed = new EmbedBuilder()
                .setColor(member.displayHexColor || '#0099ff')
                .setTitle(`📋 ${member.displayName}'s Information`)
                .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 256 }))
                .addFields(
                    { name: '👤 Username', value: targetUser.username, inline: true },
                    { name: '🏷️ Tag', value: targetUser.tag, inline: true },
                    { name: '🆔 User ID', value: targetUser.id, inline: true },
                    { name: '📅 Account Created', value: `<t:${Math.floor(targetUser.createdTimestamp / 1000)}:F>`, inline: true },
                    { name: '📥 Joined Server', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:F>`, inline: true },
                    { name: '🎭 Roles', value: member.roles.cache.filter(role => role.id !== interaction.guild.id).map(role => role.toString()).join(', ') || 'No roles', inline: false }
                )
                .setTimestamp();

            // Add user stats if available
            if (userData) {
                userEmbed.addFields(
                    { name: '📊 Level', value: userData.level.toString(), inline: true },
                    { name: '⭐ XP', value: `${userData.xp}/${userData.level * 100}`, inline: true },
                    { name: '💬 Messages', value: userData.messages.toString(), inline: true },
                    { name: '⚠️ Warnings', value: userData.warnings.toString(), inline: true },
                    { name: '🎤 Voice Time', value: `${Math.floor(userData.voice / 60)}h ${userData.voice % 60}m`, inline: true }
                );
            }

            // Add economy data if available
            if (economyData) {
                const balance = parseInt(economyData.balance) || 0;
                const bank = parseInt(economyData.bank) || 0;
                userEmbed.addFields(
                    { name: '💰 Wallet', value: `$${balance.toLocaleString()}`, inline: true },
                    { name: '🏦 Bank', value: `$${bank.toLocaleString()}`, inline: true },
                    { name: '💎 Net Worth', value: `$${(balance + bank).toLocaleString()}`, inline: true }
                );
            }

            // Add status information
            const status = {
                'online': '🟢 Online',
                'idle': '🟡 Idle',
                'dnd': '🔴 Do Not Disturb',
                'offline': '⚫ Offline'
            };

            userEmbed.addFields({
                name: '📱 Status',
                value: status[member.presence?.status] || '⚫ Offline',
                inline: true
            });

            // Add current activity
            if (member.presence?.activities?.length > 0) {
                const activity = member.presence.activities[0];
                userEmbed.addFields({
                    name: '🎮 Activity',
                    value: `${activity.name}`,
                    inline: true
                });
            }

            // Add permissions info
            const keyPermissions = member.permissions.toArray().filter(perm => 
                ['Administrator', 'ManageGuild', 'ManageChannels', 'ManageRoles', 'BanMembers', 'KickMembers'].includes(perm)
            );

            if (keyPermissions.length > 0) {
                userEmbed.addFields({
                    name: '🔑 Key Permissions',
                    value: keyPermissions.join(', '),
                    inline: false
                });
            }

            await interaction.reply({ embeds: [userEmbed] });

        } catch (error) {
            console.error('Userinfo command error:', error);
            await interaction.reply({ 
                content: '❌ An error occurred while fetching user information.', 
                ephemeral: true 
            });
        }
    }
};