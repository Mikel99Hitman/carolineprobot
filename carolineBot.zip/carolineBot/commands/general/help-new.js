const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const { Pool } = require('pg');
const axios = require('axios');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('📚 Comprehensive help system with interactive navigation')
        .addStringOption(option =>
            option.setName('category')
                .setDescription('Command category to view')
                .setRequired(false)
                .addChoices(
                    { name: 'Admin & Moderation', value: 'admin' },
                    { name: 'Music & Entertainment', value: 'music' },
                    { name: 'Economy & Games', value: 'economy' },
                    { name: 'Utility & Tools', value: 'utility' },
                    { name: 'Gaming & FiveM', value: 'gaming' },
                    { name: 'News & Information', value: 'news' },
                    { name: 'Security & Protection', value: 'security' },
                    { name: 'General Commands', value: 'general' }
                ))
        .addStringOption(option =>
            option.setName('webhook_url')
                .setDescription('Webhook URL for help notifications')
                .setRequired(false)),
    
    async execute(interaction) {
        const category = interaction.options.getString('category');
        const webhookUrl = interaction.options.getString('webhook_url');
        
        try {
            await this.createTables();
            
            // Log help usage
            await this.logHelpUsage(interaction, category);
            
            if (category) {
                await this.showCategoryHelp(interaction, category, webhookUrl);
            } else {
                await this.showMainHelp(interaction, webhookUrl);
            }
        } catch (error) {
            console.error('Help command error:', error);
            await interaction.reply({ content: '❌ An error occurred while loading help information.', ephemeral: true });
        }
    },

    async createTables() {
        await pool.query(`
            CREATE TABLE IF NOT EXISTS help_usage (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                category VARCHAR(50),
                command_searched VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
    },

    async logHelpUsage(interaction, category) {
        await pool.query(
            'INSERT INTO help_usage (user_id, guild_id, category) VALUES ($1, $2, $3)',
            [interaction.user.id, interaction.guild.id, category || 'main']
        );
    },

    async showMainHelp(interaction, webhookUrl) {
        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('📚 Caroline Bot - Complete Command Guide')
            .setDescription('**Welcome to Caroline Bot!** Your all-in-one Discord server management solution.\n\nSelect a category below to explore commands, or use the dropdown menu for quick navigation.')
            .addFields(
                {
                    name: '👑 Admin & Moderation (25+ commands)',
                    value: 'Server management, user moderation, automod, logging, and protection systems',
                    inline: true
                },
                {
                    name: '🎵 Music & Entertainment (15+ commands)',
                    value: 'Music player, playlists, sound effects, and entertainment features',
                    inline: true
                },
                {
                    name: '💰 Economy & Games (20+ commands)',
                    value: 'Virtual economy, gambling, daily rewards, inventory, and mini-games',
                    inline: true
                },
                {
                    name: '🔧 Utility & Tools (30+ commands)',
                    value: 'Calculators, converters, polls, reminders, and productivity tools',
                    inline: true
                },
                {
                    name: '🎮 Gaming & FiveM (12+ commands)',
                    value: 'FiveM roleplay, server status, character management, and gaming utilities',
                    inline: true
                },
                {
                    name: '📰 News & Information (10+ commands)',
                    value: 'World news, tech updates, sports, entertainment, and live information feeds',
                    inline: true
                },
                {
                    name: '🛡️ Security & Protection (8+ commands)',
                    value: 'Cybersecurity tools, threat analysis, compliance audits, and security monitoring',
                    inline: true
                },
                {
                    name: '📝 General Commands (15+ commands)',
                    value: 'User info, server stats, avatars, and basic utility commands',
                    inline: true
                },
                {
                    name: '📈 Bot Statistics',
                    value: `**Total Commands:** 135+\n**Servers:** ${interaction.client.guilds.cache.size}\n**Users:** ${interaction.client.users.cache.size}\n**Uptime:** <t:${Math.floor((Date.now() - interaction.client.uptime) / 1000)}:R>`,
                    inline: false
                }
            )
            .setThumbnail(interaction.client.user.displayAvatarURL())
            .setFooter({ text: 'Caroline Bot • Professional Discord Management', iconURL: interaction.client.user.displayAvatarURL() })
            .setTimestamp();

        const categorySelect = new StringSelectMenuBuilder()
            .setCustomId('help_category_select')
            .setPlaceholder('📚 Select a category to explore...')
            .addOptions([
                {
                    label: 'Admin & Moderation',
                    description: 'Server management and moderation tools',
                    value: 'admin',
                    emoji: '👑'
                },
                {
                    label: 'Music & Entertainment',
                    description: 'Music player and entertainment features',
                    value: 'music',
                    emoji: '🎵'
                },
                {
                    label: 'Economy & Games',
                    description: 'Virtual economy and gaming systems',
                    value: 'economy',
                    emoji: '💰'
                },
                {
                    label: 'Utility & Tools',
                    description: 'Productivity and utility commands',
                    value: 'utility',
                    emoji: '🔧'
                },
                {
                    label: 'Gaming & FiveM',
                    description: 'Gaming utilities and FiveM integration',
                    value: 'gaming',
                    emoji: '🎮'
                },
                {
                    label: 'News & Information',
                    description: 'News feeds and information services',
                    value: 'news',
                    emoji: '📰'
                },
                {
                    label: 'Security & Protection',
                    description: 'Cybersecurity and protection tools',
                    value: 'security',
                    emoji: '🛡️'
                },
                {
                    label: 'General Commands',
                    description: 'Basic utility and information commands',
                    value: 'general',
                    emoji: '📝'
                }
            ]);

        const buttonRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('help_quick_start')
                    .setLabel('🚀 Quick Start Guide')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('help_support')
                    .setLabel('📞 Support Server')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('help_invite')
                    .setLabel('🔗 Invite Bot')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('help_premium')
                    .setLabel('⭐ Premium Features')
                    .setStyle(ButtonStyle.Secondary)
            );

        const selectRow = new ActionRowBuilder().addComponents(categorySelect);

        await interaction.reply({ 
            embeds: [embed], 
            components: [selectRow, buttonRow]
        });

        // Send webhook notification if provided
        if (webhookUrl) {
            await this.sendWebhookNotification(webhookUrl, {
                title: '📚 Help Command Used',
                description: `**User:** ${interaction.user.tag}\n**Server:** ${interaction.guild.name}\n**Category:** Main Help`,
                color: 0x0099ff,
                timestamp: new Date().toISOString()
            });
        }
    },

    async showCategoryHelp(interaction, category, webhookUrl) {
        const categories = {
            admin: {
                title: '👑 Admin & Moderation Commands',
                color: '#dc143c',
                description: 'Comprehensive server management and moderation tools',
                commands: [
                    '`/setup` - Configure bot settings and features',
                    '`/warn` - Issue warnings to members with tracking',
                    '`/kick` - Remove members from the server',
                    '`/ban` - Permanently ban members with reason logging',
                    '`/unban` - Remove bans and restore access',
                    '`/timeout` - Temporarily mute members',
                    '`/clear` - Bulk delete messages with filters',
                    '`/slowmode` - Set channel message cooldowns',
                    '`/lock` - Lock channels to prevent messaging',
                    '`/unlock` - Restore channel permissions',
                    '`/role` - Manage member roles efficiently',
                    '`/automod` - Configure automatic moderation',
                    '`/filter` - Advanced word filtering system',
                    '`/logs` - Comprehensive server logging',
                    '`/backup` - Server backup and restoration'
                ]
            },
            music: {
                title: '🎵 Music & Entertainment Commands',
                color: '#9932cc',
                description: 'High-quality music streaming and entertainment features',
                commands: [
                    '`/play` - Play music from YouTube, Spotify, SoundCloud',
                    '`/pause` - Pause current playback',
                    '`/resume` - Resume paused music',
                    '`/stop` - Stop music and clear queue',
                    '`/skip` - Skip to next song in queue',
                    '`/queue` - View and manage music queue',
                    '`/volume` - Adjust playback volume',
                    '`/loop` - Enable song/queue looping',
                    '`/shuffle` - Randomize queue order',
                    '`/lyrics` - Display song lyrics',
                    '`/nowplaying` - Current song information',
                    '`/playlist` - Manage custom playlists',
                    '`/radio` - Stream online radio stations',
                    '`/soundboard` - Play sound effects',
                    '`/karaoke` - Karaoke mode with lyrics'
                ]
            },
            economy: {
                title: '💰 Economy & Games Commands',
                color: '#228b22',
                description: 'Virtual economy system with engaging mini-games',
                commands: [
                    '`/balance` - Check your virtual currency',
                    '`/daily` - Claim daily rewards and bonuses',
                    '`/work` - Earn money through various jobs',
                    '`/gamble` - Multiple gambling games (slots, blackjack, roulette)',
                    '`/shop` - Browse and purchase items',
                    '`/inventory` - Manage your items and collectibles',
                    '`/trade` - Trade items with other users',
                    '`/rob` - Attempt to steal from other users',
                    '`/heist` - Organize group heists for big rewards',
                    '`/lottery` - Participate in server lottery',
                    '`/coinflip` - Simple coin flip betting',
                    '`/dice` - Roll dice for gambling',
                    '`/rps` - Rock Paper Scissors with betting',
                    '`/trivia` - Answer questions for rewards',
                    '`/fishing` - Virtual fishing mini-game'
                ]
            },
            utility: {
                title: '🔧 Utility & Tools Commands',
                color: '#4169e1',
                description: 'Productivity tools and useful utilities',
                commands: [
                    '`/calculator` - Advanced scientific calculator',
                    '`/poll` - Create interactive polls with reactions',
                    '`/reminder` - Set personal reminders',
                    '`/timer` - Countdown timers with notifications',
                    '`/weather` - Real-time weather information',
                    '`/translate` - Multi-language translation',
                    '`/qr` - Generate QR codes',
                    '`/shorten` - URL shortening service',
                    '`/color` - Color palette and hex tools',
                    '`/embed` - Create custom embed messages',
                    '`/ascii` - Convert text to ASCII art',
                    '`/base64` - Encode/decode base64 text',
                    '`/hash` - Generate various hash types',
                    '`/password` - Generate secure passwords',
                    '`/timestamp` - Unix timestamp converter'
                ]
            },
            gaming: {
                title: '🎮 Gaming & FiveM Commands',
                color: '#ff4500',
                description: 'Gaming utilities and FiveM roleplay integration',
                commands: [
                    '`/fivem server` - Check FiveM server status',
                    '`/fivem character` - Manage roleplay characters',
                    '`/fivem jobs` - View and apply for RP jobs',
                    '`/fivem economy` - Track virtual finances',
                    '`/fivem whitelist` - Manage server applications',
                    '`/fivem vehicles` - Vehicle garage management',
                    '`/minecraft` - Minecraft server utilities',
                    '`/steam` - Steam profile and game info',
                    '`/valorant` - Valorant stats and ranks',
                    '`/fortnite` - Fortnite player statistics',
                    '`/apex` - Apex Legends player data',
                    '`/gamedeals` - Latest gaming deals and offers'
                ]
            },
            news: {
                title: '📰 News & Information Commands',
                color: '#ff6b6b',
                description: 'Stay updated with real-time news and information',
                commands: [
                    '`/world-news` - Global news and breaking stories',
                    '`/tech-news` - Technology and innovation updates',
                    '`/sports-news` - Sports scores and highlights',
                    '`/entertainment-news` - Celebrity and entertainment news',
                    '`/crypto` - Cryptocurrency prices and trends',
                    '`/stocks` - Stock market information',
                    '`/covid` - COVID-19 statistics and updates',
                    '`/earthquake` - Recent earthquake data',
                    '`/space` - Space news and astronomy updates',
                    '`/reddit` - Trending Reddit posts'
                ]
            },
            security: {
                title: '🛡️ Security & Protection Commands',
                color: '#8b0000',
                description: 'Cybersecurity tools and threat analysis',
                commands: [
                    '`/cybersecurity threat-intel` - Threat intelligence analysis',
                    '`/cybersecurity pentest` - Penetration testing simulation',
                    '`/cybersecurity incident` - Incident response procedures',
                    '`/cybersecurity compliance` - Security compliance audits',
                    '`/ip-lookup` - IP address geolocation and analysis',
                    '`/domain-check` - Domain security analysis',
                    '`/password-strength` - Password security testing',
                    '`/breach-check` - Check for data breaches'
                ]
            },
            general: {
                title: '📝 General Commands',
                color: '#708090',
                description: 'Basic utility and information commands',
                commands: [
                    '`/userinfo` - Detailed member information',
                    '`/serverinfo` - Comprehensive server statistics',
                    '`/avatar` - Display user avatars',
                    '`/banner` - Show user banners',
                    '`/roles` - List server roles',
                    '`/channels` - Server channel overview',
                    '`/emojis` - Server emoji list',
                    '`/boosters` - Server boost information',
                    '`/invites` - Invitation tracking',
                    '`/ping` - Bot latency and performance',
                    '`/uptime` - Bot uptime statistics',
                    '`/stats` - Comprehensive bot statistics',
                    '`/about` - Bot information and credits',
                    '`/changelog` - Recent updates and changes',
                    '`/feedback` - Submit feedback and suggestions'
                ]
            }
        };

        const categoryData = categories[category];
        if (!categoryData) {
            return interaction.reply({ content: '❌ Invalid category specified!', ephemeral: true });
        }

        const embed = new EmbedBuilder()
            .setColor(categoryData.color)
            .setTitle(categoryData.title)
            .setDescription(categoryData.description + '\n\n' + categoryData.commands.join('\n'))
            .addFields(
                { name: '📈 Total Commands', value: categoryData.commands.length.toString(), inline: true },
                { name: '🔄 Last Updated', value: '<t:1703980800:R>', inline: true },
                { name: '📚 Usage', value: 'Type `/command-name` to use', inline: true }
            )
            .setFooter({ text: `Caroline Bot • ${categoryData.title}`, iconURL: interaction.client.user.displayAvatarURL() })
            .setTimestamp();

        const backButton = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('help_back_main')
                    .setLabel('⬅️ Back to Main')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId(`help_examples_${category}`)
                    .setLabel('📝 Command Examples')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId(`help_permissions_${category}`)
                    .setLabel('🔒 Required Permissions')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.reply({ embeds: [embed], components: [backButton] });

        // Send webhook notification if provided
        if (webhookUrl) {
            await this.sendWebhookNotification(webhookUrl, {
                title: `📚 Help Category: ${categoryData.title}`,
                description: `**User:** ${interaction.user.tag}\n**Server:** ${interaction.guild.name}\n**Commands Shown:** ${categoryData.commands.length}`,
                color: parseInt(categoryData.color.replace('#', ''), 16),
                timestamp: new Date().toISOString()
            });
        }
    },

    async sendWebhookNotification(webhookUrl, data) {
        try {
            await axios.post(webhookUrl, {
                embeds: [{
                    title: data.title,
                    description: data.description,
                    color: data.color,
                    timestamp: data.timestamp,
                    footer: {
                        text: 'Help System Notification'
                    }
                }]
            });
        } catch (error) {
            console.error('Webhook notification error:', error);
        }
    }
};