const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('avatar')
        .setDescription('عرض الصورة الشخصية لمستخدم')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('المستخدم المراد عرض صورته')
                .setRequired(false)),

    async execute(interaction) {
        const targetUser = interaction.options.getUser('user') || interaction.user;
        const member = interaction.guild.members.cache.get(targetUser.id);

        const avatarEmbed = new EmbedBuilder()
            .setColor(member?.displayHexColor || '#0099ff')
            .setTitle(`🖼️ صورة ${targetUser.username}`)
            .setImage(targetUser.displayAvatarURL({ dynamic: true, size: 1024 }))
            .addFields(
                { name: '📱 PNG', value: `[رابط](${targetUser.displayAvatarURL({ extension: 'png', size: 1024 })})`, inline: true },
                { name: '📱 JPG', value: `[رابط](${targetUser.displayAvatarURL({ extension: 'jpg', size: 1024 })})`, inline: true },
                { name: '📱 WEBP', value: `[رابط](${targetUser.displayAvatarURL({ extension: 'webp', size: 1024 })})`, inline: true }
            )
            .setTimestamp();

        // إضافة رابط GIF إذا كانت الصورة متحركة
        if (targetUser.avatar && targetUser.avatar.startsWith('a_')) {
            avatarEmbed.addFields({
                name: '🎬 GIF',
                value: `[رابط](${targetUser.displayAvatarURL({ extension: 'gif', size: 1024 })})`,
                inline: true
            });
        }

        await interaction.reply({ embeds: [avatarEmbed] });
    }
};