const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('avatar')
        .setDescription('Display user\'s avatar with download links')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to display avatar for')
                .setRequired(false))
        .addBooleanOption(option =>
            option.setName('server_avatar')
                .setDescription('Show server-specific avatar if available')
                .setRequired(false)),

    async execute(interaction) {
        const targetUser = interaction.options.getUser('user') || interaction.user;
        const showServerAvatar = interaction.options.getBoolean('server_avatar') || false;
        const member = interaction.guild.members.cache.get(targetUser.id);

        // Determine which avatar to show
        let avatarURL;
        let avatarType = 'Global Avatar';
        
        if (showServerAvatar && member && member.avatar) {
            avatarURL = member.displayAvatarURL({ dynamic: true, size: 1024 });
            avatarType = 'Server Avatar';
        } else {
            avatarURL = targetUser.displayAvatarURL({ dynamic: true, size: 1024 });
        }

        const avatarEmbed = new EmbedBuilder()
            .setColor(member?.displayHexColor || '#0099ff')
            .setTitle(`🖼️ ${targetUser.username}'s ${avatarType}`)
            .setDescription(`Avatar for ${targetUser} (${targetUser.tag})`)
            .setImage(avatarURL)
            .addFields(
                { name: '👤 User', value: targetUser.toString(), inline: true },
                { name: '🆔 User ID', value: targetUser.id, inline: true },
                { name: '📱 Avatar Type', value: avatarType, inline: true }
            )
            .setFooter({ text: `Requested by ${interaction.user.tag}` })
            .setTimestamp();

        // Add download links
        const formats = [];
        
        // PNG
        try {
            const pngURL = showServerAvatar && member?.avatar ? 
                member.displayAvatarURL({ extension: 'png', size: 1024 }) :
                targetUser.displayAvatarURL({ extension: 'png', size: 1024 });
            formats.push(`[PNG](${pngURL})`);
        } catch (e) {}

        // JPG
        try {
            const jpgURL = showServerAvatar && member?.avatar ? 
                member.displayAvatarURL({ extension: 'jpg', size: 1024 }) :
                targetUser.displayAvatarURL({ extension: 'jpg', size: 1024 });
            formats.push(`[JPG](${jpgURL})`);
        } catch (e) {}

        // WEBP
        try {
            const webpURL = showServerAvatar && member?.avatar ? 
                member.displayAvatarURL({ extension: 'webp', size: 1024 }) :
                targetUser.displayAvatarURL({ extension: 'webp', size: 1024 });
            formats.push(`[WEBP](${webpURL})`);
        } catch (e) {}

        // GIF (if animated)
        const avatarHash = showServerAvatar && member?.avatar ? member.avatar : targetUser.avatar;
        if (avatarHash && avatarHash.startsWith('a_')) {
            try {
                const gifURL = showServerAvatar && member?.avatar ? 
                    member.displayAvatarURL({ extension: 'gif', size: 1024 }) :
                    targetUser.displayAvatarURL({ extension: 'gif', size: 1024 });
                formats.push(`[GIF](${gifURL})`);
            } catch (e) {}
        }

        if (formats.length > 0) {
            avatarEmbed.addFields({
                name: '📥 Download Links',
                value: formats.join(' • '),
                inline: false
            });
        }

        // Create buttons for different avatar types
        const buttons = new ActionRowBuilder();

        if (member && member.avatar && !showServerAvatar) {
            buttons.addComponents(
                new ButtonBuilder()
                    .setCustomId(`avatar_server_${targetUser.id}`)
                    .setLabel('Server Avatar')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('🏠')
            );
        }

        if (showServerAvatar) {
            buttons.addComponents(
                new ButtonBuilder()
                    .setCustomId(`avatar_global_${targetUser.id}`)
                    .setLabel('Global Avatar')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('🌐')
            );
        }

        // Add size options
        buttons.addComponents(
            new ButtonBuilder()
                .setCustomId(`avatar_sizes_${targetUser.id}`)
                .setLabel('Other Sizes')
                .setStyle(ButtonStyle.Secondary)
                .setEmoji('📏')
        );

        const components = buttons.components.length > 0 ? [buttons] : [];

        await interaction.reply({ embeds: [avatarEmbed], components });
    }
};