const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('serverinfo')
        .setDescription('عرض معلومات السيرفر'),

    async execute(interaction) {
        const guild = interaction.guild;
        
        const serverEmbed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle(`📊 معلومات ${guild.name}`)
            .setThumbnail(guild.iconURL({ dynamic: true, size: 256 }))
            .addFields(
                { name: '👑 المالك', value: `<@${guild.ownerId}>`, inline: true },
                { name: '🆔 معرف السيرفر', value: guild.id, inline: true },
                { name: '📅 تاريخ الإنشاء', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:F>`, inline: true },
                { name: '👥 الأعضاء', value: guild.memberCount.toString(), inline: true },
                { name: '🤖 البوتات', value: guild.members.cache.filter(member => member.user.bot).size.toString(), inline: true },
                { name: '📝 القنوات النصية', value: guild.channels.cache.filter(channel => channel.type === 0).size.toString(), inline: true },
                { name: '🔊 القنوات الصوتية', value: guild.channels.cache.filter(channel => channel.type === 2).size.toString(), inline: true },
                { name: '🎭 الأدوار', value: guild.roles.cache.size.toString(), inline: true },
                { name: '😀 الإيموجي', value: guild.emojis.cache.size.toString(), inline: true },
                { name: '🔒 مستوى التحقق', value: getVerificationLevel(guild.verificationLevel), inline: true },
                { name: '🛡️ مستوى المحتوى', value: getContentFilterLevel(guild.explicitContentFilter), inline: true },
                { name: '🚀 التحسينات', value: guild.premiumSubscriptionCount?.toString() || '0', inline: true }
            )
            .setTimestamp();

        if (guild.banner) {
            serverEmbed.setImage(guild.bannerURL({ dynamic: true, size: 1024 }));
        }

        await interaction.reply({ embeds: [serverEmbed] });
    }
};

function getVerificationLevel(level) {
    const levels = {
        0: 'بلا قيود',
        1: 'منخفض',
        2: 'متوسط',
        3: 'عالي',
        4: 'أعلى'
    };
    return levels[level] || 'غير معروف';
}

function getContentFilterLevel(level) {
    const levels = {
        0: 'معطل',
        1: 'الأعضاء بدون أدوار',
        2: 'جميع الأعضاء'
    };
    return levels[level] || 'غير معروف';
}