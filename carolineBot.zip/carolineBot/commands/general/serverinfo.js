const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('serverinfo')
        .setDescription('Display detailed server information'),

    async execute(interaction) {
        const guild = interaction.guild;
        
        // Calculate member statistics
        const totalMembers = guild.memberCount;
        const bots = guild.members.cache.filter(member => member.user.bot).size;
        const humans = totalMembers - bots;
        const onlineMembers = guild.members.cache.filter(member => member.presence?.status !== 'offline').size;

        // Calculate channel statistics
        const textChannels = guild.channels.cache.filter(channel => channel.type === 0).size;
        const voiceChannels = guild.channels.cache.filter(channel => channel.type === 2).size;
        const categories = guild.channels.cache.filter(channel => channel.type === 4).size;
        const totalChannels = textChannels + voiceChannels + categories;

        const serverEmbed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle(`📊 ${guild.name} Server Information`)
            .setThumbnail(guild.iconURL({ dynamic: true, size: 256 }))
            .addFields(
                { name: '👑 Owner', value: `<@${guild.ownerId}>`, inline: true },
                { name: '🆔 Server ID', value: guild.id, inline: true },
                { name: '📅 Created', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:F>`, inline: true },
                { name: '👥 Total Members', value: totalMembers.toString(), inline: true },
                { name: '👤 Humans', value: humans.toString(), inline: true },
                { name: '🤖 Bots', value: bots.toString(), inline: true },
                { name: '🟢 Online', value: onlineMembers.toString(), inline: true },
                { name: '📝 Text Channels', value: textChannels.toString(), inline: true },
                { name: '🔊 Voice Channels', value: voiceChannels.toString(), inline: true },
                { name: '📁 Categories', value: categories.toString(), inline: true },
                { name: '🎭 Roles', value: guild.roles.cache.size.toString(), inline: true },
                { name: '😀 Emojis', value: guild.emojis.cache.size.toString(), inline: true },
                { name: '🔒 Verification Level', value: getVerificationLevel(guild.verificationLevel), inline: true },
                { name: '🛡️ Content Filter', value: getContentFilterLevel(guild.explicitContentFilter), inline: true },
                { name: '🚀 Boosts', value: `${guild.premiumSubscriptionCount || 0} (Tier ${guild.premiumTier})`, inline: true }
            )
            .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
            .setTimestamp();

        // Add server features
        const features = guild.features;
        if (features.length > 0) {
            const featureList = features.map(feature => 
                feature.toLowerCase().replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())
            ).join(', ');
            
            serverEmbed.addFields({
                name: '✨ Server Features',
                value: featureList,
                inline: false
            });
        }

        // Add banner if exists
        if (guild.banner) {
            serverEmbed.setImage(guild.bannerURL({ dynamic: true, size: 1024 }));
        }

        // Add description if exists
        if (guild.description) {
            serverEmbed.setDescription(guild.description);
        }

        await interaction.reply({ embeds: [serverEmbed] });
    }
};

function getVerificationLevel(level) {
    const levels = {
        0: 'None',
        1: 'Low',
        2: 'Medium',
        3: 'High',
        4: 'Very High'
    };
    return levels[level] || 'Unknown';
}

function getContentFilterLevel(level) {
    const levels = {
        0: 'Disabled',
        1: 'Members without roles',
        2: 'All members'
    };
    return levels[level] || 'Unknown';
}