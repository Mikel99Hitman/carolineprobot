const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('application')
        .setDescription('Create a staff application form'),

    async execute(interaction) {
        const applicationEmbed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('📝 Staff Application')
            .setDescription('Click the button below to fill out the staff application form')
            .addFields(
                { name: '📋 Requirements', value: '• Age: 16+ years\n• Discord experience\n• Available for sufficient hours\n• Respect server rules', inline: false },
                { name: '⏰ Review Time', value: 'Your application will be reviewed within 24-48 hours', inline: false }
            )
            .setFooter({ text: 'Make sure to fill all fields honestly' })
            .setTimestamp();

        const applyButton = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('open_application')
                    .setLabel('Apply Now')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('📝')
            );

        await interaction.reply({ embeds: [applicationEmbed], components: [applyButton] });
    }
};

// Application button handler
module.exports.handleApplicationButton = async (interaction) => {
    if (interaction.customId === 'open_application') {
        const modal = new ModalBuilder()
            .setCustomId('application_modal')
            .setTitle('Staff Application Form');

        const nameInput = new TextInputBuilder()
            .setCustomId('applicant_name')
            .setLabel('Full Name')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMaxLength(50);

        const ageInput = new TextInputBuilder()
            .setCustomId('applicant_age')
            .setLabel('Age')
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMaxLength(3);

        const experienceInput = new TextInputBuilder()
            .setCustomId('applicant_experience')
            .setLabel('Discord & Moderation Experience')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true)
            .setMaxLength(500);

        const availabilityInput = new TextInputBuilder()
            .setCustomId('applicant_availability')
            .setLabel('Available Hours/Times')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true)
            .setMaxLength(200);

        const motivationInput = new TextInputBuilder()
            .setCustomId('applicant_motivation')
            .setLabel('Why do you want to join our team?')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(true)
            .setMaxLength(300);

        const firstActionRow = new ActionRowBuilder().addComponents(nameInput);
        const secondActionRow = new ActionRowBuilder().addComponents(ageInput);
        const thirdActionRow = new ActionRowBuilder().addComponents(experienceInput);
        const fourthActionRow = new ActionRowBuilder().addComponents(availabilityInput);
        const fifthActionRow = new ActionRowBuilder().addComponents(motivationInput);

        modal.addComponents(firstActionRow, secondActionRow, thirdActionRow, fourthActionRow, fifthActionRow);

        await interaction.showModal(modal);
    }
};

// Modal handler
module.exports.handleApplicationModal = async (interaction) => {
    if (interaction.customId === 'application_modal') {
        const name = interaction.fields.getTextInputValue('applicant_name');
        const age = interaction.fields.getTextInputValue('applicant_age');
        const experience = interaction.fields.getTextInputValue('applicant_experience');
        const availability = interaction.fields.getTextInputValue('applicant_availability');
        const motivation = interaction.fields.getTextInputValue('applicant_motivation');

        const applicationEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('📝 New Staff Application')
            .setThumbnail(interaction.user.displayAvatarURL())
            .addFields(
                { name: '👤 Applicant', value: `${interaction.user} (${interaction.user.tag})`, inline: false },
                { name: '📛 Name', value: name, inline: true },
                { name: '🎂 Age', value: age, inline: true },
                { name: '📅 Application Date', value: new Date().toLocaleString('en-US'), inline: true },
                { name: '💼 Experience', value: experience, inline: false },
                { name: '⏰ Availability', value: availability, inline: false },
                { name: '💭 Motivation', value: motivation, inline: false }
            )
            .setTimestamp();

        const actionButtons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`accept_app_${interaction.user.id}`)
                    .setLabel('Accept')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('✅'),
                new ButtonBuilder()
                    .setCustomId(`reject_app_${interaction.user.id}`)
                    .setLabel('Reject')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('❌')
            );

        // Send to applications channel
        const applicationChannel = interaction.guild.channels.cache.find(ch => ch.name === 'applications' || ch.name === 'staff-applications');
        
        if (applicationChannel) {
            await applicationChannel.send({ embeds: [applicationEmbed], components: [actionButtons] });
            await interaction.reply({ 
                content: '✅ Your application has been submitted successfully! It will be reviewed soon.', 
                ephemeral: true 
            });
        } else {
            await interaction.reply({ 
                content: '❌ Applications channel not found. Please contact an administrator.', 
                ephemeral: true 
            });
        }
    }
};