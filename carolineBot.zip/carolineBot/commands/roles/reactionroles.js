const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('reactionroles')
        .setDescription('Setup reaction roles system')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Channel to send reaction roles message')
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(true))
        .addStringOption(option =>
            option.setName('title')
                .setDescription('Title for the reaction roles embed')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('description')
                .setDescription('Description for the reaction roles embed')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    async execute(interaction) {
        const channel = interaction.options.getChannel('channel');
        const title = interaction.options.getString('title') || 'Reaction Roles';
        const description = interaction.options.getString('description') || 'React to get roles!';

        try {
            // Create tables if not exist
            await pool.query(`
                CREATE TABLE IF NOT EXISTS reaction_roles (
                    id SERIAL PRIMARY KEY,
                    guild_id VARCHAR(20) NOT NULL,
                    message_id VARCHAR(20) NOT NULL,
                    channel_id VARCHAR(20) NOT NULL,
                    title VARCHAR(100) DEFAULT 'Reaction Roles',
                    description TEXT DEFAULT 'React to get roles!',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            `);

            await pool.query(`
                CREATE TABLE IF NOT EXISTS reaction_role_mappings (
                    id SERIAL PRIMARY KEY,
                    reaction_role_id INTEGER REFERENCES reaction_roles(id) ON DELETE CASCADE,
                    emoji VARCHAR(100) NOT NULL,
                    role_id VARCHAR(20) NOT NULL
                )
            `);

            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle(title)
                .setDescription(description)
                .addFields(
                    { name: '📋 How to use', value: 'React with emojis below to get roles!', inline: false },
                    { name: '⚙️ Setup', value: 'Use `/addrole` to add role mappings', inline: true },
                    { name: '🗑️ Remove', value: 'Remove reaction to lose role', inline: true }
                )
                .setFooter({ text: 'Reaction Role System • Advanced Features' })
                .setTimestamp();

            const message = await channel.send({ embeds: [embed] });

            // Save to database
            await pool.query(`
                INSERT INTO reaction_roles (guild_id, message_id, channel_id, title, description)
                VALUES ($1, $2, $3, $4, $5)
            `, [interaction.guild.id, message.id, channel.id, title, description]);

            const successEmbed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('✅ Reaction Roles Setup Complete')
                .setDescription(`Reaction roles message created in ${channel}!`)
                .addFields(
                    { name: '📝 Message ID', value: message.id, inline: true },
                    { name: '📍 Channel', value: channel.toString(), inline: true },
                    { name: '🎭 Roles Added', value: '0 (use `/addrole` to add)', inline: true },
                    { name: '📋 Next Steps', value: '1. Use `/addrole` to add role mappings\n2. Users can react to get roles\n3. Remove reactions to lose roles', inline: false }
                )
                .setFooter({ text: 'Reaction Role System' })
                .setTimestamp();

            await interaction.reply({ embeds: [successEmbed] });

        } catch (error) {
            console.error('Reaction roles setup error:', error);
            await interaction.reply({ 
                content: '❌ An error occurred while setting up reaction roles.', 
                ephemeral: true 
            });
        }
    }
};