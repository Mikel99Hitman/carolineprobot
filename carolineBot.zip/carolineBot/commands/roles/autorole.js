const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('autorole')
        .setDescription('Manage auto roles')
        .addSubcommand(subcommand =>
            subcommand
                .setName('add')
                .setDescription('Add an auto role')
                .addStringOption(option =>
                    option.setName('type')
                        .setDescription('Auto role type')
                        .addChoices(
                            { name: 'On Join', value: 'join' },
                            { name: 'Level Requirement', value: 'level' },
                            { name: 'Server Boost', value: 'boost' },
                            { name: 'Time in Server', value: 'time' }
                        )
                        .setRequired(true))
                .addRoleOption(option =>
                    option.setName('role')
                        .setDescription('Role to assign')
                        .setRequired(true))
                .addIntegerOption(option =>
                    option.setName('level')
                        .setDescription('Required level (for level type)')
                        .setMinValue(1)
                        .setRequired(false))
                .addIntegerOption(option =>
                    option.setName('hours')
                        .setDescription('Hours in server (for time type)')
                        .setMinValue(1)
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('list')
                .setDescription('List all auto roles'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('remove')
                .setDescription('Remove an auto role')
                .addRoleOption(option =>
                    option.setName('role')
                        .setDescription('Role to remove from auto roles')
                        .setRequired(true)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'add') {
            const type = interaction.options.getString('type');
            const role = interaction.options.getRole('role');
            const level = interaction.options.getInteger('level') || 0;
            const hours = interaction.options.getInteger('hours') || 0;

            if (type === 'level' && level === 0) {
                return interaction.reply({ content: '❌ Level is required for level type auto role!', ephemeral: true });
            }

            if (type === 'time' && hours === 0) {
                return interaction.reply({ content: '❌ Hours is required for time type auto role!', ephemeral: true });
            }

            try {
                await pool.query(
                    'INSERT INTO auto_roles (guild_id, type, role_id, level_requirement, time_requirement) VALUES ($1, $2, $3, $4, $5) ON CONFLICT (guild_id, role_id) DO UPDATE SET type = $2, level_requirement = $4, time_requirement = $5',
                    [interaction.guild.id, type, role.id, level, hours]
                );

                const embed = new EmbedBuilder()
                    .setColor('#00ff00')
                    .setTitle('✅ Auto Role Added')
                    .setDescription(`Auto role **${role.name}** has been configured!`)
                    .addFields(
                        { name: 'Type', value: type, inline: true },
                        { name: 'Role', value: role.toString(), inline: true }
                    );

                if (level > 0) embed.addFields({ name: 'Required Level', value: level.toString(), inline: true });
                if (hours > 0) embed.addFields({ name: 'Required Hours', value: hours.toString(), inline: true });

                await interaction.reply({ embeds: [embed] });
            } catch (error) {
                console.error('Auto role add error:', error);
                await interaction.reply({ content: '❌ Failed to add auto role!', ephemeral: true });
            }

        } else if (subcommand === 'list') {
            try {
                const result = await pool.query(
                    'SELECT * FROM auto_roles WHERE guild_id = $1 AND enabled = true',
                    [interaction.guild.id]
                );

                if (result.rows.length === 0) {
                    return interaction.reply({ content: '❌ No auto roles configured!', ephemeral: true });
                }

                const embed = new EmbedBuilder()
                    .setColor('#0099ff')
                    .setTitle('🤖 Auto Roles')
                    .setDescription('List of all configured auto roles');

                result.rows.forEach(autoRole => {
                    const role = interaction.guild.roles.cache.get(autoRole.role_id);
                    if (role) {
                        let description = `Type: ${autoRole.type}`;
                        if (autoRole.level_requirement > 0) description += `\nLevel: ${autoRole.level_requirement}`;
                        if (autoRole.time_requirement > 0) description += `\nTime: ${autoRole.time_requirement}h`;

                        embed.addFields({ name: role.name, value: description, inline: true });
                    }
                });

                await interaction.reply({ embeds: [embed] });
            } catch (error) {
                console.error('Auto role list error:', error);
                await interaction.reply({ content: '❌ Failed to fetch auto roles!', ephemeral: true });
            }

        } else if (subcommand === 'remove') {
            const role = interaction.options.getRole('role');

            try {
                const result = await pool.query(
                    'DELETE FROM auto_roles WHERE guild_id = $1 AND role_id = $2',
                    [interaction.guild.id, role.id]
                );

                if (result.rowCount === 0) {
                    return interaction.reply({ content: '❌ This role is not configured as an auto role!', ephemeral: true });
                }

                const embed = new EmbedBuilder()
                    .setColor('#ff0000')
                    .setTitle('🗑️ Auto Role Removed')
                    .setDescription(`Auto role **${role.name}** has been removed!`);

                await interaction.reply({ embeds: [embed] });
            } catch (error) {
                console.error('Auto role remove error:', error);
                await interaction.reply({ content: '❌ Failed to remove auto role!', ephemeral: true });
            }
        }
    }
};