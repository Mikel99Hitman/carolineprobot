const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, ChannelType } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('Create a new support ticket')
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for creating the ticket')
                .setRequired(false)
                .addChoices(
                    { name: 'General Support', value: 'general' },
                    { name: 'Technical Issue', value: 'technical' },
                    { name: 'Complaint', value: 'complaint' },
                    { name: 'Suggestion', value: 'suggestion' },
                    { name: 'Bug Report', value: 'bug' }
                )),

    async execute(interaction) {
        try {
            // Create tables if not exist
            await pool.query(`
                CREATE TABLE IF NOT EXISTS tickets (
                    id SERIAL PRIMARY KEY,
                    ticket_id VARCHAR(50) UNIQUE NOT NULL,
                    guild_id VARCHAR(20) NOT NULL,
                    user_id VARCHAR(20) NOT NULL,
                    channel_id VARCHAR(20) NOT NULL,
                    status VARCHAR(10) DEFAULT 'open' CHECK (status IN ('open', 'closed')),
                    reason TEXT DEFAULT 'general',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    closed_at TIMESTAMP
                )
            `);

            // Get guild ticket category
            const guildResult = await pool.query(
                'SELECT ticket_category FROM guilds WHERE guild_id = $1',
                [interaction.guild.id]
            );

            const guildData = guildResult.rows[0];
            if (!guildData || !guildData.ticket_category) {
                return interaction.reply({ 
                    content: '❌ Ticket system not configured! Use `/setup tickets` to set it up.', 
                    ephemeral: true 
                });
            }

            const category = interaction.guild.channels.cache.get(guildData.ticket_category);
            if (!category) {
                return interaction.reply({ 
                    content: '❌ Ticket category not found!', 
                    ephemeral: true 
                });
            }

            // Check for existing open ticket
            const existingTicket = await pool.query(
                'SELECT * FROM tickets WHERE user_id = $1 AND guild_id = $2 AND status = $3',
                [interaction.user.id, interaction.guild.id, 'open']
            );

            if (existingTicket.rows.length > 0) {
                const ticketChannel = interaction.guild.channels.cache.get(existingTicket.rows[0].channel_id);
                return interaction.reply({ 
                    content: `❌ You already have an open ticket! ${ticketChannel || 'Channel not found'}`, 
                    ephemeral: true 
                });
            }

            const reason = interaction.options.getString('reason') || 'general';
            const ticketId = `ticket-${interaction.user.id}-${Date.now()}`;

            // Create ticket channel
            const ticketChannel = await interaction.guild.channels.create({
                name: `🎫-${interaction.user.username}`,
                type: ChannelType.GuildText,
                parent: category.id,
                permissionOverwrites: [
                    {
                        id: interaction.guild.id,
                        deny: [PermissionFlagsBits.ViewChannel],
                    },
                    {
                        id: interaction.user.id,
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ReadMessageHistory,
                            PermissionFlagsBits.AttachFiles
                        ],
                    },
                    {
                        id: interaction.client.user.id,
                        allow: [
                            PermissionFlagsBits.ViewChannel,
                            PermissionFlagsBits.SendMessages,
                            PermissionFlagsBits.ManageChannels,
                            PermissionFlagsBits.ManageMessages
                        ],
                    }
                ],
            });

            // Save ticket to database
            await pool.query(`
                INSERT INTO tickets (ticket_id, guild_id, user_id, channel_id, reason)
                VALUES ($1, $2, $3, $4, $5)
            `, [ticketId, interaction.guild.id, interaction.user.id, ticketChannel.id, reason]);

            // Create ticket embed
            const ticketEmbed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle('🎫 New Support Ticket')
                .setDescription(`Hello ${interaction.user}!\nYour ticket has been created successfully.`)
                .addFields(
                    { name: '📋 Reason', value: this.getReasonText(reason), inline: true },
                    { name: '🆔 Ticket ID', value: ticketId, inline: true },
                    { name: '📅 Created', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
                    { name: '📝 Instructions', value: 'Please describe your issue in detail. A staff member will assist you shortly.', inline: false },
                    { name: '⚠️ Important', value: 'Do not share sensitive information like passwords or personal data.', inline: false }
                )
                .setFooter({ text: 'Support Team • We\'ll respond soon' })
                .setTimestamp();

            const ticketButtons = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('close_ticket')
                        .setLabel('Close Ticket')
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji('🔒'),
                    new ButtonBuilder()
                        .setCustomId('ticket_priority')
                        .setLabel('Mark Priority')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('⚡'),
                    new ButtonBuilder()
                        .setCustomId('ticket_transcript')
                        .setLabel('Get Transcript')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('📄')
                );

            await ticketChannel.send({ 
                content: `${interaction.user} Welcome to your support ticket!`, 
                embeds: [ticketEmbed], 
                components: [ticketButtons] 
            });

            // Send confirmation to user
            const confirmEmbed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('✅ Ticket Created Successfully')
                .setDescription(`Your support ticket has been created in ${ticketChannel}`)
                .addFields(
                    { name: '🎫 Ticket ID', value: ticketId, inline: true },
                    { name: '📋 Reason', value: this.getReasonText(reason), inline: true },
                    { name: '📍 Channel', value: ticketChannel.toString(), inline: true }
                )
                .setFooter({ text: 'Support System' })
                .setTimestamp();

            await interaction.reply({ embeds: [confirmEmbed], ephemeral: true });

            // Log ticket creation
            const Logger = require('../../utils/Logger');
            await Logger.log(interaction.guild, 'TICKET_CREATE', {
                user: interaction.user,
                channel: ticketChannel,
                reason: reason,
                ticketId: ticketId
            });

        } catch (error) {
            console.error('Ticket creation error:', error);
            await interaction.reply({ 
                content: '❌ An error occurred while creating your ticket!', 
                ephemeral: true 
            });
        }
    },

    getReasonText(reason) {
        const reasons = {
            'general': 'General Support',
            'technical': 'Technical Issue',
            'complaint': 'Complaint',
            'suggestion': 'Suggestion',
            'bug': 'Bug Report'
        };
        return reasons[reason] || 'Not specified';
    }
};