const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('adhkar')
        .setDescription('📿 الأذكار الإسلامية - Islamic Remembrance')
        .addSubcommand(subcommand =>
            subcommand
                .setName('morning')
                .setDescription('أذكار الصباح - Morning Remembrance'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('evening')
                .setDescription('أذكار المساء - Evening Remembrance'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('sleep')
                .setDescription('أذكار النوم - Sleep Remembrance'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('random')
                .setDescription('ذكر عشوائي - Random Remembrance'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('custom')
                .setDescription('ذكر مخصص - Custom dhikr')
                .addStringOption(option =>
                    option.setName('text')
                        .setDescription('نص الذكر - Dhikr text')
                        .setRequired(true))
                .addIntegerOption(option =>
                    option.setName('count')
                        .setDescription('عدد التكرار - Repetition count')
                        .setMinValue(1)
                        .setMaxValue(1000)
                        .setRequired(true))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        await interaction.deferReply();

        switch (subcommand) {
            case 'morning':
                await this.morningAdhkar(interaction);
                break;
            case 'evening':
                await this.eveningAdhkar(interaction);
                break;
            case 'sleep':
                await this.sleepAdhkar(interaction);
                break;
            case 'random':
                await this.randomAdhkar(interaction);
                break;
            case 'custom':
                await this.customAdhkar(interaction);
                break;
        }
    },

    async morningAdhkar(interaction) {
        const adhkar = this.getMorningAdhkar();
        const currentIndex = 0;

        const embed = new EmbedBuilder()
            .setTitle('🌅 أذكار الصباح')
            .setDescription(`الذكر ${currentIndex + 1} من ${adhkar.length}`)
            .addFields(
                { name: '📖 الذكر', value: adhkar[currentIndex].text, inline: false },
                { name: '🔢 عدد التكرار', value: `${adhkar[currentIndex].count} مرة`, inline: true },
                { name: '🎯 الفضل', value: adhkar[currentIndex].benefit, inline: false }
            )
            .setColor('#ffd700')
            .setTimestamp()
            .setFooter({ text: 'أذكار الصباح • Morning Adhkar' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`adhkar_morning_prev_${currentIndex}`)
                    .setLabel('⬅️ السابق')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(currentIndex === 0),
                new ButtonBuilder()
                    .setCustomId(`adhkar_morning_next_${currentIndex}`)
                    .setLabel('التالي ➡️')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(currentIndex === adhkar.length - 1),
                new ButtonBuilder()
                    .setCustomId('adhkar_morning_all')
                    .setLabel('📋 جميع الأذكار')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async eveningAdhkar(interaction) {
        const adhkar = this.getEveningAdhkar();
        const currentIndex = 0;

        const embed = new EmbedBuilder()
            .setTitle('🌇 أذكار المساء')
            .setDescription(`الذكر ${currentIndex + 1} من ${adhkar.length}`)
            .addFields(
                { name: '📖 الذكر', value: adhkar[currentIndex].text, inline: false },
                { name: '🔢 عدد التكرار', value: `${adhkar[currentIndex].count} مرة`, inline: true },
                { name: '🎯 الفضل', value: adhkar[currentIndex].benefit, inline: false }
            )
            .setColor('#ff6b35')
            .setTimestamp()
            .setFooter({ text: 'أذكار المساء • Evening Adhkar' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`adhkar_evening_prev_${currentIndex}`)
                    .setLabel('⬅️ السابق')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(currentIndex === 0),
                new ButtonBuilder()
                    .setCustomId(`adhkar_evening_next_${currentIndex}`)
                    .setLabel('التالي ➡️')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(currentIndex === adhkar.length - 1),
                new ButtonBuilder()
                    .setCustomId('adhkar_evening_all')
                    .setLabel('📋 جميع الأذكار')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async sleepAdhkar(interaction) {
        const adhkar = this.getSleepAdhkar();
        const currentIndex = 0;

        const embed = new EmbedBuilder()
            .setTitle('🌙 أذكار النوم')
            .setDescription(`الذكر ${currentIndex + 1} من ${adhkar.length}`)
            .addFields(
                { name: '📖 الذكر', value: adhkar[currentIndex].text, inline: false },
                { name: '🔢 عدد التكرار', value: `${adhkar[currentIndex].count} مرة`, inline: true },
                { name: '🎯 الفضل', value: adhkar[currentIndex].benefit, inline: false }
            )
            .setColor('#4a90e2')
            .setTimestamp()
            .setFooter({ text: 'أذكار النوم • Sleep Adhkar' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`adhkar_sleep_prev_${currentIndex}`)
                    .setLabel('⬅️ السابق')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(currentIndex === 0),
                new ButtonBuilder()
                    .setCustomId(`adhkar_sleep_next_${currentIndex}`)
                    .setLabel('التالي ➡️')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(currentIndex === adhkar.length - 1),
                new ButtonBuilder()
                    .setCustomId('adhkar_sleep_all')
                    .setLabel('📋 جميع الأذكار')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async randomAdhkar(interaction) {
        const allAdhkar = [...this.getMorningAdhkar(), ...this.getEveningAdhkar(), ...this.getSleepAdhkar()];
        const randomDhikr = allAdhkar[Math.floor(Math.random() * allAdhkar.length)];

        const embed = new EmbedBuilder()
            .setTitle('🎲 ذكر عشوائي')
            .setDescription('ذكر مختار عشوائياً من مجموعة الأذكار')
            .addFields(
                { name: '📖 الذكر', value: randomDhikr.text, inline: false },
                { name: '🔢 عدد التكرار', value: `${randomDhikr.count} مرة`, inline: true },
                { name: '🎯 الفضل', value: randomDhikr.benefit, inline: false }
            )
            .setColor('#9b59b6')
            .setTimestamp()
            .setFooter({ text: 'ذكر عشوائي • Random Dhikr' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('adhkar_random_new')
                    .setLabel('🎲 ذكر جديد')
                    .setStyle(ButtonStyle.Success)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async customAdhkar(interaction) {
        const dhikrText = interaction.options.getString('text');
        const count = interaction.options.getInteger('count');

        const embed = new EmbedBuilder()
            .setTitle('📿 ذكر مخصص')
            .setDescription('ذكر مخصص من اختيارك')
            .addFields(
                { name: '📖 الذكر', value: dhikrText, inline: false },
                { name: '🔢 عدد التكرار', value: `${count} مرة`, inline: true },
                { name: '💡 نصيحة', value: 'اذكر الله في كل وقت وحين', inline: false },
                { name: '🎯 الهدف', value: `أكمل ${count} مرة من هذا الذكر`, inline: false }
            )
            .setColor('#e67e22')
            .setTimestamp()
            .setFooter({ text: 'ذكر مخصص • Custom Dhikr' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`custom_dhikr_start_${count}`)
                    .setLabel('🎯 ابدأ العد')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('adhkar_random_new')
                    .setLabel('🎲 ذكر عشوائي')
                    .setStyle(ButtonStyle.Primary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    getMorningAdhkar() {
        return [
            {
                text: 'أَعُوذُ بِاللَّهِ مِنَ الشَّيْطَانِ الرَّجِيمِ\nاللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ',
                count: 1,
                benefit: 'آية الكرسي - حفظ من الشيطان حتى المساء'
            },
            {
                text: 'بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ',
                count: 3,
                benefit: 'حفظ من كل ضرر'
            },
            {
                text: 'رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ رَسُولًا',
                count: 3,
                benefit: 'وجبت شفاعة النبي صلى الله عليه وسلم'
            },
            {
                text: 'اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَٰهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَىٰ عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ لَكَ بِذَنْبِي فَاغْفِرْ لِي، فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ',
                count: 1,
                benefit: 'سيد الاستغفار - من قالها موقناً فمات دخل الجنة'
            },
            {
                text: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ',
                count: 100,
                benefit: 'حطت خطاياه وإن كانت مثل زبد البحر'
            }
        ];
    },

    getEveningAdhkar() {
        return [
            {
                text: 'أَعُوذُ بِاللَّهِ مِنَ الشَّيْطَانِ الرَّجِيمِ\nاللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ',
                count: 1,
                benefit: 'آية الكرسي - حفظ من الشيطان حتى الصباح'
            },
            {
                text: 'أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ، رَبِّ أَسْأَلُكَ خَيْرَ مَا فِي هَٰذِهِ اللَّيْلَةِ وَخَيْرَ مَا بَعْدَهَا، وَأَعُوذُ بِكَ مِنْ شَرِّ مَا فِي هَٰذِهِ اللَّيْلَةِ وَشَرِّ مَا بَعْدَهَا',
                count: 1,
                benefit: 'دعاء المساء الشامل'
            },
            {
                text: 'اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ',
                count: 1,
                benefit: 'التوكل على الله في المساء'
            },
            {
                text: 'أَسْتَغْفِرُ اللَّهَ الَّذِي لَا إِلَٰهَ إِلَّا هُوَ الْحَيَّ الْقَيُّومَ وَأَتُوبُ إِلَيْهِ',
                count: 3,
                benefit: 'غفران الذنوب'
            }
        ];
    },

    getSleepAdhkar() {
        return [
            {
                text: 'بِاسْمِكَ رَبِّي وَضَعْتُ جَنْبِي، وَبِكَ أَرْفَعُهُ، فَإِنْ أَمْسَكْتَ نَفْسِي فَارْحَمْهَا، وَإِنْ أَرْسَلْتَهَا فَاحْفَظْهَا بِمَا تَحْفَظُ بِهِ عِبَادَكَ الصَّالِحِينَ',
                count: 1,
                benefit: 'دعاء عند النوم'
            },
            {
                text: 'اللَّهُمَّ قِنِي عَذَابَكَ يَوْمَ تَبْعَثُ عِبَادَكَ',
                count: 3,
                benefit: 'الوقاية من عذاب القبر'
            },
            {
                text: 'سُبْحَانَ اللَّهِ',
                count: 33,
                benefit: 'تسبيح قبل النوم'
            },
            {
                text: 'الْحَمْدُ لِلَّهِ',
                count: 33,
                benefit: 'حمد قبل النوم'
            },
            {
                text: 'اللَّهُ أَكْبَرُ',
                count: 34,
                benefit: 'تكبير قبل النوم'
            }
        ];
    }
};