const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('prayer-times')
        .setDescription('🕌 أوقات الصلاة - Prayer Times System')
        .addSubcommand(subcommand =>
            subcommand
                .setName('today')
                .setDescription('أوقات الصلاة اليوم - Today\'s prayer times')
                .addStringOption(option =>
                    option.setName('city')
                        .setDescription('المدينة - City name')
                        .addChoices(
                            { name: 'مكة المكرمة - Mecca', value: 'mecca' },
                            { name: 'المدينة المنورة - Medina', value: 'medina' },
                            { name: 'الرياض - Riyadh', value: 'riyadh' },
                            { name: 'القاهرة - Cairo', value: 'cairo' },
                            { name: 'دبي - Dubai', value: 'dubai' },
                            { name: 'القدس - Jerusalem', value: 'jerusalem' },
                            { name: 'تونس - Tunis', value: 'tunis' }
                        )
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('notifications')
                .setDescription('إشعارات الصلاة - Prayer notifications')
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('قناة الإشعارات - Notifications channel')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('city')
                        .setDescription('المدينة - City')
                        .addChoices(
                            { name: 'مكة المكرمة', value: 'mecca' },
                            { name: 'القاهرة', value: 'cairo' },
                            { name: 'الرياض', value: 'riyadh' },
                            { name: 'القدس', value: 'jerusalem' },
                            { name: 'تونس', value: 'tunis' }
                        )
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('qibla')
                .setDescription('اتجاه القبلة - Qibla direction')
                .addStringOption(option =>
                    option.setName('location')
                        .setDescription('الموقع - Your location')
                        .setRequired(true))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        await interaction.deferReply();

        switch (subcommand) {
            case 'today':
                await this.todayPrayerTimes(interaction);
                break;
            case 'notifications':
                await this.prayerNotifications(interaction);
                break;
            case 'qibla':
                await this.qiblaDirection(interaction);
                break;
        }
    },

    async todayPrayerTimes(interaction) {
        const city = interaction.options.getString('city');
        const prayerData = this.getPrayerTimes(city);

        const embed = new EmbedBuilder()
            .setTitle(`🕌 أوقات الصلاة - ${prayerData.cityName}`)
            .setDescription(`${prayerData.hijriDate} - ${prayerData.gregorianDate}`)
            .addFields(
                { name: '🌅 الفجر - Fajr', value: prayerData.fajr, inline: true },
                { name: '🌄 الشروق - Sunrise', value: prayerData.sunrise, inline: true },
                { name: '☀️ الظهر - Dhuhr', value: prayerData.dhuhr, inline: true },
                { name: '🌇 العصر - Asr', value: prayerData.asr, inline: true },
                { name: '🌅 المغرب - Maghrib', value: prayerData.maghrib, inline: true },
                { name: '🌙 العشاء - Isha', value: prayerData.isha, inline: true },
                { name: '⏰ الصلاة القادمة', value: `${prayerData.nextPrayer.name} - ${prayerData.nextPrayer.time}\nباقي: ${prayerData.nextPrayer.remaining}`, inline: false },
                { name: '📍 معلومات إضافية', value: `خط الطول: ${prayerData.longitude}\nخط العرض: ${prayerData.latitude}\nالمنطقة الزمنية: ${prayerData.timezone}`, inline: false }
            )
            .setColor('#00ff00')
            .setTimestamp()
            .setFooter({ text: 'أوقات الصلاة • Prayer Times' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('refresh_prayer_times')
                    .setLabel('🔄 تحديث')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('setup_notifications')
                    .setLabel('🔔 إعداد التنبيهات')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('qibla_direction')
                    .setLabel('🧭 اتجاه القبلة')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async prayerNotifications(interaction) {
        const channel = interaction.options.getChannel('channel');
        const city = interaction.options.getString('city');
        const cityNames = {
            'mecca': 'مكة المكرمة',
            'cairo': 'القاهرة',
            'riyadh': 'الرياض',
            'jerusalem': 'القدس',
            'tunis': 'تونس'
        };

        const embed = new EmbedBuilder()
            .setTitle('🔔 إشعارات أوقات الصلاة')
            .setDescription(`تم إعداد إشعارات الصلاة لمدينة ${cityNames[city]}`)
            .addFields(
                { name: '📺 القناة المحددة', value: `<#${channel.id}>`, inline: true },
                { name: '🏙️ المدينة', value: cityNames[city], inline: true },
                { name: '📊 الحالة', value: '✅ مفعل', inline: true },
                { name: '🔔 الإشعارات المفعلة', value: '🌅 تنبيه الفجر\n☀️ تنبيه الظهر\n🌇 تنبيه العصر\n🌅 تنبيه المغرب\n🌙 تنبيه العشاء', inline: false },
                { name: '⚙️ الإعدادات', value: '⏰ تنبيه قبل 10 دقائق\n🔊 تنبيه صوتي مفعل\n📱 إشعار للجميع\n🕌 آية قرآنية مع كل تنبيه', inline: false }
            )
            .setColor('#9b59b6')
            .setTimestamp()
            .setFooter({ text: 'إشعارات الصلاة • Prayer Notifications' });

        await interaction.editReply({ embeds: [embed] });
    },

    async qiblaDirection(interaction) {
        const location = interaction.options.getString('location');
        const qiblaData = this.getQiblaDirection(location);

        const embed = new EmbedBuilder()
            .setTitle('🧭 اتجاه القبلة - Qibla Direction')
            .setDescription(`اتجاه القبلة من ${location}`)
            .addFields(
                { name: '📍 موقعك', value: location, inline: true },
                { name: '🧭 اتجاه القبلة', value: `${qiblaData.direction}° شمال شرق`, inline: true },
                { name: '📏 المسافة', value: `${qiblaData.distance} كم`, inline: true },
                { name: '🕌 الكعبة المشرفة', value: 'مكة المكرمة، المملكة العربية السعودية', inline: false },
                { name: '📐 الإحداثيات', value: `خط الطول: ${qiblaData.longitude}\nخط العرض: ${qiblaData.latitude}`, inline: false },
                { name: '💡 نصائح', value: '🧭 استخدم البوصلة للتوجه\n📱 تأكد من معايرة الهاتف\n🕌 اتجه نحو الكعبة المشرفة', inline: false }
            )
            .setColor('#ffd700')
            .setTimestamp()
            .setFooter({ text: 'اتجاه القبلة • Qibla Direction' });

        await interaction.editReply({ embeds: [embed] });
    },

    getPrayerTimes(city) {
        const now = new Date();
        const currentHour = now.getHours();
        const currentMinute = now.getMinutes();
        const currentTime = currentHour * 60 + currentMinute;

        const cities = {
            'mecca': {
                cityName: 'مكة المكرمة',
                fajr: '04:45',
                sunrise: '06:15',
                dhuhr: '12:30',
                asr: '15:45',
                maghrib: '18:20',
                isha: '19:50',
                longitude: '39.8262',
                latitude: '21.4225',
                timezone: 'GMT+3'
            },
            'medina': {
                cityName: 'المدينة المنورة',
                fajr: '04:50',
                sunrise: '06:20',
                dhuhr: '12:35',
                asr: '15:50',
                maghrib: '18:25',
                isha: '19:55',
                longitude: '39.6142',
                latitude: '24.4539',
                timezone: 'GMT+3'
            },
            'cairo': {
                cityName: 'القاهرة',
                fajr: '04:30',
                sunrise: '06:00',
                dhuhr: '12:15',
                asr: '15:30',
                maghrib: '18:05',
                isha: '19:35',
                longitude: '31.2357',
                latitude: '30.0444',
                timezone: 'GMT+2'
            },
            'jerusalem': {
                cityName: 'القدس',
                fajr: '04:35',
                sunrise: '06:05',
                dhuhr: '12:20',
                asr: '15:35',
                maghrib: '18:10',
                isha: '19:40',
                longitude: '35.2137',
                latitude: '31.7683',
                timezone: 'GMT+2'
            },
            'tunis': {
                cityName: 'تونس',
                fajr: '04:25',
                sunrise: '05:55',
                dhuhr: '12:10',
                asr: '15:25',
                maghrib: '18:00',
                isha: '19:30',
                longitude: '10.1815',
                latitude: '36.8065',
                timezone: 'GMT+1'
            }
        };

        const cityData = cities[city] || cities['mecca'];
        
        // Calculate next prayer
        const prayers = [
            { name: 'الفجر', time: cityData.fajr, minutes: this.timeToMinutes(cityData.fajr) },
            { name: 'الظهر', time: cityData.dhuhr, minutes: this.timeToMinutes(cityData.dhuhr) },
            { name: 'العصر', time: cityData.asr, minutes: this.timeToMinutes(cityData.asr) },
            { name: 'المغرب', time: cityData.maghrib, minutes: this.timeToMinutes(cityData.maghrib) },
            { name: 'العشاء', time: cityData.isha, minutes: this.timeToMinutes(cityData.isha) }
        ];

        let nextPrayer = prayers.find(prayer => prayer.minutes > currentTime);
        if (!nextPrayer) {
            nextPrayer = prayers[0]; // Next day Fajr
        }

        const remainingMinutes = nextPrayer.minutes > currentTime ? 
            nextPrayer.minutes - currentTime : 
            (24 * 60) - currentTime + nextPrayer.minutes;
        
        const hours = Math.floor(remainingMinutes / 60);
        const minutes = remainingMinutes % 60;
        
        return {
            ...cityData,
            hijriDate: this.getHijriDate(),
            gregorianDate: now.toLocaleDateString('ar-SA'),
            nextPrayer: {
                name: nextPrayer.name,
                time: nextPrayer.time,
                remaining: `${hours} ساعة و ${minutes} دقيقة`
            }
        };
    },

    timeToMinutes(timeStr) {
        const [hours, minutes] = timeStr.split(':').map(Number);
        return hours * 60 + minutes;
    },

    getHijriDate() {
        const hijriMonths = [
            'محرم', 'صفر', 'ربيع الأول', 'ربيع الثاني', 'جمادى الأولى', 'جمادى الثانية',
            'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'
        ];
        
        // Simple approximation - in real implementation, use proper Hijri calendar library
        const now = new Date();
        const hijriYear = 1445;
        const hijriMonth = Math.floor(Math.random() * 12);
        const hijriDay = Math.floor(Math.random() * 29) + 1;
        
        return `${hijriDay} ${hijriMonths[hijriMonth]} ${hijriYear}`;
    },
    },

    getQiblaDirection(location) {
        return {
            direction: 57,
            distance: 1247,
            longitude: '39.8262',
            latitude: '21.4225'
        };
    }
};',
            latitude: '21.4225'
        };
    }
};