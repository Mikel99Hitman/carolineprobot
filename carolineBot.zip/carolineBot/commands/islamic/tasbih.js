const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('tasbih')
        .setDescription('📿 السبحة الإلكترونية - Digital Tasbih')
        .addSubcommand(subcommand =>
            subcommand
                .setName('start')
                .setDescription('بدء السبحة - Start Tasbih')
                .addStringOption(option =>
                    option.setName('dhikr')
                        .setDescription('نوع الذكر - Type of dhikr')
                        .addChoices(
                            { name: 'سبحان الله - SubhanAllah', value: 'subhanallah' },
                            { name: 'الحمد لله - Alhamdulillah', value: 'alhamdulillah' },
                            { name: 'الله أكبر - Allahu Akbar', value: 'allahuakbar' },
                            { name: 'لا إله إلا الله - La ilaha illa Allah', value: 'lailahaillallah' },
                            { name: 'أستغفر الله - Astaghfirullah', value: 'astaghfirullah' },
                            { name: 'لا حول ولا قوة إلا بالله - La hawla wa la quwwata illa billah', value: 'lahawla' },
                            { name: 'صلى الله عليه وسلم - Sallallahu alayhi wa sallam', value: 'salawat' }
                        )
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('stats')
                .setDescription('إحصائيات السبحة - Tasbih statistics'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('leaderboard')
                .setDescription('المتصدرين - Leaderboard'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('reset')
                .setDescription('إعادة تعيين العداد - Reset counter')),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        await interaction.deferReply();

        switch (subcommand) {
            case 'start':
                await this.startTasbih(interaction);
                break;
            case 'stats':
                await this.tasbihStats(interaction);
                break;
            case 'leaderboard':
                await this.tasbihLeaderboard(interaction);
                break;
            case 'reset':
                await this.resetTasbih(interaction);
                break;
        }
    },

    async startTasbih(interaction) {
        const dhikrType = interaction.options.getString('dhikr');
        const dhikrData = this.getDhikrData(dhikrType);
        const count = 0;
        const target = 33;

        const embed = new EmbedBuilder()
            .setTitle('📿 السبحة الإلكترونية')
            .setDescription(`**${dhikrData.arabic}**\n*${dhikrData.transliteration}*\n\n${dhikrData.meaning}`)
            .addFields(
                { name: '🔢 العداد', value: `**${count}**`, inline: true },
                { name: '🎯 الهدف', value: `**${target}**`, inline: true },
                { name: '⏱️ الوقت', value: '00:00', inline: true },
                { name: '📊 التقدم', value: this.getProgressBar(count, target), inline: false },
                { name: '🎁 الفضل', value: dhikrData.benefit, inline: false },
                { name: '📖 الدليل', value: dhikrData.reference, inline: false }
            )
            .setColor('#00ff00')
            .setTimestamp()
            .setFooter({ text: 'السبحة الإلكترونية • Digital Tasbih' });

        const row1 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`tasbih_count_${dhikrType}_${count}_${target}`)
                    .setLabel('📿 سبّح')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId(`tasbih_reset_${dhikrType}`)
                    .setLabel('🔄 إعادة تعيين')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('tasbih_stats')
                    .setLabel('📊 الإحصائيات')
                    .setStyle(ButtonStyle.Success)
            );

        const row2 = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`tasbih_target_33_${dhikrType}`)
                    .setLabel('🎯 33')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId(`tasbih_target_99_${dhikrType}`)
                    .setLabel('🎯 99')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId(`tasbih_target_100_${dhikrType}`)
                    .setLabel('🎯 100')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId(`tasbih_target_1000_${dhikrType}`)
                    .setLabel('🎯 1000')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row1, row2] });
    },

    async tasbihStats(interaction) {
        const stats = await this.getUserStats(interaction.user.id);

        const embed = new EmbedBuilder()
            .setTitle('📊 إحصائيات السبحة')
            .setDescription(`إحصائيات ${interaction.user.displayName}`)
            .addFields(
                { name: '📿 إجمالي التسبيحات', value: stats.totalCount.toLocaleString(), inline: true },
                { name: '🏆 أعلى عدد يومي', value: stats.dailyRecord.toLocaleString(), inline: true },
                { name: '🔥 أيام متتالية', value: `${stats.streak} يوم`, inline: true },
                { name: '🌟 سبحان الله', value: stats.subhanallah.toLocaleString(), inline: true },
                { name: '🙏 الحمد لله', value: stats.alhamdulillah.toLocaleString(), inline: true },
                { name: '💪 الله أكبر', value: stats.allahuakbar.toLocaleString(), inline: true },
                { name: '☝️ لا إله إلا الله', value: stats.lailahaillallah.toLocaleString(), inline: true },
                { name: '🤲 أستغفر الله', value: stats.astaghfirullah.toLocaleString(), inline: true },
                { name: '🛡️ لا حول ولا قوة إلا بالله', value: stats.lahawla.toLocaleString(), inline: true },
                { name: '💝 الصلاة على النبي', value: stats.salawat.toLocaleString(), inline: true },
                { name: '📅 آخر نشاط', value: stats.lastActivity, inline: true },
                { name: '⏱️ إجمالي الوقت', value: stats.totalTime, inline: true },
                { name: '🏅 الإنجازات', value: this.getAchievements(stats), inline: false }
            )
            .setColor('#9b59b6')
            .setTimestamp()
            .setFooter({ text: 'إحصائيات السبحة • Tasbih Statistics' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('tasbih_leaderboard')
                    .setLabel('🏆 المتصدرين')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('tasbih_achievements')
                    .setLabel('🏅 الإنجازات')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('tasbih_export')
                    .setLabel('📤 تصدير البيانات')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async tasbihLeaderboard(interaction) {
        const leaderboard = await this.getLeaderboard();

        const embed = new EmbedBuilder()
            .setTitle('🏆 متصدري السبحة')
            .setDescription('أكثر المسبحين نشاطاً في السيرفر')
            .addFields(
                leaderboard.map((user, index) => ({
                    name: `${this.getRankEmoji(index + 1)} المركز ${index + 1}`,
                    value: `<@${user.user_id}>\n📿 ${user.total_count.toLocaleString()} تسبيحة\n🔥 ${user.streak} يوم متتالي`,
                    inline: true
                }))
            )
            .setColor('#ffd700')
            .setTimestamp()
            .setFooter({ text: 'متصدري السبحة • Tasbih Leaderboard' });

        await interaction.editReply({ embeds: [embed] });
    },

    async resetTasbih(interaction) {
        const embed = new EmbedBuilder()
            .setTitle('🔄 إعادة تعيين السبحة')
            .setDescription('اختر نوع الإعادة تعيين')
            .addFields(
                { name: '🔄 إعادة تعيين الجلسة', value: 'إعادة تعيين العداد الحالي فقط', inline: false },
                { name: '⚠️ إعادة تعيين كاملة', value: 'حذف جميع الإحصائيات (لا يمكن التراجع)', inline: false }
            )
            .setColor('#e74c3c')
            .setTimestamp()
            .setFooter({ text: 'إعادة تعيين السبحة • Reset Tasbih' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('tasbih_reset_session')
                    .setLabel('🔄 إعادة تعيين الجلسة')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('tasbih_reset_all')
                    .setLabel('⚠️ إعادة تعيين كاملة')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('tasbih_cancel_reset')
                    .setLabel('❌ إلغاء')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    getDhikrData(type) {
        const dhikrTypes = {
            subhanallah: {
                arabic: 'سُبْحَانَ اللَّهِ',
                transliteration: 'SubhanAllah',
                meaning: 'Glory be to Allah',
                benefit: 'تنزيه الله عن كل نقص وعيب، وهو من أحب الكلام إلى الله',
                reference: 'صحيح مسلم: "سبحان الله وبحمده سبحان الله العظيم"'
            },
            alhamdulillah: {
                arabic: 'الْحَمْدُ لِلَّهِ',
                transliteration: 'Alhamdulillah',
                meaning: 'All praise is due to Allah',
                benefit: 'حمد الله على جميع نعمه، وهي تملأ الميزان يوم القيامة',
                reference: 'صحيح مسلم: "الحمد لله تملأ الميزان"'
            },
            allahuakbar: {
                arabic: 'اللَّهُ أَكْبَرُ',
                transliteration: 'Allahu Akbar',
                meaning: 'Allah is the Greatest',
                benefit: 'تعظيم الله وإقرار بكبريائه، وهي أحب إلى الله مما طلعت عليه الشمس',
                reference: 'صحيح مسلم: "لأن أقول سبحان الله والحمد لله ولا إله إلا الله والله أكبر أحب إلي مما طلعت عليه الشمس"'
            },
            lailahaillallah: {
                arabic: 'لَا إِلَٰهَ إِلَّا اللَّهُ',
                transliteration: 'La ilaha illa Allah',
                meaning: 'There is no god but Allah',
                benefit: 'شهادة التوحيد وإقرار بوحدانية الله، وهي أفضل الذكر',
                reference: 'سنن الترمذي: "أفضل الذكر لا إله إلا الله"'
            },
            astaghfirullah: {
                arabic: 'أَسْتَغْفِرُ اللَّهَ',
                transliteration: 'Astaghfirullah',
                meaning: 'I seek forgiveness from Allah',
                benefit: 'طلب المغفرة من الله، ومن أكثر منه فتح الله له أبواب الرزق',
                reference: 'سورة نوح: "فقلت استغفروا ربكم إنه كان غفارا يرسل السماء عليكم مدرارا"'
            },
            lahawla: {
                arabic: 'لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ',
                transliteration: 'La hawla wa la quwwata illa billah',
                meaning: 'There is no power except with Allah',
                benefit: 'الاعتراف بأن القوة والحول من الله وحده، وهي كنز من كنوز الجنة',
                reference: 'صحيح البخاري: "لا حول ولا قوة إلا بالله كنز من كنوز الجنة"'
            },
            salawat: {
                arabic: 'صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ',
                transliteration: 'Sallallahu alayhi wa sallam',
                meaning: 'May Allah bless him and grant him peace',
                benefit: 'الصلاة على النبي محمد، ومن صلى عليه مرة صلى الله عليه عشراً',
                reference: 'صحيح مسلم: "من صلى علي واحدة صلى الله عليه عشرا"'
            }
        };

        return dhikrTypes[type] || dhikrTypes.subhanallah;
    },

    getProgressBar(current, target) {
        const percentage = Math.min((current / target) * 100, 100);
        const filledBars = Math.floor(percentage / 10);
        const emptyBars = 10 - filledBars;
        
        return '🟩'.repeat(filledBars) + '⬜'.repeat(emptyBars) + ` ${percentage.toFixed(1)}%`;
    },

    async getUserStats(userId) {
        try {
            const result = await pool.query(`
                SELECT * FROM tasbih_stats 
                WHERE user_id = $1
            `, [userId]);

            if (result.rows.length === 0) {
                return {
                    totalCount: 0,
                    dailyRecord: 0,
                    streak: 0,
                    subhanallah: 0,
                    alhamdulillah: 0,
                    allahuakbar: 0,
                    lailahaillallah: 0,
                    astaghfirullah: 0,
                    lahawla: 0,
                    salawat: 0,
                    lastActivity: 'لم يبدأ بعد',
                    totalTime: '0 دقيقة'
                };
            }

            const stats = result.rows[0];
            return {
                totalCount: stats.total_count || 0,
                dailyRecord: stats.daily_record || 0,
                streak: stats.streak || 0,
                subhanallah: stats.subhanallah || 0,
                alhamdulillah: stats.alhamdulillah || 0,
                allahuakbar: stats.allahuakbar || 0,
                lailahaillallah: stats.lailahaillallah || 0,
                astaghfirullah: stats.astaghfirullah || 0,
                lahawla: stats.lahawla || 0,
                salawat: stats.salawat || 0,
                lastActivity: stats.last_activity ? new Date(stats.last_activity).toLocaleDateString('ar-SA') : 'لم يبدأ بعد',
                totalTime: this.formatTime(stats.total_time || 0)
            };
        } catch (error) {
            console.error('Error fetching tasbih stats:', error);
            return this.getDefaultStats();
        }
    },

    async getLeaderboard() {
        try {
            const result = await pool.query(`
                SELECT user_id, total_count, streak 
                FROM tasbih_stats 
                ORDER BY total_count DESC 
                LIMIT 10
            `);
            return result.rows;
        } catch (error) {
            console.error('Error fetching leaderboard:', error);
            return [];
        }
    },

    getRankEmoji(rank) {
        const emojis = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];
        return emojis[rank - 1] || '📍';
    },

    getAchievements(stats) {
        const achievements = [];
        
        if (stats.totalCount >= 10000) achievements.push('💎 عشرة آلاف تسبيحة');
        else if (stats.totalCount >= 5000) achievements.push('🏆 خمسة آلاف تسبيحة');
        else if (stats.totalCount >= 1000) achievements.push('🥇 ألف تسبيحة');
        else if (stats.totalCount >= 500) achievements.push('🥈 خمسمئة تسبيحة');
        else if (stats.totalCount >= 100) achievements.push('🥉 مئة تسبيحة');
        
        if (stats.dailyRecord >= 1000) achievements.push('🔥 ألف في اليوم');
        else if (stats.dailyRecord >= 500) achievements.push('💯 خمسمئة في اليوم');
        else if (stats.dailyRecord >= 100) achievements.push('⭐ مئة في اليوم');
        
        if (stats.streak >= 30) achievements.push('📅 شهر متواصل');
        else if (stats.streak >= 7) achievements.push('🗓️ أسبوع متواصل');
        
        if (stats.subhanallah >= 1000) achievements.push('🌟 محب التسبيح');
        if (stats.alhamdulillah >= 1000) achievements.push('🙏 كثير الحمد');
        if (stats.allahuakbar >= 1000) achievements.push('💪 مكبر الله');
        if (stats.salawat >= 1000) achievements.push('💝 محب النبي');
        
        return achievements.length > 0 ? achievements.join('\n') : 'ابدأ التسبيح لتحصل على إنجازات!';
    },

    formatTime(seconds) {
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        
        if (hours > 0) {
            return `${hours} ساعة و ${minutes} دقيقة`;
        }
        return `${minutes} دقيقة`;
    },

    getDefaultStats() {
        return {
            totalCount: 0,
            dailyRecord: 0,
            streak: 0,
            subhanallah: 0,
            alhamdulillah: 0,
            allahuakbar: 0,
            lailahaillallah: 0,
            astaghfirullah: 0,
            lahawla: 0,
            salawat: 0,
            lastActivity: 'لم يبدأ بعد',
            totalTime: '0 دقيقة'
        };
    }
};