const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('islamic-holidays')
        .setDescription('🎉 الأعياد الإسلامية - Islamic Holidays')
        .addSubcommand(subcommand =>
            subcommand
                .setName('upcoming')
                .setDescription('الأعياد القادمة - Upcoming holidays'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('all')
                .setDescription('جميع الأعياد - All holidays'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('countdown')
                .setDescription('العد التنازلي للعيد القادم - Countdown to next holiday'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('notifications')
                .setDescription('إشعارات الأعياد - Holiday notifications')
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('قناة الإشعارات - Notifications channel')
                        .setRequired(true))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        await interaction.deferReply();

        switch (subcommand) {
            case 'upcoming':
                await this.upcomingHolidays(interaction);
                break;
            case 'all':
                await this.allHolidays(interaction);
                break;
            case 'countdown':
                await this.holidayCountdown(interaction);
                break;
            case 'notifications':
                await this.holidayNotifications(interaction);
                break;
        }
    },

    async upcomingHolidays(interaction) {
        const holidays = this.getUpcomingHolidays();

        const embed = new EmbedBuilder()
            .setTitle('🎉 الأعياد الإسلامية القادمة')
            .setDescription('أقرب الأعياد والمناسبات الإسلامية')
            .addFields(
                holidays.slice(0, 5).map(holiday => ({
                    name: `${holiday.emoji} ${holiday.name}`,
                    value: `📅 ${holiday.hijriDate}\n🗓️ ${holiday.gregorianDate}\n⏰ باقي: ${holiday.remaining}\n📝 ${holiday.description}`,
                    inline: false
                }))
            )
            .setColor('#00ff00')
            .setTimestamp()
            .setFooter({ text: 'الأعياد الإسلامية • Islamic Holidays' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('holidays_countdown')
                    .setLabel('⏰ العد التنازلي')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('holidays_all')
                    .setLabel('📋 جميع الأعياد')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async allHolidays(interaction) {
        const holidays = this.getAllHolidays();

        const embed = new EmbedBuilder()
            .setTitle('📅 جميع الأعياد والمناسبات الإسلامية')
            .setDescription('التقويم الإسلامي الكامل للأعياد والمناسبات')
            .addFields(
                { name: '🌙 الأعياد الرئيسية', value: holidays.major.map(h => `${h.emoji} ${h.name} - ${h.hijriDate}`).join('\n'), inline: false },
                { name: '📿 المناسبات الدينية', value: holidays.religious.map(h => `${h.emoji} ${h.name} - ${h.hijriDate}`).join('\n'), inline: false },
                { name: '🕌 الأشهر المقدسة', value: holidays.sacred.map(h => `${h.emoji} ${h.name} - ${h.hijriDate}`).join('\n'), inline: false }
            )
            .setColor('#9b59b6')
            .setTimestamp()
            .setFooter({ text: 'التقويم الإسلامي • Islamic Calendar' });

        await interaction.editReply({ embeds: [embed] });
    },

    async holidayCountdown(interaction) {
        const nextHoliday = this.getNextHoliday();

        const embed = new EmbedBuilder()
            .setTitle(`⏰ العد التنازلي لـ ${nextHoliday.name}`)
            .setDescription('الوقت المتبقي للعيد القادم')
            .addFields(
                { name: '🎉 العيد القادم', value: nextHoliday.name, inline: true },
                { name: '📅 التاريخ الهجري', value: nextHoliday.hijriDate, inline: true },
                { name: '🗓️ التاريخ الميلادي', value: nextHoliday.gregorianDate, inline: true },
                { name: '⏰ الوقت المتبقي', value: nextHoliday.countdown, inline: false },
                { name: '📝 عن العيد', value: nextHoliday.description, inline: false },
                { name: '🎯 الأعمال المستحبة', value: nextHoliday.recommendations, inline: false }
            )
            .setColor('#ffd700')
            .setTimestamp()
            .setFooter({ text: 'العد التنازلي • Holiday Countdown' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('countdown_refresh')
                    .setLabel('🔄 تحديث')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('countdown_notify')
                    .setLabel('🔔 تذكيرني')
                    .setStyle(ButtonStyle.Success)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async holidayNotifications(interaction) {
        const channel = interaction.options.getChannel('channel');

        const embed = new EmbedBuilder()
            .setTitle('🔔 إشعارات الأعياد الإسلامية')
            .setDescription(`تم إعداد إشعارات الأعياد في <#${channel.id}>`)
            .addFields(
                { name: '📺 القناة المحددة', value: `<#${channel.id}>`, inline: true },
                { name: '📊 الحالة', value: '✅ مفعل', inline: true },
                { name: '🎉 الإشعارات المفعلة', value: '🌙 عيد الفطر\n🐑 عيد الأضحى\n🕌 ليلة القدر\n📿 ليلة الإسراء والمعراج\n🌟 المولد النبوي\n🕌 ليلة النصف من شعبان', inline: false },
                { name: '⚙️ الإعدادات', value: '⏰ تنبيه قبل 3 أيام\n🔔 تنبيه يوم العيد\n📱 إشعار للجميع\n🎨 رسائل مخصصة', inline: false }
            )
            .setColor('#e74c3c')
            .setTimestamp()
            .setFooter({ text: 'إشعارات الأعياد • Holiday Notifications' });

        await interaction.editReply({ embeds: [embed] });
    },

    getUpcomingHolidays() {
        return [
            {
                name: 'عيد الفطر المبارك',
                emoji: '🌙',
                hijriDate: '1 شوال 1445',
                gregorianDate: '10 أبريل 2024',
                remaining: '45 يوم',
                description: 'عيد الفطر المبارك بعد انتهاء شهر رمضان'
            },
            {
                name: 'عيد الأضحى المبارك',
                emoji: '🐑',
                hijriDate: '10 ذو الحجة 1445',
                gregorianDate: '16 يونيو 2024',
                remaining: '112 يوم',
                description: 'عيد الأضحى المبارك في موسم الحج'
            },
            {
                name: 'رأس السنة الهجرية',
                emoji: '🌟',
                hijriDate: '1 محرم 1446',
                gregorianDate: '7 يوليو 2024',
                remaining: '133 يوم',
                description: 'بداية السنة الهجرية الجديدة'
            },
            {
                name: 'يوم عاشوراء',
                emoji: '🕌',
                hijriDate: '10 محرم 1446',
                gregorianDate: '16 يوليو 2024',
                remaining: '142 يوم',
                description: 'يوم عاشوراء المبارك'
            },
            {
                name: 'المولد النبوي الشريف',
                emoji: '🌹',
                hijriDate: '12 ربيع الأول 1446',
                gregorianDate: '15 سبتمبر 2024',
                remaining: '203 يوم',
                description: 'ذكرى مولد النبي محمد صلى الله عليه وسلم'
            }
        ];
    },

    getAllHolidays() {
        return {
            major: [
                { name: 'عيد الفطر', emoji: '🌙', hijriDate: '1-3 شوال' },
                { name: 'عيد الأضحى', emoji: '🐑', hijriDate: '10-13 ذو الحجة' }
            ],
            religious: [
                { name: 'ليلة القدر', emoji: '✨', hijriDate: 'العشر الأواخر من رمضان' },
                { name: 'ليلة الإسراء والمعراج', emoji: '🌌', hijriDate: '27 رجب' },
                { name: 'ليلة النصف من شعبان', emoji: '🌟', hijriDate: '15 شعبان' },
                { name: 'المولد النبوي', emoji: '🌹', hijriDate: '12 ربيع الأول' },
                { name: 'يوم عاشوراء', emoji: '🕌', hijriDate: '10 محرم' }
            ],
            sacred: [
                { name: 'شهر رمضان', emoji: '🌙', hijriDate: 'شهر رمضان كاملاً' },
                { name: 'الأشهر الحرم', emoji: '🕌', hijriDate: 'محرم، رجب، ذو القعدة، ذو الحجة' },
                { name: 'العشر من ذي الحجة', emoji: '🐑', hijriDate: '1-10 ذو الحجة' }
            ]
        };
    },

    getNextHoliday() {
        return {
            name: 'عيد الفطر المبارك',
            hijriDate: '1 شوال 1445',
            gregorianDate: '10 أبريل 2024',
            countdown: '45 يوم، 12 ساعة، 30 دقيقة',
            description: 'عيد الفطر هو أول أعياد المسلمين والذي يأتي بعد صيام شهر رمضان المبارك. يحتفل المسلمون بهذا العيد لمدة ثلاثة أيام.',
            recommendations: '🤲 صلاة العيد\n💰 زكاة الفطر\n👥 صلة الأرحام\n🎁 التهاني والهدايا\n🍽️ الإفطار الجماعي'
        };
    }
};