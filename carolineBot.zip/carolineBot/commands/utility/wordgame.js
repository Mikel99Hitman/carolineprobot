const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

const words = ['javascript', 'discord', 'programming', 'computer', 'technology', 'internet', 'software', 'hardware'];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('wordgame')
        .setDescription('Start a word guessing game'),

    async execute(interaction) {
        const word = words[Math.floor(Math.random() * words.length)];
        const scrambled = word.split('').sort(() => Math.random() - 0.5).join('');
        
        const embed = new EmbedBuilder()
            .setColor('#ff6b6b')
            .setTitle('🎯 Word Game')
            .setDescription(`Unscramble this word: **${scrambled}**`)
            .addFields(
                { name: 'Letters', value: word.length.toString(), inline: true },
                { name: 'Time Limit', value: '60 seconds', inline: true }
            )
            .setTimestamp();

        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`wordgame_${word}`)
                    .setLabel('Give Up')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🏳️')
            );

        await interaction.reply({ embeds: [embed], components: [buttons] });

        const filter = m => m.author.id === interaction.user.id && m.content.toLowerCase() === word.toLowerCase();
        const collector = interaction.channel.createMessageCollector({ filter, time: 60000, max: 1 });

        collector.on('collect', async (m) => {
            const winEmbed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('🎉 Correct!')
                .setDescription(`You guessed **${word}** correctly!`)
                .setTimestamp();

            await interaction.followUp({ embeds: [winEmbed] });
        });

        collector.on('end', (collected) => {
            if (collected.size === 0) {
                const loseEmbed = new EmbedBuilder()
                    .setColor('#ff0000')
                    .setTitle('⏰ Time\'s Up!')
                    .setDescription(`The word was **${word}**`)
                    .setTimestamp();

                interaction.followUp({ embeds: [loseEmbed] });
            }
        });
    }
};