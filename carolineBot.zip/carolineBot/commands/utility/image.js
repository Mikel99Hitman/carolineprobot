const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const Canvas = require('canvas');
const { Pool } = require('pg');
const axios = require('axios');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('image')
        .setDescription('🇮 Advanced image manipulation and generation system')
        .addSubcommand(subcommand =>
            subcommand
                .setName('effects')
                .setDescription('Apply visual effects to images')
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('User whose avatar to edit')
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('effect')
                        .setDescription('Effect to apply')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Blur', value: 'blur' },
                            { name: 'Invert Colors', value: 'invert' },
                            { name: 'Grayscale', value: 'grayscale' },
                            { name: 'Sepia', value: 'sepia' },
                            { name: 'Brightness', value: 'brightness' },
                            { name: 'Contrast', value: 'contrast' },
                            { name: 'Saturate', value: 'saturate' },
                            { name: 'Hue Rotate', value: 'hue-rotate' }
                        ))
                .addIntegerOption(option =>
                    option.setName('intensity')
                        .setDescription('Effect intensity (1-100)')
                        .setRequired(false)
                        .setMinValue(1)
                        .setMaxValue(100))
                .addStringOption(option =>
                    option.setName('webhook_url')
                        .setDescription('Webhook URL for notifications')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('meme')
                .setDescription('Create meme templates')
                .addStringOption(option =>
                    option.setName('template')
                        .setDescription('Meme template')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Drake Pointing', value: 'drake' },
                            { name: 'Distracted Boyfriend', value: 'distracted' },
                            { name: 'Change My Mind', value: 'changemymind' },
                            { name: 'This Is Fine', value: 'thisisfine' },
                            { name: 'Expanding Brain', value: 'brain' }
                        ))
                .addStringOption(option =>
                    option.setName('top_text')
                        .setDescription('Top text for meme')
                        .setRequired(true)
                        .setMaxLength(100))
                .addStringOption(option =>
                    option.setName('bottom_text')
                        .setDescription('Bottom text for meme')
                        .setRequired(false)
                        .setMaxLength(100)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('overlay')
                .setDescription('Add overlays to images')
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('User whose avatar to use')
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('overlay_type')
                        .setDescription('Overlay type')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Wanted Poster', value: 'wanted' },
                            { name: 'Jail Bars', value: 'jail' },
                            { name: 'Triggered', value: 'triggered' },
                            { name: 'Rainbow Frame', value: 'rainbow' },
                            { name: 'Fire Effect', value: 'fire' },
                            { name: 'Glitch Effect', value: 'glitch' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('generate')
                .setDescription('Generate custom images')
                .addStringOption(option =>
                    option.setName('type')
                        .setDescription('Generation type')
                        .setRequired(true)
                        .addChoices(
                            { name: 'QR Code', value: 'qr' },
                            { name: 'Color Palette', value: 'palette' },
                            { name: 'Gradient', value: 'gradient' },
                            { name: 'Pattern', value: 'pattern' },
                            { name: 'Chart', value: 'chart' }
                        ))
                .addStringOption(option =>
                    option.setName('data')
                        .setDescription('Data for generation (text, colors, etc.)')
                        .setRequired(true)
                        .setMaxLength(500)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('stats')
                .setDescription('View image processing statistics')),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        
        try {
            await this.createTables();
            
            switch (subcommand) {
                case 'effects':
                    await this.applyEffects(interaction);
                    break;
                case 'meme':
                    await this.createMeme(interaction);
                    break;
                case 'overlay':
                    await this.addOverlay(interaction);
                    break;
                case 'generate':
                    await this.generateImage(interaction);
                    break;
                case 'stats':
                    await this.showStats(interaction);
                    break;
            }
        } catch (error) {
            console.error('Image command error:', error);
            await interaction.reply({ content: '❌ An error occurred while processing the image command.', ephemeral: true });
        }
    },

    async createTables() {
        await pool.query(`
            CREATE TABLE IF NOT EXISTS image_processing (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                command_type VARCHAR(50) NOT NULL,
                effect_applied VARCHAR(100),
                processing_time INTEGER,
                file_size INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
    },

    async logImageProcessing(interaction, commandType, effect, processingTime, fileSize) {
        await pool.query(
            'INSERT INTO image_processing (user_id, guild_id, command_type, effect_applied, processing_time, file_size) VALUES ($1, $2, $3, $4, $5, $6)',
            [interaction.user.id, interaction.guild.id, commandType, effect, processingTime, fileSize]
        );
    },

    async applyEffects(interaction) {
        await interaction.deferReply();
        
        const user = interaction.options.getUser('user') || interaction.user;
        const effect = interaction.options.getString('effect');
        const intensity = interaction.options.getInteger('intensity') || 50;
        const webhookUrl = interaction.options.getString('webhook_url');
        
        const startTime = Date.now();

        try {
            const canvas = Canvas.createCanvas(512, 512);
            const ctx = canvas.getContext('2d');

            const avatar = await Canvas.loadImage(user.displayAvatarURL({ extension: 'png', size: 512 }));
            
            // Apply different effects based on selection
            switch (effect) {
                case 'blur':
                    ctx.filter = `blur(${intensity / 10}px)`;
                    break;
                case 'invert':
                    ctx.filter = 'invert(100%)';
                    break;
                case 'grayscale':
                    ctx.filter = 'grayscale(100%)';
                    break;
                case 'sepia':
                    ctx.filter = 'sepia(100%)';
                    break;
                case 'brightness':
                    ctx.filter = `brightness(${intensity * 2}%)`;
                    break;
                case 'contrast':
                    ctx.filter = `contrast(${intensity * 2}%)`;
                    break;
                case 'saturate':
                    ctx.filter = `saturate(${intensity * 2}%)`;
                    break;
                case 'hue-rotate':
                    ctx.filter = `hue-rotate(${intensity * 3.6}deg)`;
                    break;
            }

            ctx.drawImage(avatar, 0, 0, 512, 512);

            // Add decorative border
            ctx.filter = 'none';
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 8;
            ctx.strokeRect(4, 4, 504, 504);

            const buffer = canvas.toBuffer();
            const processingTime = Date.now() - startTime;
            
            const attachment = new AttachmentBuilder(buffer, { 
                name: `${effect}-${user.username}.png` 
            });

            const embed = new EmbedBuilder()
                .setColor('#ff6b6b')
                .setTitle(`🇮 Image Effect: ${effect.toUpperCase()}`)
                .setDescription(`Applied **${effect}** effect to ${user.username}'s avatar`)
                .addFields(
                    { name: '🎯 Effect', value: effect.charAt(0).toUpperCase() + effect.slice(1), inline: true },
                    { name: '📈 Intensity', value: `${intensity}%`, inline: true },
                    { name: '⏱️ Processing Time', value: `${processingTime}ms`, inline: true },
                    { name: '📄 File Size', value: `${(buffer.length / 1024).toFixed(2)} KB`, inline: true },
                    { name: '👥 Target User', value: user.toString(), inline: true },
                    { name: '📅 Created', value: '<t:' + Math.floor(Date.now() / 1000) + ':R>', inline: true }
                )
                .setImage(`attachment://${effect}-${user.username}.png`)
                .setFooter({ text: 'Image Processing System' })
                .setTimestamp();

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('image_save')
                        .setLabel('💾 Save Image')
                        .setStyle(ButtonStyle.Success),
                    new ButtonBuilder()
                        .setCustomId('image_share')
                        .setLabel('🔗 Share')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId('image_effects_menu')
                        .setLabel('🎨 More Effects')
                        .setStyle(ButtonStyle.Secondary)
                );

            await interaction.editReply({ embeds: [embed], files: [attachment], components: [row] });

            // Log processing
            await this.logImageProcessing(interaction, 'effects', effect, processingTime, buffer.length);

            // Send webhook notification
            if (webhookUrl) {
                await this.sendWebhookNotification(webhookUrl, {
                    title: '🇮 Image Effect Applied',
                    description: `**User:** ${interaction.user.tag}\n**Effect:** ${effect}\n**Target:** ${user.tag}\n**Processing Time:** ${processingTime}ms`,
                    color: 0xff6b6b,
                    timestamp: new Date().toISOString()
                });
            }

        } catch (error) {
            console.error('Image effects error:', error);
            await interaction.editReply({ content: '❌ Failed to process image effect!' });
        }
    },

    async createMeme(interaction) {
        await interaction.deferReply();
        
        const template = interaction.options.getString('template');
        const topText = interaction.options.getString('top_text');
        const bottomText = interaction.options.getString('bottom_text') || '';
        
        const startTime = Date.now();

        try {
            const canvas = Canvas.createCanvas(600, 400);
            const ctx = canvas.getContext('2d');

            // Create meme background based on template
            ctx.fillStyle = this.getMemeBackground(template);
            ctx.fillRect(0, 0, 600, 400);

            // Add meme template elements
            await this.drawMemeTemplate(ctx, template);

            // Add text
            ctx.font = 'bold 36px Impact';
            ctx.fillStyle = '#ffffff';
            ctx.strokeStyle = '#000000';
            ctx.lineWidth = 2;
            ctx.textAlign = 'center';

            // Top text
            const topLines = this.wrapText(ctx, topText.toUpperCase(), 550);
            topLines.forEach((line, index) => {
                ctx.strokeText(line, 300, 50 + (index * 40));
                ctx.fillText(line, 300, 50 + (index * 40));
            });

            // Bottom text
            if (bottomText) {
                const bottomLines = this.wrapText(ctx, bottomText.toUpperCase(), 550);
                bottomLines.forEach((line, index) => {
                    const y = 350 - ((bottomLines.length - 1 - index) * 40);
                    ctx.strokeText(line, 300, y);
                    ctx.fillText(line, 300, y);
                });
            }

            const buffer = canvas.toBuffer();
            const processingTime = Date.now() - startTime;
            
            const attachment = new AttachmentBuilder(buffer, { 
                name: `meme-${template}.png` 
            });

            const embed = new EmbedBuilder()
                .setColor('#ff9500')
                .setTitle(`😂 Meme Generator: ${template.toUpperCase()}`)
                .setDescription(`Created custom meme with **${template}** template`)
                .addFields(
                    { name: '🎨 Template', value: template.charAt(0).toUpperCase() + template.slice(1), inline: true },
                    { name: '📝 Top Text', value: topText, inline: true },
                    { name: '📝 Bottom Text', value: bottomText || 'None', inline: true },
                    { name: '⏱️ Processing Time', value: `${processingTime}ms`, inline: true },
                    { name: '📄 File Size', value: `${(buffer.length / 1024).toFixed(2)} KB`, inline: true },
                    { name: '👥 Creator', value: interaction.user.toString(), inline: true }
                )
                .setImage(`attachment://meme-${template}.png`)
                .setFooter({ text: 'Meme Generator System' })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed], files: [attachment] });

            // Log processing
            await this.logImageProcessing(interaction, 'meme', template, processingTime, buffer.length);

        } catch (error) {
            console.error('Meme creation error:', error);
            await interaction.editReply({ content: '❌ Failed to create meme!' });
        }
    },

    async addOverlay(interaction) {
        await interaction.deferReply();
        
        const user = interaction.options.getUser('user') || interaction.user;
        const overlayType = interaction.options.getString('overlay_type');
        
        const startTime = Date.now();

        try {
            const canvas = Canvas.createCanvas(512, 512);
            const ctx = canvas.getContext('2d');

            const avatar = await Canvas.loadImage(user.displayAvatarURL({ extension: 'png', size: 512 }));
            ctx.drawImage(avatar, 0, 0, 512, 512);

            // Apply overlay based on type
            await this.applyOverlay(ctx, overlayType);

            const buffer = canvas.toBuffer();
            const processingTime = Date.now() - startTime;
            
            const attachment = new AttachmentBuilder(buffer, { 
                name: `overlay-${overlayType}-${user.username}.png` 
            });

            const embed = new EmbedBuilder()
                .setColor('#9932cc')
                .setTitle(`🎆 Image Overlay: ${overlayType.toUpperCase()}`)
                .setDescription(`Applied **${overlayType}** overlay to ${user.username}'s avatar`)
                .addFields(
                    { name: '🎭 Overlay Type', value: overlayType.charAt(0).toUpperCase() + overlayType.slice(1), inline: true },
                    { name: '👥 Target User', value: user.toString(), inline: true },
                    { name: '⏱️ Processing Time', value: `${processingTime}ms`, inline: true }
                )
                .setImage(`attachment://overlay-${overlayType}-${user.username}.png`)
                .setFooter({ text: 'Image Overlay System' })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed], files: [attachment] });

            // Log processing
            await this.logImageProcessing(interaction, 'overlay', overlayType, processingTime, buffer.length);

        } catch (error) {
            console.error('Overlay error:', error);
            await interaction.editReply({ content: '❌ Failed to apply overlay!' });
        }
    },

    async generateImage(interaction) {
        await interaction.deferReply();
        
        const type = interaction.options.getString('type');
        const data = interaction.options.getString('data');
        
        const startTime = Date.now();

        try {
            let canvas, buffer;
            
            switch (type) {
                case 'qr':
                    canvas = await this.generateQRCode(data);
                    break;
                case 'palette':
                    canvas = await this.generateColorPalette(data);
                    break;
                case 'gradient':
                    canvas = await this.generateGradient(data);
                    break;
                case 'pattern':
                    canvas = await this.generatePattern(data);
                    break;
                case 'chart':
                    canvas = await this.generateChart(data);
                    break;
            }

            buffer = canvas.toBuffer();
            const processingTime = Date.now() - startTime;
            
            const attachment = new AttachmentBuilder(buffer, { 
                name: `generated-${type}.png` 
            });

            const embed = new EmbedBuilder()
                .setColor('#4169e1')
                .setTitle(`🎨 Generated Image: ${type.toUpperCase()}`)
                .setDescription(`Generated custom **${type}** image`)
                .addFields(
                    { name: '🎯 Type', value: type.charAt(0).toUpperCase() + type.slice(1), inline: true },
                    { name: '📝 Input Data', value: data.substring(0, 50) + (data.length > 50 ? '...' : ''), inline: true },
                    { name: '⏱️ Processing Time', value: `${processingTime}ms`, inline: true }
                )
                .setImage(`attachment://generated-${type}.png`)
                .setFooter({ text: 'Image Generation System' })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed], files: [attachment] });

            // Log processing
            await this.logImageProcessing(interaction, 'generate', type, processingTime, buffer.length);

        } catch (error) {
            console.error('Image generation error:', error);
            await interaction.editReply({ content: '❌ Failed to generate image!' });
        }
    },

    async showStats(interaction) {
        const userStats = await pool.query(
            'SELECT command_type, COUNT(*) as count, AVG(processing_time) as avg_time FROM image_processing WHERE user_id = $1 GROUP BY command_type',
            [interaction.user.id]
        );

        const serverStats = await pool.query(
            'SELECT COUNT(*) as total, AVG(processing_time) as avg_time, SUM(file_size) as total_size FROM image_processing WHERE guild_id = $1',
            [interaction.guild.id]
        );

        const embed = new EmbedBuilder()
            .setTitle('📈 Image Processing Statistics')
            .setDescription('Your image processing usage and server statistics')
            .setColor('#32cd32')
            .setTimestamp();

        if (userStats.rows.length > 0) {
            const userBreakdown = userStats.rows.map(row => 
                `**${row.command_type}:** ${row.count} uses (${Math.round(row.avg_time)}ms avg)`
            ).join('\n');
            embed.addFields({ name: '👥 Your Usage', value: userBreakdown, inline: false });
        }

        if (serverStats.rows.length > 0) {
            const stats = serverStats.rows[0];
            embed.addFields(
                { name: '🏢 Server Total', value: stats.total.toString(), inline: true },
                { name: '⏱️ Avg Processing', value: `${Math.round(stats.avg_time)}ms`, inline: true },
                { name: '📄 Total Data', value: `${(stats.total_size / 1024 / 1024).toFixed(2)} MB`, inline: true }
            );
        }

        await interaction.reply({ embeds: [embed] });
    },

    // Helper functions
    getMemeBackground(template) {
        const backgrounds = {
            drake: '#1a1a1a',
            distracted: '#87ceeb',
            changemymind: '#f0f0f0',
            thisisfine: '#ff6b6b',
            brain: '#9932cc'
        };
        return backgrounds[template] || '#ffffff';
    },

    async drawMemeTemplate(ctx, template) {
        // Simple template drawing - in production, you'd load actual template images
        ctx.fillStyle = '#333333';
        ctx.fillRect(50, 100, 500, 200);
        
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 24px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(`${template.toUpperCase()} TEMPLATE`, 300, 200);
    },

    async applyOverlay(ctx, overlayType) {
        switch (overlayType) {
            case 'wanted':
                ctx.fillStyle = 'rgba(139, 69, 19, 0.3)';
                ctx.fillRect(0, 0, 512, 512);
                ctx.fillStyle = '#8b4513';
                ctx.font = 'bold 48px serif';
                ctx.textAlign = 'center';
                ctx.fillText('WANTED', 256, 60);
                break;
            case 'jail':
                for (let i = 0; i < 512; i += 40) {
                    ctx.fillStyle = '#333333';
                    ctx.fillRect(i, 0, 20, 512);
                }
                break;
            case 'triggered':
                ctx.fillStyle = 'rgba(255, 0, 0, 0.5)';
                ctx.fillRect(0, 0, 512, 512);
                ctx.fillStyle = '#ff0000';
                ctx.font = 'bold 36px Arial';
                ctx.textAlign = 'center';
                ctx.fillText('TRIGGERED', 256, 256);
                break;
        }
    },

    wrapText(ctx, text, maxWidth) {
        const words = text.split(' ');
        const lines = [];
        let currentLine = words[0];

        for (let i = 1; i < words.length; i++) {
            const word = words[i];
            const width = ctx.measureText(currentLine + ' ' + word).width;
            if (width < maxWidth) {
                currentLine += ' ' + word;
            } else {
                lines.push(currentLine);
                currentLine = word;
            }
        }
        lines.push(currentLine);
        return lines;
    },

    async generateQRCode(data) {
        const canvas = Canvas.createCanvas(300, 300);
        const ctx = canvas.getContext('2d');
        
        // Simple QR-like pattern (in production, use a real QR library)
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, 300, 300);
        
        ctx.fillStyle = '#000000';
        for (let i = 0; i < 30; i++) {
            for (let j = 0; j < 30; j++) {
                if (Math.random() > 0.5) {
                    ctx.fillRect(i * 10, j * 10, 10, 10);
                }
            }
        }
        
        return canvas;
    },

    async generateColorPalette(colors) {
        const canvas = Canvas.createCanvas(500, 100);
        const ctx = canvas.getContext('2d');
        
        const colorArray = colors.split(',').map(c => c.trim());
        const width = 500 / colorArray.length;
        
        colorArray.forEach((color, index) => {
            ctx.fillStyle = color;
            ctx.fillRect(index * width, 0, width, 100);
        });
        
        return canvas;
    },

    async generateGradient(colors) {
        const canvas = Canvas.createCanvas(400, 400);
        const ctx = canvas.getContext('2d');
        
        const colorArray = colors.split(',').map(c => c.trim());
        const gradient = ctx.createLinearGradient(0, 0, 400, 400);
        
        colorArray.forEach((color, index) => {
            gradient.addColorStop(index / (colorArray.length - 1), color);
        });
        
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, 400, 400);
        
        return canvas;
    },

    async generatePattern(data) {
        const canvas = Canvas.createCanvas(400, 400);
        const ctx = canvas.getContext('2d');
        
        ctx.fillStyle = '#f0f0f0';
        ctx.fillRect(0, 0, 400, 400);
        
        ctx.fillStyle = '#333333';
        for (let i = 0; i < 400; i += 20) {
            for (let j = 0; j < 400; j += 20) {
                if ((i + j) % 40 === 0) {
                    ctx.fillRect(i, j, 20, 20);
                }
            }
        }
        
        return canvas;
    },

    async generateChart(data) {
        const canvas = Canvas.createCanvas(500, 300);
        const ctx = canvas.getContext('2d');
        
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, 500, 300);
        
        // Simple bar chart
        const values = data.split(',').map(v => parseInt(v.trim()) || 0);
        const maxValue = Math.max(...values);
        const barWidth = 400 / values.length;
        
        values.forEach((value, index) => {
            const height = (value / maxValue) * 200;
            ctx.fillStyle = `hsl(${index * 60}, 70%, 50%)`;
            ctx.fillRect(50 + index * barWidth, 250 - height, barWidth - 10, height);
        });
        
        return canvas;
    },

    async sendWebhookNotification(webhookUrl, data) {
        try {
            await axios.post(webhookUrl, {
                embeds: [{
                    title: data.title,
                    description: data.description,
                    color: data.color,
                    timestamp: data.timestamp,
                    footer: {
                        text: 'Image Processing Notification'
                    }
                }]
            });
        } catch (error) {
            console.error('Webhook notification error:', error);
        }
    }
};