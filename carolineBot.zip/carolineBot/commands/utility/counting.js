const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('counting')
        .setDescription('Setup counting channel')
        .addSubcommand(subcommand =>
            subcommand
                .setName('setup')
                .setDescription('Setup counting channel')
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('Counting channel')
                        .addChannelTypes(ChannelType.GuildText)
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('stats')
                .setDescription('View counting statistics'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('reset')
                .setDescription('Reset counting game'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        try {
            if (subcommand === 'setup') {
                const channel = interaction.options.getChannel('channel');

                // Create counting table if not exists
                await pool.query(`
                    CREATE TABLE IF NOT EXISTS counting (
                        guild_id VARCHAR(20) PRIMARY KEY,
                        channel_id VARCHAR(20) NOT NULL,
                        current_number INTEGER DEFAULT 0,
                        last_user_id VARCHAR(20),
                        highest_number INTEGER DEFAULT 0,
                        fails INTEGER DEFAULT 0,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                `);

                // Insert or update counting setup
                await pool.query(`
                    INSERT INTO counting (guild_id, channel_id) 
                    VALUES ($1, $2) 
                    ON CONFLICT (guild_id) 
                    DO UPDATE SET channel_id = $2, current_number = 0, last_user_id = NULL
                `, [interaction.guild.id, channel.id]);

                const embed = new EmbedBuilder()
                    .setColor('#00ff00')
                    .setTitle('🔢 Counting Setup Complete')
                    .setDescription(`Counting game setup in ${channel}!\nUsers must count from 1 in order.`)
                    .addFields(
                        { name: '📋 Rules', value: '• Count in sequential order (1, 2, 3...)\n• No double counting by same user\n• Numbers only\n• Wrong number resets to 0', inline: false },
                        { name: '🎯 Goal', value: 'Reach the highest number possible!', inline: false }
                    )
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });
                await channel.send('🔢 **Counting Game Started!** Start with `1`');

            } else if (subcommand === 'stats') {
                const result = await pool.query(
                    'SELECT * FROM counting WHERE guild_id = $1',
                    [interaction.guild.id]
                );

                if (result.rows.length === 0) {
                    return interaction.reply({ content: '❌ No counting game setup in this server!', ephemeral: true });
                }

                const data = result.rows[0];
                const channel = interaction.guild.channels.cache.get(data.channel_id);

                const embed = new EmbedBuilder()
                    .setColor('#0099ff')
                    .setTitle('📊 Counting Statistics')
                    .addFields(
                        { name: '📍 Channel', value: channel ? channel.toString() : 'Channel not found', inline: true },
                        { name: '🔢 Current Number', value: data.current_number.toString(), inline: true },
                        { name: '🏆 Highest Number', value: data.highest_number.toString(), inline: true },
                        { name: '❌ Total Fails', value: data.fails.toString(), inline: true },
                        { name: '👤 Last Counter', value: data.last_user_id ? `<@${data.last_user_id}>` : 'None', inline: true }
                    )
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });

            } else if (subcommand === 'reset') {
                await pool.query(
                    'UPDATE counting SET current_number = 0, last_user_id = NULL WHERE guild_id = $1',
                    [interaction.guild.id]
                );

                const embed = new EmbedBuilder()
                    .setColor('#ff9900')
                    .setTitle('🔄 Counting Reset')
                    .setDescription('Counting game has been reset to 0!')
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });
            }

        } catch (error) {
            console.error('Counting command error:', error);
            await interaction.reply({ content: '❌ An error occurred while processing the command.', ephemeral: true });
        }
    }
};