const { SlashCommandBuilder, EmbedBuilder, ChannelType, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('confess')
        .setDescription('Send anonymous confession')
        .addSubcommand(subcommand =>
            subcommand
                .setName('send')
                .setDescription('Send a confession')
                .addStringOption(option =>
                    option.setName('message')
                        .setDescription('Your confession')
                        .setRequired(true)
                        .setMaxLength(1000))
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('Channel to send confession')
                        .addChannelTypes(ChannelType.GuildText)
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('modal')
                .setDescription('Send confession using modal form'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('stats')
                .setDescription('View confession statistics')),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        try {
            // Create confessions table if not exists
            await pool.query(`
                CREATE TABLE IF NOT EXISTS confessions (
                    id SERIAL PRIMARY KEY,
                    guild_id VARCHAR(20) NOT NULL,
                    channel_id VARCHAR(20) NOT NULL,
                    user_id VARCHAR(20) NOT NULL,
                    confession_number INTEGER NOT NULL,
                    message_text TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            `);

            if (subcommand === 'send') {
                const message = interaction.options.getString('message');
                let channel = interaction.options.getChannel('channel');
                
                // Find confession channel
                if (!channel) {
                    channel = interaction.guild.channels.cache.find(ch => 
                        ch.name.toLowerCase().includes('confession') || 
                        ch.name.toLowerCase().includes('confess') ||
                        ch.name.toLowerCase().includes('anonymous')
                    ) || interaction.channel;
                }

                // Check permissions
                if (!channel.permissionsFor(interaction.guild.members.me).has(['SendMessages', 'EmbedLinks'])) {
                    return interaction.reply({ 
                        content: '❌ I don\'t have permission to send messages in that channel!', 
                        ephemeral: true 
                    });
                }

                await this.sendConfession(interaction, channel, message);

            } else if (subcommand === 'modal') {
                const modal = new ModalBuilder()
                    .setCustomId('confession_modal')
                    .setTitle('📝 Anonymous Confession');

                const confessionInput = new TextInputBuilder()
                    .setCustomId('confession_text')
                    .setLabel('Your Confession')
                    .setStyle(TextInputStyle.Paragraph)
                    .setPlaceholder('Write your anonymous confession here...')
                    .setRequired(true)
                    .setMaxLength(1000);

                const actionRow = new ActionRowBuilder().addComponents(confessionInput);
                modal.addComponents(actionRow);

                await interaction.showModal(modal);

            } else if (subcommand === 'stats') {
                const result = await pool.query(
                    'SELECT COUNT(*) as total, MAX(confession_number) as highest FROM confessions WHERE guild_id = $1',
                    [interaction.guild.id]
                );

                const stats = result.rows[0];
                const embed = new EmbedBuilder()
                    .setColor('#800080')
                    .setTitle('📊 Confession Statistics')
                    .addFields(
                        { name: '📝 Total Confessions', value: stats.total || '0', inline: true },
                        { name: '🔢 Highest Number', value: stats.highest || '0', inline: true },
                        { name: '🤫 Anonymous', value: 'Always', inline: true }
                    )
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });
            }

        } catch (error) {
            console.error('Confession error:', error);
            await interaction.reply({ 
                content: '❌ An error occurred while processing your confession.', 
                ephemeral: true 
            });
        }
    },

    async sendConfession(interaction, channel, message) {
        // Get next confession number
        const numberResult = await pool.query(
            'SELECT COALESCE(MAX(confession_number), 0) + 1 as next_number FROM confessions WHERE guild_id = $1',
            [interaction.guild.id]
        );
        const confessionNumber = numberResult.rows[0].next_number;

        // Save to database
        await pool.query(`
            INSERT INTO confessions (guild_id, channel_id, user_id, confession_number, message_text) 
            VALUES ($1, $2, $3, $4, $5)
        `, [interaction.guild.id, channel.id, interaction.user.id, confessionNumber, message]);

        const embed = new EmbedBuilder()
            .setColor('#800080')
            .setTitle(`🤫 Anonymous Confession #${confessionNumber}`)
            .setDescription(message)
            .setFooter({ text: 'This confession is completely anonymous' })
            .setTimestamp();

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`confession_react_${confessionNumber}`)
                    .setLabel('❤️ Support')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId(`confession_hug_${confessionNumber}`)
                    .setLabel('🤗 Hug')
                    .setStyle(ButtonStyle.Secondary)
            );

        await channel.send({ embeds: [embed], components: [row] });

        const confirmEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('✅ Confession Sent Successfully')
            .setDescription(`Your confession #${confessionNumber} has been sent to ${channel}`)
            .addFields(
                { name: '🔒 Privacy', value: 'Your identity is completely protected', inline: false }
            )
            .setTimestamp();

        if (interaction.replied || interaction.deferred) {
            await interaction.followUp({ embeds: [confirmEmbed], ephemeral: true });
        } else {
            await interaction.reply({ embeds: [confirmEmbed], ephemeral: true });
        }
    }
};