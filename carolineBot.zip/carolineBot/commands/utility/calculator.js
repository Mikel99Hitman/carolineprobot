const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('calculator')
        .setDescription('🧮 Interactive professional calculator')
        .addStringOption(option =>
            option.setName('mode')
                .setDescription('Calculator mode')
                .setRequired(false)
                .addChoices(
                    { name: 'Basic', value: 'basic' },
                    { name: 'Scientific', value: 'scientific' }
                )),

    async execute(interaction) {
        const mode = interaction.options.getString('mode') || 'basic';
        
        const embed = new EmbedBuilder()
            .setTitle(`🧮 ${mode === 'scientific' ? 'Scientific' : 'Basic'} Calculator`)
            .setDescription('```\n0\n```')
            .setColor('#2F3136')
            .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() })
            .setTimestamp();

        if (mode === 'scientific') {
            // Scientific calculator layout
            const row1 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setCustomId('calc_clear').setLabel('C').setStyle(ButtonStyle.Danger),
                    new ButtonBuilder().setCustomId('calc_delete').setLabel('⌫').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('calc_sin').setLabel('sin').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('calc_cos').setLabel('cos').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('calc_tan').setLabel('tan').setStyle(ButtonStyle.Secondary)
                );

            const row2 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setCustomId('calc_7').setLabel('7').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_8').setLabel('8').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_9').setLabel('9').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_divide').setLabel('÷').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('calc_sqrt').setLabel('√').setStyle(ButtonStyle.Secondary)
                );

            const row3 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setCustomId('calc_4').setLabel('4').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_5').setLabel('5').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_6').setLabel('6').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_multiply').setLabel('×').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('calc_power').setLabel('x²').setStyle(ButtonStyle.Secondary)
                );

            const row4 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setCustomId('calc_1').setLabel('1').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_2').setLabel('2').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_3').setLabel('3').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_subtract').setLabel('-').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('calc_log').setLabel('log').setStyle(ButtonStyle.Secondary)
                );

            const row5 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setCustomId('calc_0').setLabel('0').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_dot').setLabel('.').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_pi').setLabel('π').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('calc_add').setLabel('+').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('calc_equals').setLabel('=').setStyle(ButtonStyle.Success).setEmoji('✅')
                );

            await interaction.reply({
                embeds: [embed],
                components: [row1, row2, row3, row4, row5],
                ephemeral: false
            });
        } else {
            // Basic calculator layout
            const row1 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setCustomId('calc_clear').setLabel('C').setStyle(ButtonStyle.Danger),
                    new ButtonBuilder().setCustomId('calc_delete').setLabel('⌫').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('calc_percent').setLabel('%').setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder().setCustomId('calc_divide').setLabel('÷').setStyle(ButtonStyle.Secondary)
                );

            const row2 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setCustomId('calc_7').setLabel('7').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_8').setLabel('8').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_9').setLabel('9').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_multiply').setLabel('×').setStyle(ButtonStyle.Secondary)
                );

            const row3 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setCustomId('calc_4').setLabel('4').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_5').setLabel('5').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_6').setLabel('6').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_subtract').setLabel('-').setStyle(ButtonStyle.Secondary)
                );

            const row4 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setCustomId('calc_1').setLabel('1').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_2').setLabel('2').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_3').setLabel('3').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_add').setLabel('+').setStyle(ButtonStyle.Secondary)
                );

            const row5 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder().setCustomId('calc_0').setLabel('0').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_dot').setLabel('.').setStyle(ButtonStyle.Primary),
                    new ButtonBuilder().setCustomId('calc_equals').setLabel('=').setStyle(ButtonStyle.Success).setEmoji('✅')
                );

            await interaction.reply({
                embeds: [embed],
                components: [row1, row2, row3, row4, row5],
                ephemeral: false
            });
        }
    }
};