const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Reminder = require('../../models/Reminder');
const ms = require('ms');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('remind')
        .setDescription('Set a reminder')
        .addStringOption(option =>
            option.setName('time')
                .setDescription('When to remind (e.g., 1h, 30m, 2d)')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('message')
                .setDescription('Reminder message')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('recurring')
                .setDescription('Make it recurring')
                .addChoices(
                    { name: 'Daily', value: 'daily' },
                    { name: 'Weekly', value: 'weekly' },
                    { name: 'Monthly', value: 'monthly' }
                )
                .setRequired(false)),

    async execute(interaction) {
        const timeString = interaction.options.getString('time');
        const message = interaction.options.getString('message');
        const recurring = interaction.options.getString('recurring');

        const time = ms(timeString);
        if (!time || time < 60000) {
            return interaction.reply({ content: '❌ Invalid time! Minimum is 1 minute.', ephemeral: true });
        }

        const remindTime = new Date(Date.now() + time);

        const reminder = new Reminder({
            userId: interaction.user.id,
            guildId: interaction.guild.id,
            channelId: interaction.channel.id,
            message,
            remindTime,
            recurring: {
                enabled: !!recurring,
                interval: recurring
            }
        });

        await reminder.save();

        const embed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('⏰ Reminder Set!')
            .setDescription(`I'll remind you about: **${message}**`)
            .addFields(
                { name: 'Time', value: `<t:${Math.floor(remindTime.getTime() / 1000)}:F>`, inline: true },
                { name: 'In', value: `<t:${Math.floor(remindTime.getTime() / 1000)}:R>`, inline: true }
            );

        if (recurring) {
            embed.addFields({ name: 'Recurring', value: recurring, inline: true });
        }

        await interaction.reply({ embeds: [embed] });

        // Set timeout for reminder
        setTimeout(async () => {
            await sendReminder(reminder._id);
        }, time);
    }
};

async function sendReminder(reminderId) {
    try {
        const reminder = await Reminder.findById(reminderId);
        if (!reminder || reminder.completed) return;

        const guild = client.guilds.cache.get(reminder.guildId);
        const channel = guild?.channels.cache.get(reminder.channelId);
        const user = await client.users.fetch(reminder.userId);

        if (!channel || !user) return;

        const embed = new EmbedBuilder()
            .setColor('#ffaa00')
            .setTitle('⏰ Reminder!')
            .setDescription(reminder.message)
            .setFooter({ text: 'Reminder from ProBot' })
            .setTimestamp();

        await channel.send({ content: `${user}`, embeds: [embed] });

        if (reminder.recurring.enabled) {
            // Set next reminder
            let nextTime;
            switch (reminder.recurring.interval) {
                case 'daily':
                    nextTime = new Date(Date.now() + 24 * 60 * 60 * 1000);
                    break;
                case 'weekly':
                    nextTime = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
                    break;
                case 'monthly':
                    nextTime = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
                    break;
            }

            reminder.remindTime = nextTime;
            await reminder.save();

            setTimeout(async () => {
                await sendReminder(reminderId);
            }, nextTime.getTime() - Date.now());
        } else {
            reminder.completed = true;
            await reminder.save();
        }
    } catch (error) {
        console.error('Error sending reminder:', error);
    }
}