const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const Starboard = require('../../models/Starboard');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('starboard')
        .setDescription('Setup starboard system')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Starboard channel')
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('threshold')
                .setDescription('Star threshold')
                .setMinValue(1)
                .setMaxValue(20)
                .setRequired(false))
        .addStringOption(option =>
            option.setName('emoji')
                .setDescription('Star emoji')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

    async execute(interaction) {
        const channel = interaction.options.getChannel('channel');
        const threshold = interaction.options.getInteger('threshold') || 3;
        const emoji = interaction.options.getString('emoji') || '⭐';

        const starboard = new Starboard({
            guildId: interaction.guild.id,
            channelId: channel.id,
            threshold,
            emoji
        });

        await starboard.save();

        const embed = new EmbedBuilder()
            .setColor('#ffd700')
            .setTitle('⭐ Starboard Setup')
            .setDescription(`Starboard configured in ${channel}`)
            .addFields(
                { name: 'Threshold', value: threshold.toString(), inline: true },
                { name: 'Emoji', value: emoji, inline: true }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};