const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('embed')
        .setDescription('Create custom embed')
        .addSubcommand(subcommand =>
            subcommand
                .setName('create')
                .setDescription('Create embed with basic options')
                .addStringOption(option =>
                    option.setName('title')
                        .setDescription('Embed title')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('description')
                        .setDescription('Embed description')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('color')
                        .setDescription('Embed color (hex)')
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('image')
                        .setDescription('Image URL')
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('thumbnail')
                        .setDescription('Thumbnail URL')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('builder')
                .setDescription('Advanced embed builder with interactive interface'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'create') {
            const title = interaction.options.getString('title');
            const description = interaction.options.getString('description');
            const color = interaction.options.getString('color') || '#0099ff';
            const image = interaction.options.getString('image');
            const thumbnail = interaction.options.getString('thumbnail');

            // Validate color format
            const colorRegex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
            if (!colorRegex.test(color)) {
                return interaction.reply({ content: '❌ Invalid color format! Use hex format like #0099ff', ephemeral: true });
            }

            // Validate URLs
            if (image && !isValidUrl(image)) {
                return interaction.reply({ content: '❌ Invalid image URL!', ephemeral: true });
            }
            if (thumbnail && !isValidUrl(thumbnail)) {
                return interaction.reply({ content: '❌ Invalid thumbnail URL!', ephemeral: true });
            }

            try {
                const embed = new EmbedBuilder()
                    .setTitle(title.substring(0, 256))
                    .setDescription(description.substring(0, 4096))
                    .setColor(color)
                    .setTimestamp()
                    .setFooter({ text: `Created by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL() });

                if (image) embed.setImage(image);
                if (thumbnail) embed.setThumbnail(thumbnail);

                await interaction.reply({ content: '✅ Embed created successfully!', embeds: [embed] });
            } catch (error) {
                console.error('Embed creation error:', error);
                await interaction.reply({ content: '❌ Failed to create embed!', ephemeral: true });
            }

        } else if (subcommand === 'builder') {
            const embed = new EmbedBuilder()
                .setTitle('🛠️ Embed Builder')
                .setDescription('Use the buttons below to customize your embed')
                .setColor('#0099ff')
                .addFields(
                    { name: 'Title', value: 'Not set', inline: true },
                    { name: 'Description', value: 'Not set', inline: true },
                    { name: 'Color', value: '#0099ff', inline: true },
                    { name: 'Image', value: 'Not set', inline: true },
                    { name: 'Thumbnail', value: 'Not set', inline: true },
                    { name: 'Footer', value: 'Not set', inline: true }
                )
                .setTimestamp();

            const row1 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('embed_title')
                        .setLabel('Set Title')
                        .setStyle(ButtonStyle.Primary)
                        .setEmoji('📝'),
                    new ButtonBuilder()
                        .setCustomId('embed_description')
                        .setLabel('Set Description')
                        .setStyle(ButtonStyle.Primary)
                        .setEmoji('📜'),
                    new ButtonBuilder()
                        .setCustomId('embed_color')
                        .setLabel('Set Color')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('🎨')
                );

            const row2 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('embed_image')
                        .setLabel('Set Image')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('🖼️'),
                    new ButtonBuilder()
                        .setCustomId('embed_thumbnail')
                        .setLabel('Set Thumbnail')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('🗺'),
                    new ButtonBuilder()
                        .setCustomId('embed_footer')
                        .setLabel('Set Footer')
                        .setStyle(ButtonStyle.Secondary)
                        .setEmoji('📝')
                );

            const row3 = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('embed_preview')
                        .setLabel('Preview')
                        .setStyle(ButtonStyle.Success)
                        .setEmoji('👀'),
                    new ButtonBuilder()
                        .setCustomId('embed_send')
                        .setLabel('Send Embed')
                        .setStyle(ButtonStyle.Success)
                        .setEmoji('✅'),
                    new ButtonBuilder()
                        .setCustomId('embed_reset')
                        .setLabel('Reset')
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji('🔄')
                );

            await interaction.reply({ 
                embeds: [embed], 
                components: [row1, row2, row3],
                ephemeral: true
            });
        }
    }
};

function isValidUrl(string) {
    try {
        const url = new URL(string);
        return url.protocol === 'http:' || url.protocol === 'https:';
    } catch {
        return false;
    }
}