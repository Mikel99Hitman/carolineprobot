const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('birthday')
        .setDescription('Birthday management')
        .addSubcommand(subcommand =>
            subcommand
                .setName('set')
                .setDescription('Set your birthday')
                .addStringOption(option =>
                    option.setName('date')
                        .setDescription('Birthday date (DD/MM/YYYY)')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('list')
                .setDescription('List upcoming birthdays'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('today')
                .setDescription('Show today\'s birthdays')),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'set') {
            const dateString = interaction.options.getString('date');
            const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
            
            if (!dateRegex.test(dateString)) {
                return interaction.reply({ content: '❌ Invalid date format! Use DD/MM/YYYY', ephemeral: true });
            }

            const [, day, month, year] = dateString.match(dateRegex);
            const birthday = new Date(year, month - 1, day);

            if (birthday > new Date()) {
                return interaction.reply({ content: '❌ Birthday cannot be in the future!', ephemeral: true });
            }

            try {
                await pool.query(
                    'INSERT INTO birthdays (user_id, guild_id, birthday) VALUES ($1, $2, $3) ON CONFLICT (user_id, guild_id) DO UPDATE SET birthday = $3',
                    [interaction.user.id, interaction.guild.id, birthday]
                );

                const embed = new EmbedBuilder()
                    .setColor('#ff69b4')
                    .setTitle('🎂 Birthday Set!')
                    .setDescription(`Your birthday has been set to ${birthday.toLocaleDateString()}`)
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });
            } catch (error) {
                console.error('Birthday set error:', error);
                await interaction.reply({ content: '❌ Failed to set birthday!', ephemeral: true });
            }

        } else if (subcommand === 'list') {
            try {
                const result = await pool.query(
                    'SELECT user_id, birthday FROM birthdays WHERE guild_id = $1 ORDER BY EXTRACT(MONTH FROM birthday), EXTRACT(DAY FROM birthday)',
                    [interaction.guild.id]
                );

                if (result.rows.length === 0) {
                    return interaction.reply({ content: '🎂 No birthdays registered!', ephemeral: true });
                }

                const embed = new EmbedBuilder()
                    .setColor('#ff69b4')
                    .setTitle('🎉 Upcoming Birthdays')
                    .setDescription('List of all registered birthdays');

                const today = new Date();
                const upcomingBirthdays = result.rows
                    .map(row => {
                        const birthday = new Date(row.birthday);
                        const thisYear = new Date(today.getFullYear(), birthday.getMonth(), birthday.getDate());
                        const nextYear = new Date(today.getFullYear() + 1, birthday.getMonth(), birthday.getDate());
                        const nextBirthday = thisYear >= today ? thisYear : nextYear;
                        const daysUntil = Math.ceil((nextBirthday - today) / (1000 * 60 * 60 * 24));
                        
                        return {
                            userId: row.user_id,
                            birthday: birthday,
                            daysUntil: daysUntil
                        };
                    })
                    .sort((a, b) => a.daysUntil - b.daysUntil)
                    .slice(0, 10);

                upcomingBirthdays.forEach((b, index) => {
                    const daysText = b.daysUntil === 0 ? 'Today!' : b.daysUntil === 1 ? 'Tomorrow' : `${b.daysUntil} days`;
                    embed.addFields({
                        name: `${index + 1}. <@${b.userId}>`,
                        value: `${b.birthday.toLocaleDateString()} (${daysText})`,
                        inline: true
                    });
                });

                await interaction.reply({ embeds: [embed] });
            } catch (error) {
                console.error('Birthday list error:', error);
                await interaction.reply({ content: '❌ Failed to fetch birthdays!', ephemeral: true });
            }

        } else if (subcommand === 'today') {
            try {
                const today = new Date();
                const result = await pool.query(
                    'SELECT user_id, birthday FROM birthdays WHERE guild_id = $1 AND EXTRACT(MONTH FROM birthday) = $2 AND EXTRACT(DAY FROM birthday) = $3',
                    [interaction.guild.id, today.getMonth() + 1, today.getDate()]
                );

                if (result.rows.length === 0) {
                    return interaction.reply({ content: '🎂 No birthdays today!', ephemeral: true });
                }

                const embed = new EmbedBuilder()
                    .setColor('#ff69b4')
                    .setTitle('🎉 Today\'s Birthdays!')
                    .setDescription(result.rows.map(row => `<@${row.user_id}>`).join('\n'))
                    .setFooter({ text: `${result.rows.length} birthday${result.rows.length > 1 ? 's' : ''} today!` })
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });
            } catch (error) {
                console.error('Birthday today error:', error);
                await interaction.reply({ content: '❌ Failed to fetch today\'s birthdays!', ephemeral: true });
            }
        }
    }
};