const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

const deletedMessages = new Map();
const editedMessages = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('snipe')
        .setDescription('View recently deleted messages')
        .addSubcommand(subcommand =>
            subcommand
                .setName('delete')
                .setDescription('View deleted message'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('edit')
                .setDescription('View edited message')),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'delete') {
            const deleted = deletedMessages.get(interaction.channel.id);
            if (!deleted) {
                return interaction.reply({ content: '❌ No recently deleted messages!', ephemeral: true });
            }

            const embed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('🗑️ Deleted Message')
                .setDescription(deleted.content || 'No content')
                .setFooter({ text: `${deleted.author.tag}`, iconURL: deleted.author.displayAvatarURL() })
                .setTimestamp(deleted.deletedAt);

            await interaction.reply({ embeds: [embed] });

        } else if (subcommand === 'edit') {
            const edited = editedMessages.get(interaction.channel.id);
            if (!edited) {
                return interaction.reply({ content: '❌ No recently edited messages!', ephemeral: true });
            }

            const embed = new EmbedBuilder()
                .setColor('#ffaa00')
                .setTitle('✏️ Edited Message')
                .addFields(
                    { name: 'Before', value: edited.oldContent || 'No content', inline: false },
                    { name: 'After', value: edited.newContent || 'No content', inline: false }
                )
                .setFooter({ text: `${edited.author.tag}`, iconURL: edited.author.displayAvatarURL() })
                .setTimestamp(edited.editedAt);

            await interaction.reply({ embeds: [embed] });
        }
    }
};

// Export for use in message events
module.exports.deletedMessages = deletedMessages;
module.exports.editedMessages = editedMessages;