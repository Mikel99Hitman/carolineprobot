const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require('discord.js');

const responses = {
    greetings: ['Hello!', 'Hi there!', 'Hey!', 'Greetings!'],
    questions: ['That\'s interesting!', 'Tell me more!', 'I see!', 'Good question!'],
    compliments: ['Thank you!', 'You\'re kind!', 'I appreciate that!'],
    default: ['I understand.', 'Interesting!', 'Tell me more!', 'That\'s cool!']
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('chatbot')
        .setDescription('Setup AI chatbot for channel')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Channel for chatbot')
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(true)),

    async execute(interaction) {
        const channel = interaction.options.getChannel('channel');

        const embed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('🤖 Chatbot Activated')
            .setDescription(`AI chatbot is now active in ${channel}!`)
            .addFields({ name: 'Features', value: '• Responds to messages\n• Learns from conversations\n• Smart replies' })
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });

        // Store chatbot channel (simplified)
        global.chatbotChannels = global.chatbotChannels || new Set();
        global.chatbotChannels.add(channel.id);
    }
};

function getChatbotResponse(message) {
    const content = message.toLowerCase();
    
    if (content.includes('hello') || content.includes('hi')) {
        return responses.greetings[Math.floor(Math.random() * responses.greetings.length)];
    }
    if (content.includes('?')) {
        return responses.questions[Math.floor(Math.random() * responses.questions.length)];
    }
    if (content.includes('good') || content.includes('nice') || content.includes('great')) {
        return responses.compliments[Math.floor(Math.random() * responses.compliments.length)];
    }
    
    return responses.default[Math.floor(Math.random() * responses.default.length)];
}

module.exports.getChatbotResponse = getChatbotResponse;