const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { Pool } = require('pg');
const ms = require('ms');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('poll')
        .setDescription('Create an interactive poll with voting buttons')
        .addStringOption(option =>
            option.setName('question')
                .setDescription('Poll question')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('options')
                .setDescription('Poll options separated by | (max 10)')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('duration')
                .setDescription('Poll duration (e.g., 1h, 30m, 1d)')
                .setRequired(false))
        .addBooleanOption(option =>
            option.setName('multiple')
                .setDescription('Allow multiple votes per user')
                .setRequired(false))
        .addBooleanOption(option =>
            option.setName('anonymous')
                .setDescription('Hide voter identities')
                .setRequired(false)),

    async execute(interaction) {
        const question = interaction.options.getString('question');
        const optionsString = interaction.options.getString('options');
        const duration = interaction.options.getString('duration') || '1h';
        const allowMultiple = interaction.options.getBoolean('multiple') || false;
        const anonymous = interaction.options.getBoolean('anonymous') || false;

        const optionTexts = optionsString.split('|').map(opt => opt.trim()).slice(0, 10);
        
        if (optionTexts.length < 2) {
            return interaction.reply({ content: '❌ You need at least 2 options!', ephemeral: true });
        }

        const time = ms(duration);
        if (!time || time < 60000) {
            return interaction.reply({ content: '❌ Invalid duration! Minimum is 1 minute.', ephemeral: true });
        }

        try {
            // Create polls table
            await pool.query(`
                CREATE TABLE IF NOT EXISTS polls (
                    id SERIAL PRIMARY KEY,
                    guild_id VARCHAR(20) NOT NULL,
                    channel_id VARCHAR(20) NOT NULL,
                    message_id VARCHAR(20) NOT NULL,
                    creator_id VARCHAR(20) NOT NULL,
                    question TEXT NOT NULL,
                    options TEXT[] NOT NULL,
                    votes JSONB DEFAULT '{}',
                    end_time TIMESTAMP NOT NULL,
                    allow_multiple BOOLEAN DEFAULT false,
                    anonymous BOOLEAN DEFAULT false,
                    ended BOOLEAN DEFAULT false,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            `);

            const endTime = new Date(Date.now() + time);
            const emojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟'];

            const pollEmbed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle('📊 Interactive Poll')
                .setDescription(`**${question}**`)
                .addFields(
                    optionTexts.map((text, index) => ({
                        name: `${emojis[index]} ${text}`,
                        value: '0 votes (0%)',
                        inline: true
                    }))
                )
                .addFields(
                    { name: '⚙️ Settings', value: `Multiple votes: ${allowMultiple ? '✅' : '❌'}\nAnonymous: ${anonymous ? '✅' : '❌'}`, inline: true },
                    { name: '⏰ Ends', value: `<t:${Math.floor(endTime.getTime() / 1000)}:R>`, inline: true },
                    { name: '👥 Total Votes', value: '0', inline: true }
                )
                .setFooter({ text: `Created by ${interaction.user.tag} • Click buttons to vote` })
                .setTimestamp();

            // Create voting buttons
            const buttons = [];
            for (let i = 0; i < Math.min(optionTexts.length, 5); i++) {
                buttons.push(
                    new ButtonBuilder()
                        .setCustomId(`poll_vote_${i}`)
                        .setLabel(optionTexts[i])
                        .setEmoji(emojis[i])
                        .setStyle(ButtonStyle.Primary)
                );
            }

            const row1 = new ActionRowBuilder().addComponents(buttons);
            const components = [row1];

            // Second row if more than 5 options
            if (optionTexts.length > 5) {
                const buttons2 = [];
                for (let i = 5; i < Math.min(optionTexts.length, 10); i++) {
                    buttons2.push(
                        new ButtonBuilder()
                            .setCustomId(`poll_vote_${i}`)
                            .setLabel(optionTexts[i])
                            .setEmoji(emojis[i])
                            .setStyle(ButtonStyle.Primary)
                    );
                }
                components.push(new ActionRowBuilder().addComponents(buttons2));
            }

            // Control buttons
            const controlButtons = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('poll_results')
                        .setLabel('📊 Results')
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId('poll_end')
                        .setLabel('⏹️ End Poll')
                        .setStyle(ButtonStyle.Danger)
                );

            components.push(controlButtons);

            const pollMessage = await interaction.reply({ embeds: [pollEmbed], components, fetchReply: true });

            // Save poll to database
            await pool.query(`
                INSERT INTO polls (guild_id, channel_id, message_id, creator_id, question, options, end_time, allow_multiple, anonymous)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
            `, [
                interaction.guild.id,
                interaction.channel.id,
                pollMessage.id,
                interaction.user.id,
                question,
                optionTexts,
                endTime,
                allowMultiple,
                anonymous
            ]);

            // Set timeout to end poll
            setTimeout(async () => {
                await this.endPoll(pollMessage.id);
            }, time);

        } catch (error) {
            console.error('Poll creation error:', error);
            await interaction.reply({ 
                content: '❌ An error occurred while creating the poll.', 
                ephemeral: true 
            });
        }
    },

    async endPoll(messageId) {
        try {
            const result = await pool.query(
                'SELECT * FROM polls WHERE message_id = $1 AND ended = false',
                [messageId]
            );

            if (result.rows.length === 0) return;

            const poll = result.rows[0];
            
            // Mark as ended
            await pool.query(
                'UPDATE polls SET ended = true WHERE message_id = $1',
                [messageId]
            );

            // Update message with final results
            // This would require access to the Discord client
            console.log(`Poll ${messageId} has ended`);

        } catch (error) {
            console.error('Error ending poll:', error);
        }
    }
};