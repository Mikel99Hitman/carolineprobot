const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('fivem')
        .setDescription('🎮 Advanced FiveM Roleplay Management System')
        .addSubcommand(subcommand =>
            subcommand
                .setName('server')
                .setDescription('Check FiveM server status and information')
                .addStringOption(option =>
                    option.setName('ip')
                        .setDescription('FiveM server IP address (optional)')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('character')
                .setDescription('Create and manage roleplay characters')
                .addStringOption(option =>
                    option.setName('action')
                        .setDescription('Character action')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Create New Character', value: 'create' },
                            { name: 'View My Characters', value: 'view' },
                            { name: 'Edit Character', value: 'edit' },
                            { name: 'Delete Character', value: 'delete' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('jobs')
                .setDescription('Manage roleplay jobs and careers')
                .addStringOption(option =>
                    option.setName('action')
                        .setDescription('Job system action')
                        .setRequired(true)
                        .addChoices(
                            { name: 'View Available Jobs', value: 'list' },
                            { name: 'Apply for Job', value: 'apply' },
                            { name: 'Job Statistics', value: 'stats' },
                            { name: 'Salary Calculator', value: 'salary' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('economy')
                .setDescription('Track server economy and player finances')
                .addStringOption(option =>
                    option.setName('type')
                        .setDescription('Economy tracking type')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Bank Account', value: 'bank' },
                            { name: 'Business Stats', value: 'business' },
                            { name: 'Property Values', value: 'property' },
                            { name: 'Market Analysis', value: 'market' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('whitelist')
                .setDescription('Manage server whitelist applications')
                .addStringOption(option =>
                    option.setName('action')
                        .setDescription('Whitelist action')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Submit Application', value: 'apply' },
                            { name: 'Check Status', value: 'status' },
                            { name: 'View Applications', value: 'view' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('vehicles')
                .setDescription('Manage player vehicles and garage')
                .addStringOption(option =>
                    option.setName('action')
                        .setDescription('Vehicle action')
                        .setRequired(true)
                        .addChoices(
                            { name: 'View Garage', value: 'garage' },
                            { name: 'Vehicle Stats', value: 'stats' },
                            { name: 'Insurance Claims', value: 'insurance' },
                            { name: 'Marketplace', value: 'market' }
                        ))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        
        try {
            await this.createTables();
            
            switch (subcommand) {
                case 'server':
                    await this.handleServer(interaction);
                    break;
                case 'character':
                    await this.handleCharacter(interaction);
                    break;
                case 'jobs':
                    await this.handleJobs(interaction);
                    break;
                case 'economy':
                    await this.handleEconomy(interaction);
                    break;
                case 'whitelist':
                    await this.handleWhitelist(interaction);
                    break;
                case 'vehicles':
                    await this.handleVehicles(interaction);
                    break;
            }
        } catch (error) {
            console.error('FiveM command error:', error);
            await interaction.reply({ content: '❌ An error occurred while processing the FiveM command.', ephemeral: true });
        }
    },

    async createTables() {
        await pool.query(`
            CREATE TABLE IF NOT EXISTS fivem_characters (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                character_name VARCHAR(100) NOT NULL,
                character_age INTEGER NOT NULL,
                background TEXT,
                job VARCHAR(50),
                skills TEXT,
                bank_balance BIGINT DEFAULT 0,
                cash_balance BIGINT DEFAULT 5000,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS fivem_whitelist (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                application_text TEXT NOT NULL,
                status VARCHAR(20) DEFAULT 'pending',
                reviewed_by VARCHAR(20),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS fivem_vehicles (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                vehicle_name VARCHAR(100) NOT NULL,
                vehicle_type VARCHAR(50) NOT NULL,
                purchase_price BIGINT NOT NULL,
                condition_percent INTEGER DEFAULT 100,
                insurance_active BOOLEAN DEFAULT false,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
    },

    async handleServer(interaction) {
        await interaction.deferReply();

        const serverIP = interaction.options.getString('ip') || 'connect.example-rp.com';
        const serverData = this.generateServerData(serverIP);

        const embed = new EmbedBuilder()
            .setTitle('🎮 FiveM Server Status')
            .setDescription(`**Server:** \`${serverIP}\``)
            .addFields(
                { name: '🟢 Status', value: serverData.status, inline: true },
                { name: '👥 Players', value: `${serverData.playersOnline}/${serverData.maxPlayers}`, inline: true },
                { name: '📈 Load', value: serverData.serverLoad, inline: true },
                { name: '🏢 Server Name', value: serverData.serverName, inline: false },
                { name: '🎯 Game Mode', value: serverData.gameMode, inline: true },
                { name: '🗺️ Map', value: serverData.currentMap, inline: true },
                { name: '⏱️ Uptime', value: serverData.uptime, inline: true },
                { name: '👮 Active Jobs', value: `👮 Police: ${serverData.activePolice}\n🚑 EMS: ${serverData.activeEMS}\n🔧 Mechanics: ${serverData.activeMechanics}`, inline: true },
                { name: '📡 Live Activity', value: serverData.recentActivity.join('\n'), inline: false }
            )
            .setColor(serverData.status.includes('Online') ? '#00ff00' : '#ff0000')
            .setTimestamp()
            .setFooter({ text: 'FiveM Server Monitor • Live Data' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('fivem_refresh')
                    .setLabel('🔄 Refresh')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('fivem_players')
                    .setLabel('👥 Player List')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('fivem_connect')
                    .setLabel('🔗 Connect')
                    .setStyle(ButtonStyle.Success)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async handleCharacter(interaction) {
        const action = interaction.options.getString('action');
        
        if (action === 'create') {
            const modal = new ModalBuilder()
                .setCustomId('fivem_character_modal')
                .setTitle('🎭 Create FiveM Character');

            const nameInput = new TextInputBuilder()
                .setCustomId('char_name')
                .setLabel('Character Full Name')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('John Smith')
                .setRequired(true)
                .setMaxLength(50);

            const ageInput = new TextInputBuilder()
                .setCustomId('char_age')
                .setLabel('Character Age (18-80)')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('25')
                .setRequired(true)
                .setMaxLength(2);

            const backgroundInput = new TextInputBuilder()
                .setCustomId('char_background')
                .setLabel('Character Background & Personality')
                .setStyle(TextInputStyle.Paragraph)
                .setPlaceholder('Describe your character\'s history, personality, goals...')
                .setRequired(true)
                .setMaxLength(1000);

            const jobInput = new TextInputBuilder()
                .setCustomId('char_job')
                .setLabel('Desired Job/Career')
                .setStyle(TextInputStyle.Short)
                .setPlaceholder('Police, Doctor, Mechanic, Criminal, etc.')
                .setRequired(false)
                .setMaxLength(50);

            const skillsInput = new TextInputBuilder()
                .setCustomId('char_skills')
                .setLabel('Special Skills & Abilities')
                .setStyle(TextInputStyle.Paragraph)
                .setPlaceholder('Driving, Medical, Combat, Technology, etc.')
                .setRequired(false)
                .setMaxLength(500);

            modal.addComponents(
                new ActionRowBuilder().addComponents(nameInput),
                new ActionRowBuilder().addComponents(ageInput),
                new ActionRowBuilder().addComponents(backgroundInput),
                new ActionRowBuilder().addComponents(jobInput),
                new ActionRowBuilder().addComponents(skillsInput)
            );

            await interaction.showModal(modal);
            
        } else if (action === 'view') {
            const characters = await pool.query(
                'SELECT * FROM fivem_characters WHERE user_id = $1 AND guild_id = $2 ORDER BY created_at DESC',
                [interaction.user.id, interaction.guild.id]
            );

            if (characters.rows.length === 0) {
                return interaction.reply({ 
                    content: '📋 You have no characters created. Use `/fivem character action:create` to create one!', 
                    ephemeral: true 
                });
            }

            const embed = new EmbedBuilder()
                .setTitle('🎭 Your FiveM Characters')
                .setDescription(`You have **${characters.rows.length}** character(s)`)
                .setColor('#9932cc')
                .setTimestamp();

            characters.rows.forEach((char, index) => {
                embed.addFields({
                    name: `${index + 1}. ${char.character_name} (Age: ${char.character_age})`,
                    value: `**Job:** ${char.job || 'Unemployed'}\n**Bank:** $${parseInt(char.bank_balance).toLocaleString()}\n**Cash:** $${parseInt(char.cash_balance).toLocaleString()}\n**Created:** <t:${Math.floor(new Date(char.created_at).getTime() / 1000)}:R>`,
                    inline: true
                });
            });

            await interaction.reply({ embeds: [embed] });
        }
    },

    async handleJobs(interaction) {
        const action = interaction.options.getString('action');
        
        if (action === 'list') {
            const jobs = this.getAvailableJobs();
            
            const embed = new EmbedBuilder()
                .setTitle('💼 Available FiveM Jobs')
                .setDescription('Choose your career path in the city')
                .setColor('#4169e1')
                .setTimestamp();

            Object.keys(jobs).forEach(category => {
                const jobList = jobs[category].map(job => 
                    `**${job.name}** - $${job.salary.toLocaleString()}/hour\n${job.description}`
                ).join('\n\n');
                
                embed.addFields({
                    name: `${category} Jobs`,
                    value: jobList,
                    inline: false
                });
            });

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('fivem_job_apply')
                        .setLabel('📝 Apply for Job')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId('fivem_job_requirements')
                        .setLabel('📄 Requirements')
                        .setStyle(ButtonStyle.Secondary)
                );

            await interaction.reply({ embeds: [embed], components: [row] });
            
        } else if (action === 'salary') {
            const embed = new EmbedBuilder()
                .setTitle('💰 FiveM Salary Calculator')
                .setDescription('Calculate your potential earnings')
                .addFields(
                    { name: '👮 Police Officer', value: 'Base: $75/hour\nBonus: $25/arrest\nOvertime: 1.5x rate', inline: true },
                    { name: '🚑 Paramedic', value: 'Base: $70/hour\nBonus: $30/life saved\nNight shift: +$15/hour', inline: true },
                    { name: '🔧 Mechanic', value: 'Base: $60/hour\nRepair bonus: $50/vehicle\nCustom work: $100+', inline: true },
                    { name: '🏦 Bank Teller', value: 'Base: $45/hour\nTransaction fee: $2 each\nSafe hours: 9AM-5PM', inline: true },
                    { name: '🍕 Delivery Driver', value: 'Base: $35/hour\nDelivery bonus: $15 each\nTips: Variable', inline: true },
                    { name: '💼 Business Owner', value: 'Profit share: 60%\nEmployee costs: -$40/hour\nTax rate: 15%', inline: true }
                )
                .setColor('#228b22')
                .setFooter({ text: 'Salaries may vary based on server economy' })
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        }
    },

    async handleEconomy(interaction) {
        const type = interaction.options.getString('type');
        const economyData = this.generateEconomyData(type);
        
        const embed = new EmbedBuilder()
            .setTitle(`💹 FiveM ${type.toUpperCase()} System`)
            .setDescription(economyData.description)
            .setColor('#daa520')
            .setTimestamp();

        economyData.fields.forEach(field => {
            embed.addFields(field);
        });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`fivem_${type}_details`)
                    .setLabel('🔍 View Details')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId(`fivem_${type}_history`)
                    .setLabel('📈 Transaction History')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.reply({ embeds: [embed], components: [row] });
    },

    async handleWhitelist(interaction) {
        const action = interaction.options.getString('action');
        
        if (action === 'apply') {
            const modal = new ModalBuilder()
                .setCustomId('fivem_whitelist_modal')
                .setTitle('📋 FiveM Whitelist Application');

            const applicationInput = new TextInputBuilder()
                .setCustomId('whitelist_application')
                .setLabel('Why do you want to join our FiveM server?')
                .setStyle(TextInputStyle.Paragraph)
                .setPlaceholder('Tell us about your roleplay experience, what you can bring to the community, and why you want to join...')
                .setRequired(true)
                .setMaxLength(2000);

            modal.addComponents(new ActionRowBuilder().addComponents(applicationInput));
            await interaction.showModal(modal);
            
        } else if (action === 'status') {
            const application = await pool.query(
                'SELECT * FROM fivem_whitelist WHERE user_id = $1 AND guild_id = $2 ORDER BY created_at DESC LIMIT 1',
                [interaction.user.id, interaction.guild.id]
            );

            if (application.rows.length === 0) {
                return interaction.reply({ 
                    content: '📋 You have no whitelist applications. Use `/fivem whitelist action:apply` to submit one!', 
                    ephemeral: true 
                });
            }

            const app = application.rows[0];
            const statusEmojis = {
                pending: '🟡',
                approved: '✅',
                denied: '❌'
            };

            const embed = new EmbedBuilder()
                .setTitle('📋 Whitelist Application Status')
                .addFields(
                    { name: '📅 Submitted', value: `<t:${Math.floor(new Date(app.created_at).getTime() / 1000)}:F>`, inline: true },
                    { name: '📈 Status', value: `${statusEmojis[app.status]} ${app.status.toUpperCase()}`, inline: true },
                    { name: '👥 Reviewed By', value: app.reviewed_by ? `<@${app.reviewed_by}>` : 'Pending review', inline: true }
                )
                .setColor(app.status === 'approved' ? '#00ff00' : app.status === 'denied' ? '#ff0000' : '#ffff00')
                .setTimestamp();

            await interaction.reply({ embeds: [embed], ephemeral: true });
        }
    },

    async handleVehicles(interaction) {
        const action = interaction.options.getString('action');
        
        if (action === 'garage') {
            const vehicles = await pool.query(
                'SELECT * FROM fivem_vehicles WHERE user_id = $1 AND guild_id = $2 ORDER BY created_at DESC',
                [interaction.user.id, interaction.guild.id]
            );

            if (vehicles.rows.length === 0) {
                return interaction.reply({ 
                    content: '🏎️ Your garage is empty! Visit a dealership to purchase vehicles.', 
                    ephemeral: true 
                });
            }

            const embed = new EmbedBuilder()
                .setTitle('🏎️ Your Vehicle Garage')
                .setDescription(`You own **${vehicles.rows.length}** vehicle(s)`)
                .setColor('#ff4500')
                .setTimestamp();

            vehicles.rows.forEach((vehicle, index) => {
                const conditionEmoji = vehicle.condition_percent >= 80 ? '🟢' : 
                                     vehicle.condition_percent >= 50 ? '🟡' : '🔴';
                
                embed.addFields({
                    name: `${index + 1}. ${vehicle.vehicle_name}`,
                    value: `**Type:** ${vehicle.vehicle_type}\n**Condition:** ${conditionEmoji} ${vehicle.condition_percent}%\n**Insurance:** ${vehicle.insurance_active ? '✅ Active' : '❌ Inactive'}\n**Value:** $${parseInt(vehicle.purchase_price).toLocaleString()}`,
                    inline: true
                });
            });

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('fivem_vehicle_spawn')
                        .setLabel('🚗 Spawn Vehicle')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId('fivem_vehicle_repair')
                        .setLabel('🔧 Repair Service')
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId('fivem_vehicle_sell')
                        .setLabel('💰 Sell Vehicle')
                        .setStyle(ButtonStyle.Danger)
                );

            await interaction.reply({ embeds: [embed], components: [row] });
            
        } else if (action === 'market') {
            const vehicles = this.getVehicleMarket();
            
            const embed = new EmbedBuilder()
                .setTitle('🏎️ Vehicle Marketplace')
                .setDescription('Browse and purchase vehicles')
                .setColor('#4169e1')
                .setTimestamp();

            Object.keys(vehicles).forEach(category => {
                const vehicleList = vehicles[category].map(v => 
                    `**${v.name}** - $${v.price.toLocaleString()}\n${v.description}`
                ).join('\n\n');
                
                embed.addFields({
                    name: `${category} Vehicles`,
                    value: vehicleList,
                    inline: false
                });
            });

            await interaction.reply({ embeds: [embed] });
        }
    },

    generateServerData(serverIP) {
        return {
            status: '🟢 Online',
            playersOnline: Math.floor(Math.random() * 200) + 50,
            maxPlayers: 250,
            serverLoad: `${Math.floor(Math.random() * 30) + 40}%`,
            serverName: 'Los Santos Roleplay | Serious RP',
            gameMode: 'Roleplay',
            currentMap: 'Los Santos',
            uptime: `${Math.floor(Math.random() * 24) + 1}h ${Math.floor(Math.random() * 60)}m`,
            activePolice: Math.floor(Math.random() * 15) + 5,
            activeEMS: Math.floor(Math.random() * 8) + 3,
            activeMechanics: Math.floor(Math.random() * 6) + 2,
            recentActivity: [
                '🚔 Police chase - Downtown LS',
                '🚑 Medical emergency - Sandy Shores', 
                '🏦 Bank robbery - Vinewood',
                '🚗 Street racing - Highway 1',
                '👮 Traffic stop - Mirror Park'
            ]
        };
    },

    getAvailableJobs() {
        return {
            'Government': [
                { name: 'Police Officer', salary: 75, description: 'Protect and serve the city' },
                { name: 'Paramedic', salary: 70, description: 'Save lives and provide medical care' },
                { name: 'Judge', salary: 120, description: 'Oversee court proceedings' }
            ],
            'Civilian': [
                { name: 'Mechanic', salary: 60, description: 'Repair and customize vehicles' },
                { name: 'Taxi Driver', salary: 40, description: 'Transport citizens around the city' },
                { name: 'Store Clerk', salary: 35, description: 'Manage retail operations' }
            ],
            'Criminal': [
                { name: 'Gang Member', salary: 0, description: 'Illegal activities and territory control' },
                { name: 'Drug Dealer', salary: 0, description: 'High risk, high reward operations' }
            ]
        };
    },

    generateEconomyData(type) {
        const data = {
            bank: {
                description: 'Manage your bank account and finances',
                fields: [
                    { name: '💳 Account Balance', value: '$45,230', inline: true },
                    { name: '📈 Monthly Income', value: '$12,400', inline: true },
                    { name: '📉 Monthly Expenses', value: '$8,750', inline: true },
                    { name: '🏠 Loan Status', value: 'Car Loan: $15,000 remaining', inline: false },
                    { name: '📊 Credit Score', value: '785 (Excellent)', inline: true },
                    { name: '💰 Investment Portfolio', value: '$23,500', inline: true }
                ]
            },
            business: {
                description: 'Track your business performance and profits',
                fields: [
                    { name: '🏢 Business Type', value: 'Auto Repair Shop', inline: true },
                    { name: '💰 Daily Revenue', value: '$2,340', inline: true },
                    { name: '📉 Operating Costs', value: '$890/day', inline: true },
                    { name: '👥 Employees', value: '3 mechanics', inline: true },
                    { name: '📈 Customer Rating', value: '4.8/5 stars', inline: true },
                    { name: '📊 Monthly Profit', value: '$43,500', inline: true }
                ]
            }
        };
        return data[type] || data.bank;
    },

    getVehicleMarket() {
        return {
            'Sports Cars': [
                { name: 'Pfister 811', price: 1200000, description: 'High-performance supercar' },
                { name: 'Dewbauchee Vagner', price: 1535000, description: 'Track-focused hypercar' }
            ],
            'Sedans': [
                { name: 'Ubermacht Oracle', price: 80000, description: 'Luxury executive sedan' },
                { name: 'Albany Washington', price: 15000, description: 'Reliable family car' }
            ],
            'Motorcycles': [
                { name: 'Pegassi Bati 801', price: 15000, description: 'Fast sport bike' },
                { name: 'Western Daemon', price: 25000, description: 'Classic cruiser' }
            ]
        };
    }
};