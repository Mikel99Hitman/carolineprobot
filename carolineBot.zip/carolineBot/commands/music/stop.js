const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios = require('axios');

// Import queue from play.js (this should be shared)
const queue = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('stop')
        .setDescription('Stop music and clear the queue')
        .addStringOption(option =>
            option.setName('webhook_url')
                .setDescription('Webhook URL for stop notifications')
                .setRequired(false)),

    async execute(interaction) {
        const voiceChannel = interaction.member.voice.channel;
        if (!voiceChannel) {
            return interaction.reply({ content: '❌ You must be in a voice channel!', ephemeral: true });
        }

        const serverQueue = queue.get(interaction.guild.id);
        if (!serverQueue) {
            return interaction.reply({ content: '❌ No music is currently playing!', ephemeral: true });
        }

        const webhookUrl = interaction.options.getString('webhook_url') || serverQueue.webhookUrl;

        // Store queue info for embed
        const songsCount = serverQueue.songs.length;
        const currentSong = serverQueue.songs[0];

        // Stop and clear everything
        serverQueue.songs = [];
        serverQueue.playing = false;
        
        if (serverQueue.player) {
            serverQueue.player.stop();
        }
        if (serverQueue.connection) {
            serverQueue.connection.destroy();
        }
        queue.delete(interaction.guild.id);

        const stopEmbed = new EmbedBuilder()
            .setColor('#ff0000')
            .setTitle('⏹️ Music Stopped')
            .setDescription('Music has been stopped and queue cleared')
            .addFields(
                { name: '🎵 Last Playing', value: currentSong ? currentSong.title : 'None', inline: true },
                { name: '📊 Songs Cleared', value: songsCount.toString(), inline: true },
                { name: '👤 Stopped by', value: interaction.user.toString(), inline: true }
            )
            .setFooter({ text: 'Music Player • Stopped' })
            .setTimestamp();

        if (currentSong && currentSong.thumbnail) {
            stopEmbed.setThumbnail(currentSong.thumbnail);
        }

        await interaction.reply({ embeds: [stopEmbed] });

        // Send webhook notification
        if (webhookUrl) {
            await this.sendWebhookNotification(webhookUrl, {
                title: '⏹️ Music Stopped',
                description: `**Stopped by:** ${interaction.user.tag}\n**Songs Cleared:** ${songsCount}\n**Last Song:** ${currentSong ? currentSong.title : 'None'}`,
                color: 0xff0000,
                timestamp: new Date().toISOString()
            });
        }
    },

    async sendWebhookNotification(webhookUrl, data) {
        try {
            await axios.post(webhookUrl, {
                embeds: [{
                    title: data.title,
                    description: data.description,
                    color: data.color,
                    timestamp: data.timestamp,
                    footer: {
                        text: 'Music Player Notification'
                    }
                }]
            });
        } catch (error) {
            console.error('Webhook notification error:', error);
        }
    }
};