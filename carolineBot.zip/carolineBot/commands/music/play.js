const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus, VoiceConnectionStatus } = require('@discordjs/voice');
const play = require('play-dl');
const { Pool } = require('pg');
const axios = require('axios');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

const queue = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('play')
        .setDescription('🎵 Advanced music player with multiple sources and features')
        .addStringOption(option =>
            option.setName('query')
                .setDescription('Song name, YouTube/Spotify URL, or playlist')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('source')
                .setDescription('Music source platform')
                .setRequired(false)
                .addChoices(
                    { name: 'YouTube', value: 'youtube' },
                    { name: 'Spotify', value: 'spotify' },
                    { name: 'SoundCloud', value: 'soundcloud' },
                    { name: 'Auto Detect', value: 'auto' }
                ))
        .addBooleanOption(option =>
            option.setName('shuffle')
                .setDescription('Shuffle playlist if adding multiple songs')
                .setRequired(false))
        .addBooleanOption(option =>
            option.setName('priority')
                .setDescription('Add to front of queue (skip current song)')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('webhook_url')
                .setDescription('Webhook URL for music notifications')
                .setRequired(false)),

    async execute(interaction) {
        const voiceChannel = interaction.member.voice.channel;
        if (!voiceChannel) {
            return interaction.reply({ content: '❌ You must be in a voice channel to play music!', ephemeral: true });
        }

        const permissions = voiceChannel.permissionsFor(interaction.client.user);
        if (!permissions.has('Connect') || !permissions.has('Speak')) {
            return interaction.reply({ content: '❌ I need permissions to join and speak in your voice channel!', ephemeral: true });
        }

        await interaction.deferReply();

        const query = interaction.options.getString('query');
        const source = interaction.options.getString('source') || 'auto';
        const shuffle = interaction.options.getBoolean('shuffle') || false;
        const priority = interaction.options.getBoolean('priority') || false;
        const webhookUrl = interaction.options.getString('webhook_url');

        try {
            await this.createTables();
            
            const songs = await this.searchMusic(query, source);
            if (!songs || songs.length === 0) {
                return interaction.editReply('❌ No results found for your search!');
            }

            const serverQueue = queue.get(interaction.guild.id);
            
            if (!serverQueue) {
                await this.createNewQueue(interaction, voiceChannel, songs, shuffle, webhookUrl);
            } else {
                await this.addToQueue(interaction, serverQueue, songs, shuffle, priority, webhookUrl);
            }

            // Log music usage
            await this.logMusicUsage(interaction, query, source, songs.length);

        } catch (error) {
            console.error('Play command error:', error);
            await interaction.editReply('❌ An error occurred while processing your music request!');
        }
    },

    async createTables() {
        await pool.query(`
            CREATE TABLE IF NOT EXISTS music_usage (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                query TEXT NOT NULL,
                source VARCHAR(20) NOT NULL,
                songs_added INTEGER DEFAULT 1,
                duration INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS music_playlists (
                id SERIAL PRIMARY KEY,
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                playlist_name VARCHAR(100) NOT NULL,
                songs TEXT[] DEFAULT '{}',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
    },

    async logMusicUsage(interaction, query, source, songsCount) {
        await pool.query(
            'INSERT INTO music_usage (user_id, guild_id, query, source, songs_added) VALUES ($1, $2, $3, $4, $5)',
            [interaction.user.id, interaction.guild.id, query, source, songsCount]
        );
    },

    async searchMusic(query, source) {
        try {
            let results = [];

            // Check if it's a URL
            if (this.isURL(query)) {
                if (query.includes('youtube.com') || query.includes('youtu.be')) {
                    if (query.includes('playlist')) {
                        const playlist = await play.playlist_info(query, { incomplete: true });
                        const videos = await playlist.all_videos();
                        results = videos.slice(0, 50).map(video => ({
                            title: video.title,
                            url: video.url,
                            duration: video.durationInSec,
                            thumbnail: video.thumbnails[0]?.url,
                            source: 'YouTube'
                        }));
                    } else {
                        const video = await play.video_info(query);
                        results = [{
                            title: video.video_details.title,
                            url: video.video_details.url,
                            duration: video.video_details.durationInSec,
                            thumbnail: video.video_details.thumbnails[0]?.url,
                            source: 'YouTube'
                        }];
                    }
                } else if (query.includes('spotify.com')) {
                    // Handle Spotify URLs (requires Spotify API setup)
                    const spotifyData = await this.handleSpotifyURL(query);
                    results = spotifyData;
                }
            } else {
                // Search by query
                const searched = await play.search(query, { limit: 10, source: { youtube: source === 'youtube' || source === 'auto' } });
                results = searched.map(video => ({
                    title: video.title,
                    url: video.url,
                    duration: video.durationInSec,
                    thumbnail: video.thumbnails[0]?.url,
                    source: 'YouTube'
                }));
            }

            return results;
        } catch (error) {
            console.error('Search error:', error);
            return [];
        }
    },

    async createNewQueue(interaction, voiceChannel, songs, shuffle, webhookUrl) {
        const queueConstruct = {
            textChannel: interaction.channel,
            voiceChannel: voiceChannel,
            connection: null,
            player: null,
            songs: [],
            playing: true,
            volume: 50,
            loop: false,
            loopQueue: false,
            webhookUrl: webhookUrl
        };

        queue.set(interaction.guild.id, queueConstruct);
        
        if (shuffle && songs.length > 1) {
            songs = this.shuffleArray(songs);
        }
        
        queueConstruct.songs.push(...songs.map(song => ({
            ...song,
            requester: interaction.user
        })));

        try {
            const connection = joinVoiceChannel({
                channelId: voiceChannel.id,
                guildId: interaction.guild.id,
                adapterCreator: interaction.guild.voiceAdapterCreator,
            });

            queueConstruct.connection = connection;
            
            connection.on(VoiceConnectionStatus.Disconnected, () => {
                queue.delete(interaction.guild.id);
            });

            await this.playSong(interaction.guild, queueConstruct.songs[0]);

            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('🎵 Now Playing')
                .setDescription(`**${queueConstruct.songs[0].title}**`)
                .setThumbnail(queueConstruct.songs[0].thumbnail)
                .addFields(
                    { name: '🕰️ Duration', value: this.formatTime(queueConstruct.songs[0].duration), inline: true },
                    { name: '👥 Requested by', value: queueConstruct.songs[0].requester.toString(), inline: true },
                    { name: '📊 Queue Length', value: `${queueConstruct.songs.length} song(s)`, inline: true },
                    { name: '🎯 Source', value: queueConstruct.songs[0].source, inline: true },
                    { name: '🔊 Volume', value: `${queueConstruct.volume}%`, inline: true },
                    { name: '🔄 Loop', value: queueConstruct.loop ? 'Song' : queueConstruct.loopQueue ? 'Queue' : 'Off', inline: true }
                )
                .setFooter({ text: 'Music Player • Advanced Features' })
                .setTimestamp();

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('music_pause')
                        .setLabel('⏸️ Pause')
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId('music_skip')
                        .setLabel('⏭️ Skip')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId('music_stop')
                        .setLabel('⏹️ Stop')
                        .setStyle(ButtonStyle.Danger),
                    new ButtonBuilder()
                        .setCustomId('music_queue')
                        .setLabel('📊 Queue')
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId('music_loop')
                        .setLabel('🔁 Loop')
                        .setStyle(ButtonStyle.Secondary)
                );

            await interaction.editReply({ embeds: [embed], components: [row] });

            // Send webhook notification
            if (webhookUrl) {
                await this.sendWebhookNotification(webhookUrl, {
                    title: '🎵 Music Started',
                    description: `**Song:** ${queueConstruct.songs[0].title}\n**Requested by:** ${interaction.user.tag}\n**Queue Length:** ${queueConstruct.songs.length}`,
                    color: 0x00ff00,
                    timestamp: new Date().toISOString()
                });
            }

        } catch (error) {
            console.error('Connection error:', error);
            queue.delete(interaction.guild.id);
            throw error;
        }
    },

    async addToQueue(interaction, serverQueue, songs, shuffle, priority, webhookUrl) {
        if (shuffle && songs.length > 1) {
            songs = this.shuffleArray(songs);
        }

        const songsWithRequester = songs.map(song => ({
            ...song,
            requester: interaction.user
        }));

        if (priority) {
            serverQueue.songs.splice(1, 0, ...songsWithRequester);
        } else {
            serverQueue.songs.push(...songsWithRequester);
        }

        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('📝 Added to Queue')
            .setDescription(songs.length === 1 ? 
                `**${songs[0].title}**` : 
                `**${songs.length} songs** added to queue`)
            .addFields(
                { name: '📊 Queue Position', value: priority ? '2' : serverQueue.songs.length.toString(), inline: true },
                { name: '🕰️ Total Duration', value: this.formatTime(songs.reduce((acc, song) => acc + song.duration, 0)), inline: true },
                { name: '👥 Requested by', value: interaction.user.toString(), inline: true },
                { name: '🔀 Shuffled', value: shuffle ? 'Yes' : 'No', inline: true },
                { name: '⚡ Priority', value: priority ? 'Yes' : 'No', inline: true },
                { name: '📊 Total Queue', value: `${serverQueue.songs.length} song(s)`, inline: true }
            )
            .setThumbnail(songs[0].thumbnail)
            .setFooter({ text: 'Music Queue • Advanced Player' })
            .setTimestamp();

        if (songs.length > 1) {
            const songList = songs.slice(0, 5).map((song, index) => 
                `${index + 1}. ${song.title} (${this.formatTime(song.duration)})`
            ).join('\n');
            
            if (songs.length > 5) {
                embed.addFields({ name: '🎵 Songs Preview', value: songList + `\n... and ${songs.length - 5} more`, inline: false });
            } else {
                embed.addFields({ name: '🎵 Songs Added', value: songList, inline: false });
            }
        }

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('music_queue')
                    .setLabel('📊 View Queue')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('music_shuffle_queue')
                    .setLabel('🔀 Shuffle Queue')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('music_clear_queue')
                    .setLabel('🗑️ Clear Queue')
                    .setStyle(ButtonStyle.Danger)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });

        // Send webhook notification
        if (webhookUrl) {
            await this.sendWebhookNotification(webhookUrl, {
                title: '📝 Songs Added to Queue',
                description: `**Songs:** ${songs.length}\n**Requested by:** ${interaction.user.tag}\n**Queue Length:** ${serverQueue.songs.length}`,
                color: 0x0099ff,
                timestamp: new Date().toISOString()
            });
        }
    },

    async playSong(guild, song) {
        const serverQueue = queue.get(guild.id);
        if (!song) {
            if (serverQueue.loopQueue && serverQueue.songs.length > 0) {
                // Restart queue if loop queue is enabled
                return this.playSong(guild, serverQueue.songs[0]);
            }
            
            serverQueue.connection.destroy();
            queue.delete(guild.id);
            
            // Send webhook notification for queue end
            if (serverQueue.webhookUrl) {
                await this.sendWebhookNotification(serverQueue.webhookUrl, {
                    title: '🎵 Music Queue Ended',
                    description: 'All songs have been played. Queue is now empty.',
                    color: 0xff9500,
                    timestamp: new Date().toISOString()
                });
            }
            return;
        }

        try {
            const stream = await play.stream(song.url);
            const resource = createAudioResource(stream.stream, { 
                inputType: stream.type,
                inlineVolume: true
            });
            
            if (!serverQueue.player) {
                serverQueue.player = createAudioPlayer();
                serverQueue.connection.subscribe(serverQueue.player);
            }

            // Set volume
            if (resource.volume) {
                resource.volume.setVolume(serverQueue.volume / 100);
            }

            serverQueue.player.play(resource);

            serverQueue.player.on(AudioPlayerStatus.Idle, () => {
                if (serverQueue.loop) {
                    // Loop current song
                    this.playSong(guild, song);
                } else {
                    // Move to next song
                    serverQueue.songs.shift();
                    this.playSong(guild, serverQueue.songs[0]);
                }
            });

            serverQueue.player.on('error', error => {
                console.error('Audio player error:', error);
                serverQueue.songs.shift();
                this.playSong(guild, serverQueue.songs[0]);
            });

        } catch (error) {
            console.error('Play song error:', error);
            serverQueue.songs.shift();
            this.playSong(guild, serverQueue.songs[0]);
        }
    },

    async handleSpotifyURL(url) {
        // Placeholder for Spotify integration
        // In production, you'd use Spotify Web API to get track info
        // then search for equivalent YouTube videos
        return [];
    },

    isURL(string) {
        try {
            new URL(string);
            return true;
        } catch {
            return false;
        }
    },

    shuffleArray(array) {
        const shuffled = [...array];
        for (let i = shuffled.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
        }
        return shuffled;
    },

    formatTime(seconds) {
        if (!seconds || seconds === 0) return '0:00';
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const remainingSeconds = seconds % 60;
        
        if (hours > 0) {
            return `${hours}:${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
        }
        return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
    },

    async sendWebhookNotification(webhookUrl, data) {
        try {
            await axios.post(webhookUrl, {
                embeds: [{
                    title: data.title,
                    description: data.description,
                    color: data.color,
                    timestamp: data.timestamp,
                    footer: {
                        text: 'Music Player Notification'
                    }
                }]
            });
        } catch (error) {
            console.error('Webhook notification error:', error);
        }
    }
};