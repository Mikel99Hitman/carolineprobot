const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('health-fitness')
        .setDescription('Advanced Health & Fitness AI System')
        .addSubcommand(subcommand =>
            subcommand
                .setName('fitness-tracker')
                .setDescription('Comprehensive fitness tracking and analysis')
                .addStringOption(option =>
                    option.setName('activity_type')
                        .setDescription('Type of fitness activity')
                        .addChoices(
                            { name: 'Cardio Training', value: 'cardio' },
                            { name: 'Strength Training', value: 'strength' },
                            { name: 'Yoga & Flexibility', value: 'yoga' },
                            { name: 'Sports Activities', value: 'sports' },
                            { name: 'Daily Activities', value: 'daily' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('nutrition-analysis')
                .setDescription('AI-powered nutrition tracking and meal planning')
                .addStringOption(option =>
                    option.setName('analysis_type')
                        .setDescription('Type of nutrition analysis')
                        .addChoices(
                            { name: 'Meal Analysis', value: 'meal' },
                            { name: 'Daily Nutrition', value: 'daily' },
                            { name: 'Meal Planning', value: 'planning' },
                            { name: 'Supplement Guide', value: 'supplements' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('health-monitoring')
                .setDescription('Advanced health metrics monitoring')
                .addStringOption(option =>
                    option.setName('health_metric')
                        .setDescription('Health metric to monitor')
                        .addChoices(
                            { name: 'Heart Rate & Cardio', value: 'heart' },
                            { name: 'Sleep Quality', value: 'sleep' },
                            { name: 'Stress & Mental Health', value: 'stress' },
                            { name: 'Body Composition', value: 'body' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('ai-coach')
                .setDescription('Personal AI fitness and health coach')
                .addStringOption(option =>
                    option.setName('coaching_focus')
                        .setDescription('Coaching focus area')
                        .addChoices(
                            { name: 'Weight Management', value: 'weight' },
                            { name: 'Muscle Building', value: 'muscle' },
                            { name: 'Endurance Training', value: 'endurance' },
                            { name: 'Rehabilitation', value: 'rehab' }
                        ))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        switch (subcommand) {
            case 'fitness-tracker':
                await this.fitnessTracker(interaction);
                break;
            case 'nutrition-analysis':
                await this.nutritionAnalysis(interaction);
                break;
            case 'health-monitoring':
                await this.healthMonitoring(interaction);
                break;
            case 'ai-coach':
                await this.aiCoach(interaction);
                break;
        }
    },

    async fitnessTracker(interaction) {
        await interaction.deferReply();

        const activityType = interaction.options.getString('activity_type') || 'cardio';
        const fitnessData = this.generateFitnessData(activityType);

        const embed = new EmbedBuilder()
            .setTitle('💪 Advanced Fitness Tracker')
            .setDescription('AI-powered fitness monitoring and performance analysis')
            .addFields(
                { name: '🏃 Activity Type', value: fitnessData.activityName, inline: true },
                { name: '⏱️ Today\'s Session', value: fitnessData.todaySession, inline: true },
                { name: '🔥 Calories Burned', value: fitnessData.caloriesBurned, inline: true },
                { name: '📊 Weekly Progress', value: fitnessData.weeklyProgress, inline: true },
                { name: '🎯 Goal Achievement', value: fitnessData.goalAchievement, inline: true },
                { name: '📈 Performance Score', value: fitnessData.performanceScore, inline: true },
                { name: '📊 Detailed Metrics', value: fitnessData.detailedMetrics.join('\n'), inline: false },
                { name: '🎯 Performance Insights', value: fitnessData.insights.join('\n'), inline: false },
                { name: '💡 AI Recommendations', value: fitnessData.recommendations.join('\n'), inline: false }
            )
            .setColor('#ff5722')
            .setTimestamp()
            .setFooter({ text: 'Fitness Tracker • AI-Powered Analytics' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('start_workout')
                    .setLabel('🏃 Start Workout')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('workout_plan')
                    .setLabel('📋 Workout Plan')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('progress_report')
                    .setLabel('📊 Progress Report')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async nutritionAnalysis(interaction) {
        await interaction.deferReply();

        const analysisType = interaction.options.getString('analysis_type') || 'meal';
        const nutritionData = this.generateNutritionData(analysisType);

        const embed = new EmbedBuilder()
            .setTitle('🥗 AI Nutrition Analysis')
            .setDescription('Smart nutrition tracking and personalized meal planning')
            .addFields(
                { name: '🍽️ Analysis Type', value: nutritionData.analysisName, inline: true },
                { name: '📊 Daily Calories', value: nutritionData.dailyCalories, inline: true },
                { name: '🎯 Calorie Goal', value: nutritionData.calorieGoal, inline: true },
                { name: '🥩 Protein', value: nutritionData.protein, inline: true },
                { name: '🍞 Carbohydrates', value: nutritionData.carbs, inline: true },
                { name: '🥑 Fats', value: nutritionData.fats, inline: true },
                { name: '📊 Macro Breakdown', value: nutritionData.macroBreakdown.join('\n'), inline: false },
                { name: '🌟 Nutritional Insights', value: nutritionData.insights.join('\n'), inline: false },
                { name: '💡 Meal Suggestions', value: nutritionData.suggestions.join('\n'), inline: false }
            )
            .setColor('#4caf50')
            .setTimestamp()
            .setFooter({ text: 'Nutrition AI • Smart Meal Planning' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('log_meal')
                    .setLabel('🍽️ Log Meal')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('meal_planner')
                    .setLabel('📅 Meal Planner')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('nutrition_report')
                    .setLabel('📊 Nutrition Report')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async healthMonitoring(interaction) {
        await interaction.deferReply();

        const healthMetric = interaction.options.getString('health_metric') || 'heart';
        const healthData = this.generateHealthData(healthMetric);

        const embed = new EmbedBuilder()
            .setTitle('🏥 Advanced Health Monitoring')
            .setDescription('Comprehensive health metrics tracking and analysis')
            .addFields(
                { name: '❤️ Health Metric', value: healthData.metricName, inline: true },
                { name: '📊 Current Status', value: healthData.currentStatus, inline: true },
                { name: '🎯 Health Score', value: healthData.healthScore, inline: true },
                { name: '📈 Trend (7 days)', value: healthData.weeklyTrend, inline: true },
                { name: '⚠️ Risk Level', value: healthData.riskLevel, inline: true },
                { name: '🏆 Optimal Range', value: healthData.optimalRange, inline: true },
                { name: '📊 Detailed Analysis', value: healthData.detailedAnalysis.join('\n'), inline: false },
                { name: '🔍 Health Insights', value: healthData.insights.join('\n'), inline: false },
                { name: '💊 Recommendations', value: healthData.recommendations.join('\n'), inline: false }
            )
            .setColor('#2196f3')
            .setTimestamp()
            .setFooter({ text: 'Health Monitor • AI-Powered Insights' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('health_checkup')
                    .setLabel('🏥 Health Checkup')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('set_health_goals')
                    .setLabel('🎯 Set Goals')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('doctor_consultation')
                    .setLabel('👨‍⚕️ Consult Doctor')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async aiCoach(interaction) {
        await interaction.deferReply();

        const coachingFocus = interaction.options.getString('coaching_focus') || 'weight';
        const coachData = this.generateCoachData(coachingFocus);

        const embed = new EmbedBuilder()
            .setTitle('🤖 Personal AI Health Coach')
            .setDescription('Intelligent coaching for optimal health and fitness results')
            .addFields(
                { name: '🎯 Coaching Focus', value: coachData.focusArea, inline: true },
                { name: '📊 Current Progress', value: coachData.currentProgress, inline: true },
                { name: '🏆 Goal Timeline', value: coachData.goalTimeline, inline: true },
                { name: '📈 Success Rate', value: coachData.successRate, inline: true },
                { name: '🔥 Motivation Level', value: coachData.motivationLevel, inline: true },
                { name: '🎖️ Achievement Level', value: coachData.achievementLevel, inline: true },
                { name: '🎯 Today\'s Plan', value: coachData.todaysPlan.join('\n'), inline: false },
                { name: '💡 AI Coaching Tips', value: coachData.coachingTips.join('\n'), inline: false },
                { name: '🏆 Motivational Insights', value: coachData.motivationalInsights.join('\n'), inline: false }
            )
            .setColor('#9c27b0')
            .setTimestamp()
            .setFooter({ text: 'AI Coach • Personalized Guidance' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('daily_coaching')
                    .setLabel('📅 Daily Coaching')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('adjust_goals')
                    .setLabel('🎯 Adjust Goals')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('progress_celebration')
                    .setLabel('🎉 Celebrate Progress')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    generateFitnessData(activityType) {
        const activities = {
            cardio: {
                activityName: 'Cardio Training',
                todaySession: '45 min running',
                caloriesBurned: '487 kcal',
                weeklyProgress: '4/5 sessions',
                goalAchievement: '87% complete',
                performanceScore: '8.9/10',
                detailedMetrics: [
                    '❤️ Avg Heart Rate: 152 bpm',
                    '⚡ Max Heart Rate: 178 bpm',
                    '🏃 Distance: 6.2 km',
                    '⏱️ Pace: 7:15 min/km'
                ],
                insights: [
                    '📈 Endurance improved by 12% this month',
                    '🎯 Consistent pace throughout workout',
                    '💪 Recovery time decreased by 8%',
                    '🔥 Fat burning zone: 78% of workout'
                ],
                recommendations: [
                    '🎯 Increase distance by 10% next week',
                    '⚡ Add interval training twice weekly',
                    '🧘 Include 10-min cool-down stretches',
                    '💧 Maintain hydration during longer runs'
                ]
            },
            strength: {
                activityName: 'Strength Training',
                todaySession: '60 min weights',
                caloriesBurned: '312 kcal',
                weeklyProgress: '3/4 sessions',
                goalAchievement: '92% complete',
                performanceScore: '9.2/10'
            }
        };

        return activities[activityType] || activities.cardio;
    },

    generateNutritionData(analysisType) {
        return {
            analysisName: analysisType.charAt(0).toUpperCase() + analysisType.slice(1) + ' Analysis',
            dailyCalories: '1,847 / 2,200',
            calorieGoal: '2,200 kcal',
            protein: '127g (23%)',
            carbs: '245g (45%)',
            fats: '78g (32%)',
            macroBreakdown: [
                '🥩 Protein: 127g (Target: 130g) ✅',
                '🍞 Carbs: 245g (Target: 275g) 📊',
                '🥑 Fats: 78g (Target: 85g) 📊',
                '💧 Water: 2.1L (Target: 2.5L) 💧'
            ],
            insights: [
                '🌟 Excellent protein intake for muscle recovery',
                '📊 Slightly low on complex carbohydrates',
                '🥑 Healthy fat sources well distributed',
                '🍎 Micronutrient profile: 87% complete'
            ],
            suggestions: [
                '🍌 Add banana for pre-workout energy',
                '🥗 Include leafy greens for vitamins',
                '🐟 Omega-3 rich fish twice weekly',
                '🥜 Handful of nuts for healthy fats'
            ]
        };
    },

    generateHealthData(healthMetric) {
        const metrics = {
            heart: {
                metricName: 'Heart Rate & Cardiovascular Health',
                currentStatus: '🟢 Excellent',
                healthScore: '9.1/10',
                weeklyTrend: '📈 Improving',
                riskLevel: '🟢 Low Risk',
                optimalRange: '60-100 bpm',
                detailedAnalysis: [
                    '❤️ Resting HR: 62 bpm (Excellent)',
                    '📊 HRV: 45ms (Good recovery)',
                    '⚡ Max HR: 185 bpm (Age-appropriate)',
                    '🏃 Exercise HR zones well utilized'
                ],
                insights: [
                    '💪 Cardiovascular fitness improving steadily',
                    '🧘 Stress levels well managed',
                    '😴 Sleep quality positively affecting HR',
                    '🏃 Regular exercise showing benefits'
                ],
                recommendations: [
                    '🏃 Continue current cardio routine',
                    '🧘 Add meditation for stress management',
                    '😴 Maintain 7-8 hours sleep',
                    '🩺 Annual cardio checkup recommended'
                ]
            },
            sleep: {
                metricName: 'Sleep Quality & Recovery',
                currentStatus: '🟡 Good',
                healthScore: '7.8/10',
                weeklyTrend: '📊 Stable',
                riskLevel: '🟢 Low Risk',
                optimalRange: '7-9 hours'
            }
        };

        return metrics[healthMetric] || metrics.heart;
    },

    generateCoachData(coachingFocus) {
        const coaching = {
            weight: {
                focusArea: 'Weight Management & Fat Loss',
                currentProgress: '73% to goal',
                goalTimeline: '8 weeks remaining',
                successRate: '94% on track',
                motivationLevel: '🔥 High',
                achievementLevel: '🏆 Advanced',
                todaysPlan: [
                    '🏃 30-min morning cardio session',
                    '🥗 Balanced lunch with lean protein',
                    '💪 Evening strength training (legs)',
                    '😴 8-hour sleep target'
                ],
                coachingTips: [
                    '🎯 Focus on consistency over perfection',
                    '📊 Track measurements, not just weight',
                    '💧 Increase water intake by 500ml',
                    '🧘 Manage stress for better results'
                ],
                motivationalInsights: [
                    '🏆 You\'ve lost 12kg - amazing progress!',
                    '💪 Strength has increased 23% this month',
                    '🎯 Only 3kg away from your goal',
                    '🔥 Your dedication is truly inspiring!'
                ]
            }
        };

        return coaching[coachingFocus] || coaching.weight;
    }
};