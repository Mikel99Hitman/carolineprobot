const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');

// Multilingual support
const translations = {
    en: {
        title: '🤖 Advanced AI System',
        description: 'Intelligent AI with multilingual support',
        analyzing: 'Analyzing...',
        complete: 'Analysis Complete',
        language: 'Language',
        confidence: 'Confidence',
        processing: 'Processing your request...',
        success: 'Operation completed successfully',
        error: 'An error occurred',
        sentiment: 'Sentiment Analysis',
        emotions: 'Emotion Detection',
        topics: 'Topic Analysis',
        summary: 'Content Summary',
        recommendations: 'AI Recommendations',
        insights: 'Smart Insights'
    },
    ar: {
        title: '🤖 نظام الذكاء الاصطناعي المتقدم',
        description: 'ذكاء اصطناعي متطور مع دعم متعدد اللغات',
        analyzing: 'جاري التحليل...',
        complete: 'اكتمل التحليل',
        language: 'اللغة',
        confidence: 'مستوى الثقة',
        processing: 'جاري معالجة طلبك...',
        success: 'تمت العملية بنجاح',
        error: 'حدث خطأ',
        sentiment: 'تحليل المشاعر',
        emotions: 'كشف العواطف',
        topics: 'تحليل المواضيع',
        summary: 'ملخص المحتوى',
        recommendations: 'توصيات الذكاء الاصطناعي',
        insights: 'رؤى ذكية'
    }
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ai-advanced')
        .setDescription('Advanced AI system with multilingual support')
        .addSubcommand(subcommand =>
            subcommand
                .setName('analyze-text')
                .setDescription('Analyze text with AI (Arabic/English)')
                .addStringOption(option =>
                    option.setName('text')
                        .setDescription('Text to analyze')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('language')
                        .setDescription('Response language')
                        .addChoices(
                            { name: 'English', value: 'en' },
                            { name: 'العربية', value: 'ar' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('smart-chat')
                .setDescription('Advanced AI conversation (Arabic/English)')
                .addStringOption(option =>
                    option.setName('message')
                        .setDescription('Your message')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('personality')
                        .setDescription('AI personality')
                        .addChoices(
                            { name: 'Professional', value: 'professional' },
                            { name: 'Friendly', value: 'friendly' },
                            { name: 'Creative', value: 'creative' },
                            { name: 'Academic', value: 'academic' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('content-generator')
                .setDescription('Generate content with AI (Arabic/English)')
                .addStringOption(option =>
                    option.setName('type')
                        .setDescription('Content type')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Article', value: 'article' },
                            { name: 'Story', value: 'story' },
                            { name: 'Poem', value: 'poem' },
                            { name: 'Script', value: 'script' }
                        ))
                .addStringOption(option =>
                    option.setName('topic')
                        .setDescription('Content topic')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('language')
                        .setDescription('Content language')
                        .addChoices(
                            { name: 'English', value: 'en' },
                            { name: 'العربية', value: 'ar' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('ai-tutor')
                .setDescription('AI tutoring system (Arabic/English)')
                .addStringOption(option =>
                    option.setName('subject')
                        .setDescription('Subject to learn')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('level')
                        .setDescription('Learning level')
                        .addChoices(
                            { name: 'Beginner', value: 'beginner' },
                            { name: 'Intermediate', value: 'intermediate' },
                            { name: 'Advanced', value: 'advanced' }
                        ))),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        switch (subcommand) {
            case 'analyze-text':
                await this.analyzeText(interaction);
                break;
            case 'smart-chat':
                await this.smartChat(interaction);
                break;
            case 'content-generator':
                await this.generateContent(interaction);
                break;
            case 'ai-tutor':
                await this.aiTutor(interaction);
                break;
        }
    },

    async analyzeText(interaction) {
        await interaction.deferReply();

        const text = interaction.options.getString('text');
        const lang = interaction.options.getString('language') || this.detectLanguage(text);
        const t = translations[lang] || translations.en;

        // Show processing
        const processingEmbed = new EmbedBuilder()
            .setTitle(t.title)
            .setDescription(t.processing)
            .setColor('#f39c12')
            .setTimestamp();

        await interaction.editReply({ embeds: [processingEmbed] });

        // Simulate AI analysis
        setTimeout(async () => {
            const analysis = this.performTextAnalysis(text, lang);

            const embed = new EmbedBuilder()
                .setTitle(`${t.complete} 🧠`)
                .setDescription(t.description)
                .addFields(
                    { name: `📊 ${t.sentiment}`, value: analysis.sentiment, inline: true },
                    { name: `😊 ${t.emotions}`, value: analysis.emotions, inline: true },
                    { name: `🎯 ${t.topics}`, value: analysis.topics, inline: true },
                    { name: `📝 ${t.summary}`, value: analysis.summary, inline: false },
                    { name: `💡 ${t.insights}`, value: analysis.insights, inline: false },
                    { name: `🔍 ${t.language}`, value: `${analysis.detectedLang} (${analysis.confidence}% ${t.confidence})`, inline: true }
                )
                .setColor('#00ff88')
                .setTimestamp()
                .setFooter({ text: 'AI Analysis • Multilingual Support' });

            const row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('detailed_analysis')
                        .setLabel(lang === 'ar' ? '📊 تحليل مفصل' : '📊 Detailed Analysis')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId('translate_text')
                        .setLabel(lang === 'ar' ? '🌐 ترجمة' : '🌐 Translate')
                        .setStyle(ButtonStyle.Secondary)
                );

            await interaction.editReply({ embeds: [embed], components: [row] });
        }, 3000);
    },

    async smartChat(interaction) {
        await interaction.deferReply();

        const message = interaction.options.getString('message');
        const personality = interaction.options.getString('personality') || 'friendly';
        const lang = this.detectLanguage(message);
        const t = translations[lang] || translations.en;

        const responses = {
            en: {
                professional: "I understand your inquiry. Based on my analysis, I recommend focusing on structured approaches and evidence-based solutions.",
                friendly: "Hey there! 😊 That's a great question! I'd love to help you with that. Let me share some thoughts...",
                creative: "What an interesting perspective! 🎨 Let me think outside the box here and explore some creative possibilities...",
                academic: "From an analytical standpoint, this topic requires careful examination of multiple variables and theoretical frameworks."
            },
            ar: {
                professional: "أفهم استفسارك. بناءً على تحليلي، أنصح بالتركيز على المناهج المنظمة والحلول القائمة على الأدلة.",
                friendly: "مرحباً! 😊 هذا سؤال رائع! أحب أن أساعدك في ذلك. دعني أشارك بعض الأفكار...",
                creative: "يا لها من وجهة نظر مثيرة للاهتمام! 🎨 دعني أفكر خارج الصندوق هنا وأستكشف بعض الإمكانيات الإبداعية...",
                academic: "من منظور تحليلي، يتطلب هذا الموضوع فحصاً دقيقاً لمتغيرات متعددة وأطر نظرية."
            }
        };

        const aiResponse = responses[lang][personality];

        const embed = new EmbedBuilder()
            .setTitle(lang === 'ar' ? '🤖 محادثة ذكية' : '🤖 Smart Conversation')
            .setDescription(lang === 'ar' ? 'ذكاء اصطناعي متقدم مع شخصيات متعددة' : 'Advanced AI with multiple personalities')
            .addFields(
                { name: lang === 'ar' ? '💬 رسالتك' : '💬 Your Message', value: message, inline: false },
                { name: lang === 'ar' ? '🎭 الشخصية' : '🎭 Personality', value: personality.charAt(0).toUpperCase() + personality.slice(1), inline: true },
                { name: lang === 'ar' ? '🌐 اللغة المكتشفة' : '🌐 Detected Language', value: lang === 'ar' ? 'العربية' : 'English', inline: true },
                { name: lang === 'ar' ? '🤖 رد الذكاء الاصطناعي' : '🤖 AI Response', value: aiResponse, inline: false }
            )
            .setColor('#9b59b6')
            .setTimestamp()
            .setFooter({ text: lang === 'ar' ? 'محادثة ذكية • دعم متعدد اللغات' : 'Smart Chat • Multilingual Support' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('continue_chat')
                    .setLabel(lang === 'ar' ? '💬 متابعة المحادثة' : '💬 Continue Chat')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('change_personality')
                    .setLabel(lang === 'ar' ? '🎭 تغيير الشخصية' : '🎭 Change Personality')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async generateContent(interaction) {
        await interaction.deferReply();

        const type = interaction.options.getString('type');
        const topic = interaction.options.getString('topic');
        const lang = interaction.options.getString('language') || 'en';
        const t = translations[lang] || translations.en;

        const content = this.generateAIContent(type, topic, lang);

        const embed = new EmbedBuilder()
            .setTitle(lang === 'ar' ? '✍️ مولد المحتوى بالذكاء الاصطناعي' : '✍️ AI Content Generator')
            .setDescription(lang === 'ar' ? 'محتوى مُولد بالذكاء الاصطناعي' : 'AI-generated content')
            .addFields(
                { name: lang === 'ar' ? '📝 نوع المحتوى' : '📝 Content Type', value: type.charAt(0).toUpperCase() + type.slice(1), inline: true },
                { name: lang === 'ar' ? '🎯 الموضوع' : '🎯 Topic', value: topic, inline: true },
                { name: lang === 'ar' ? '🌐 اللغة' : '🌐 Language', value: lang === 'ar' ? 'العربية' : 'English', inline: true },
                { name: lang === 'ar' ? '📄 المحتوى المُولد' : '📄 Generated Content', value: content, inline: false }
            )
            .setColor('#e67e22')
            .setTimestamp()
            .setFooter({ text: lang === 'ar' ? 'مولد المحتوى • ذكاء اصطناعي متقدم' : 'Content Generator • Advanced AI' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('regenerate_content')
                    .setLabel(lang === 'ar' ? '🔄 إعادة توليد' : '🔄 Regenerate')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('improve_content')
                    .setLabel(lang === 'ar' ? '✨ تحسين' : '✨ Improve')
                    .setStyle(ButtonStyle.Success)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    async aiTutor(interaction) {
        await interaction.deferReply();

        const subject = interaction.options.getString('subject');
        const level = interaction.options.getString('level') || 'beginner';
        const lang = this.detectLanguage(subject);
        const t = translations[lang] || translations.en;

        const lesson = this.generateLesson(subject, level, lang);

        const embed = new EmbedBuilder()
            .setTitle(lang === 'ar' ? '👨‍🏫 مدرس الذكاء الاصطناعي' : '👨‍🏫 AI Tutor')
            .setDescription(lang === 'ar' ? 'نظام تعليمي ذكي متعدد اللغات' : 'Intelligent multilingual tutoring system')
            .addFields(
                { name: lang === 'ar' ? '📚 الموضوع' : '📚 Subject', value: subject, inline: true },
                { name: lang === 'ar' ? '📊 المستوى' : '📊 Level', value: level.charAt(0).toUpperCase() + level.slice(1), inline: true },
                { name: lang === 'ar' ? '🎯 أهداف التعلم' : '🎯 Learning Objectives', value: lesson.objectives, inline: false },
                { name: lang === 'ar' ? '📖 الدرس' : '📖 Lesson', value: lesson.content, inline: false },
                { name: lang === 'ar' ? '💡 نصائح' : '💡 Tips', value: lesson.tips, inline: false },
                { name: lang === 'ar' ? '❓ أسئلة للمراجعة' : '❓ Review Questions', value: lesson.questions, inline: false }
            )
            .setColor('#3498db')
            .setTimestamp()
            .setFooter({ text: lang === 'ar' ? 'مدرس ذكي • تعلم تفاعلي' : 'AI Tutor • Interactive Learning' });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('next_lesson')
                    .setLabel(lang === 'ar' ? '➡️ الدرس التالي' : '➡️ Next Lesson')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('quiz_me')
                    .setLabel(lang === 'ar' ? '🧠 اختبرني' : '🧠 Quiz Me')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('practice_exercises')
                    .setLabel(lang === 'ar' ? '📝 تمارين' : '📝 Practice')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.editReply({ embeds: [embed], components: [row] });
    },

    detectLanguage(text) {
        const arabicPattern = /[\u0600-\u06FF]/;
        return arabicPattern.test(text) ? 'ar' : 'en';
    },

    performTextAnalysis(text, lang) {
        const isArabic = lang === 'ar';
        
        return {
            sentiment: isArabic ? '😊 إيجابي (85%)' : '😊 Positive (85%)',
            emotions: isArabic ? '😊 سعادة، 🤔 فضول' : '😊 Joy, 🤔 Curiosity',
            topics: isArabic ? '💻 تكنولوجيا، 🎯 تطوير' : '💻 Technology, 🎯 Development',
            summary: isArabic ? 'النص يتحدث عن موضوع تقني بطريقة إيجابية ومفيدة' : 'The text discusses technical topics in a positive and helpful manner',
            insights: isArabic ? '• محتوى عالي الجودة\n• لغة واضحة ومفهومة\n• يحتوي على معلومات مفيدة' : '• High-quality content\n• Clear and understandable language\n• Contains useful information',
            detectedLang: isArabic ? 'العربية' : 'English',
            confidence: Math.floor(Math.random() * 10) + 90
        };
    },

    generateAIContent(type, topic, lang) {
        const isArabic = lang === 'ar';
        
        const templates = {
            article: {
                en: `# ${topic}\n\nThis comprehensive article explores the fascinating world of ${topic}. Through careful analysis and research, we discover that this subject offers numerous insights and opportunities for growth.\n\n## Key Points:\n- Important aspect 1\n- Critical element 2\n- Essential factor 3\n\nIn conclusion, ${topic} represents a significant area of interest that deserves further exploration.`,
                ar: `# ${topic}\n\nيستكشف هذا المقال الشامل العالم الرائع لموضوع ${topic}. من خلال التحليل والبحث الدقيق، نكتشف أن هذا الموضوع يقدم رؤى وفرص عديدة للنمو.\n\n## النقاط الرئيسية:\n- الجانب المهم الأول\n- العنصر الحاسم الثاني\n- العامل الأساسي الثالث\n\nفي الختام، يمثل ${topic} مجالاً مهماً يستحق المزيد من الاستكشاف.`
            },
            story: {
                en: `Once upon a time, in a world where ${topic} was the center of everything, there lived a curious individual who sought to understand its mysteries. Through adventures and discoveries, they learned valuable lessons about life and the importance of ${topic}.`,
                ar: `في قديم الزمان، في عالم كان فيه ${topic} محور كل شيء، عاش شخص فضولي سعى لفهم أسراره. من خلال المغامرات والاكتشافات، تعلم دروساً قيمة عن الحياة وأهمية ${topic}.`
            }
        };

        return templates[type]?.[lang] || templates.article[lang];
    },

    generateLesson(subject, level, lang) {
        const isArabic = lang === 'ar';
        
        return {
            objectives: isArabic ? 
                `• فهم أساسيات ${subject}\n• تطبيق المفاهيم الأساسية\n• تطوير المهارات العملية` :
                `• Understand the basics of ${subject}\n• Apply fundamental concepts\n• Develop practical skills`,
            content: isArabic ?
                `مرحباً بك في درس ${subject}! سنبدأ بالمفاهيم الأساسية ونتقدم تدريجياً نحو المواضيع المتقدمة. هذا الموضوع مهم جداً في عالم اليوم.` :
                `Welcome to the ${subject} lesson! We'll start with basic concepts and gradually progress to advanced topics. This subject is very important in today's world.`,
            tips: isArabic ?
                `• مارس بانتظام\n• اطرح الأسئلة\n• طبق ما تتعلمه` :
                `• Practice regularly\n• Ask questions\n• Apply what you learn`,
            questions: isArabic ?
                `1. ما هي أهمية ${subject}؟\n2. كيف يمكن تطبيقه عملياً؟\n3. ما هي التحديات الرئيسية؟` :
                `1. What is the importance of ${subject}?\n2. How can it be applied practically?\n3. What are the main challenges?`
        };
    }
};