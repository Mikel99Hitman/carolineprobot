const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('leaderboard')
        .setDescription('View server leaderboards')
        .addStringOption(option =>
            option.setName('type')
                .setDescription('Leaderboard type')
                .setRequired(false)
                .addChoices(
                    { name: 'Levels', value: 'levels' },
                    { name: 'Messages', value: 'messages' },
                    { name: 'Voice Time', value: 'voice' }
                )),

    async execute(interaction) {
        const type = interaction.options.getString('type') || 'levels';
        
        try {
            let query, title, emoji;
            switch (type) {
                case 'levels':
                    query = 'SELECT * FROM users WHERE guild_id = $1 ORDER BY level DESC, xp DESC LIMIT 10';
                    title = '🏆 Level Leaderboard';
                    emoji = '📊';
                    break;
                case 'messages':
                    query = 'SELECT * FROM users WHERE guild_id = $1 ORDER BY messages DESC LIMIT 10';
                    title = '💬 Message Leaderboard';
                    emoji = '📝';
                    break;
                case 'voice':
                    query = 'SELECT * FROM users WHERE guild_id = $1 ORDER BY voice DESC LIMIT 10';
                    title = '🎤 Voice Time Leaderboard';
                    emoji = '🔊';
                    break;
            }

            const result = await pool.query(query, [interaction.guild.id]);
            const topUsers = result.rows;

            if (topUsers.length === 0) {
                return interaction.reply({ content: '❌ No data available to display!', ephemeral: true });
            }

            const leaderboardEmbed = new EmbedBuilder()
                .setColor('#ffd700')
                .setTitle(title)
                .setThumbnail(interaction.guild.iconURL())
                .setTimestamp();

            let description = '';
            for (let i = 0; i < topUsers.length; i++) {
                const user = topUsers[i];
                const member = interaction.guild.members.cache.get(user.user_id);
                
                if (!member) continue;

                const position = i + 1;
                const medal = position === 1 ? '🥇' : position === 2 ? '🥈' : position === 3 ? '🥉' : `${position}.`;
                
                let value;
                switch (type) {
                    case 'levels':
                        value = `Level ${user.level} (${user.xp} XP)`;
                        break;
                    case 'messages':
                        value = `${user.messages} messages`;
                        break;
                    case 'voice':
                        const hours = Math.floor(user.voice / 60);
                        const minutes = user.voice % 60;
                        value = `${hours}h ${minutes}m`;
                        break;
                }

                description += `${medal} **${member.displayName}** - ${value}\n`;
            }

            leaderboardEmbed.setDescription(description);

            // Add current user's position
            const currentUserResult = await pool.query(
                'SELECT * FROM users WHERE user_id = $1 AND guild_id = $2',
                [interaction.user.id, interaction.guild.id]
            );

            if (currentUserResult.rows.length > 0) {
                const currentUser = currentUserResult.rows[0];
                
                let rankQuery;
                switch (type) {
                    case 'levels':
                        rankQuery = `
                            SELECT COUNT(*) + 1 as rank 
                            FROM users 
                            WHERE guild_id = $1 AND (
                                level > $2 OR 
                                (level = $2 AND xp > $3)
                            )
                        `;
                        break;
                    case 'messages':
                        rankQuery = 'SELECT COUNT(*) + 1 as rank FROM users WHERE guild_id = $1 AND messages > $2';
                        break;
                    case 'voice':
                        rankQuery = 'SELECT COUNT(*) + 1 as rank FROM users WHERE guild_id = $1 AND voice > $2';
                        break;
                }

                const rankResult = await pool.query(rankQuery, 
                    type === 'levels' ? 
                        [interaction.guild.id, currentUser.level, currentUser.xp] :
                        [interaction.guild.id, currentUser[type]]
                );
                
                const userRank = parseInt(rankResult.rows[0].rank);
                
                let userValue;
                switch (type) {
                    case 'levels':
                        userValue = `Level ${currentUser.level} (${currentUser.xp} XP)`;
                        break;
                    case 'messages':
                        userValue = `${currentUser.messages} messages`;
                        break;
                    case 'voice':
                        const hours = Math.floor(currentUser.voice / 60);
                        const minutes = currentUser.voice % 60;
                        userValue = `${hours}h ${minutes}m`;
                        break;
                }

                leaderboardEmbed.addFields({
                    name: '📍 Your Position',
                    value: `#${userRank} - ${userValue}`,
                    inline: false
                });
            }

            await interaction.reply({ embeds: [leaderboardEmbed] });

        } catch (error) {
            console.error('Leaderboard command error:', error);
            await interaction.reply({ 
                content: '❌ An error occurred while fetching leaderboard data.', 
                ephemeral: true 
            });
        }
    }
};