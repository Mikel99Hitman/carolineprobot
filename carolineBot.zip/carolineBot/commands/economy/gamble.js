const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('gamble')
        .setDescription('🎰 Advanced gambling system with multiple games')
        .addSubcommand(subcommand =>
            subcommand
                .setName('slots')
                .setDescription('🎰 Play slot machine')
                .addIntegerOption(option =>
                    option.setName('amount')
                        .setDescription('Amount to bet')
                        .setRequired(true)
                        .setMinValue(10)
                        .setMaxValue(10000)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('blackjack')
                .setDescription('🃏 Play blackjack')
                .addIntegerOption(option =>
                    option.setName('amount')
                        .setDescription('Amount to bet')
                        .setRequired(true)
                        .setMinValue(10)
                        .setMaxValue(5000)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('roulette')
                .setDescription('🎡 Play roulette')
                .addIntegerOption(option =>
                    option.setName('amount')
                        .setDescription('Amount to bet')
                        .setRequired(true)
                        .setMinValue(10)
                        .setMaxValue(5000))
                .addStringOption(option =>
                    option.setName('bet')
                        .setDescription('Bet type')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Red', value: 'red' },
                            { name: 'Black', value: 'black' },
                            { name: 'Even', value: 'even' },
                            { name: 'Odd', value: 'odd' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('coinflip')
                .setDescription('🪙 Flip a coin')
                .addIntegerOption(option =>
                    option.setName('amount')
                        .setDescription('Amount to bet')
                        .setRequired(true)
                        .setMinValue(10)
                        .setMaxValue(10000))
                .addStringOption(option =>
                    option.setName('choice')
                        .setDescription('Your choice')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Heads', value: 'heads' },
                            { name: 'Tails', value: 'tails' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('stats')
                .setDescription('📊 View gambling statistics')),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        
        try {
            // Create tables
            await this.createTables();
            
            switch (subcommand) {
                case 'slots':
                    await this.playSlots(interaction);
                    break;
                case 'blackjack':
                    await this.playBlackjack(interaction);
                    break;
                case 'roulette':
                    await this.playRoulette(interaction);
                    break;
                case 'coinflip':
                    await this.playCoinflip(interaction);
                    break;
                case 'stats':
                    await this.showStats(interaction);
                    break;
            }
        } catch (error) {
            console.error('Gamble command error:', error);
            await interaction.reply({ content: '❌ An error occurred while processing your bet.', ephemeral: true });
        }
    },

    async createTables() {
        await pool.query(`
            CREATE TABLE IF NOT EXISTS economy (
                user_id VARCHAR(20) NOT NULL,
                guild_id VARCHAR(20) NOT NULL,
                balance BIGINT DEFAULT 0,
                last_daily TIMESTAMP,
                total_gambled BIGINT DEFAULT 0,
                total_won BIGINT DEFAULT 0,
                games_played INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (user_id, guild_id)
            )
        `);
    },

    async getEconomyData(userId, guildId) {
        let result = await pool.query(
            'SELECT * FROM economy WHERE user_id = $1 AND guild_id = $2',
            [userId, guildId]
        );

        if (result.rows.length === 0) {
            await pool.query(
                'INSERT INTO economy (user_id, guild_id, balance) VALUES ($1, $2, $3)',
                [userId, guildId, 1000]
            );
            
            result = await pool.query(
                'SELECT * FROM economy WHERE user_id = $1 AND guild_id = $2',
                [userId, guildId]
            );
        }

        return result.rows[0];
    },

    async updateBalance(userId, guildId, newBalance, amountGambled, amountWon) {
        await pool.query(`
            UPDATE economy 
            SET balance = $1, 
                total_gambled = total_gambled + $2, 
                total_won = total_won + $3,
                games_played = games_played + 1
            WHERE user_id = $4 AND guild_id = $5
        `, [newBalance, amountGambled, amountWon, userId, guildId]);
    },

    async playSlots(interaction) {
        const amount = interaction.options.getInteger('amount');
        const economyData = await this.getEconomyData(interaction.user.id, interaction.guild.id);

        if (parseInt(economyData.balance) < amount) {
            return interaction.reply({ 
                content: `❌ Insufficient funds! You need $${amount.toLocaleString()} but only have $${parseInt(economyData.balance).toLocaleString()}`, 
                ephemeral: true 
            });
        }

        const symbols = ['🍒', '🍋', '🍊', '🍇', '⭐', '💎', '7️⃣'];
        const slot1 = symbols[Math.floor(Math.random() * symbols.length)];
        const slot2 = symbols[Math.floor(Math.random() * symbols.length)];
        const slot3 = symbols[Math.floor(Math.random() * symbols.length)];

        let multiplier = 0;
        let result = 'Lost';

        if (slot1 === slot2 && slot2 === slot3) {
            if (slot1 === '💎') {
                multiplier = 10;
                result = 'MEGA JACKPOT! 💎💎💎';
            } else if (slot1 === '7️⃣') {
                multiplier = 7;
                result = 'JACKPOT! 7️⃣7️⃣7️⃣';
            } else if (slot1 === '⭐') {
                multiplier = 5;
                result = 'BIG WIN! ⭐⭐⭐';
            } else {
                multiplier = 3;
                result = 'Triple Match!';
            }
        } else if (slot1 === slot2 || slot2 === slot3 || slot1 === slot3) {
            multiplier = 1.5;
            result = 'Pair Match!';
        }

        const winnings = Math.floor(amount * multiplier);
        const profit = winnings - amount;
        const newBalance = parseInt(economyData.balance) + profit;

        await this.updateBalance(interaction.user.id, interaction.guild.id, newBalance, amount, Math.max(0, profit));

        const embed = new EmbedBuilder()
            .setTitle('🎰 SLOT MACHINE 🎰')
            .setDescription(`**${slot1} | ${slot2} | ${slot3}**\n\n**${result}**`)
            .addFields(
                { name: '💰 Bet', value: `$${amount.toLocaleString()}`, inline: true },
                { name: '🎯 Multiplier', value: `${multiplier}x`, inline: true },
                { name: profit >= 0 ? '🎉 Won' : '💸 Lost', value: `$${Math.abs(profit).toLocaleString()}`, inline: true },
                { name: '💎 New Balance', value: `$${newBalance.toLocaleString()}`, inline: false }
            )
            .setColor(profit >= 0 ? '#00ff00' : '#ff0000')
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    },

    async playBlackjack(interaction) {
        const amount = interaction.options.getInteger('amount');
        const economyData = await this.getEconomyData(interaction.user.id, interaction.guild.id);

        if (parseInt(economyData.balance) < amount) {
            return interaction.reply({ 
                content: `❌ Insufficient funds! You need $${amount.toLocaleString()} but only have $${parseInt(economyData.balance).toLocaleString()}`, 
                ephemeral: true 
            });
        }

        const cards = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
        const getCardValue = (card) => {
            if (card === 'A') return 11;
            if (['J', 'Q', 'K'].includes(card)) return 10;
            return parseInt(card);
        };

        const playerCards = [cards[Math.floor(Math.random() * cards.length)], cards[Math.floor(Math.random() * cards.length)]];
        const dealerCards = [cards[Math.floor(Math.random() * cards.length)], cards[Math.floor(Math.random() * cards.length)]];

        let playerScore = getCardValue(playerCards[0]) + getCardValue(playerCards[1]);
        let dealerScore = getCardValue(dealerCards[0]) + getCardValue(dealerCards[1]);

        // Adjust for Aces
        if (playerScore > 21 && playerCards.includes('A')) playerScore -= 10;
        if (dealerScore > 21 && dealerCards.includes('A')) dealerScore -= 10;

        let result = '';
        let multiplier = 0;

        if (playerScore === 21) {
            result = 'BLACKJACK! 🃏';
            multiplier = 2.5;
        } else if (playerScore > 21) {
            result = 'BUST! 💥';
            multiplier = 0;
        } else if (dealerScore > 21) {
            result = 'Dealer Bust - You Win! 🎉';
            multiplier = 2;
        } else if (playerScore > dealerScore) {
            result = 'You Win! 🎉';
            multiplier = 2;
        } else if (playerScore === dealerScore) {
            result = 'Push (Tie) 🤝';
            multiplier = 1;
        } else {
            result = 'Dealer Wins 😔';
            multiplier = 0;
        }

        const winnings = Math.floor(amount * multiplier);
        const profit = winnings - amount;
        const newBalance = parseInt(economyData.balance) + profit;

        await this.updateBalance(interaction.user.id, interaction.guild.id, newBalance, amount, Math.max(0, profit));

        const embed = new EmbedBuilder()
            .setTitle('🃏 BLACKJACK 🃏')
            .setDescription(`**${result}**`)
            .addFields(
                { name: '🎴 Your Cards', value: `${playerCards.join(' ')} (${playerScore})`, inline: true },
                { name: '🎴 Dealer Cards', value: `${dealerCards.join(' ')} (${dealerScore})`, inline: true },
                { name: '💰 Bet', value: `$${amount.toLocaleString()}`, inline: true },
                { name: profit >= 0 ? '🎉 Won' : '💸 Lost', value: `$${Math.abs(profit).toLocaleString()}`, inline: true },
                { name: '💎 New Balance', value: `$${newBalance.toLocaleString()}`, inline: true }
            )
            .setColor(profit >= 0 ? '#00ff00' : '#ff0000')
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    },

    async playRoulette(interaction) {
        const amount = interaction.options.getInteger('amount');
        const bet = interaction.options.getString('bet');
        const economyData = await this.getEconomyData(interaction.user.id, interaction.guild.id);

        if (parseInt(economyData.balance) < amount) {
            return interaction.reply({ 
                content: `❌ Insufficient funds! You need $${amount.toLocaleString()} but only have $${parseInt(economyData.balance).toLocaleString()}`, 
                ephemeral: true 
            });
        }

        const number = Math.floor(Math.random() * 37); // 0-36
        const isRed = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36].includes(number);
        const isBlack = number !== 0 && !isRed;
        const isEven = number !== 0 && number % 2 === 0;
        const isOdd = number !== 0 && number % 2 === 1;

        let won = false;
        let multiplier = 0;

        if (bet === 'red' && isRed) {
            won = true;
            multiplier = 2;
        } else if (bet === 'black' && isBlack) {
            won = true;
            multiplier = 2;
        } else if (bet === 'even' && isEven) {
            won = true;
            multiplier = 2;
        } else if (bet === 'odd' && isOdd) {
            won = true;
            multiplier = 2;
        }

        const winnings = won ? amount * multiplier : 0;
        const profit = winnings - amount;
        const newBalance = parseInt(economyData.balance) + profit;

        await this.updateBalance(interaction.user.id, interaction.guild.id, newBalance, amount, Math.max(0, profit));

        const color = number === 0 ? '🟢' : isRed ? '🔴' : '⚫';
        
        const embed = new EmbedBuilder()
            .setTitle('🎡 ROULETTE 🎡')
            .setDescription(`**The ball landed on: ${color} ${number}**\n\n**${won ? 'YOU WIN! 🎉' : 'YOU LOSE 😔'}**`)
            .addFields(
                { name: '🎯 Your Bet', value: `${bet.toUpperCase()} - $${amount.toLocaleString()}`, inline: true },
                { name: '🎲 Result', value: `${color} ${number}`, inline: true },
                { name: profit >= 0 ? '🎉 Won' : '💸 Lost', value: `$${Math.abs(profit).toLocaleString()}`, inline: true },
                { name: '💎 New Balance', value: `$${newBalance.toLocaleString()}`, inline: false }
            )
            .setColor(won ? '#00ff00' : '#ff0000')
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    },

    async playCoinflip(interaction) {
        const amount = interaction.options.getInteger('amount');
        const choice = interaction.options.getString('choice');
        const economyData = await this.getEconomyData(interaction.user.id, interaction.guild.id);

        if (parseInt(economyData.balance) < amount) {
            return interaction.reply({ 
                content: `❌ Insufficient funds! You need $${amount.toLocaleString()} but only have $${parseInt(economyData.balance).toLocaleString()}`, 
                ephemeral: true 
            });
        }

        const result = Math.random() < 0.5 ? 'heads' : 'tails';
        const won = choice === result;
        const multiplier = won ? 2 : 0;
        
        const winnings = amount * multiplier;
        const profit = winnings - amount;
        const newBalance = parseInt(economyData.balance) + profit;

        await this.updateBalance(interaction.user.id, interaction.guild.id, newBalance, amount, Math.max(0, profit));

        const coinEmoji = result === 'heads' ? '🪙' : '🪙';
        
        const embed = new EmbedBuilder()
            .setTitle('🪙 COINFLIP 🪙')
            .setDescription(`**The coin landed on: ${result.toUpperCase()} ${coinEmoji}**\n\n**${won ? 'YOU WIN! 🎉' : 'YOU LOSE 😔'}**`)
            .addFields(
                { name: '🎯 Your Choice', value: choice.toUpperCase(), inline: true },
                { name: '🪙 Result', value: result.toUpperCase(), inline: true },
                { name: '💰 Bet', value: `$${amount.toLocaleString()}`, inline: true },
                { name: profit >= 0 ? '🎉 Won' : '💸 Lost', value: `$${Math.abs(profit).toLocaleString()}`, inline: true },
                { name: '💎 New Balance', value: `$${newBalance.toLocaleString()}`, inline: true }
            )
            .setColor(won ? '#00ff00' : '#ff0000')
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    },

    async showStats(interaction) {
        const economyData = await this.getEconomyData(interaction.user.id, interaction.guild.id);
        
        const totalGambled = parseInt(economyData.total_gambled) || 0;
        const totalWon = parseInt(economyData.total_won) || 0;
        const gamesPlayed = parseInt(economyData.games_played) || 0;
        const netProfit = totalWon - totalGambled;
        const winRate = gamesPlayed > 0 ? ((totalWon / totalGambled) * 100).toFixed(1) : 0;

        const embed = new EmbedBuilder()
            .setTitle('📊 Gambling Statistics')
            .setDescription(`Statistics for ${interaction.user.username}`)
            .addFields(
                { name: '💰 Current Balance', value: `$${parseInt(economyData.balance).toLocaleString()}`, inline: true },
                { name: '🎮 Games Played', value: gamesPlayed.toLocaleString(), inline: true },
                { name: '💸 Total Gambled', value: `$${totalGambled.toLocaleString()}`, inline: true },
                { name: '🎉 Total Won', value: `$${totalWon.toLocaleString()}`, inline: true },
                { name: netProfit >= 0 ? '📈 Net Profit' : '📉 Net Loss', value: `$${Math.abs(netProfit).toLocaleString()}`, inline: true },
                { name: '🎯 Success Rate', value: `${winRate}%`, inline: true }
            )
            .setColor(netProfit >= 0 ? '#00ff00' : '#ff0000')
            .setFooter({ text: 'Gamble responsibly!' })
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};