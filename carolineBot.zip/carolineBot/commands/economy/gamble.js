const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Economy = require('../../models/Economy');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('gamble')
        .setDescription('Gamble your money')
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('Amount to gamble')
                .setRequired(true)
                .setMinValue(10)),

    async execute(interaction) {
        const amount = interaction.options.getInteger('amount');

        let economyData = await Economy.findOne({
            userId: interaction.user.id,
            guildId: interaction.guild.id
        });

        if (!economyData) {
            economyData = new Economy({
                userId: interaction.user.id,
                guildId: interaction.guild.id
            });
        }

        if (economyData.balance < amount) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('💸 Insufficient Funds')
                .setDescription(`You need **$${amount.toLocaleString()}** but only have **$${economyData.balance.toLocaleString()}**`);

            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        const random = Math.random();
        let multiplier = 0;
        let result = '';

        if (random < 0.45) { // 45% chance to lose
            multiplier = 0;
            result = 'Lost';
        } else if (random < 0.80) { // 35% chance to win 1.5x
            multiplier = 1.5;
            result = 'Won';
        } else if (random < 0.95) { // 15% chance to win 2x
            multiplier = 2;
            result = 'Big Win';
        } else { // 5% chance to win 3x
            multiplier = 3;
            result = 'Jackpot';
        }

        const winnings = Math.floor(amount * multiplier);
        const profit = winnings - amount;

        economyData.balance += profit;
        
        economyData.transactions.push({
            type: profit >= 0 ? 'earn' : 'spend',
            amount: Math.abs(profit),
            description: `Gambling - ${result}`
        });

        await economyData.save();

        const color = profit >= 0 ? '#00ff00' : '#ff0000';
        const emoji = profit >= 0 ? '🎉' : '💸';

        const gambleEmbed = new EmbedBuilder()
            .setColor(color)
            .setTitle(`${emoji} ${result}!`)
            .setDescription(`You ${profit >= 0 ? 'won' : 'lost'} **$${Math.abs(profit).toLocaleString()}**!`)
            .addFields(
                { name: '🎲 Multiplier', value: `${multiplier}x`, inline: true },
                { name: '💰 New Balance', value: `$${economyData.balance.toLocaleString()}`, inline: true }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [gambleEmbed] });
    }
};