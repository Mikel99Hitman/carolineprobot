const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Economy = require('../../models/Economy');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('daily')
        .setDescription('Claim your daily reward'),

    async execute(interaction) {
        let economyData = await Economy.findOne({
            userId: interaction.user.id,
            guildId: interaction.guild.id
        });

        if (!economyData) {
            economyData = new Economy({
                userId: interaction.user.id,
                guildId: interaction.guild.id
            });
        }

        const now = new Date();
        const lastDaily = economyData.lastDaily;

        if (lastDaily && now - lastDaily < 24 * 60 * 60 * 1000) {
            const timeLeft = 24 * 60 * 60 * 1000 - (now - lastDaily);
            const hours = Math.floor(timeLeft / (60 * 60 * 1000));
            const minutes = Math.floor((timeLeft % (60 * 60 * 1000)) / (60 * 1000));

            const errorEmbed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('⏰ Daily Already Claimed')
                .setDescription(`You can claim your daily reward again in **${hours}h ${minutes}m**`);

            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        const dailyAmount = Math.floor(Math.random() * 500) + 100; // 100-600
        economyData.balance += dailyAmount;
        economyData.lastDaily = now;
        
        economyData.transactions.push({
            type: 'earn',
            amount: dailyAmount,
            description: 'Daily reward'
        });

        await economyData.save();

        const dailyEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('🎁 Daily Reward Claimed!')
            .setDescription(`You received **$${dailyAmount.toLocaleString()}**!`)
            .addFields(
                { name: '💰 New Balance', value: `$${economyData.balance.toLocaleString()}`, inline: true }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [dailyEmbed] });
    }
};