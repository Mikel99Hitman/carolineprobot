const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('daily')
        .setDescription('Claim your daily reward'),

    async execute(interaction) {
        try {
            // Create economy table if not exists
            await pool.query(`
                CREATE TABLE IF NOT EXISTS economy (
                    user_id VARCHAR(20) NOT NULL,
                    guild_id VARCHAR(20) NOT NULL,
                    balance BIGINT DEFAULT 0,
                    last_daily TIMESTAMP,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (user_id, guild_id)
                )
            `);

            // Create transactions table if not exists
            await pool.query(`
                CREATE TABLE IF NOT EXISTS transactions (
                    id SERIAL PRIMARY KEY,
                    user_id VARCHAR(20) NOT NULL,
                    guild_id VARCHAR(20) NOT NULL,
                    type VARCHAR(20) NOT NULL,
                    amount BIGINT NOT NULL,
                    description TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            `);

            // Get user economy data
            let result = await pool.query(
                'SELECT * FROM economy WHERE user_id = $1 AND guild_id = $2',
                [interaction.user.id, interaction.guild.id]
            );

            let economyData = result.rows[0];

            if (!economyData) {
                // Create new economy record
                await pool.query(
                    'INSERT INTO economy (user_id, guild_id, balance) VALUES ($1, $2, $3)',
                    [interaction.user.id, interaction.guild.id, 0]
                );
                
                result = await pool.query(
                    'SELECT * FROM economy WHERE user_id = $1 AND guild_id = $2',
                    [interaction.user.id, interaction.guild.id]
                );
                economyData = result.rows[0];
            }

            const now = new Date();
            const lastDaily = economyData.last_daily;

            if (lastDaily && now - new Date(lastDaily) < 24 * 60 * 60 * 1000) {
                const timeLeft = 24 * 60 * 60 * 1000 - (now - new Date(lastDaily));
                const hours = Math.floor(timeLeft / (60 * 60 * 1000));
                const minutes = Math.floor((timeLeft % (60 * 60 * 1000)) / (60 * 1000));

                const errorEmbed = new EmbedBuilder()
                    .setColor('#ff0000')
                    .setTitle('⏰ Daily Already Claimed')
                    .setDescription(`You can claim your daily reward again in **${hours}h ${minutes}m**`)
                    .addFields(
                        { name: '💰 Current Balance', value: `$${parseInt(economyData.balance).toLocaleString()}`, inline: true },
                        { name: '🎁 Next Reward', value: `$100 - $600`, inline: true }
                    )
                    .setTimestamp();

                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            // Calculate daily reward with streak bonus
            const baseAmount = Math.floor(Math.random() * 500) + 100; // 100-600
            const streakBonus = Math.floor(Math.random() * 200); // 0-200 bonus
            const dailyAmount = baseAmount + streakBonus;
            
            const newBalance = parseInt(economyData.balance) + dailyAmount;

            // Update economy data
            await pool.query(
                'UPDATE economy SET balance = $1, last_daily = $2 WHERE user_id = $3 AND guild_id = $4',
                [newBalance, now, interaction.user.id, interaction.guild.id]
            );

            // Add transaction record
            await pool.query(
                'INSERT INTO transactions (user_id, guild_id, type, amount, description) VALUES ($1, $2, $3, $4, $5)',
                [interaction.user.id, interaction.guild.id, 'earn', dailyAmount, 'Daily reward']
            );

            const dailyEmbed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('🎁 Daily Reward Claimed!')
                .setDescription(`Congratulations! You received your daily reward!`)
                .addFields(
                    { name: '💰 Reward Amount', value: `$${dailyAmount.toLocaleString()}`, inline: true },
                    { name: '💎 New Balance', value: `$${newBalance.toLocaleString()}`, inline: true },
                    { name: '🔥 Streak Bonus', value: `$${streakBonus.toLocaleString()}`, inline: true },
                    { name: '⏰ Next Claim', value: '24 hours', inline: true },
                    { name: '🎯 Daily Range', value: '$100 - $600', inline: true },
                    { name: '📈 Total Earned', value: 'Check with `/balance`', inline: true }
                )
                .setFooter({ text: 'Come back tomorrow for another reward!' })
                .setTimestamp();

            await interaction.reply({ embeds: [dailyEmbed] });

        } catch (error) {
            console.error('Daily command error:', error);
            await interaction.reply({ 
                content: '❌ An error occurred while processing your daily reward.', 
                ephemeral: true 
            });
        }
    }
};