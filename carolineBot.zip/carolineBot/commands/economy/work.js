const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Economy = require('../../models/Economy');

const jobs = [
    { name: 'Developer', min: 200, max: 800 },
    { name: 'Designer', min: 150, max: 600 },
    { name: 'Writer', min: 100, max: 400 },
    { name: 'Streamer', min: 300, max: 1000 },
    { name: 'Gamer', min: 50, max: 300 }
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('work')
        .setDescription('Work to earn money'),

    async execute(interaction) {
        let economyData = await Economy.findOne({
            userId: interaction.user.id,
            guildId: interaction.guild.id
        });

        if (!economyData) {
            economyData = new Economy({
                userId: interaction.user.id,
                guildId: interaction.guild.id
            });
        }

        const now = new Date();
        const lastWork = economyData.lastWork;

        if (lastWork && now - lastWork < 60 * 60 * 1000) { // 1 hour cooldown
            const timeLeft = 60 * 60 * 1000 - (now - lastWork);
            const minutes = Math.floor(timeLeft / (60 * 1000));

            const errorEmbed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('⏰ Work Cooldown')
                .setDescription(`You can work again in **${minutes} minutes**`);

            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }

        const job = jobs[Math.floor(Math.random() * jobs.length)];
        const earnings = Math.floor(Math.random() * (job.max - job.min + 1)) + job.min;

        economyData.balance += earnings;
        economyData.lastWork = now;
        
        economyData.transactions.push({
            type: 'earn',
            amount: earnings,
            description: `Worked as ${job.name}`
        });

        await economyData.save();

        const workEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('💼 Work Complete!')
            .setDescription(`You worked as a **${job.name}** and earned **$${earnings.toLocaleString()}**!`)
            .addFields(
                { name: '💰 New Balance', value: `$${economyData.balance.toLocaleString()}`, inline: true }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [workEmbed] });
    }
};