const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

const jobs = [
    { name: 'Developer', min: 200, max: 800 },
    { name: 'Designer', min: 150, max: 600 },
    { name: 'Writer', min: 100, max: 400 },
    { name: 'Streamer', min: 300, max: 1000 },
    { name: 'Gamer', min: 50, max: 300 }
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('work')
        .setDescription('Work to earn money'),

    async execute(interaction) {
        try {
            // Get or create economy data
            let result = await pool.query(
                'SELECT * FROM economy WHERE user_id = $1 AND guild_id = $2',
                [interaction.user.id, interaction.guild.id]
            );

            let economyData = result.rows[0];
            if (!economyData) {
                await pool.query(
                    'INSERT INTO economy (user_id, guild_id, balance) VALUES ($1, $2, $3)',
                    [interaction.user.id, interaction.guild.id, 1000]
                );
                
                result = await pool.query(
                    'SELECT * FROM economy WHERE user_id = $1 AND guild_id = $2',
                    [interaction.user.id, interaction.guild.id]
                );
                economyData = result.rows[0];
            }

            const now = new Date();
            const lastWork = economyData.last_work;

            if (lastWork && now - new Date(lastWork) < 60 * 60 * 1000) { // 1 hour cooldown
                const timeLeft = 60 * 60 * 1000 - (now - new Date(lastWork));
                const minutes = Math.floor(timeLeft / (60 * 1000));

                const errorEmbed = new EmbedBuilder()
                    .setColor('#ff0000')
                    .setTitle('⏰ Work Cooldown')
                    .setDescription(`You can work again in **${minutes} minutes**`)
                    .addFields(
                        { name: '💰 Current Balance', value: `$${parseInt(economyData.balance).toLocaleString()}`, inline: true },
                        { name: '💼 Available Jobs', value: jobs.map(j => j.name).join(', '), inline: false }
                    )
                    .setTimestamp();

                return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }

            const job = jobs[Math.floor(Math.random() * jobs.length)];
            const earnings = Math.floor(Math.random() * (job.max - job.min + 1)) + job.min;
            const newBalance = parseInt(economyData.balance) + earnings;

            // Update economy data
            await pool.query(
                'UPDATE economy SET balance = $1, last_work = $2 WHERE user_id = $3 AND guild_id = $4',
                [newBalance, now, interaction.user.id, interaction.guild.id]
            );

            // Add transaction record
            await pool.query(
                'INSERT INTO transactions (user_id, guild_id, type, amount, description) VALUES ($1, $2, $3, $4, $5)',
                [interaction.user.id, interaction.guild.id, 'earn', earnings, `Worked as ${job.name}`]
            );

            const workEmbed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('💼 Work Complete!')
                .setDescription(`You worked as a **${job.name}** and earned **$${earnings.toLocaleString()}**!`)
                .addFields(
                    { name: '💰 Earnings', value: `$${earnings.toLocaleString()}`, inline: true },
                    { name: '💎 New Balance', value: `$${newBalance.toLocaleString()}`, inline: true },
                    { name: '⏰ Next Work', value: '1 hour', inline: true },
                    { name: '📊 Job Range', value: `$${job.min} - $${job.max}`, inline: true },
                    { name: '🎯 Job Type', value: job.name, inline: true },
                    { name: '📈 Total Earned', value: 'Check with `/balance`', inline: true }
                )
                .setFooter({ text: 'Keep working to earn more money!' })
                .setTimestamp();

            await interaction.reply({ embeds: [workEmbed] });

        } catch (error) {
            console.error('Work command error:', error);
            await interaction.reply({ 
                content: '❌ An error occurred while processing your work.', 
                ephemeral: true 
            });
        }
    }
};