const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

const shopItems = [
    { id: 'vip', name: 'VIP Role', price: 5000, description: 'Get VIP status for 30 days', emoji: '⭐' },
    { id: 'color', name: 'Custom Color', price: 2000, description: 'Custom role color for 7 days', emoji: '🎨' },
    { id: 'nickname', name: 'Nickname Change', price: 1000, description: 'Change your nickname', emoji: '📝' },
    { id: 'boost', name: 'XP Boost', price: 3000, description: '2x XP for 24 hours', emoji: '🚀' },
    { id: 'lottery', name: 'Lottery Ticket', price: 500, description: 'Enter weekly lottery', emoji: '🎫' }
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('shop')
        .setDescription('View and purchase items from the server shop')
        .addStringOption(option =>
            option.setName('item')
                .setDescription('Item to purchase')
                .setRequired(false)
                .addChoices(
                    ...shopItems.map(item => ({ name: `${item.emoji} ${item.name} - $${item.price}`, value: item.id }))
                )),

    async execute(interaction) {
        const itemId = interaction.options.getString('item');

        try {
            if (itemId) {
                await this.purchaseItem(interaction, itemId);
            } else {
                await this.showShop(interaction);
            }
        } catch (error) {
            console.error('Shop command error:', error);
            await interaction.reply({ 
                content: '❌ An error occurred while processing your request.', 
                ephemeral: true 
            });
        }
    },

    async showShop(interaction) {
        // Get user balance
        const result = await pool.query(
            'SELECT balance FROM economy WHERE user_id = $1 AND guild_id = $2',
            [interaction.user.id, interaction.guild.id]
        );

        const balance = result.rows[0]?.balance || 0;

        const embed = new EmbedBuilder()
            .setColor('#ffd700')
            .setTitle('🛒 Server Shop')
            .setDescription(`Welcome to the server shop! You have **$${parseInt(balance).toLocaleString()}**`)
            .addFields(
                { name: '💰 Your Balance', value: `$${parseInt(balance).toLocaleString()}`, inline: true },
                { name: '🛍️ Total Items', value: shopItems.length.toString(), inline: true },
                { name: '📦 Categories', value: 'Roles, Boosts, Utilities', inline: true }
            )
            .setFooter({ text: 'Use /shop <item> to purchase or click buttons below' })
            .setTimestamp();

        // Add shop items
        shopItems.forEach(item => {
            const canAfford = parseInt(balance) >= item.price;
            embed.addFields({
                name: `${item.emoji} ${item.name}`,
                value: `**Price:** $${item.price.toLocaleString()}\n**Description:** ${item.description}\n**Status:** ${canAfford ? '✅ Available' : '❌ Can\'t afford'}`,
                inline: true
            });
        });

        const buttons = shopItems.slice(0, 5).map(item =>
            new ButtonBuilder()
                .setCustomId(`shop_buy_${item.id}`)
                .setLabel(`${item.emoji} $${item.price}`)
                .setStyle(parseInt(balance) >= item.price ? ButtonStyle.Success : ButtonStyle.Secondary)
                .setDisabled(parseInt(balance) < item.price)
        );

        const row = new ActionRowBuilder().addComponents(buttons);
        await interaction.reply({ embeds: [embed], components: [row] });
    },

    async purchaseItem(interaction, itemId) {
        const item = shopItems.find(i => i.id === itemId);
        if (!item) {
            return interaction.reply({ content: '❌ Item not found!', ephemeral: true });
        }

        // Get user balance
        const result = await pool.query(
            'SELECT balance FROM economy WHERE user_id = $1 AND guild_id = $2',
            [interaction.user.id, interaction.guild.id]
        );

        const balance = parseInt(result.rows[0]?.balance || 0);

        if (balance < item.price) {
            const embed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('❌ Insufficient Funds')
                .setDescription(`You need **$${item.price.toLocaleString()}** but only have **$${balance.toLocaleString()}**`)
                .addFields(
                    { name: '💰 Required', value: `$${item.price.toLocaleString()}`, inline: true },
                    { name: '💳 Your Balance', value: `$${balance.toLocaleString()}`, inline: true },
                    { name: '💸 Needed', value: `$${(item.price - balance).toLocaleString()}`, inline: true }
                )
                .setFooter({ text: 'Use /work or /daily to earn more money!' });

            return interaction.reply({ embeds: [embed], ephemeral: true });
        }

        // Deduct money
        const newBalance = balance - item.price;
        await pool.query(
            'UPDATE economy SET balance = $1 WHERE user_id = $2 AND guild_id = $3',
            [newBalance, interaction.user.id, interaction.guild.id]
        );

        // Add to inventory
        await pool.query(`
            INSERT INTO inventory (user_id, guild_id, item, quantity) 
            VALUES ($1, $2, $3, 1)
            ON CONFLICT (user_id, guild_id, item) 
            DO UPDATE SET quantity = inventory.quantity + 1
        `, [interaction.user.id, interaction.guild.id, item.id]);

        // Add transaction record
        await pool.query(
            'INSERT INTO transactions (user_id, guild_id, type, amount, description) VALUES ($1, $2, $3, $4, $5)',
            [interaction.user.id, interaction.guild.id, 'spend', item.price, `Purchased ${item.name}`]
        );

        const embed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('✅ Purchase Successful!')
            .setDescription(`You successfully purchased **${item.emoji} ${item.name}**!`)
            .addFields(
                { name: '🛍️ Item', value: `${item.emoji} ${item.name}`, inline: true },
                { name: '💰 Price', value: `$${item.price.toLocaleString()}`, inline: true },
                { name: '💳 New Balance', value: `$${newBalance.toLocaleString()}`, inline: true },
                { name: '📝 Description', value: item.description, inline: false }
            )
            .setFooter({ text: 'Thank you for your purchase!' })
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });

        // Apply item effects (this would be expanded based on item type)
        await this.applyItemEffects(interaction, item);
    },

    async applyItemEffects(interaction, item) {
        // This would contain logic to apply item effects
        // For example, giving roles, setting boosts, etc.
        console.log(`Applied effects for item: ${item.name} to user: ${interaction.user.id}`);
    }
};