const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('balance')
        .setDescription('Check your or another user\'s balance')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to check balance for')
                .setRequired(false)),

    async execute(interaction) {
        const targetUser = interaction.options.getUser('user') || interaction.user;
        
        try {
            // Get or create economy data
            let result = await pool.query(
                'SELECT * FROM economy WHERE user_id = $1 AND guild_id = $2',
                [targetUser.id, interaction.guild.id]
            );

            let economyData = result.rows[0];
            if (!economyData) {
                await pool.query(
                    'INSERT INTO economy (user_id, guild_id, balance, bank) VALUES ($1, $2, $3, $4)',
                    [targetUser.id, interaction.guild.id, 1000, 0]
                );
                
                result = await pool.query(
                    'SELECT * FROM economy WHERE user_id = $1 AND guild_id = $2',
                    [targetUser.id, interaction.guild.id]
                );
                economyData = result.rows[0];
            }

            const balance = parseInt(economyData.balance) || 0;
            const bank = parseInt(economyData.bank) || 0;
            const netWorth = balance + bank;

            const balanceEmbed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle(`💰 ${targetUser.username}'s Balance`)
                .setThumbnail(targetUser.displayAvatarURL())
                .addFields(
                    { name: '💵 Wallet', value: `$${balance.toLocaleString()}`, inline: true },
                    { name: '🏦 Bank', value: `$${bank.toLocaleString()}`, inline: true },
                    { name: '💎 Net Worth', value: `$${netWorth.toLocaleString()}`, inline: true }
                )
                .setFooter({ text: `Requested by ${interaction.user.tag}` })
                .setTimestamp();

            await interaction.reply({ embeds: [balanceEmbed] });

        } catch (error) {
            console.error('Balance command error:', error);
            await interaction.reply({ 
                content: '❌ An error occurred while fetching balance data.', 
                ephemeral: true 
            });
        }
    }
};