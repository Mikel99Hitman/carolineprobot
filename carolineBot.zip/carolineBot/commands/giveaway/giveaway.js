const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, ChannelType } = require('discord.js');
const Giveaway = require('../../models/Giveaway');
const ms = require('ms');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('giveaway')
        .setDescription('Start a giveaway')
        .addStringOption(option =>
            option.setName('duration')
                .setDescription('Duration (e.g., 1h, 30m, 1d)')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('prize')
                .setDescription('Prize description')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('winners')
                .setDescription('Number of winners')
                .setRequired(true)
                .setMinValue(1)
                .setMaxValue(20))
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Channel to host the giveaway')
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(false))
        .addRoleOption(option =>
            option.setName('required_role')
                .setDescription('Required role to participate')
                .setRequired(false))
        .addIntegerOption(option =>
            option.setName('required_level')
                .setDescription('Required level to participate')
                .setRequired(false)
                .setMinValue(1))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    async execute(interaction) {
        const duration = interaction.options.getString('duration');
        const prize = interaction.options.getString('prize');
        const winners = interaction.options.getInteger('winners');
        const channel = interaction.options.getChannel('channel') || interaction.channel;
        const requiredRole = interaction.options.getRole('required_role');
        const requiredLevel = interaction.options.getInteger('required_level');

        const time = ms(duration);
        if (!time || time < 10000) {
            return interaction.reply({ content: '❌ Invalid duration! Minimum is 10 seconds.', ephemeral: true });
        }

        const endTime = new Date(Date.now() + time);

        const giveawayEmbed = new EmbedBuilder()
            .setColor('#ff6b6b')
            .setTitle('🎉 GIVEAWAY 🎉')
            .setDescription(`**Prize:** ${prize}\\n**Winners:** ${winners}\\n**Ends:** <t:${Math.floor(endTime.getTime() / 1000)}:R>\\n**Hosted by:** ${interaction.user}`)
            .setFooter({ text: 'Click the button below to enter!' })
            .setTimestamp(endTime);

        if (requiredRole || requiredLevel) {
            let requirements = '**Requirements:**\\n';
            if (requiredRole) requirements += `• Have the ${requiredRole} role\\n`;
            if (requiredLevel) requirements += `• Be level ${requiredLevel} or higher\\n`;
            giveawayEmbed.addFields({ name: '📋 Entry Requirements', value: requirements });
        }

        const enterButton = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('enter_giveaway')
                    .setLabel('🎉 Enter Giveaway')
                    .setStyle(ButtonStyle.Primary)
            );

        const giveawayMessage = await channel.send({ embeds: [giveawayEmbed], components: [enterButton] });

        const giveaway = new Giveaway({
            guildId: interaction.guild.id,
            channelId: channel.id,
            messageId: giveawayMessage.id,
            hostId: interaction.user.id,
            prize,
            winners,
            endTime,
            requirements: {
                role: requiredRole?.id || null,
                level: requiredLevel || 0
            }
        });

        await giveaway.save();

        // Set timeout to end giveaway
        setTimeout(async () => {
            await endGiveaway(giveaway.id);
        }, time);

        await interaction.reply({ content: `✅ Giveaway started in ${channel}!`, ephemeral: true });
    }
};

async function endGiveaway(giveawayId) {
    try {
        const giveaway = await Giveaway.findById(giveawayId);
        if (!giveaway || giveaway.ended) return;

        const guild = client.guilds.cache.get(giveaway.guildId);
        const channel = guild?.channels.cache.get(giveaway.channelId);
        const message = await channel?.messages.fetch(giveaway.messageId);

        if (!message) return;

        giveaway.ended = true;
        await giveaway.save();

        if (giveaway.participants.length === 0) {
            const noWinnerEmbed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('🎉 Giveaway Ended')
                .setDescription(`**Prize:** ${giveaway.prize}\\n**Winners:** No valid entries`)
                .setTimestamp();

            await message.edit({ embeds: [noWinnerEmbed], components: [] });
            return;
        }

        const winnerCount = Math.min(giveaway.winners, giveaway.participants.length);
        const winners = [];
        const participants = [...giveaway.participants];

        for (let i = 0; i < winnerCount; i++) {
            const randomIndex = Math.floor(Math.random() * participants.length);
            winners.push(participants.splice(randomIndex, 1)[0]);
        }

        const winnerMentions = winners.map(id => `<@${id}>`).join(', ');

        const winnerEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('🎉 Giveaway Ended')
            .setDescription(`**Prize:** ${giveaway.prize}\\n**Winners:** ${winnerMentions}`)
            .setTimestamp();

        await message.edit({ embeds: [winnerEmbed], components: [] });
        await channel.send(`🎉 Congratulations ${winnerMentions}! You won **${giveaway.prize}**!`);

    } catch (error) {
        console.error('Error ending giveaway:', error);
    }
}