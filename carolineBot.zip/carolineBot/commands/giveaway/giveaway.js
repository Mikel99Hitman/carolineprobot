const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits, ChannelType } = require('discord.js');
const { Pool } = require('pg');
const ms = require('ms');
const axios = require('axios');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('giveaway')
        .setDescription('🎉 Advanced giveaway system with multiple features')
        .addSubcommand(subcommand =>
            subcommand
                .setName('start')
                .setDescription('Start a new giveaway')
                .addStringOption(option =>
                    option.setName('duration')
                        .setDescription('Duration (e.g., 1h, 30m, 1d)')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('prize')
                        .setDescription('Prize description')
                        .setRequired(true))
                .addIntegerOption(option =>
                    option.setName('winners')
                        .setDescription('Number of winners')
                        .setRequired(true)
                        .setMinValue(1)
                        .setMaxValue(20))
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('Channel to host the giveaway')
                        .addChannelTypes(ChannelType.GuildText)
                        .setRequired(false))
                .addRoleOption(option =>
                    option.setName('required_role')
                        .setDescription('Required role to participate')
                        .setRequired(false))
                .addIntegerOption(option =>
                    option.setName('required_level')
                        .setDescription('Required level to participate')
                        .setRequired(false)
                        .setMinValue(1))
                .addStringOption(option =>
                    option.setName('webhook_url')
                        .setDescription('Webhook URL for notifications')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('end')
                .setDescription('End a giveaway early')
                .addStringOption(option =>
                    option.setName('message_id')
                        .setDescription('Giveaway message ID')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('reroll')
                .setDescription('Reroll giveaway winners')
                .addStringOption(option =>
                    option.setName('message_id')
                        .setDescription('Giveaway message ID')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('list')
                .setDescription('List active giveaways'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('stats')
                .setDescription('View giveaway statistics'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        
        try {
            await this.createTables();
            
            switch (subcommand) {
                case 'start':
                    await this.startGiveaway(interaction);
                    break;
                case 'end':
                    await this.endGiveaway(interaction);
                    break;
                case 'reroll':
                    await this.rerollGiveaway(interaction);
                    break;
                case 'list':
                    await this.listGiveaways(interaction);
                    break;
                case 'stats':
                    await this.showStats(interaction);
                    break;
            }
        } catch (error) {
            console.error('Giveaway command error:', error);
            await interaction.reply({ content: '❌ An error occurred while processing the giveaway command.', ephemeral: true });
        }
    },

    async createTables() {
        await pool.query(`
            CREATE TABLE IF NOT EXISTS giveaways (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                channel_id VARCHAR(20) NOT NULL,
                message_id VARCHAR(20) NOT NULL,
                host_id VARCHAR(20) NOT NULL,
                prize TEXT NOT NULL,
                winners_count INTEGER NOT NULL,
                end_time TIMESTAMP NOT NULL,
                required_role VARCHAR(20),
                required_level INTEGER DEFAULT 0,
                webhook_url TEXT,
                ended BOOLEAN DEFAULT false,
                participants TEXT[] DEFAULT '{}',
                winners TEXT[] DEFAULT '{}',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
    },

    async startGiveaway(interaction) {
        const duration = interaction.options.getString('duration');
        const prize = interaction.options.getString('prize');
        const winners = interaction.options.getInteger('winners');
        const channel = interaction.options.getChannel('channel') || interaction.channel;
        const requiredRole = interaction.options.getRole('required_role');
        const requiredLevel = interaction.options.getInteger('required_level');
        const webhookUrl = interaction.options.getString('webhook_url');

        const time = ms(duration);
        if (!time || time < 10000) {
            return interaction.reply({ content: '❌ Invalid duration! Minimum is 10 seconds.', ephemeral: true });
        }

        const endTime = new Date(Date.now() + time);

        const giveawayEmbed = new EmbedBuilder()
            .setColor('#ff6b6b')
            .setTitle('🎉 GIVEAWAY 🎉')
            .setDescription(`**🎁 Prize:** ${prize}\n**🏆 Winners:** ${winners}\n**⏰ Ends:** <t:${Math.floor(endTime.getTime() / 1000)}:R>\n**👥 Hosted by:** ${interaction.user}`)
            .addFields(
                { name: '📊 Participants', value: '0', inline: true },
                { name: '🎯 Status', value: '🟢 Active', inline: true },
                { name: '🕰️ Time Left', value: `<t:${Math.floor(endTime.getTime() / 1000)}:R>`, inline: true }
            )
            .setFooter({ text: 'Click the button below to enter!' })
            .setTimestamp(endTime);

        if (requiredRole || requiredLevel) {
            let requirements = '**Requirements:**\n';
            if (requiredRole) requirements += `• Have the ${requiredRole} role\n`;
            if (requiredLevel) requirements += `• Be level ${requiredLevel} or higher\n`;
            giveawayEmbed.addFields({ name: '📋 Entry Requirements', value: requirements });
        }

        const enterButton = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('enter_giveaway')
                    .setLabel('🎉 Enter Giveaway')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('🎁'),
                new ButtonBuilder()
                    .setCustomId('giveaway_info')
                    .setLabel('📊 Info')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('ℹ️')
            );

        const giveawayMessage = await channel.send({ embeds: [giveawayEmbed], components: [enterButton] });

        // Save to database
        await pool.query(`
            INSERT INTO giveaways (guild_id, channel_id, message_id, host_id, prize, winners_count, end_time, required_role, required_level, webhook_url)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
        `, [interaction.guild.id, channel.id, giveawayMessage.id, interaction.user.id, prize, winners, endTime, requiredRole?.id, requiredLevel || 0, webhookUrl]);

        // Send webhook notification if provided
        if (webhookUrl) {
            await this.sendWebhookNotification(webhookUrl, {
                title: '🎉 New Giveaway Started',
                description: `**Prize:** ${prize}\n**Winners:** ${winners}\n**Duration:** ${duration}\n**Channel:** ${channel}`,
                color: 0xff6b6b,
                timestamp: new Date().toISOString()
            });
        }

        // Log giveaway start
        const Logger = require('../utils/Logger');
        await Logger.log(interaction.guild, 'GIVEAWAY_START', {
            host: interaction.user,
            prize: prize,
            winners: winners,
            channel: channel
        });

        // Set timeout to end giveaway
        setTimeout(async () => {
            await this.endGiveawayById(giveawayMessage.id, interaction.client);
        }, time);

        await interaction.reply({ content: `✅ Giveaway started in ${channel}!`, ephemeral: true });
    },

    async endGiveaway(interaction) {
        const messageId = interaction.options.getString('message_id');
        
        const result = await pool.query(
            'SELECT * FROM giveaways WHERE message_id = $1 AND guild_id = $2 AND ended = false',
            [messageId, interaction.guild.id]
        );

        if (result.rows.length === 0) {
            return interaction.reply({ content: '❌ Giveaway not found or already ended!', ephemeral: true });
        }

        await this.endGiveawayById(messageId, interaction.client);
        await interaction.reply({ content: '✅ Giveaway ended successfully!', ephemeral: true });
    },

    async rerollGiveaway(interaction) {
        const messageId = interaction.options.getString('message_id');
        
        const result = await pool.query(
            'SELECT * FROM giveaways WHERE message_id = $1 AND guild_id = $2 AND ended = true',
            [messageId, interaction.guild.id]
        );

        if (result.rows.length === 0) {
            return interaction.reply({ content: '❌ Giveaway not found or not ended yet!', ephemeral: true });
        }

        const giveaway = result.rows[0];
        const participants = giveaway.participants || [];

        if (participants.length === 0) {
            return interaction.reply({ content: '❌ No participants to reroll!', ephemeral: true });
        }

        const winnerCount = Math.min(giveaway.winners_count, participants.length);
        const newWinners = [];
        const availableParticipants = [...participants];

        for (let i = 0; i < winnerCount; i++) {
            const randomIndex = Math.floor(Math.random() * availableParticipants.length);
            newWinners.push(availableParticipants.splice(randomIndex, 1)[0]);
        }

        // Update winners in database
        await pool.query(
            'UPDATE giveaways SET winners = $1 WHERE message_id = $2',
            [newWinners, messageId]
        );

        const channel = interaction.guild.channels.cache.get(giveaway.channel_id);
        const winnerMentions = newWinners.map(id => `<@${id}>`).join(', ');

        const rerollEmbed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('🎉 Giveaway Rerolled')
            .setDescription(`**🎁 Prize:** ${giveaway.prize}\n**🏆 New Winners:** ${winnerMentions}`)
            .setFooter({ text: 'Rerolled by ' + interaction.user.tag })
            .setTimestamp();

        await channel.send({ embeds: [rerollEmbed] });
        await interaction.reply({ content: `✅ Giveaway rerolled! New winners: ${winnerMentions}`, ephemeral: true });
    },

    async listGiveaways(interaction) {
        const result = await pool.query(
            'SELECT * FROM giveaways WHERE guild_id = $1 AND ended = false ORDER BY end_time ASC',
            [interaction.guild.id]
        );

        if (result.rows.length === 0) {
            return interaction.reply({ content: '📋 No active giveaways found.', ephemeral: true });
        }

        const embed = new EmbedBuilder()
            .setTitle('🎉 Active Giveaways')
            .setDescription(`Found **${result.rows.length}** active giveaway(s)`)
            .setColor('#ff6b6b')
            .setTimestamp();

        result.rows.forEach((giveaway, index) => {
            const channel = interaction.guild.channels.cache.get(giveaway.channel_id);
            const endTime = Math.floor(new Date(giveaway.end_time).getTime() / 1000);
            
            embed.addFields({
                name: `${index + 1}. ${giveaway.prize}`,
                value: `**Channel:** ${channel || 'Unknown'}\n**Winners:** ${giveaway.winners_count}\n**Ends:** <t:${endTime}:R>\n**Participants:** ${giveaway.participants?.length || 0}`,
                inline: true
            });
        });

        await interaction.reply({ embeds: [embed] });
    },

    async showStats(interaction) {
        const totalGiveaways = await pool.query(
            'SELECT COUNT(*) as count FROM giveaways WHERE guild_id = $1',
            [interaction.guild.id]
        );

        const activeGiveaways = await pool.query(
            'SELECT COUNT(*) as count FROM giveaways WHERE guild_id = $1 AND ended = false',
            [interaction.guild.id]
        );

        const completedGiveaways = await pool.query(
            'SELECT COUNT(*) as count FROM giveaways WHERE guild_id = $1 AND ended = true',
            [interaction.guild.id]
        );

        const totalParticipants = await pool.query(
            'SELECT SUM(array_length(participants, 1)) as total FROM giveaways WHERE guild_id = $1',
            [interaction.guild.id]
        );

        const recentGiveaways = await pool.query(
            'SELECT * FROM giveaways WHERE guild_id = $1 ORDER BY created_at DESC LIMIT 5',
            [interaction.guild.id]
        );

        const embed = new EmbedBuilder()
            .setTitle('📊 Giveaway Statistics')
            .setDescription('Server giveaway analytics and data')
            .addFields(
                { name: '🎉 Total Giveaways', value: totalGiveaways.rows[0].count.toString(), inline: true },
                { name: '🟢 Active', value: activeGiveaways.rows[0].count.toString(), inline: true },
                { name: '✅ Completed', value: completedGiveaways.rows[0].count.toString(), inline: true },
                { name: '👥 Total Participants', value: (totalParticipants.rows[0].total || 0).toString(), inline: true },
                { name: '📈 Average Participants', value: totalGiveaways.rows[0].count > 0 ? Math.round((totalParticipants.rows[0].total || 0) / totalGiveaways.rows[0].count).toString() : '0', inline: true },
                { name: '📅 This Month', value: 'Coming soon', inline: true }
            )
            .setColor('#9932cc')
            .setTimestamp();

        if (recentGiveaways.rows.length > 0) {
            const recentList = recentGiveaways.rows.map(g => 
                `• ${g.prize} (${g.ended ? '✅ Ended' : '🟢 Active'})`
            ).join('\n');
            embed.addFields({ name: '🕰️ Recent Giveaways', value: recentList, inline: false });
        }

        await interaction.reply({ embeds: [embed] });
    },

    async endGiveawayById(messageId, client) {
        try {
            const result = await pool.query(
                'SELECT * FROM giveaways WHERE message_id = $1 AND ended = false',
                [messageId]
            );

            if (result.rows.length === 0) return;

            const giveaway = result.rows[0];
            const guild = client.guilds.cache.get(giveaway.guild_id);
            const channel = guild?.channels.cache.get(giveaway.channel_id);
            const message = await channel?.messages.fetch(giveaway.message_id);

            if (!message) return;

            // Mark as ended
            await pool.query(
                'UPDATE giveaways SET ended = true WHERE message_id = $1',
                [messageId]
            );

            const participants = giveaway.participants || [];

            if (participants.length === 0) {
                const noWinnerEmbed = new EmbedBuilder()
                    .setColor('#ff0000')
                    .setTitle('🎉 Giveaway Ended')
                    .setDescription(`**🎁 Prize:** ${giveaway.prize}\n**🏆 Winners:** No valid entries`)
                    .setTimestamp();

                await message.edit({ embeds: [noWinnerEmbed], components: [] });
                return;
            }

            const winnerCount = Math.min(giveaway.winners_count, participants.length);
            const winners = [];
            const availableParticipants = [...participants];

            for (let i = 0; i < winnerCount; i++) {
                const randomIndex = Math.floor(Math.random() * availableParticipants.length);
                winners.push(availableParticipants.splice(randomIndex, 1)[0]);
            }

            // Update winners in database
            await pool.query(
                'UPDATE giveaways SET winners = $1 WHERE message_id = $2',
                [winners, messageId]
            );

            const winnerMentions = winners.map(id => `<@${id}>`).join(', ');

            const winnerEmbed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('🎉 Giveaway Ended')
                .setDescription(`**🎁 Prize:** ${giveaway.prize}\n**🏆 Winners:** ${winnerMentions}`)
                .addFields(
                    { name: '📊 Total Participants', value: participants.length.toString(), inline: true },
                    { name: '🏆 Winners Selected', value: winners.length.toString(), inline: true }
                )
                .setTimestamp();

            await message.edit({ embeds: [winnerEmbed], components: [] });
            await channel.send(`🎉 Congratulations ${winnerMentions}! You won **${giveaway.prize}**!`);

            // Send webhook notification
            if (giveaway.webhook_url) {
                await this.sendWebhookNotification(giveaway.webhook_url, {
                    title: '🎉 Giveaway Ended',
                    description: `**Prize:** ${giveaway.prize}\n**Winners:** ${winnerMentions}\n**Participants:** ${participants.length}`,
                    color: 0x00ff00,
                    timestamp: new Date().toISOString()
                });
            }

        } catch (error) {
            console.error('Error ending giveaway:', error);
        }
    },

    async sendWebhookNotification(webhookUrl, data) {
        try {
            await axios.post(webhookUrl, {
                embeds: [{
                    title: data.title,
                    description: data.description,
                    color: data.color,
                    timestamp: data.timestamp,
                    footer: {
                        text: 'Giveaway System'
                    }
                }]
            });
        } catch (error) {
            console.error('Webhook notification error:', error);
        }
    }
};