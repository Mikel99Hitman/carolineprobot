const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('backup')
        .setDescription('Server backup system')
        .addSubcommand(subcommand =>
            subcommand
                .setName('create')
                .setDescription('Create server backup'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('list')
                .setDescription('List all backups'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('load')
                .setDescription('Load server backup')
                .addStringOption(option =>
                    option.setName('id')
                        .setDescription('Backup ID')
                        .setRequired(true)))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        
        if (subcommand === 'create') {
            await interaction.deferReply();
            
            try {
                const guild = interaction.guild;
                const backupId = Date.now().toString();
                
                const backup = {
                    id: backupId,
                    name: guild.name,
                    icon: guild.iconURL(),
                    createdAt: new Date(),
                    channels: [],
                    roles: [],
                    categories: []
                };

                // Backup categories
                guild.channels.cache.filter(ch => ch.type === 4).forEach(category => {
                    backup.categories.push({
                        name: category.name,
                        position: category.position
                    });
                });

                // Backup channels
                guild.channels.cache.filter(ch => ch.type !== 4).forEach(channel => {
                    backup.channels.push({
                        name: channel.name,
                        type: channel.type,
                        position: channel.position,
                        parent: channel.parent?.name || null,
                        topic: channel.topic || null,
                        nsfw: channel.nsfw || false
                    });
                });

                // Backup roles (exclude @everyone and bot roles)
                guild.roles.cache.filter(role => !role.managed && role.name !== '@everyone').forEach(role => {
                    backup.roles.push({
                        name: role.name,
                        color: role.hexColor,
                        permissions: role.permissions.toArray(),
                        position: role.position,
                        hoist: role.hoist,
                        mentionable: role.mentionable
                    });
                });

                // Save to database
                await pool.query(
                    'INSERT INTO backups (backup_id, guild_id, backup_data, created_at) VALUES ($1, $2, $3, $4)',
                    [backupId, guild.id, JSON.stringify(backup), new Date()]
                );

                const embed = new EmbedBuilder()
                    .setColor('#00ff00')
                    .setTitle('✅ Backup Created Successfully')
                    .setDescription(`Backup ID: \`${backupId}\``)
                    .addFields(
                        { name: 'Server Name', value: guild.name, inline: true },
                        { name: 'Categories', value: backup.categories.length.toString(), inline: true },
                        { name: 'Channels', value: backup.channels.length.toString(), inline: true },
                        { name: 'Roles', value: backup.roles.length.toString(), inline: true },
                        { name: 'Created At', value: new Date().toLocaleString(), inline: true }
                    )
                    .setFooter({ text: 'Use /backup list to see all backups' });

                await interaction.editReply({ embeds: [embed] });
            } catch (error) {
                console.error('Backup creation error:', error);
                await interaction.editReply({ content: '❌ Failed to create backup!', ephemeral: true });
            }

        } else if (subcommand === 'list') {
            try {
                const result = await pool.query(
                    'SELECT backup_id, created_at, backup_data FROM backups WHERE guild_id = $1 ORDER BY created_at DESC LIMIT 10',
                    [interaction.guild.id]
                );

                if (result.rows.length === 0) {
                    return interaction.reply({ content: '❌ No backups found!', ephemeral: true });
                }

                const embed = new EmbedBuilder()
                    .setColor('#0099ff')
                    .setTitle('💾 Server Backups')
                    .setDescription('List of available backups for this server');

                result.rows.forEach((backup, index) => {
                    const backupData = JSON.parse(backup.backup_data);
                    embed.addFields({
                        name: `${index + 1}. Backup ${backup.backup_id}`,
                        value: `Created: ${new Date(backup.created_at).toLocaleString()}\nChannels: ${backupData.channels.length} | Roles: ${backupData.roles.length}`,
                        inline: false
                    });
                });

                await interaction.reply({ embeds: [embed] });
            } catch (error) {
                console.error('Backup list error:', error);
                await interaction.reply({ content: '❌ Failed to fetch backups!', ephemeral: true });
            }

        } else if (subcommand === 'load') {
            await interaction.deferReply();
            
            const backupId = interaction.options.getString('id');
            
            try {
                const result = await pool.query(
                    'SELECT backup_data FROM backups WHERE backup_id = $1 AND guild_id = $2',
                    [backupId, interaction.guild.id]
                );

                if (result.rows.length === 0) {
                    return interaction.editReply({ content: '❌ Backup not found!' });
                }

                const backup = JSON.parse(result.rows[0].backup_data);
                const guild = interaction.guild;

                let restored = { categories: 0, channels: 0, roles: 0 };

                // Restore categories first
                for (const category of backup.categories) {
                    try {
                        if (!guild.channels.cache.find(ch => ch.name === category.name && ch.type === 4)) {
                            await guild.channels.create({
                                name: category.name,
                                type: 4,
                                position: category.position
                            });
                            restored.categories++;
                        }
                    } catch (error) {
                        console.error(`Failed to create category ${category.name}:`, error);
                    }
                }

                // Restore roles
                for (const roleData of backup.roles) {
                    try {
                        if (!guild.roles.cache.find(role => role.name === roleData.name)) {
                            await guild.roles.create({
                                name: roleData.name,
                                color: roleData.color,
                                permissions: roleData.permissions,
                                hoist: roleData.hoist,
                                mentionable: roleData.mentionable
                            });
                            restored.roles++;
                        }
                    } catch (error) {
                        console.error(`Failed to create role ${roleData.name}:`, error);
                    }
                }

                // Restore channels
                for (const channelData of backup.channels) {
                    try {
                        if (!guild.channels.cache.find(ch => ch.name === channelData.name)) {
                            const parent = channelData.parent ? 
                                guild.channels.cache.find(ch => ch.name === channelData.parent && ch.type === 4) : null;
                            
                            await guild.channels.create({
                                name: channelData.name,
                                type: channelData.type,
                                parent: parent?.id,
                                topic: channelData.topic,
                                nsfw: channelData.nsfw
                            });
                            restored.channels++;
                        }
                    } catch (error) {
                        console.error(`Failed to create channel ${channelData.name}:`, error);
                    }
                }

                const embed = new EmbedBuilder()
                    .setColor('#00ff00')
                    .setTitle('✅ Backup Restored Successfully')
                    .setDescription(`Backup \`${backupId}\` has been restored!`)
                    .addFields(
                        { name: 'Categories Restored', value: restored.categories.toString(), inline: true },
                        { name: 'Channels Restored', value: restored.channels.toString(), inline: true },
                        { name: 'Roles Restored', value: restored.roles.toString(), inline: true }
                    )
                    .setFooter({ text: 'Note: Existing items with same names were skipped' });

                await interaction.editReply({ embeds: [embed] });
            } catch (error) {
                console.error('Backup restore error:', error);
                await interaction.editReply({ content: '❌ Failed to restore backup!' });
            }
        }
    }
};