const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('health')
        .setDescription('Server health monitoring dashboard')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        await interaction.deferReply();

        const guild = interaction.guild;
        const botMember = guild.members.cache.get(interaction.client.user.id);

        // System health checks
        const checks = {
            botPermissions: checkBotPermissions(botMember),
            channelHealth: checkChannelHealth(guild),
            roleHealth: checkRoleHealth(guild),
            memberHealth: checkMemberHealth(guild),
            securityHealth: checkSecurityHealth(guild)
        };

        const overallHealth = calculateOverallHealth(checks);
        const healthColor = getHealthColor(overallHealth);

        const embed = new EmbedBuilder()
            .setColor(healthColor)
            .setTitle('🏥 Server Health Monitor')
            .setDescription(`Overall Health Score: **${overallHealth}/100**`)
            .addFields(
                { name: '🤖 Bot Permissions', value: getHealthStatus(checks.botPermissions), inline: true },
                { name: '📝 Channel Health', value: getHealthStatus(checks.channelHealth), inline: true },
                { name: '🎭 Role Health', value: getHealthStatus(checks.roleHealth), inline: true },
                { name: '👥 Member Health', value: getHealthStatus(checks.memberHealth), inline: true },
                { name: '🛡️ Security Health', value: getHealthStatus(checks.securityHealth), inline: true },
                { name: '📊 Performance', value: getPerformanceStatus(), inline: true }
            )
            .addFields({
                name: '💡 Recommendations',
                value: getRecommendations(checks),
                inline: false
            })
            .setFooter({ text: 'Health check completed' })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    }
};

function checkBotPermissions(botMember) {
    const requiredPerms = [
        'SendMessages', 'EmbedLinks', 'AttachFiles', 'ReadMessageHistory',
        'UseExternalEmojis', 'AddReactions', 'ManageMessages', 'ManageRoles'
    ];
    
    const hasPerms = requiredPerms.filter(perm => 
        botMember.permissions.has(perm)
    ).length;
    
    return Math.floor((hasPerms / requiredPerms.length) * 100);
}

function checkChannelHealth(guild) {
    const channels = guild.channels.cache;
    const textChannels = channels.filter(ch => ch.type === 0).size;
    const voiceChannels = channels.filter(ch => ch.type === 2).size;
    
    // Ideal ratio and count
    const totalChannels = textChannels + voiceChannels;
    const memberRatio = totalChannels / guild.memberCount;
    
    if (memberRatio > 0.1) return 60; // Too many channels
    if (memberRatio < 0.01) return 70; // Too few channels
    return 95; // Good ratio
}

function checkRoleHealth(guild) {
    const roles = guild.roles.cache.size;
    const memberRatio = roles / guild.memberCount;
    
    if (memberRatio > 0.5) return 60; // Too many roles
    if (memberRatio < 0.05) return 80; // Could use more roles
    return 90; // Good balance
}

function checkMemberHealth(guild) {
    const members = guild.memberCount;
    const bots = guild.members.cache.filter(m => m.user.bot).size;
    const botRatio = bots / members;
    
    if (botRatio > 0.3) return 50; // Too many bots
    if (botRatio < 0.05) return 85; // Good bot ratio
    return 90; // Healthy member composition
}

function checkSecurityHealth(guild) {
    let score = 100;
    
    // Check verification level
    if (guild.verificationLevel < 2) score -= 20;
    
    // Check explicit content filter
    if (guild.explicitContentFilter === 0) score -= 15;
    
    // Check if server has rules channel
    const hasRules = guild.rulesChannel !== null;
    if (!hasRules) score -= 10;
    
    return Math.max(0, score);
}

function calculateOverallHealth(checks) {
    const values = Object.values(checks);
    return Math.floor(values.reduce((sum, val) => sum + val, 0) / values.length);
}

function getHealthColor(score) {
    if (score >= 90) return '#00ff00';
    if (score >= 70) return '#ffaa00';
    return '#ff0000';
}

function getHealthStatus(score) {
    if (score >= 90) return '✅ Excellent';
    if (score >= 70) return '⚠️ Good';
    if (score >= 50) return '❌ Needs Attention';
    return '🚨 Critical';
}

function getPerformanceStatus() {
    const uptime = process.uptime();
    const memUsage = process.memoryUsage().heapUsed / 1024 / 1024;
    
    if (memUsage < 100 && uptime > 3600) return '✅ Optimal';
    if (memUsage < 200) return '⚠️ Good';
    return '❌ High Usage';
}

function getRecommendations(checks) {
    const recommendations = [];
    
    if (checks.botPermissions < 90) recommendations.push('• Grant missing bot permissions');
    if (checks.securityHealth < 80) recommendations.push('• Improve security settings');
    if (checks.channelHealth < 80) recommendations.push('• Optimize channel structure');
    
    return recommendations.length > 0 ? recommendations.join('\n') : '• Server is healthy!';
}