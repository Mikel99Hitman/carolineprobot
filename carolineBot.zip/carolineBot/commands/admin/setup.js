const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup')
        .setDescription('Setup bot for server')
        .addSubcommand(subcommand =>
            subcommand
                .setName('welcome')
                .setDescription('Setup welcome system')
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('Welcome channel')
                        .setRequired(true)
                        .addChannelTypes(ChannelType.GuildText))
                .addStringOption(option =>
                    option.setName('message')
                        .setDescription('Welcome message (use {user} for member and {server} for server)')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('logs')
                .setDescription('Setup logs system')
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('Logs channel')
                        .setRequired(true)
                        .addChannelTypes(ChannelType.GuildText))
                .addStringOption(option =>
                    option.setName('webhook')
                        .setDescription('Webhook URL for logs')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('levels')
                .setDescription('Setup levels system')
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('Level notifications channel')
                        .setRequired(true)
                        .addChannelTypes(ChannelType.GuildText)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('protection')
                .setDescription('Setup protection system')
                .addBooleanOption(option =>
                    option.setName('antispam')
                        .setDescription('Enable anti-spam')
                        .setRequired(true))
                .addBooleanOption(option =>
                    option.setName('antilink')
                        .setDescription('Enable anti-link')
                        .setRequired(true)))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        
        try {
            // Ensure guild exists in database
            await pool.query(`
                INSERT INTO guilds (guild_id) VALUES ($1) 
                ON CONFLICT (guild_id) DO NOTHING
            `, [interaction.guild.id]);

            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('⚙️ Setup completed successfully!')
                .setTimestamp();

            switch (subcommand) {
                case 'welcome':
                    const welcomeChannel = interaction.options.getChannel('channel');
                    const welcomeMessage = interaction.options.getString('message') || 'Welcome {user} to {server}!';
                    
                    await pool.query(`
                        UPDATE guilds 
                        SET welcome_channel = $1, welcome_message = $2 
                        WHERE guild_id = $3
                    `, [welcomeChannel.id, welcomeMessage, interaction.guild.id]);
                    
                    embed.setDescription(`✅ Welcome system setup in ${welcomeChannel}\n📝 Message: ${welcomeMessage}`);
                    break;

                case 'logs':
                    const logChannel = interaction.options.getChannel('channel');
                    const webhookUrl = interaction.options.getString('webhook');
                    
                    await pool.query(`
                        UPDATE guilds 
                        SET log_channel = $1, webhook_url = $2 
                        WHERE guild_id = $3
                    `, [logChannel.id, webhookUrl, interaction.guild.id]);
                    
                    let logDesc = `✅ Logs system setup in ${logChannel}`;
                    if (webhookUrl) logDesc += `\n🔗 Webhook configured`;
                    embed.setDescription(logDesc);
                    break;

                case 'levels':
                    const levelChannel = interaction.options.getChannel('channel');
                    
                    await pool.query(`
                        UPDATE guilds 
                        SET level_up_channel = $1 
                        WHERE guild_id = $2
                    `, [levelChannel.id, interaction.guild.id]);
                    
                    embed.setDescription(`✅ Levels system setup in ${levelChannel}`);
                    break;

                case 'protection':
                    const antiSpam = interaction.options.getBoolean('antispam');
                    const antiLink = interaction.options.getBoolean('antilink');
                    
                    await pool.query(`
                        UPDATE guilds 
                        SET anti_spam = $1, anti_link = $2 
                        WHERE guild_id = $3
                    `, [antiSpam, antiLink, interaction.guild.id]);
                    
                    embed.setDescription(`✅ Protection system setup:\n🛡️ Anti-spam: ${antiSpam ? 'Enabled' : 'Disabled'}\n🔗 Anti-link: ${antiLink ? 'Enabled' : 'Disabled'}`);
                    break;
            }

            await interaction.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Setup command error:', error);
            await interaction.reply({ 
                content: '❌ An error occurred while setting up the bot.', 
                ephemeral: true 
            });
        }
    }
};