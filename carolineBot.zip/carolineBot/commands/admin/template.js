const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');

const serverTemplates = {
    gaming: {
        name: 'Gaming Server',
        channels: [
            { name: '📋-rules', type: 'text' },
            { name: '📢-announcements', type: 'text' },
            { name: '💬-general', type: 'text' },
            { name: '🎮-gaming', type: 'text' },
            { name: '🎯-looking-for-group', type: 'text' },
            { name: '🔊-General Voice', type: 'voice' },
            { name: '🎮-Gaming Voice', type: 'voice' }
        ],
        roles: [
            { name: 'Gamer', color: '#ff6b6b' },
            { name: 'Streamer', color: '#9b59b6' },
            { name: 'Moderator', color: '#3498db' }
        ]
    },
    community: {
        name: 'Community Server',
        channels: [
            { name: '👋-welcome', type: 'text' },
            { name: '📜-rules', type: 'text' },
            { name: '📢-announcements', type: 'text' },
            { name: '💬-general-chat', type: 'text' },
            { name: '🤝-introductions', type: 'text' },
            { name: '💡-suggestions', type: 'text' },
            { name: '🎉-events', type: 'text' },
            { name: '🔊-General Voice', type: 'voice' },
            { name: '🎵-Music Voice', type: 'voice' }
        ],
        roles: [
            { name: 'Member', color: '#2ecc71' },
            { name: 'Active', color: '#f39c12' },
            { name: 'Helper', color: '#e74c3c' },
            { name: 'Moderator', color: '#9b59b6' }
        ]
    },
    business: {
        name: 'Business Server',
        channels: [
            { name: '📋-guidelines', type: 'text' },
            { name: '📢-announcements', type: 'text' },
            { name: '💼-general', type: 'text' },
            { name: '📊-reports', type: 'text' },
            { name: '💡-ideas', type: 'text' },
            { name: '🤝-partnerships', type: 'text' },
            { name: '🔊-Meeting Room 1', type: 'voice' },
            { name: '🔊-Meeting Room 2', type: 'voice' }
        ],
        roles: [
            { name: 'Employee', color: '#3498db' },
            { name: 'Manager', color: '#e67e22' },
            { name: 'Executive', color: '#8e44ad' }
        ]
    }
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('template')
        .setDescription('Server template system')
        .addSubcommand(subcommand =>
            subcommand
                .setName('apply')
                .setDescription('Apply server template')
                .addStringOption(option =>
                    option.setName('type')
                        .setDescription('Template type')
                        .addChoices(
                            { name: '🎮 Gaming Server', value: 'gaming' },
                            { name: '🤝 Community Server', value: 'community' },
                            { name: '💼 Business Server', value: 'business' }
                        )
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('preview')
                .setDescription('Preview template')
                .addStringOption(option =>
                    option.setName('type')
                        .setDescription('Template type')
                        .addChoices(
                            { name: '🎮 Gaming Server', value: 'gaming' },
                            { name: '🤝 Community Server', value: 'community' },
                            { name: '💼 Business Server', value: 'business' }
                        )
                        .setRequired(true)))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        const templateType = interaction.options.getString('type');
        const template = serverTemplates[templateType];

        if (subcommand === 'preview') {
            const embed = new EmbedBuilder()
                .setColor('#0099ff')
                .setTitle(`📋 ${template.name} Template Preview`)
                .addFields(
                    {
                        name: '📝 Channels',
                        value: template.channels.map(ch => `${ch.name} (${ch.type})`).join('\n'),
                        inline: true
                    },
                    {
                        name: '🎭 Roles',
                        value: template.roles.map(role => `${role.name} (${role.color})`).join('\n'),
                        inline: true
                    }
                )
                .setFooter({ text: 'Use /template apply to create these channels and roles' })
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

        } else if (subcommand === 'apply') {
            await interaction.deferReply();

            try {
                let createdChannels = 0;
                let createdRoles = 0;

                // Create roles
                for (const roleData of template.roles) {
                    try {
                        await interaction.guild.roles.create({
                            name: roleData.name,
                            color: roleData.color,
                            reason: `Template: ${template.name}`
                        });
                        createdRoles++;
                    } catch (error) {
                        console.error(`Failed to create role ${roleData.name}:`, error);
                    }
                }

                // Create channels
                for (const channelData of template.channels) {
                    try {
                        await interaction.guild.channels.create({
                            name: channelData.name,
                            type: channelData.type === 'voice' ? ChannelType.GuildVoice : ChannelType.GuildText,
                            reason: `Template: ${template.name}`
                        });
                        createdChannels++;
                    } catch (error) {
                        console.error(`Failed to create channel ${channelData.name}:`, error);
                    }
                }

                const embed = new EmbedBuilder()
                    .setColor('#00ff00')
                    .setTitle('✅ Template Applied Successfully')
                    .setDescription(`Applied **${template.name}** template to your server!`)
                    .addFields(
                        { name: '📝 Channels Created', value: `${createdChannels}/${template.channels.length}`, inline: true },
                        { name: '🎭 Roles Created', value: `${createdRoles}/${template.roles.length}`, inline: true }
                    )
                    .setFooter({ text: 'You can customize these channels and roles as needed' })
                    .setTimestamp();

                await interaction.editReply({ embeds: [embed] });

            } catch (error) {
                console.error('Template application error:', error);
                
                const errorEmbed = new EmbedBuilder()
                    .setColor('#ff0000')
                    .setTitle('❌ Template Application Failed')
                    .setDescription('An error occurred while applying the template. Please check bot permissions.')
                    .setTimestamp();

                await interaction.editReply({ embeds: [errorEmbed] });
            }
        }
    }
};