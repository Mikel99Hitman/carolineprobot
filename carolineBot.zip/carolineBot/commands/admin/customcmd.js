const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('customcmd')
        .setDescription('Manage custom commands')
        .addSubcommand(subcommand =>
            subcommand
                .setName('create')
                .setDescription('Create custom command')
                .addStringOption(option =>
                    option.setName('name')
                        .setDescription('Command name')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('response')
                        .setDescription('Command response')
                        .setRequired(true))
                .addBooleanOption(option =>
                    option.setName('embed')
                        .setDescription('Send as embed')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('delete')
                .setDescription('Delete custom command')
                .addStringOption(option =>
                    option.setName('name')
                        .setDescription('Command name')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('list')
                .setDescription('List custom commands'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('edit')
                .setDescription('Edit custom command')
                .addStringOption(option =>
                    option.setName('name')
                        .setDescription('Command name')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('response')
                        .setDescription('New response')
                        .setRequired(true)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'create') {
            const name = interaction.options.getString('name').toLowerCase();
            const response = interaction.options.getString('response');
            const embed = interaction.options.getBoolean('embed') || false;

            if (name.length > 32) {
                return interaction.reply({ content: '❌ Command name too long! (max 32 characters)', ephemeral: true });
            }

            try {
                const existing = await pool.query(
                    'SELECT name FROM custom_commands WHERE guild_id = $1 AND name = $2',
                    [interaction.guild.id, name]
                );

                if (existing.rows.length > 0) {
                    return interaction.reply({ content: '❌ Command already exists!', ephemeral: true });
                }

                await pool.query(
                    'INSERT INTO custom_commands (guild_id, name, response, author_id, is_embed, created_at) VALUES ($1, $2, $3, $4, $5, $6)',
                    [interaction.guild.id, name, response, interaction.user.id, embed, new Date()]
                );

                const successEmbed = new EmbedBuilder()
                    .setColor('#00ff00')
                    .setTitle('✅ Custom Command Created')
                    .setDescription(`Command \`${name}\` has been created!`)
                    .addFields(
                        { name: 'Response', value: response.substring(0, 1000), inline: false },
                        { name: 'Embed', value: embed ? 'Yes' : 'No', inline: true },
                        { name: 'Author', value: `<@${interaction.user.id}>`, inline: true }
                    )
                    .setTimestamp();

                await interaction.reply({ embeds: [successEmbed] });
            } catch (error) {
                console.error('Custom command create error:', error);
                await interaction.reply({ content: '❌ Failed to create command!', ephemeral: true });
            }

        } else if (subcommand === 'delete') {
            const name = interaction.options.getString('name').toLowerCase();

            try {
                const result = await pool.query(
                    'DELETE FROM custom_commands WHERE guild_id = $1 AND name = $2',
                    [interaction.guild.id, name]
                );

                if (result.rowCount === 0) {
                    return interaction.reply({ content: '❌ Command not found!', ephemeral: true });
                }

                const embed = new EmbedBuilder()
                    .setColor('#ff0000')
                    .setTitle('🗑️ Custom Command Deleted')
                    .setDescription(`Command \`${name}\` has been deleted!`)
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });
            } catch (error) {
                console.error('Custom command delete error:', error);
                await interaction.reply({ content: '❌ Failed to delete command!', ephemeral: true });
            }

        } else if (subcommand === 'edit') {
            const name = interaction.options.getString('name').toLowerCase();
            const newResponse = interaction.options.getString('response');

            try {
                const result = await pool.query(
                    'UPDATE custom_commands SET response = $1, updated_at = $2 WHERE guild_id = $3 AND name = $4',
                    [newResponse, new Date(), interaction.guild.id, name]
                );

                if (result.rowCount === 0) {
                    return interaction.reply({ content: '❌ Command not found!', ephemeral: true });
                }

                const embed = new EmbedBuilder()
                    .setColor('#00ff00')
                    .setTitle('✅ Custom Command Updated')
                    .setDescription(`Command \`${name}\` has been updated!`)
                    .addFields({ name: 'New Response', value: newResponse.substring(0, 1000), inline: false })
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });
            } catch (error) {
                console.error('Custom command edit error:', error);
                await interaction.reply({ content: '❌ Failed to edit command!', ephemeral: true });
            }

        } else if (subcommand === 'list') {
            try {
                const result = await pool.query(
                    'SELECT name, response, uses, is_embed, author_id FROM custom_commands WHERE guild_id = $1 ORDER BY uses DESC LIMIT 20',
                    [interaction.guild.id]
                );

                if (result.rows.length === 0) {
                    return interaction.reply({ content: '❌ No custom commands found!', ephemeral: true });
                }

                const embed = new EmbedBuilder()
                    .setColor('#0099ff')
                    .setTitle('🛠️ Custom Commands')
                    .setDescription(`Total: ${result.rows.length} commands`)
                    .setTimestamp();

                result.rows.forEach((cmd, index) => {
                    embed.addFields({
                        name: `${index + 1}. \`${cmd.name}\``,
                        value: `Uses: ${cmd.uses} | Embed: ${cmd.is_embed ? 'Yes' : 'No'}\nResponse: ${cmd.response.substring(0, 100)}${cmd.response.length > 100 ? '...' : ''}`,
                        inline: false
                    });
                });

                await interaction.reply({ embeds: [embed] });
            } catch (error) {
                console.error('Custom command list error:', error);
                await interaction.reply({ content: '❌ Failed to fetch commands!', ephemeral: true });
            }
        }
    }
};