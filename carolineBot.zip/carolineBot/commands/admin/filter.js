const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { Pool } = require('pg');

const pool = new Pool({
    connectionString: process.env.DATABASE_URL
});

module.exports = {
    data: new SlashCommandBuilder()
        .setName('filter')
        .setDescription('🚫 Advanced word filter and content moderation system')
        .addSubcommand(subcommand =>
            subcommand
                .setName('add')
                .setDescription('Add word to filter')
                .addStringOption(option =>
                    option.setName('word')
                        .setDescription('Word or phrase to filter')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('severity')
                        .setDescription('Filter severity level')
                        .addChoices(
                            { name: 'Low - Warning only', value: 'low' },
                            { name: 'Medium - Delete message', value: 'medium' },
                            { name: 'High - Delete + timeout', value: 'high' },
                            { name: 'Critical - Delete + ban', value: 'critical' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('remove')
                .setDescription('Remove word from filter')
                .addStringOption(option =>
                    option.setName('word')
                        .setDescription('Word to remove from filter')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('list')
                .setDescription('View all filtered words')
                .addStringOption(option =>
                    option.setName('severity')
                        .setDescription('Filter by severity level')
                        .addChoices(
                            { name: 'All levels', value: 'all' },
                            { name: 'Low', value: 'low' },
                            { name: 'Medium', value: 'medium' },
                            { name: 'High', value: 'high' },
                            { name: 'Critical', value: 'critical' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('settings')
                .setDescription('Configure filter settings')
                .addBooleanOption(option =>
                    option.setName('enabled')
                        .setDescription('Enable/disable word filter')
                        .setRequired(false))
                .addBooleanOption(option =>
                    option.setName('log_violations')
                        .setDescription('Log filter violations')
                        .setRequired(false))
                .addBooleanOption(option =>
                    option.setName('auto_moderate')
                        .setDescription('Enable automatic moderation')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('stats')
                .setDescription('View filter statistics and violations'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('whitelist')
                .setDescription('Manage filter whitelist')
                .addStringOption(option =>
                    option.setName('action')
                        .setDescription('Whitelist action')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Add user', value: 'add_user' },
                            { name: 'Remove user', value: 'remove_user' },
                            { name: 'Add role', value: 'add_role' },
                            { name: 'Remove role', value: 'remove_role' },
                            { name: 'List all', value: 'list' }
                        ))
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('User to whitelist')
                        .setRequired(false))
                .addRoleOption(option =>
                    option.setName('role')
                        .setDescription('Role to whitelist')
                        .setRequired(false)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        
        try {
            await this.createTables();
            
            switch (subcommand) {
                case 'add':
                    await this.addWord(interaction);
                    break;
                case 'remove':
                    await this.removeWord(interaction);
                    break;
                case 'list':
                    await this.listWords(interaction);
                    break;
                case 'settings':
                    await this.configureSettings(interaction);
                    break;
                case 'stats':
                    await this.showStats(interaction);
                    break;
                case 'whitelist':
                    await this.manageWhitelist(interaction);
                    break;
            }
        } catch (error) {
            console.error('Filter command error:', error);
            await interaction.reply({ content: '❌ An error occurred while processing the filter command.', ephemeral: true });
        }
    },

    async createTables() {
        await pool.query(`
            CREATE TABLE IF NOT EXISTS word_filter (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                word TEXT NOT NULL,
                severity VARCHAR(20) DEFAULT 'medium',
                added_by VARCHAR(20) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS filter_settings (
                guild_id VARCHAR(20) PRIMARY KEY,
                enabled BOOLEAN DEFAULT true,
                log_violations BOOLEAN DEFAULT true,
                auto_moderate BOOLEAN DEFAULT true,
                log_channel_id VARCHAR(20),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS filter_violations (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                user_id VARCHAR(20) NOT NULL,
                channel_id VARCHAR(20) NOT NULL,
                word TEXT NOT NULL,
                severity VARCHAR(20) NOT NULL,
                action_taken VARCHAR(50) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);

        await pool.query(`
            CREATE TABLE IF NOT EXISTS filter_whitelist (
                id SERIAL PRIMARY KEY,
                guild_id VARCHAR(20) NOT NULL,
                target_id VARCHAR(20) NOT NULL,
                target_type VARCHAR(10) NOT NULL,
                added_by VARCHAR(20) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
    },

    async addWord(interaction) {
        const word = interaction.options.getString('word').toLowerCase().trim();
        const severity = interaction.options.getString('severity') || 'medium';

        // Check if word already exists
        const existing = await pool.query(
            'SELECT * FROM word_filter WHERE guild_id = $1 AND word = $2',
            [interaction.guild.id, word]
        );

        if (existing.rows.length > 0) {
            return interaction.reply({ 
                content: `❌ The word "${word}" is already in the filter list!`, 
                ephemeral: true 
            });
        }

        // Add word to filter
        await pool.query(
            'INSERT INTO word_filter (guild_id, word, severity, added_by) VALUES ($1, $2, $3, $4)',
            [interaction.guild.id, word, severity, interaction.user.id]
        );

        const severityEmojis = {
            low: '🟡',
            medium: '🟠', 
            high: '🔴',
            critical: '⚫'
        };

        const embed = new EmbedBuilder()
            .setTitle('✅ Word Added to Filter')
            .setDescription(`Successfully added "**${word}**" to the filter list`)
            .addFields(
                { name: '📈 Severity Level', value: `${severityEmojis[severity]} ${severity.toUpperCase()}`, inline: true },
                { name: '👥 Added by', value: interaction.user.toString(), inline: true },
                { name: '⚙️ Action', value: this.getSeverityAction(severity), inline: false }
            )
            .setColor('#00ff00')
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    },

    async removeWord(interaction) {
        const word = interaction.options.getString('word').toLowerCase().trim();

        const result = await pool.query(
            'DELETE FROM word_filter WHERE guild_id = $1 AND word = $2 RETURNING *',
            [interaction.guild.id, word]
        );

        if (result.rows.length === 0) {
            return interaction.reply({ 
                content: `❌ The word "${word}" is not in the filter list!`, 
                ephemeral: true 
            });
        }

        const embed = new EmbedBuilder()
            .setTitle('✅ Word Removed from Filter')
            .setDescription(`Successfully removed "**${word}**" from the filter list`)
            .addFields(
                { name: '👥 Removed by', value: interaction.user.toString(), inline: true }
            )
            .setColor('#ff9900')
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    },

    async listWords(interaction) {
        const severityFilter = interaction.options.getString('severity') || 'all';
        
        let query = 'SELECT * FROM word_filter WHERE guild_id = $1';
        let params = [interaction.guild.id];
        
        if (severityFilter !== 'all') {
            query += ' AND severity = $2';
            params.push(severityFilter);
        }
        
        query += ' ORDER BY severity DESC, word ASC';
        
        const result = await pool.query(query, params);
        
        if (result.rows.length === 0) {
            return interaction.reply({ 
                content: '📋 No filtered words found for the specified criteria.', 
                ephemeral: true 
            });
        }

        const severityEmojis = {
            low: '🟡',
            medium: '🟠',
            high: '🔴',
            critical: '⚫'
        };

        const groupedWords = {};
        result.rows.forEach(row => {
            if (!groupedWords[row.severity]) {
                groupedWords[row.severity] = [];
            }
            groupedWords[row.severity].push(row.word);
        });

        const embed = new EmbedBuilder()
            .setTitle('🚫 Filtered Words List')
            .setDescription(`Total filtered words: **${result.rows.length}**`)
            .setColor('#dc143c')
            .setTimestamp();

        Object.keys(groupedWords).forEach(severity => {
            const words = groupedWords[severity];
            const wordList = words.map(w => `\`${w}\``).join(', ');
            embed.addFields({
                name: `${severityEmojis[severity]} ${severity.toUpperCase()} (${words.length})`,
                value: wordList.length > 1024 ? wordList.substring(0, 1021) + '...' : wordList,
                inline: false
            });
        });

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('filter_export')
                    .setLabel('📄 Export List')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('filter_clear_all')
                    .setLabel('🗑️ Clear All')
                    .setStyle(ButtonStyle.Danger)
            );

        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
    },

    async configureSettings(interaction) {
        const enabled = interaction.options.getBoolean('enabled');
        const logViolations = interaction.options.getBoolean('log_violations');
        const autoModerate = interaction.options.getBoolean('auto_moderate');

        // Get current settings
        let result = await pool.query(
            'SELECT * FROM filter_settings WHERE guild_id = $1',
            [interaction.guild.id]
        );

        if (result.rows.length === 0) {
            // Create default settings
            await pool.query(
                'INSERT INTO filter_settings (guild_id) VALUES ($1)',
                [interaction.guild.id]
            );
            
            result = await pool.query(
                'SELECT * FROM filter_settings WHERE guild_id = $1',
                [interaction.guild.id]
            );
        }

        const currentSettings = result.rows[0];
        
        // Update settings if provided
        const updates = [];
        const values = [];
        let paramCount = 1;

        if (enabled !== null) {
            updates.push(`enabled = $${++paramCount}`);
            values.push(enabled);
        }
        if (logViolations !== null) {
            updates.push(`log_violations = $${++paramCount}`);
            values.push(logViolations);
        }
        if (autoModerate !== null) {
            updates.push(`auto_moderate = $${++paramCount}`);
            values.push(autoModerate);
        }

        if (updates.length > 0) {
            values.unshift(interaction.guild.id);
            await pool.query(
                `UPDATE filter_settings SET ${updates.join(', ')} WHERE guild_id = $1`,
                values
            );
            
            // Get updated settings
            result = await pool.query(
                'SELECT * FROM filter_settings WHERE guild_id = $1',
                [interaction.guild.id]
            );
        }

        const settings = result.rows[0];
        
        const embed = new EmbedBuilder()
            .setTitle('⚙️ Filter Settings')
            .setDescription('Current word filter configuration')
            .addFields(
                { name: '🔄 Filter Status', value: settings.enabled ? '✅ Enabled' : '❌ Disabled', inline: true },
                { name: '📄 Log Violations', value: settings.log_violations ? '✅ Enabled' : '❌ Disabled', inline: true },
                { name: '🤖 Auto Moderation', value: settings.auto_moderate ? '✅ Enabled' : '❌ Disabled', inline: true },
                { name: '📈 Log Channel', value: settings.log_channel_id ? `<#${settings.log_channel_id}>` : 'Not set', inline: true }
            )
            .setColor('#0099ff')
            .setTimestamp();

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('filter_toggle')
                    .setLabel(settings.enabled ? 'Disable Filter' : 'Enable Filter')
                    .setStyle(settings.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('filter_set_log_channel')
                    .setLabel('📄 Set Log Channel')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.reply({ embeds: [embed], components: [row] });
    },

    async showStats(interaction) {
        // Get filter statistics
        const wordCount = await pool.query(
            'SELECT COUNT(*) as count, severity FROM word_filter WHERE guild_id = $1 GROUP BY severity',
            [interaction.guild.id]
        );

        const violationStats = await pool.query(
            'SELECT COUNT(*) as count, severity, action_taken FROM filter_violations WHERE guild_id = $1 GROUP BY severity, action_taken',
            [interaction.guild.id]
        );

        const recentViolations = await pool.query(
            'SELECT * FROM filter_violations WHERE guild_id = $1 ORDER BY created_at DESC LIMIT 5',
            [interaction.guild.id]
        );

        const totalWords = wordCount.rows.reduce((sum, row) => sum + parseInt(row.count), 0);
        const totalViolations = violationStats.rows.reduce((sum, row) => sum + parseInt(row.count), 0);

        const embed = new EmbedBuilder()
            .setTitle('📈 Filter Statistics')
            .setDescription('Word filter usage and violation statistics')
            .addFields(
                { name: '📝 Total Filtered Words', value: totalWords.toString(), inline: true },
                { name: '⚠️ Total Violations', value: totalViolations.toString(), inline: true },
                { name: '📅 Period', value: 'All time', inline: true }
            )
            .setColor('#9932cc')
            .setTimestamp();

        // Add word breakdown by severity
        if (wordCount.rows.length > 0) {
            const severityBreakdown = wordCount.rows.map(row => 
                `${row.severity.toUpperCase()}: ${row.count}`
            ).join('\n');
            embed.addFields({ name: '📈 Words by Severity', value: severityBreakdown, inline: true });
        }

        // Add recent violations
        if (recentViolations.rows.length > 0) {
            const recentList = recentViolations.rows.map(v => 
                `<@${v.user_id}> - \`${v.word}\` (${v.severity})`
            ).join('\n');
            embed.addFields({ name: '🕰️ Recent Violations', value: recentList, inline: false });
        }

        await interaction.reply({ embeds: [embed] });
    },

    async manageWhitelist(interaction) {
        const action = interaction.options.getString('action');
        const user = interaction.options.getUser('user');
        const role = interaction.options.getRole('role');

        if (action === 'list') {
            const whitelist = await pool.query(
                'SELECT * FROM filter_whitelist WHERE guild_id = $1 ORDER BY target_type, created_at DESC',
                [interaction.guild.id]
            );

            if (whitelist.rows.length === 0) {
                return interaction.reply({ content: '📋 No whitelist entries found.', ephemeral: true });
            }

            const users = whitelist.rows.filter(w => w.target_type === 'user');
            const roles = whitelist.rows.filter(w => w.target_type === 'role');

            const embed = new EmbedBuilder()
                .setTitle('📋 Filter Whitelist')
                .setDescription('Users and roles exempt from word filter')
                .setColor('#00ff00')
                .setTimestamp();

            if (users.length > 0) {
                embed.addFields({
                    name: '👥 Whitelisted Users',
                    value: users.map(u => `<@${u.target_id}>`).join('\n'),
                    inline: true
                });
            }

            if (roles.length > 0) {
                embed.addFields({
                    name: '🏅 Whitelisted Roles',
                    value: roles.map(r => `<@&${r.target_id}>`).join('\n'),
                    inline: true
                });
            }

            return interaction.reply({ embeds: [embed] });
        }

        // Handle add/remove actions
        const targetId = user?.id || role?.id;
        const targetType = user ? 'user' : 'role';
        const targetMention = user ? user.toString() : role?.toString();

        if (!targetId) {
            return interaction.reply({ content: '❌ Please specify a user or role.', ephemeral: true });
        }

        if (action.startsWith('add')) {
            // Check if already whitelisted
            const existing = await pool.query(
                'SELECT * FROM filter_whitelist WHERE guild_id = $1 AND target_id = $2',
                [interaction.guild.id, targetId]
            );

            if (existing.rows.length > 0) {
                return interaction.reply({ 
                    content: `❌ ${targetMention} is already whitelisted!`, 
                    ephemeral: true 
                });
            }

            await pool.query(
                'INSERT INTO filter_whitelist (guild_id, target_id, target_type, added_by) VALUES ($1, $2, $3, $4)',
                [interaction.guild.id, targetId, targetType, interaction.user.id]
            );

            const embed = new EmbedBuilder()
                .setTitle('✅ Added to Whitelist')
                .setDescription(`${targetMention} has been added to the filter whitelist`)
                .setColor('#00ff00')
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

        } else if (action.startsWith('remove')) {
            const result = await pool.query(
                'DELETE FROM filter_whitelist WHERE guild_id = $1 AND target_id = $2 RETURNING *',
                [interaction.guild.id, targetId]
            );

            if (result.rows.length === 0) {
                return interaction.reply({ 
                    content: `❌ ${targetMention} is not whitelisted!`, 
                    ephemeral: true 
                });
            }

            const embed = new EmbedBuilder()
                .setTitle('✅ Removed from Whitelist')
                .setDescription(`${targetMention} has been removed from the filter whitelist`)
                .setColor('#ff9900')
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        }
    },

    getSeverityAction(severity) {
        const actions = {
            low: '⚠️ Warning message only',
            medium: '🗑️ Delete message',
            high: '🗑️ Delete message + 5min timeout',
            critical: '🗑️ Delete message + ban user'
        };
        return actions[severity] || actions.medium;
    }
};