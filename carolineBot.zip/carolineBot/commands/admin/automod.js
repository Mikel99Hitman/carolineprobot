const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const Guild = require('../../models/Guild');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('automod')
        .setDescription('Configure auto moderation settings')
        .addSubcommand(subcommand =>
            subcommand
                .setName('setup')
                .setDescription('Setup auto moderation')
                .addBooleanOption(option =>
                    option.setName('anti_spam')
                        .setDescription('Enable anti-spam protection')
                        .setRequired(true))
                .addBooleanOption(option =>
                    option.setName('anti_link')
                        .setDescription('Enable anti-link protection')
                        .setRequired(true))
                .addBooleanOption(option =>
                    option.setName('anti_caps')
                        .setDescription('Enable anti-caps protection')
                        .setRequired(false))
                .addBooleanOption(option =>
                    option.setName('anti_mention')
                        .setDescription('Enable anti-mention spam protection')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('whitelist')
                .setDescription('Add channel to automod whitelist')
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('Channel to whitelist')
                        .setRequired(true)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        let guildData = await Guild.findOne({ guildId: interaction.guild.id });
        
        if (!guildData) {
            guildData = new Guild({ guildId: interaction.guild.id });
        }

        if (subcommand === 'setup') {
            const antiSpam = interaction.options.getBoolean('anti_spam');
            const antiLink = interaction.options.getBoolean('anti_link');
            const antiCaps = interaction.options.getBoolean('anti_caps') || false;
            const antiMention = interaction.options.getBoolean('anti_mention') || false;

            guildData.antiSpam = antiSpam;
            guildData.antiLink = antiLink;
            guildData.antiCaps = antiCaps;
            guildData.antiMention = antiMention;

            await guildData.save();

            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('🛡️ Auto Moderation Configured')
                .addFields(
                    { name: '🚫 Anti-Spam', value: antiSpam ? '✅ Enabled' : '❌ Disabled', inline: true },
                    { name: '🔗 Anti-Link', value: antiLink ? '✅ Enabled' : '❌ Disabled', inline: true },
                    { name: '🔠 Anti-Caps', value: antiCaps ? '✅ Enabled' : '❌ Disabled', inline: true },
                    { name: '📢 Anti-Mention', value: antiMention ? '✅ Enabled' : '❌ Disabled', inline: true }
                )
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        }
    }
};