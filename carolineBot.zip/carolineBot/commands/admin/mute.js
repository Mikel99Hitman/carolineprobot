const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const User = require('../../models/User');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mute')
        .setDescription('Mute a member')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to mute')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('duration')
                .setDescription('Mute duration (e.g., 10m, 1h, 1d)')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for mute')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

    async execute(interaction) {
        const target = interaction.options.getUser('user');
        const duration = interaction.options.getString('duration');
        const reason = interaction.options.getString('reason') || 'No reason provided';
        
        const member = interaction.guild.members.cache.get(target.id);
        if (!member) {
            return interaction.reply({ content: '❌ Member not found!', ephemeral: true });
        }

        const ms = require('ms');
        const time = ms(duration);
        if (!time) {
            return interaction.reply({ content: '❌ Invalid duration!', ephemeral: true });
        }

        await member.timeout(time, reason);

        const embed = new EmbedBuilder()
            .setColor('#ff9900')
            .setTitle('🔇 Member Muted')
            .addFields(
                { name: 'User', value: target.toString(), inline: true },
                { name: 'Duration', value: duration, inline: true },
                { name: 'Reason', value: reason, inline: false },
                { name: 'Moderator', value: interaction.user.toString(), inline: true }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    }
};