require('dotenv').config();
const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');

const commands = [];
const commandsPath = path.join(__dirname, 'commands');

// Load all commands recursively
function loadCommands(dir) {
    const files = fs.readdirSync(dir);
    
    for (const file of files) {
        const filePath = path.join(dir, file);
        const stat = fs.statSync(filePath);
        
        if (stat.isDirectory()) {
            loadCommands(filePath);
        } else if (file.endsWith('.js')) {
            try {
                const command = require(filePath);
                if ('data' in command && 'execute' in command) {
                    commands.push(command.data.toJSON());
                    console.log(`✅ Loaded command: ${command.data.name}`);
                } else {
                    console.log(`⚠️  Skipped ${file}: Missing data or execute property`);
                }
            } catch (error) {
                console.error(`❌ Error loading ${file}:`, error.message);
            }
        }
    }
}

console.log('🔄 Loading commands...');
loadCommands(commandsPath);

if (!process.env.BOT_TOKEN || !process.env.CLIENT_ID) {
    console.error('❌ Missing BOT_TOKEN or CLIENT_ID in .env file!');
    process.exit(1);
}

const rest = new REST().setToken(process.env.BOT_TOKEN);

(async () => {
    try {
        console.log(`🔄 Started refreshing ${commands.length} application (/) commands.`);

        // Register commands globally
        const data = await rest.put(
            Routes.applicationCommands(process.env.CLIENT_ID),
            { body: commands },
        );

        console.log(`✅ Successfully reloaded ${data.length} application (/) commands.`);
        console.log('🎉 Commands deployed successfully!');
        
        // List deployed commands
        console.log('\n📋 Deployed commands:');
        data.forEach(cmd => {
            console.log(`   • /${cmd.name} - ${cmd.description}`);
        });
        
    } catch (error) {
        console.error('❌ Error registering commands:', error);
        
        if (error.code === 50001) {
            console.error('💡 Make sure your bot has the applications.commands scope!');
        } else if (error.code === 401) {
            console.error('💡 Invalid bot token! Check your .env file.');
        }
    }
})();