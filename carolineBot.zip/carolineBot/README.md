# Caroline Bot - Professional Discord Bot v3.0

A comprehensive Discord bot with advanced features for server management, entertainment, and community engagement.

## 🌟 Features

### 🎯 Core Systems
- **Advanced Leveling & XP System** - Track member activity with PostgreSQL
- **Welcome System** - Automatic welcome with custom images and messages
- **Comprehensive Logging** - Log all server events with webhook support
- **Protection System** - Anti-spam, anti-link, anti-caps, anti-mention
- **Music System** - Play music from multiple sources (YouTube, Spotify)
- **Ticket System** - Create support tickets with categories
- **Application System** - Staff application forms with approval workflow
- **Invite Tracking** - Track member invites and rewards
- **Economy System** - Virtual currency with work, daily rewards, gambling
- **Reaction Roles** - Assign roles via reactions with custom setup
- **Giveaway System** - Host giveaways with advanced requirements
- **Auto Moderation** - Advanced auto-moderation with customizable rules

### 🆕 New Features (v3.0)
- **Scientific Calculator** - Advanced calculator with scientific functions
- **Confession System** - Anonymous confessions with moderation
- **Counting Game** - Interactive counting game with statistics
- **Advanced Gambling** - Multiple gambling games (slots, blackjack, roulette)
- **Content Filter** - Advanced content filtering with severity levels
- **FiveM Integration** - Roleplay system for FiveM servers
- **Interactive Help** - Comprehensive help system with categories
- **Image Processing** - Advanced image manipulation and effects
- **Enhanced Music Player** - Multi-source support with queue management
- **Islamic System** - Complete Islamic features package
  - **Digital Tasbih** - Electronic prayer beads with 7 dhikr types
  - **Prayer Times** - Prayer times for 7 cities with Qibla direction
  - **Islamic Holidays** - Holiday calendar with countdown timers
  - **Adhkar System** - Morning, evening, sleep, and custom remembrance
  - **Quran Reader** - Surah reading with search and daily verses

## 🚀 Installation & Setup

### Requirements
- Node.js v16.9.0 or higher
- PostgreSQL 12 or higher
- Discord Developer Account

### Quick Setup

1. **Clone the repository**
```bash
git clone <repository-url>
cd carolineBot
```

2. **Install dependencies**
```bash
npm install
```

3. **Setup PostgreSQL Database**
```bash
# Create database
createdb probot

# Or using psql
psql -U postgres
CREATE DATABASE probot;
\q
```

4. **Configure environment variables**
Copy `.env.example` to `.env` and fill in your values:
```env
BOT_TOKEN=your_bot_token_here
DATABASE_URL=postgresql://username:password@localhost:5432/probot
CLIENT_ID=your_client_id_here
GUILD_ID=your_guild_id_here
```

5. **Deploy commands**
```bash
node deploy-commands.js
```

6. **Start the bot**
```bash
npm start
```

## 🔧 Configuration

### Database Setup
The bot automatically creates all required tables on first run. The database schema includes:

- `guilds` - Server configurations and settings
- `users` - User data, levels, and statistics  
- `economy` - Economy system with balance and transactions
- `giveaways` - Giveaway data with participants and winners
- `tickets` - Support ticket system
- `reaction_roles` - Reaction role configurations

### Initial Bot Setup

After inviting the bot to your server:

```bash
# Setup welcome system
/setup welcome channel:#welcome message:Welcome {user} to {server}!

# Setup logging
/setup logs channel:#logs webhook:your_webhook_url

# Setup leveling
/setup levels channel:#level-ups

# Setup protection
/setup protection anti_spam:true anti_link:true

# Setup economy
/economy setup starting_balance:1000

# Create giveaway
/giveaway start duration:1h prize:Discord Nitro winners:1
```

## 📊 Command Categories

### 🎮 Entertainment (15+ commands)
- `/calculator` - Scientific calculator with interactive buttons
- `/confess` - Anonymous confession system
- `/counting` - Counting game setup and management
- `/gamble` - Multiple gambling games
- `/image` - Advanced image processing
- `/music play` - Music player with queue

### 🕊️ Islamic Features (5 commands)
- `/adhkar` - Islamic remembrance (morning, evening, sleep, custom)
- `/prayer-times` - Prayer times for 7 cities with Qibla direction
- `/islamic-holidays` - Islamic holidays calendar with countdown
- `/tasbih` - Digital prayer beads with 7 dhikr types and statistics
- `/quran` - Quran reader with search and daily verses

### 🛡️ Moderation (20+ commands)
- `/ban`, `/kick`, `/mute` - Basic moderation
- `/filter` - Content filtering system
- `/automod` - Automated moderation setup
- `/ticket` - Support ticket system
- `/warn` - Warning system

### 💰 Economy (12+ commands)
- `/balance`, `/daily`, `/work` - Basic economy
- `/shop`, `/buy`, `/inventory` - Shopping system
- `/transfer`, `/leaderboard` - Advanced features

### 🎉 Events & Giveaways (8+ commands)
- `/giveaway` - Complete giveaway system
- `/reaction-roles` - Reaction role setup
- `/application` - Staff applications

### ⚙️ Administration (25+ commands)
- `/setup` - Complete server setup
- `/config` - Configuration management
- `/logs` - Logging system
- `/backup` - Data backup and restore

## 🔄 Migration from v2.0

If upgrading from MongoDB version:

1. **Backup your data first**
2. **Run migration script**
```bash
node migrate.js
```
3. **Update environment variables**
4. **Redeploy commands**

## 📁 Project Structure

```
carolineBot/
├── commands/           # Slash commands organized by category
│   ├── admin/         # Administration commands
│   ├── economy/       # Economy system commands
│   ├── entertainment/ # Fun and games
│   ├── general/       # General purpose commands
│   ├── giveaway/      # Giveaway system
│   ├── islamic/       # Islamic features (5 commands)
│   ├── moderation/    # Moderation tools
│   ├── music/         # Music player
│   └── utility/       # Utility commands
├── events/            # Event handlers
│   ├── interactionCreate.js
│   ├── messageCreate.js
│   ├── giveawayHandler.js
│   └── ...
├── database/          # PostgreSQL setup
│   ├── connection.js
│   └── init.js
├── models/            # Legacy MongoDB models (for migration)
├── utils/             # Utility functions
├── index.js           # Main bot file
├── deploy-commands.js # Command deployment
└── package.json       # Dependencies
```

## 🎯 Key Features Explained

### 🕊️ Islamic System
- Complete Islamic features package with 5 comprehensive commands
- Digital Tasbih with 7 dhikr types, achievements, and leaderboards
- Prayer times for 7 major cities with Qibla direction
- Islamic holidays calendar with countdown and notifications
- Comprehensive Adhkar system (morning, evening, sleep, custom)
- Quran reader with search functionality and daily verses
- PostgreSQL integration for statistics and user progress
- Interactive buttons and real-time updates

### 🎮 Giveaway System
- Multiple requirements (role, level, invites)
- Automatic winner selection
- Reroll functionality
- Webhook notifications
- Statistics tracking

### Economy System
- PostgreSQL-based for reliability
- Transaction logging
- Anti-cheat measures
- Gambling games with house edge
- Inventory management

### Leveling System
- XP gain from messages and voice
- Customizable level-up messages
- Role rewards at specific levels
- Leaderboards and statistics

### Protection System
- Anti-spam with configurable limits
- Link filtering with whitelist
- Auto-moderation with actions
- Raid protection

## 🔧 Advanced Configuration

### Webhook Integration
All major systems support webhook notifications:
```javascript
// Example webhook setup
/setup webhook url:https://discord.com/api/webhooks/...
```

### Custom Prefixes
While the bot uses slash commands, legacy prefix commands are supported:
```javascript
// Set custom prefix
/config prefix !
```

### Role Management
Automatic role assignment based on:
- User level
- Economy balance
- Server activity
- Custom triggers

## 📈 Performance & Scaling

- **Database**: PostgreSQL for reliability and performance
- **Caching**: Discord.js built-in caching
- **Rate Limiting**: Automatic rate limit handling
- **Error Handling**: Comprehensive error logging
- **Memory Management**: Efficient memory usage

## 🛠️ Development

### Adding New Commands
1. Create command file in appropriate category
2. Follow the command template structure
3. Add to deploy-commands.js if needed
4. Test thoroughly

### Database Queries
Use the connection pool for all database operations:
```javascript
const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Example query
const result = await pool.query('SELECT * FROM users WHERE user_id = $1', [userId]);
```

### Event Handlers
Create event handlers in the `events/` directory following the pattern:
```javascript
module.exports = {
    name: 'eventName',
    async execute(interaction) {
        // Handle event
    }
};
```

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Check DATABASE_URL in .env
   - Ensure PostgreSQL is running
   - Verify database exists

2. **Commands Not Appearing**
   - Run `node deploy-commands.js`
   - Check bot permissions
   - Verify CLIENT_ID is correct

3. **Bot Not Responding**
   - Check bot token
   - Verify intents are enabled
   - Check console for errors

### Debug Mode
Enable debug logging:
```env
LOG_LEVEL=debug
```

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📞 Support

- **GitHub Issues**: Report bugs and request features
- **Discord**: Join our support server
- **Documentation**: Check the wiki for detailed guides

## 🏆 Credits

**Developed by Mikel99Hitman**

Special thanks to:
- Discord.js community
- PostgreSQL team
- All contributors and testers

---

**Caroline Bot v3.0** - The most comprehensive Discord bot for your server needs.

*Last updated: December 2024*