# ProBot by Mikel - Professional Discord Bot

A professional Discord bot with advanced features for server management.

## 🌟 Features

### 🎯 Core Systems
- **Leveling & XP System** - Track member activity and award levels
- **Welcome System** - Automatic welcome with custom images
- **Comprehensive Logging** - Log all server events with webhook support
- **Protection System** - Anti-spam, anti-link, anti-caps, anti-mention
- **Music System** - Play music from YouTube
- **Ticket System** - Create support tickets for members
- **Application System** - Staff application forms
- **Invite Tracking** - Track member invites
- **Economy System** - Virtual currency with work, daily rewards, gambling
- **Reaction Roles** - Assign roles via reactions
- **Giveaway System** - Host giveaways with requirements
- **Auto Moderation** - Advanced auto-moderation features

## 🚀 Installation & Setup

### Requirements
- Node.js v16.9.0 or higher
- PostgreSQL 12 or higher
- Discord Developer Account

### Installation Steps

1. **Clone the project**
```bash
git clone <repository-url>
cd SQDF
```

2. **Install dependencies**
```bash
npm install
```

3. **Setup PostgreSQL Database**
```bash
# Install PostgreSQL (Windows)
# Download from: https://www.postgresql.org/download/windows/

# Create database
createdb probot

# Or using psql
psql -U postgres
CREATE DATABASE probot;
\q
```

4. **Setup environment variables**
Edit the `.env` file:
```env
BOT_TOKEN=your_bot_token_here
DATABASE_URL=postgresql://username:password@localhost:5432/probot
CLIENT_ID=your_client_id_here
GUILD_ID=your_guild_id_here
```

5. **Deploy commands**
```bash
node deploy-commands.js
```

6. **Start the bot**
```bash
npm start
```

## 🔄 Migration from MongoDB

If you're migrating from the MongoDB version:

1. **Backup your MongoDB data first**
2. **Install PostgreSQL dependencies**
```bash
npm install pg pg-pool
npm uninstall mongoose
```

3. **Run the migration script**
```bash
node migrate.js
```

4. **Update your .env file** to use `DATABASE_URL` instead of `MONGODB_URI`

## 📊 Database Schema

The bot uses PostgreSQL with the following main tables:
- `guilds` - Server configurations
- `users` - User data and statistics
- `economy` - Economy system data
- `inventory` - User inventory items
- `transactions` - Economy transactions
- `tickets` - Support tickets
- `giveaways` - Giveaway data
- `reaction_roles` - Reaction role configurations

## ⚙️ Initial Setup

After inviting the bot to your server, use these commands for setup:

### Setup Welcome System
```
/setup welcome channel:#welcome-channel message:Welcome {user} to {server}!
```

### Setup Logging System
```
/setup logs channel:#logs-channel
/webhook url:your_webhook_url_here
```

### Setup Leveling System
```
/setup levels channel:#level-up-channel
```

### Setup Protection System
```
/setup protection antispam:true antilink:true
/automod setup anti_spam:true anti_link:true anti_caps:true anti_mention:true
```

## 🗂️ Project Structure

```
SQDF/
├── commands/           # Command files
├── events/            # Event handlers
├── models/            # PostgreSQL models
├── database/          # Database connection and initialization
├── utils/             # Utility functions
├── index.js           # Main bot file
├── migrate.js         # MongoDB to PostgreSQL migration
└── package.json       # Project dependencies
```

## 🔧 Configuration

### PostgreSQL Connection
The bot connects to PostgreSQL using the `DATABASE_URL` environment variable:
```
postgresql://username:password@host:port/database
```

### Environment Variables
- `BOT_TOKEN` - Discord bot token (required)
- `DATABASE_URL` - PostgreSQL connection string (required)
- `CLIENT_ID` - Discord application client ID (required)
- `GUILD_ID` - Test server ID (optional)

## 📝 License

This project is licensed under the MIT License.

## 🤝 Contributing

Contributions are welcome! Please create a Pull Request or open an Issue for suggestions.

## 📞 Support

For support:
- Open an Issue on GitHub
- Contact the developer: Mikel

---

**Developed by Mikel**