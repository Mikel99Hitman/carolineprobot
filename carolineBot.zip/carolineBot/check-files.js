const fs = require('fs');
const path = require('path');

console.log('🔍 Checking Caroline Bot files...\n');

// Check main files
const mainFiles = [
    'index.js',
    'package.json',
    '.env',
    'deploy-commands.js'
];

console.log('📁 Main Files:');
mainFiles.forEach(file => {
    const exists = fs.existsSync(path.join(__dirname, file));
    console.log(`   ${exists ? '✅' : '❌'} ${file}`);
});

// Check directories
const directories = [
    'commands',
    'events', 
    'database',
    'models'
];

console.log('\n📂 Directories:');
directories.forEach(dir => {
    const exists = fs.existsSync(path.join(__dirname, dir));
    console.log(`   ${exists ? '✅' : '❌'} ${dir}/`);
});

// Check command files
console.log('\n🎯 Command Files:');
const commandsPath = path.join(__dirname, 'commands');
if (fs.existsSync(commandsPath)) {
    const commandFolders = fs.readdirSync(commandsPath);
    commandFolders.forEach(folder => {
        const folderPath = path.join(commandsPath, folder);
        if (fs.statSync(folderPath).isDirectory()) {
            const files = fs.readdirSync(folderPath).filter(f => f.endsWith('.js'));
            console.log(`   📁 ${folder}/ (${files.length} files)`);
            files.forEach(file => {
                console.log(`      ✅ ${file}`);
            });
        }
    });
}

// Check event files
console.log('\n⚡ Event Files:');
const eventsPath = path.join(__dirname, 'events');
if (fs.existsSync(eventsPath)) {
    const eventFiles = fs.readdirSync(eventsPath).filter(f => f.endsWith('.js'));
    eventFiles.forEach(file => {
        console.log(`   ✅ ${file}`);
    });
}

// Check database files
console.log('\n🗄️ Database Files:');
const dbPath = path.join(__dirname, 'database');
if (fs.existsSync(dbPath)) {
    const dbFiles = fs.readdirSync(dbPath).filter(f => f.endsWith('.js'));
    dbFiles.forEach(file => {
        console.log(`   ✅ ${file}`);
    });
}

console.log('\n🎉 File check completed!');
console.log('\n💡 Next steps:');
console.log('   1. Fill in your .env file with bot token and database URL');
console.log('   2. Run: npm install');
console.log('   3. Run: node deploy-commands.js');
console.log('   4. Run: npm start');