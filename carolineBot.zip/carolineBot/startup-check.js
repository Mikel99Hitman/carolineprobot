#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

console.log('\x1b[36m%s\x1b[0m', '🚀 Caroline Bot Startup Check');
console.log('\x1b[36m%s\x1b[0m', '================================\n');

let allGood = true;

// Check Node.js version
const nodeVersion = process.version;
const requiredVersion = 'v16.9.0';
console.log(`📦 Node.js Version: ${nodeVersion}`);
if (nodeVersion < requiredVersion) {
    console.log('\x1b[31m%s\x1b[0m', `❌ Node.js ${requiredVersion} or higher required`);
    allGood = false;
} else {
    console.log('\x1b[32m%s\x1b[0m', '✅ Node.js version OK');
}

// Check .env file
console.log('\n🔧 Environment Configuration:');
if (!fs.existsSync('.env')) {
    console.log('\x1b[31m%s\x1b[0m', '❌ .env file not found');
    console.log('💡 Copy .env.example to .env and fill in your values');
    allGood = false;
} else {
    console.log('\x1b[32m%s\x1b[0m', '✅ .env file exists');
    
    // Check required environment variables
    try {
        require('dotenv').config();
        const requiredVars = ['BOT_TOKEN', 'DATABASE_URL', 'CLIENT_ID'];
        requiredVars.forEach(varName => {
            if (!process.env[varName]) {
                console.log('\x1b[31m%s\x1b[0m', `❌ Missing ${varName} in .env`);
                allGood = false;
            } else {
                console.log('\x1b[32m%s\x1b[0m', `✅ ${varName} configured`);
            }
        });
    } catch (error) {
        console.log('\x1b[33m%s\x1b[0m', '⚠️ dotenv not installed - run npm install first');
    }
}

// Check package.json and dependencies
console.log('\n📦 Dependencies:');
if (!fs.existsSync('package.json')) {
    console.log('\x1b[31m%s\x1b[0m', '❌ package.json not found');
    allGood = false;
} else {
    console.log('\x1b[32m%s\x1b[0m', '✅ package.json exists');
    
    if (!fs.existsSync('node_modules')) {
        console.log('\x1b[31m%s\x1b[0m', '❌ node_modules not found');
        console.log('💡 Run: npm install');
        allGood = false;
    } else {
        console.log('\x1b[32m%s\x1b[0m', '✅ Dependencies installed');
    }
}

// Check main files
console.log('\n📁 Core Files:');
const coreFiles = [
    'index.js',
    'deploy-commands.js',
    'database/connection.js',
    'database/init.js'
];

coreFiles.forEach(file => {
    if (fs.existsSync(file)) {
        console.log('\x1b[32m%s\x1b[0m', `✅ ${file}`);
    } else {
        console.log('\x1b[31m%s\x1b[0m', `❌ ${file} missing`);
        allGood = false;
    }
});

// Check command structure
console.log('\n🎯 Commands:');
const commandsPath = 'commands';
if (!fs.existsSync(commandsPath)) {
    console.log('\x1b[31m%s\x1b[0m', '❌ Commands directory missing');
    allGood = false;
} else {
    const commandFolders = fs.readdirSync(commandsPath);
    let totalCommands = 0;
    
    commandFolders.forEach(folder => {
        const folderPath = path.join(commandsPath, folder);
        if (fs.statSync(folderPath).isDirectory()) {
            const files = fs.readdirSync(folderPath).filter(f => f.endsWith('.js'));
            totalCommands += files.length;
            console.log(`   📁 ${folder}: ${files.length} commands`);
        }
    });
    
    console.log('\x1b[32m%s\x1b[0m', `✅ Total commands: ${totalCommands}`);
}

// Check events
console.log('\n⚡ Events:');
const eventsPath = 'events';
if (!fs.existsSync(eventsPath)) {
    console.log('\x1b[31m%s\x1b[0m', '❌ Events directory missing');
    allGood = false;
} else {
    const eventFiles = fs.readdirSync(eventsPath).filter(f => f.endsWith('.js'));
    console.log('\x1b[32m%s\x1b[0m', `✅ ${eventFiles.length} event handlers`);
}

// Database connection test
console.log('\n🗄️ Database:');
if (process.env.DATABASE_URL) {
    console.log('✅ Database URL configured');
    console.log('💡 Make sure PostgreSQL is running and database exists');
} else {
    console.log('\x1b[31m%s\x1b[0m', '❌ DATABASE_URL not configured');
    allGood = false;
}

// Final status
console.log('\n' + '='.repeat(50));
if (allGood) {
    console.log('\x1b[32m%s\x1b[0m', '🎉 All checks passed! Bot is ready to start.');
    console.log('\n📋 Next steps:');
    console.log('   1. node deploy-commands.js  (Deploy slash commands)');
    console.log('   2. npm start                (Start the bot)');
} else {
    console.log('\x1b[31m%s\x1b[0m', '❌ Some issues found. Please fix them before starting.');
}

console.log('\n💡 Need help? Check README.md for detailed setup instructions.');
console.log('🔗 GitHub: https://github.com/your-repo/caroline-bot');

process.exit(allGood ? 0 : 1);